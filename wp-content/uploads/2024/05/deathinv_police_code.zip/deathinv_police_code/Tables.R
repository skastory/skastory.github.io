########################################################################
##  Code for: Strategic Bureaucratic Opacity: Evidence from Death 
##            Investigation Laws and Police Killings   
##            Authors: E. Celislami, S. Kastoryano, G. Mastrobuoni 
##                                                                    
##  Code Author: Stephen Kastoryano                                   
##  Date  : 20 May 2024                                                      
##                                                                    
##  Purpose: Producing results tables                
##                                                                    
##  Code input: DF_analysis.Rda from DataPrep.R; adj1.Rda; adj2.Rda
##              
##              
##  Code output: Results and summary statistics tables                                             
##                                                                    
########################################################################

##### Dependencies and session info
# 
# version 4.3.1 (2023-06-16 ucrt)
# Platform: x86_64-w64-mingw32/x64 (64-bit)
# Running under: Windows 11 x64 (build 22631)
# 
# attached base packages:
# stats     graphics  grDevices utils     datasets  methods   base     
# 
# other attached packages:
# usmap_0.6.2         missForest_1.5      pastecs_1.3.21      lubridate_1.9.2     forcats_1.0.0       stringr_1.5.0      
# purrr_1.0.1         readr_2.1.4         tidyr_1.3.0         tibble_3.2.1        ggplot2_3.4.2       tidyverse_2.0.0    
# fixest_0.11.1       clusterSEs_2.6.5    plm_2.6-3           Formula_1.2-5       AER_1.2-10          survival_3.5-5     
# car_3.1-2           carData_3.0-5       clubSandwich_0.5.10 sandwich_3.0-2      lmtest_0.9-40       zoo_1.8-12         
# reshape2_1.4.4      dplyr_1.1.2         foreign_0.8-84     
# 
# loaded via a namespace (and not attached):
# gtable_0.3.3         collapse_1.9.6       lattice_0.21-8       tzdb_0.4.0           numDeriv_2016.8-1.1  vctrs_0.6.3         
# tools_4.3.1          Rdpack_2.4           generics_0.1.3       parallel_4.3.1       fansi_1.0.4          pkgconfig_2.0.3     
# dfidx_0.0-5          Matrix_1.6-0         rngtools_1.5.2       lifecycle_1.0.3      compiler_4.3.1       maxLik_1.5-2        
# statmod_1.5.0        munsell_0.5.0        codetools_0.2-19     pillar_1.9.0         MASS_7.3-60          doRNG_1.8.6         
# iterators_1.0.14     foreach_1.5.2        boot_1.3-28.1        abind_1.4-5          nlme_3.1-162         tidyselect_1.2.0    
# bdsmatrix_1.3-6      digest_0.6.33        stringi_1.7.12       splines_4.3.1        miscTools_0.6-28     grid_4.3.1          
# colorspace_2.1-0     cli_3.6.1            lfe_2.9-0            magrittr_2.0.3       randomForest_4.7-1.1 utf8_1.2.3          
# withr_2.5.0          dreamerr_1.2.3       scales_1.2.1         timechange_0.2.0     mlogit_1.1-1         hms_1.1.3           
# rbibutils_2.2.13     itertools_0.1-3      rlang_1.1.1          Rcpp_1.0.11          xtable_1.8-4         glue_1.6.2          
# rstudioapi_0.15.0    R6_2.5.1  

### 1 LOAD PACKAGES AND DATA ###

# Dependencies listed 
rm(list=ls())
library("foreign")
library("dplyr")
library("reshape2")
library(lmtest)
library(sandwich)
library("clubSandwich")
library("clusterSEs")
library("fixest")
library(tidyverse)
library(pastecs)
library("missForest")
library("ggplot2")
library(plm)
library(usmap)







setwd("...")


load("DF_analysis.Rda") # load main dataset
load("adj1.Rda") # load 1st degree county adjacency dataset
load("adj2.Rda") # load 2nd degree county adjacency dataset

### 2 FUNCTIONS ### 


FE_fun <- function (DFfe , Treat, adj){  # This function generates the fixed effects dataset
  
  # 1. Select control sample
  # Select treated in relevant sample
  df <- DFfe
  df <- df[(Treat == 1), c("CountyCode", "Year")]
  df <- df[order(df$CountyCode, df$Year), ]
  
  # Select non-treated in relevant sample and append to adjacent treated units, then add the weight corresponding to 1/(nbr times they appear in dataset)
  df1 = DFfe
  df1 <- df1[(Treat == 0), ]
  df1 <- df1[order(df1$CountyCode, df1$Year), ]
  df2 <- df1 %>%  left_join(adj, c("CountyCode", "Year")) # generate a new row for each county (indexed by CountyCode_) adjacent to one of selected non-treated counties (index CountyCode)
  df2 = df2[(df2$CountyCode != df2$CountyCode_),]  # drop rows of self adjacency
  colnames(df2)[which(colnames(df2)=="CountyCode")] <- "CountyCode_old"
  colnames(df2)[which(colnames(df2)=="CountyCode_")] <- "CountyCode"  # index CountyCode is now the adjacent counties to the selected non-treated counties
  df2 <- df2[order(df2$CountyCode, df2$Year,df2$CountyCode_old), ]
  df2 <- merge(df2,df,  by = c("CountyCode", "Year"),  all.y =   TRUE)  # Merge all control counties (indexed by CountyCode_old) associated to an adjacent treated county (indexed by CountyCode)
  df2 = df2[!is.na(df2$State),]
  df2 <- df2[order(df2$CountyCode_old, df2$Year,df2$CountyCode), ]  # Note that CountyCode_old is the actual index of the county and CountyCode is the index of the FE
  # generate weight as a new column
  df2 <- df2 %>%
    group_by(CountyCode_old, Year) %>%
    mutate(weight_var = 1/n())
  
  
  # 2.  Select treated observations and add a weight of 1 to each of them
  df <- DFfe
  df <- df[ (Treat == 1),]
  df <- df[order(df$CountyCode, df$Year), ]
  df$CountyCode_old=df$CountyCode  # Note that CountyCode_old is the actual index of the county and CountyCode is the index of the FE
  df$weight_var = 1
  df <- df %>% select(CountyCode,Year, CountyCode_old, everything())
  
  # 3.  Bind treated and control rows into single dataset
  # I have no idea why I need to go through this nonsense but the first 3 columns will not bind properly without it
  df$CountyCode_old1 = as.numeric(df$CountyCode_old);  df2$CountyCode_old1 = as.numeric(df2$CountyCode_old)
  df$CountyCode1 = as.numeric(df$CountyCode);  df2$CountyCode1 = as.numeric(df2$CountyCode)
  df$Year1 = as.numeric(df$Year);  df2$Year1 = as.numeric(df2$Year)
  
  df = rbind(df[,4:ncol(df)],df2[,4:ncol(df2)])
  df <- df %>% rename(CountyCode_FE = CountyCode1, Year = Year1, CountyCode = CountyCode_old1)
  df <- df %>% select(CountyCode,Year, CountyCode_FE, everything())
  df <- df[order(df$CountyCode, df$Year, df$CountyCode_FE), ]
  
  
  return(df)
}



PoiSampleTWFE_fn <- function (df,outcome, CC) { # This function removes county clusters which do not change over time (FE Poisson fails in such cases)
  
  
  # Create an empty vector to store the CountyCodes that we want to keep
  df$CC = CC
  unique_CCs <- unique(df$CC)
  CCs_to_keep <- vector()
  df$check = outcome
  
  for (id in unique_CCs) {  # Loop over each unique CC
    id_data <- subset(df, CC == id)  # Subset the data for the current CC
    
    if (length(unique(id_data$check)) != 1) {  # Check if the value of outcome is the same for all years
      CCs_to_keep <- c(CCs_to_keep, id)      # If the value is not the same for all years, add the ID to the ids_to_keep vector
    }
  } 
  # Subset the original dataframe to only include the IDs that we want to keep
  df <-dplyr::select(df, -c('CC', 'check'))
  df =subset(df, (CC %in% CCs_to_keep))
  df <- df[order(df$CountyCode_FE, df$Year, df$CountyCode), ]
  
  # Unfortunately, weights may no longer sum to 1 by County
  grouped_df <- df %>% group_by(Year, CountyCode)   # Group the data by year and county code
  summed_df <- grouped_df %>% summarise(sum_weight_var = sum(weight_var), .groups = "drop") # Calculate the sum of weight_var for each group
  merged_df <- left_join(df, summed_df, by = c("Year", "CountyCode"))   # Join summed_df to the original data frame
  adjusted_df <- merged_df %>% mutate(adjusted_weight_var = weight_var / sum_weight_var)   # Divide weight_var by sum_weight_var to get the adjusted weights
  df$weight_var =  adjusted_df$adjusted_weight_var
  
  return(df)
}





### 3 RESULTS ###




##############################################
#### TABLE 1 ####
##############################################

### Table 1 Column 1: LawEnf effect Poisson, without covariates ###
#####################################################
# Select sample
DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert + DF$ShCoroner >0) 
DFt = DF[(DF$sample_LE_SC1 == 1),]


DFt$diff_kill_pol[(DFt$diff_kill_pol <= 0) ] <- 0  ## Set negative values of misreporting to 0
DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$map_hom^2 + 1))


# FE Poisson estimation, weighted and clustered by county and countyFE
DFt0 = DFt
Pfe = fepois(diff_kill_pol ~ LawEnf_cert1 + kill_tot_tr  |  Year,  data = DFt0)
summary(Pfe, cluster = ~CountyCode)$coeftable
my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,length(unique(DFt$CountyCode*10000+ DFt$Year)))  # Effective sample
a = append(a,sum(DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f",mean(DFt0$diff_kill_pol)))
for (i in a) {  cat(i, "\n")}           
#sprintf("%.3f",median(DFt0$weight_var * DFt0$diff_kill_pol/DFt0$map_hom_tot))



### Table 1 Column 2: LawEnf effect Poisson, with covariates ###
#####################################################
# Select sample
DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert + DF$ShCoroner >0) 
DFt = DF[(DF$sample_LE_SC1 == 1),]


DFt$diff_kill_pol[(DFt$diff_kill_pol <= 0) ] <- 0  ## Set negative values of misreporting to 0
DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))

# FE Poisson estimation, weighted and clustered by county and countyFE
DFt0 = DFt
Pfe = fepois(diff_kill_pol ~ LawEnf_cert1   +  LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP + kill_tot_tr  |  Year,  data = DFt0)
summary(Pfe, cluster = ~CountyCode)$coeftable
my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,length(unique(DFt$CountyCode*10000+ DFt$Year)))  # Effective sample
a = append(a,sum(DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f",mean(DFt0$diff_kill_pol)))
for (i in a) {  cat(i, "\n")}           





### Table 1 Column 3: LawEnf effect Poisson FE, with covariates, cluster FE ###
#####################################################
# Select sample
DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert + DF$ShCoroner >0) 
DFt = DF[(DF$sample_LE_SC1 == 1),]


DFt = FE_fun(DFt, DFt$LawEnf_cert1, adj1 ) # Generate analysis dataset (weights adjusted inside fn)

DFt$diff_kill_pol[(DFt$diff_kill_pol <= 0) ] <- 0  ## Set negative values of misreporting to 0
DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))

# remove singletons for FE estimation
id_counts <- table(DFt$CountyCode_FE); singleton_ids <- names(id_counts[id_counts == 1])
DFt <- DFt[!(DFt$CountyCode_FE %in% singleton_ids), ]


# FE Poisson estimation, weighted and clustered by county and countyFE
DFt0 = PoiSampleTWFE_fn(DFt,DFt$diff_kill_pol,DFt$CountyCode_FE)
Pfe = fepois(diff_kill_pol ~ LawEnf_cert1  + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP + kill_tot_tr  | CountyCode_FE + Year, weights = DFt0$weight_var,  data = DFt0)
summary(Pfe, cluster = ~CountyCode)$coeftable
my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,sum(DFt0$weight_var))  # Effective sample
a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f",sum(DFt0$weight_var * DFt0$diff_kill_pol)/sum(DFt0$weight_var)))
for (i in a) {  cat(i, "\n")}  


# for change in underreported killings interpretation in text
point_coeff = exp(summary(Pfe, cluster = ~CountyCode)$coeftable[1,1])-1
point_coeff*as.numeric(a[5])



### Table 1 Column 4: LawEnf effect linear FE, with covariates ###
#####################################################
# Select sample
DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert + DF$ShCoroner >0) 
DFt = DF[(DF$sample_LE_SC1 == 1),]

DFt = FE_fun(DFt, DFt$LawEnf_cert1, adj1 ) # Generate analysis dataset (weights adjusted inside fn)
DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))

DFt$diff_kill_pol[(DFt$diff_kill_pol <= 0) ] <- 0  ## Set negative values of misreporting to 0


# remove singletons for FE estimation
id_counts <- table(DFt$CountyCode_FE); singleton_ids <- names(id_counts[id_counts == 1])
DFt <- DFt[!(DFt$CountyCode_FE %in% singleton_ids), ]


# FE linear panel estimation, weighted and clustered by county and countyFE

sX=c("LfrinMetro","MMetro","Microp","Noncore","SMetro","log_Population","Fem_perc","Black_perc","WHisp_perc","Other_perc", "perc_votes.DEM", "perc_votes.OTHER", "log_GDP","kill_tot_tr","Y2014","Y2015","Y2016","Y2017","Y2018","Y2019")
sTreat <- "LawEnf_cert1"
streatX = c(sTreat,sX)
DFt0 =DFt
Lfe <- plm(as.formula(paste("diff_kill_pol ~ ", paste(streatX, collapse= "+")))  ,  weights = weight_var, data = DFt0, index=c("CountyCode_FE") , model = "within")
coef_test(Lfe, vcov = "CR1", cluster = "individual", test = "naive-t")
my_v = as.numeric(sprintf("%.3f",coef_test(Lfe, vcov = "CR1", cluster = "individual", test = "naive-t")[1,2:6]))
my_v =  my_v[-3];my_v =  my_v[-3]
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,sum(DFt0$weight_var))  # Effective sample
a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f",sum(DFt0$weight_var * DFt0$diff_kill_pol)/sum(DFt0$weight_var)))
for (i in a) {  cat(i, "\n")}  






### Table 1 Column 5: LawEnf effect Poisson FE, with covariates sheriff-coroner ###
#####################################################
# Select sample
DF$LawEnf_cert1 =  DF$ShCoroner    # Define variable of interest as 1 if Sheriff-Coroner, 0 otherwise
DFt = DF[(DF$sample_SC_noLE1  ==1),]


DFt = FE_fun(DFt, DFt$LawEnf_cert1, adj1 ) # Generate analysis dataset (weights adjusted inside fn)

DFt$diff_kill_pol[(DFt$diff_kill_pol <= 0) ] <- 0  ## Set negative values of misreporting to 0
DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))

# remove singletons for FE estimation
id_counts <- table(DFt$CountyCode_FE); singleton_ids <- names(id_counts[id_counts == 1])
DFt <- DFt[!(DFt$CountyCode_FE %in% singleton_ids), ]


# FE Poisson estimation, weighted and clustered by county and countyFE
DFt0 = PoiSampleTWFE_fn(DFt,DFt$diff_kill_pol,DFt$CountyCode_FE)
Pfe = fepois(diff_kill_pol ~ LawEnf_cert1  + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP  + kill_tot_tr | CountyCode_FE + Year,  weights = DFt0$weight_var,  data = DFt0)
my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,sum(DFt0$weight_var))  # Effective sample
a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f",sum(DFt0$weight_var * DFt0$diff_kill_pol)/sum(DFt0$weight_var)))
for (i in a) {  cat(i, "\n")}   




### Table 1 Column 6: LawEnf effect Poisson FE, with covariates non-sheriff only ###
#####################################################
# Select sample
DF$LawEnf_cert1 =  DF$LawEnf_cert * (1-DF$ShCoroner) 
DFt = DF[(DF$sample_LE_noSC1  ==1),]


## Code snippet to obtain number of overlapping CountyCode values mentioned in text
DFt1 = DF[(DF$sample_SC_noLE1  ==1),]
DFt2 = DF[(DF$sample_LE_noSC1  ==1),]

common_county_codes <- intersect(unique(DFt1$CountyCode), unique(DFt2$CountyCode))
length(common_county_codes)
length(common_county_codes)/ length(unique(c(DFt1$CountyCode,DFt2$CountyCode)))
##

DFt = FE_fun(DFt, DFt$LawEnf_cert1, adj1 ) # Generate analysis dataset (weights adjusted inside fn)

DFt$diff_kill_pol[(DFt$diff_kill_pol <= 0) ] <- 0  ## Set negative values of misreporting to 0
DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))

# remove singletons for FE estimation
id_counts <- table(DFt$CountyCode_FE); singleton_ids <- names(id_counts[id_counts == 1])
DFt <- DFt[!(DFt$CountyCode_FE %in% singleton_ids), ]


# FE Poisson estimation, weighted and clustered by county and countyFE
DFt0 = PoiSampleTWFE_fn(DFt,DFt$diff_kill_pol,DFt$CountyCode_FE)
Pfe = fepois(diff_kill_pol ~ LawEnf_cert1   + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP  + kill_tot_tr | CountyCode_FE + Year,  weights = DFt0$weight_var,  data = DFt0)
my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,sum(DFt0$weight_var))  # Effective sample
a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f",sum(DFt0$weight_var * DFt0$diff_kill_pol)/sum(DFt0$weight_var)))
for (i in a) {  cat(i, "\n")}   





### BALANCE TABLE ###
#####################################################
# The balancing Figures were made in STATA, this is just a quick replication of approach

# Select sample
DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert + DF$ShCoroner >0) 
DFt = DF[(DF$sample_LE_SC1 == 1),]

DFt = FE_fun(DFt, DFt$LawEnf_cert1, adj1 ) # Generate analysis dataset (weights adjusted inside fn)
DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))

DFt$diff_kill_pol[(DFt$diff_kill_pol <= 0) ] <- 0  ## Set negative values of misreporting to 0


# remove singletons for FE estimation
id_counts <- table(DFt$CountyCode_FE); singleton_ids <- names(id_counts[id_counts == 1])
DFt0 <- DFt[!(DFt$CountyCode_FE %in% singleton_ids), ]


# Create an empty dataframe to store results
results <- data.frame(variable = character(), 
                      estimate = numeric(), 
                      ci_lower = numeric(), 
                      ci_upper = numeric(), 
                      stringsAsFactors = FALSE)

variables <- c("diff_kill_pol", "hom_tot", "participated", "nibrs_participated_naN",  "LfrinMetro", "MMetro", "Microp", "Noncore", "SMetro", 
               "log_Population", "Fem_perc", "WnonHisp_perc", "Black_perc", "WHisp_perc", "Other_perc", 
               "perc_votes.DEM", "perc_votes.REP", "log_GDP", "kill_tot_tr")

# Iterate through each variable and perform normalization
for (var in variables) {
  # Compute normalized variable
  normalized_var <- (DFt0[[var]] - mean(DFt0[[var]])) / sd(DFt0[[var]])
  # Assign normalized variable to DataFrame
  DFt0[[paste0(var, "_n")]] <- normalized_var
}

# List of variables to estimate
variables_n <- paste0(variables, "_n")

# Loop through each variable
for (var in variables_n) {
  
  streatX = c(var )
  # Estimate the model
  Lfe <- plm(as.formula(paste("LawEnf_cert1 ~ ", paste(streatX, collapse= "+"))) , weights = weight_var, 
             data = DFt0, index = "CountyCode_FE", model = "within")
  
  # Perform coefficient test
  coef_test_result <- coef_test(Lfe, vcov = "CR1", cluster = "individual", test = "naive-t")
  
  # Extract point estimate and confidence intervals
  estimate <- coef_test_result[1,2]
  ci_lower <- estimate - 1.96*coef_test_result[1,3]
  ci_upper <- estimate + 1.96*coef_test_result[1,3]
  
  # Add results to the dataframe
  results <- rbind(results, data.frame(variable = var, 
                                       estimate = estimate, 
                                       ci_lower = ci_lower, 
                                       ci_upper = ci_upper))
}

# Print the results
print(results)






##############################################
#### TABLE 1 Appendix ####
##############################################





### Table 1app Column 1: LawEnf effect Poisson FE, with state FEs ###
#####################################################
# Select sample
DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert + DF$ShCoroner >0) 
DFt = DF[(DF$sample_LE_SC1 == 1),]


DFt = FE_fun(DFt, DFt$LawEnf_cert1, adj1 ) # Generate analysis dataset (weights adjusted inside fn)

DFt$diff_kill_pol[(DFt$diff_kill_pol <= 0) ] <- 0  ## Set negative values of misreporting to 0
DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))

# remove singletons for FE estimation
id_counts <- table(DFt$CountyCode_FE); singleton_ids <- names(id_counts[id_counts == 1])
DFt <- DFt[!(DFt$CountyCode_FE %in% singleton_ids), ]


# FE Poisson estimation, weighted and clustered by county and countyFE
DFt0 = PoiSampleTWFE_fn(DFt,DFt$diff_kill_pol,DFt$CountyCode_FE)

# Filter states where there is only one unique value of LawEnf_cert1
state_summary <- aggregate(LawEnf_cert1 ~ State, data = DFt0, FUN = function(x) length(unique(x)))
states_with_same_value <- state_summary$State[state_summary$LawEnf_cert1 == 1]
DFt0 = DFt0[!(DFt0$State %in% states_with_same_value),] # remove all states that don't have variation in LawEnf_cert1

Pfe = fepois(diff_kill_pol ~ LawEnf_cert1 + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP  + kill_tot_tr | CountyCode_FE + Year + State,  weights = DFt0$weight_var,  data = DFt0)
my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,sum(DFt0$weight_var))  # Effective sample
a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f",sum(DFt0$weight_var * DFt0$diff_kill_pol)/sum(DFt0$weight_var)))
for (i in a) {  cat(i, "\n")}  



### Table 1app Column 2: LawEnf effect Poisson FE, with only bordering state counties ###
#####################################################
# Select sample
DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert + DF$ShCoroner >0) 
DF <- DF %>%
  mutate(State_nr = as.numeric(factor(State)))

DFt = DF[(DF$sample_LE_SC1 == 1),]

DFt = FE_fun(DFt, DFt$LawEnf_cert1, adj1 ) # Generate analysis dataset (weights adjusted inside fn)


DFtn = DF[,c("CountyCode", "Year", "State_nr")]
DFtn$State_FE_nr = DFtn$State_nr
DFtn$CountyCode_FE = DFtn$CountyCode
DFtn = DFtn[,c("CountyCode_FE", "Year","State_FE_nr")]

DFt <- merge(DFt, DFtn, by=c("CountyCode_FE","Year"), all.x=T)

DFt <- DFt %>%
  group_by(CountyCode_FE) %>%
  mutate(Mean_State_FE_nr = mean(State_nr)) %>%
  ungroup()

DFt= DFt[!(DFt$State_FE_nr == DFt$Mean_State_FE_nr),]


DFt$diff_kill_pol[(DFt$diff_kill_pol <= 0) ] <- 0  ## Set negative values of misreporting to 0
DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))

# remove singletons for FE estimation
id_counts <- table(DFt$CountyCode_FE); singleton_ids <- names(id_counts[id_counts == 1])
DFt <- DFt[!(DFt$CountyCode_FE %in% singleton_ids), ]


# FE Poisson estimation, weighted and clustered by county and countyFE
DFt0 = PoiSampleTWFE_fn(DFt,DFt$diff_kill_pol,DFt$CountyCode_FE)
Pfe = fepois(diff_kill_pol ~ LawEnf_cert1  + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP + kill_tot_tr  | CountyCode_FE + Year, weights = DFt0$weight_var,  data = DFt0)
summary(Pfe, cluster = ~CountyCode)$coeftable
my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,sum(DFt0$weight_var))  # Effective sample
a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f",sum(DFt0$weight_var * DFt0$diff_kill_pol)/sum(DFt0$weight_var)))
for (i in a) {  cat(i, "\n")}  




### Table 1app Column 3: LawEnf effect Poisson FE, adjacency matched urbanisation ###
#####################################################
# Select sample
DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert + DF$ShCoroner >0) 
DFt = DF[(DF$sample_LE_SC1_urb == 1),]


DFt = FE_fun(DFt, DFt$LawEnf_cert1, adj1 ) # Generate analysis dataset (weights adjusted inside fn)

DFt$diff_kill_pol[(DFt$diff_kill_pol <= 0) ] <- 0  ## Set negative values of misreporting to 0
DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))

# remove singletons for FE estimation
id_counts <- table(DFt$CountyCode_FE); singleton_ids <- names(id_counts[id_counts == 1])
DFt <- DFt[!(DFt$CountyCode_FE %in% singleton_ids), ]


# FE Poisson estimation, weighted and clustered by county and countyFE
DFt0 = PoiSampleTWFE_fn(DFt,DFt$diff_kill_pol,DFt$CountyCode_FE)
Pfe = fepois(diff_kill_pol ~ LawEnf_cert1 + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP + kill_tot_tr  | CountyCode_FE + Year, weights = DFt0$weight_var,  data = DFt0)
my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,sum(DFt0$weight_var))  # Effective sample
a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f",sum(DFt0$weight_var * DFt0$diff_kill_pol)/sum(DFt0$weight_var)))
for (i in a) {  cat(i, "\n")}  



### Table 1app Column 4: LawEnf effect Poisson FE, with covariates sheriff-coroner and tribal AZ-NM (ignoring other LEnf certifying from Ruiz paper) ###
#####################################################
# Select sample
DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert_n + DF$ShCoroner >0)  # Define variable of interest as 1 if law enforcement can certify or sheriff coroner county !! This should be our favoured specification
DFt = DF[(DF$sample_LE_SCn1  ==1),]

DFt = FE_fun(DFt, DFt$LawEnf_cert1, adj1 ) # Generate analysis dataset (weights adjusted inside fn)

DFt$diff_kill_pol[(DFt$diff_kill_pol <= 0) ] <- 0  ## Set negative values of misreporting to 0
DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))

# remove singletons for FE estimation
id_counts <- table(DFt$CountyCode_FE); singleton_ids <- names(id_counts[id_counts == 1])
DFt <- DFt[!(DFt$CountyCode_FE %in% singleton_ids), ]


# FE Poisson estimation, weighted and clustered by county and countyFE
DFt0 = PoiSampleTWFE_fn(DFt,DFt$diff_kill_pol,DFt$CountyCode_FE)
Pfe = fepois(diff_kill_pol ~ LawEnf_cert1  + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP  + kill_tot_tr | CountyCode_FE + Year,  weights = DFt0$weight_var,  data = DFt0)
my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,sum(DFt0$weight_var))  # Effective sample
a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f",sum(DFt0$weight_var * DFt0$diff_kill_pol)/sum(DFt0$weight_var)))
for (i in a) {  cat(i, "\n")}   






### Table 1app Column 5: LawEnf effect Poisson FE, with covariates, cluster FE, 
#                     condition on positive homicides counties ###
#####################################################
# Select sample
DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert + DF$ShCoroner >0) 
DFt = DF[(DF$sample_LE_SC1 == 1),]

DFt = DFt[(DFt$hom_tot >0),]  # only keep counties with observed homicides


DFt = FE_fun(DFt, DFt$LawEnf_cert1, adj1 ) # Generate analysis dataset (weights adjusted inside fn)

DFt$diff_kill_pol[(DFt$diff_kill_pol <= 0) ] <- 0  ## Set negative values of misreporting to 0
DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))

# remove singletons for FE estimation
id_counts <- table(DFt$CountyCode_FE); singleton_ids <- names(id_counts[id_counts == 1])
DFt <- DFt[!(DFt$CountyCode_FE %in% singleton_ids), ]


# FE Poisson estimation, weighted and clustered by county and countyFE
DFt0 = PoiSampleTWFE_fn(DFt,DFt$diff_kill_pol,DFt$CountyCode_FE)
Pfe = fepois(diff_kill_pol ~ LawEnf_cert1  + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP + kill_tot_tr  | CountyCode_FE + Year, weights = DFt0$weight_var,  data = DFt0)
summary(Pfe, cluster = ~CountyCode)$coeftable
my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,sum(DFt0$weight_var))  # Effective sample
a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f",sum(DFt0$weight_var * DFt0$diff_kill_pol)/sum(DFt0$weight_var)))
for (i in a) {  cat(i, "\n")}  



### Table 1app Column 6: LawEnf effect Poisson FE, with Physician covariate ###
#####################################################
# Select sample
DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert + DF$ShCoroner >0) 
DFt = DF[(DF$sample_LE_SC1 == 1),]


DFt = FE_fun(DFt, DFt$LawEnf_cert1, adj1 ) # Generate analysis dataset (weights adjusted inside fn)

DFt$diff_kill_pol[(DFt$diff_kill_pol <= 0) ] <- 0  ## Set negative values of misreporting to 0
DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))

# remove singletons for FE estimation
id_counts <- table(DFt$CountyCode_FE); singleton_ids <- names(id_counts[id_counts == 1])
DFt <- DFt[!(DFt$CountyCode_FE %in% singleton_ids), ]


# FE Poisson estimation, weighted and clustered by county and countyFE
DFt0 = PoiSampleTWFE_fn(DFt,DFt$diff_kill_pol,DFt$CountyCode_FE)
Pfe = fepois(diff_kill_pol ~ LawEnf_cert1 + Physician  + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP + kill_tot_tr  | CountyCode_FE + Year, weights = DFt0$weight_var,  data = DFt0)
summary(Pfe, cluster = ~CountyCode)$coeftable
my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,sum(DFt0$weight_var))  # Effective sample
a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f",sum(DFt0$weight_var * DFt0$diff_kill_pol)/sum(DFt0$weight_var)))
for (i in a) {  cat(i, "\n")}  






### Table 1app Column 7: LawEnf effect Poisson FE, with covariates no potential bad control total homicides ###
#####################################################
# Select sample
DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert + DF$ShCoroner >0) 
DFt = DF[(DF$sample_LE_SC1 == 1),]

DFt = FE_fun(DFt, DFt$LawEnf_cert1, adj1 ) # Generate analysis dataset (weights adjusted inside fn)

DFt$diff_kill_pol[(DFt$diff_kill_pol <= 0) ] <- 0  ## Set negative values of misreporting to 0

# remove singletons for FE estimation
id_counts <- table(DFt$CountyCode_FE); singleton_ids <- names(id_counts[id_counts == 1])
DFt <- DFt[!(DFt$CountyCode_FE %in% singleton_ids), ]


# FE Poisson estimation, weighted and clustered by county and countyFE
DFt0 = PoiSampleTWFE_fn(DFt,DFt$diff_kill_pol,DFt$CountyCode_FE)
Pfe = fepois(diff_kill_pol ~ LawEnf_cert1 + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP   | CountyCode_FE + Year, weights = DFt0$weight_var,  data = DFt0)
my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,sum(DFt0$weight_var))  # Effective sample
a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f",sum(DFt0$weight_var * DFt0$diff_kill_pol)/sum(DFt0$weight_var)))
for (i in a) {  cat(i, "\n")}  


### Table 1 Column 8: LawEnf effect Poisson FE, with covariates and Right-to-carry covariate ###
#####################################################
# Select sample
DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert + DF$ShCoroner >0) 
DFt = DF[(DF$sample_LE_SC1 == 1),]

# Neither of these alternative specifications of the score affect the results
DFt$RtCscorep = as.numeric(DFt$RtCscore > 6)  # Score B- or higher 
DFt$RtCscoref = DFt$RtCscore/11

DFt = FE_fun(DFt, DFt$LawEnf_cert1, adj1 ) # Generate analysis dataset (weights adjusted inside fn)

DFt$diff_kill_pol[(DFt$diff_kill_pol <= 0) ] <- 0  ## Set negative values of misreporting to 0
DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))

# remove singletons for FE estimation
id_counts <- table(DFt$CountyCode_FE); singleton_ids <- names(id_counts[id_counts == 1])
DFt <- DFt[!(DFt$CountyCode_FE %in% singleton_ids), ]


# FE Poisson estimation, weighted and clustered by county and countyFE
DFt0 = PoiSampleTWFE_fn(DFt,DFt$diff_kill_pol,DFt$CountyCode_FE)
Pfe = fepois(diff_kill_pol ~ LawEnf_cert1 + RtCscore + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP + kill_tot_tr  | CountyCode_FE + Year, weights = DFt0$weight_var,  data = DFt0)
my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,sum(DFt0$weight_var))  # Effective sample
a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f",sum(DFt0$weight_var * DFt0$diff_kill_pol)/sum(DFt0$weight_var)))
for (i in a) {  cat(i, "\n")}  


### Table 1app Column 9: LawEnf effect Poisson FE, with covariates: removing off-duty killings ###
#####################################################
# Select sample
DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert + DF$ShCoroner >0) 
DFt = DF[(DF$sample_LE_SC1 == 1),]

DFt = FE_fun(DFt, DFt$LawEnf_cert1, adj1 ) # Generate analysis dataset (weights adjusted inside fn)

DFt$diff_kill_pol_offd[(DFt$diff_kill_pol_offd <= 0) ] <- 0  ## Set negative values of misreporting to 0
DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))

DFt$diff_kill_pol[(DFt$diff_kill_pol <= 0) ] <- 0  ## Set negative values of misreporting to 0

sum(DFt$mpv_off_duty_kill)/sum(DFt$mpv_kill_pol)

# remove singletons for FE estimation
id_counts <- table(DFt$CountyCode_FE); singleton_ids <- names(id_counts[id_counts == 1])
DFt <- DFt[!(DFt$CountyCode_FE %in% singleton_ids), ]


# FE Poisson estimation, weighted and clustered by county and countyFE
DFt0 = PoiSampleTWFE_fn(DFt,DFt$diff_kill_pol_offd,DFt$CountyCode_FE)
Pfe = fepois(diff_kill_pol_offd ~ LawEnf_cert1 + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP + kill_tot_tr  | CountyCode_FE + Year, weights = DFt0$weight_var,  data = DFt0)
my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,sum(DFt0$weight_var))  # Effective sample
a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f",sum(DFt0$weight_var * DFt0$diff_kill_pol_offd)/sum(DFt0$weight_var)))
for (i in a) {  cat(i, "\n")}  


### Table 1app Column 10: LawEnf effect Poisson FE, with covariates: 
###    outcome total difference of MPV by firearm (+ anything) reported vs Official reported   ###
#####################################################

#share of mpv police killings which are by firearm
sum(DF$mpv_gunshot)/sum(DF$mpv_kill_pol)

# Select sample
DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert + DF$ShCoroner >0) 
DFt = DF[(DF$sample_LE_SC1 == 1),]

DFt = FE_fun(DFt, DFt$LawEnf_cert1, adj1 ) # Generate analysis dataset (weights adjusted inside fn)

DFt$diff_kill_pol_gun[(DFt$diff_kill_pol_gun <= 0) ] <- 0  ## Set negative values of misreporting to 0
DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))

# remove singletons for FE estimation
id_counts <- table(DFt$CountyCode_FE); singleton_ids <- names(id_counts[id_counts == 1])
DFt <- DFt[!(DFt$CountyCode_FE %in% singleton_ids), ]


# FE Poisson estimation, weighted and clustered by county and countyFE
DFt0 = PoiSampleTWFE_fn(DFt,DFt$diff_kill_pol_gun,DFt$CountyCode_FE)
Pfe = fepois(diff_kill_pol_gun ~ LawEnf_cert1  + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP + kill_tot_tr  | CountyCode_FE + Year, weights = DFt0$weight_var,  data = DFt0)
my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,sum(DFt0$weight_var))  # Effective sample
a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f",sum(DFt0$weight_var * DFt0$diff_kill_pol_gun)/sum(DFt0$weight_var)))
for (i in a) {  cat(i, "\n")}  



# ### Table 1app Column 7: LawEnf effect Poisson FE, offsetting hom_tot ###
# #####################################################
# # Select sample
# DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert + DF$ShCoroner >0) 
# DFt = DF[(DF$sample_LE_SC1 == 1),]
# 
# DFt = DFt[(DFt$map_hom>0),]  # drop county-year rows with 0 total reported homicides
# DFt$kill_tot_tr = log( DFt$hom_tot)
# 
# DFt = FE_fun(DFt, DFt$LawEnf_cert1, adj1 ) # Generate analysis dataset (weights adjusted inside fn)
# 
# DFt$diff_kill_pol[(DFt$diff_kill_pol <= 0) ] <- 0  ## Set negative values of misreporting to 0
# 
# # remove singletons for FE estimation
# id_counts <- table(DFt$CountyCode_FE); singleton_ids <- names(id_counts[id_counts == 1])
# DFt <- DFt[!(DFt$CountyCode_FE %in% singleton_ids), ]
# 
# 
# # FE Poisson estimation, weighted and clustered by county and countyFE
# DFt0 = PoiSampleTWFE_fn(DFt,DFt$diff_kill_pol,DFt$CountyCode_FE)
# Pfe = fepois(diff_kill_pol ~ LawEnf_cert1 + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
#                log_GDP   | CountyCode_FE + Year, offset = DFt0$kill_tot_tr, weights = DFt0$weight_var,  data = DFt0)
# my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
# my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
# for (i in my_v) {  cat(i, "\n")}
# # Descriptive stats
# a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
# a = append(a,sum(DFt0$weight_var))  # Effective sample
# a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
# a = append(a,length(unique(DFt0$CountyCode)) )
# a = append(a,sprintf("%.3f",sum(DFt0$weight_var * DFt0$diff_kill_pol/DFt0$hom_tot)/sum(DFt0$weight_var)))
# for (i in a) {  cat(i, "\n")}  
# 
# 
# ### Table 1app Column 8: LawEnf effect Poisson FE, offsetting mpv_kill_pol ###
# #####################################################
# # Select sample
# DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert + DF$ShCoroner >0) 
# DFt = DF[(DF$sample_LE_SC1 == 1),]
# 
# DFt = DFt[(DFt$mpv_kill_pol>0),]  # drop county-year rows with 0 total reported homicides
# DFt$kill_tot_tr = log( DFt$mpv_kill_pol)
# DFt = FE_fun(DFt, DFt$LawEnf_cert1, adj1 ) # Generate analysis dataset (weights adjusted inside fn)
# 
# DFt$diff_kill_pol[(DFt$diff_kill_pol <= 0) ] <- 0  ## Set negative values of misreporting to 0
# 
# # remove singletons for FE estimation
# id_counts <- table(DFt$CountyCode_FE); singleton_ids <- names(id_counts[id_counts == 1])
# DFt <- DFt[!(DFt$CountyCode_FE %in% singleton_ids), ]
# 
# 
# # FE Poisson estimation, weighted and clustered by county and countyFE
# DFt0 = PoiSampleTWFE_fn(DFt,DFt$diff_kill_pol,DFt$CountyCode_FE)
# Pfe = fepois(diff_kill_pol ~ LawEnf_cert1 + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
#                log_GDP   | CountyCode_FE + Year, offset = DFt0$kill_tot_tr, weights = DFt0$weight_var,  data = DFt0)
# my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
# my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
# for (i in my_v) {  cat(i, "\n")}
# # Descriptive stats
# a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
# a = append(a,sum(DFt0$weight_var))  # Effective sample
# a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
# a = append(a,length(unique(DFt0$CountyCode)) )
# a = append(a,sprintf("%.3f",sum(DFt0$weight_var * DFt0$diff_kill_pol/DFt0$mpv_kill_pol)/sum(DFt0$weight_var)))
# for (i in a) {  cat(i, "\n")}  



### Table 1app Column 11: LawEnf effect Poisson FE, with covariates and weighting adjustment ###
#####################################################
# Select sample
DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert + DF$ShCoroner >0) 
DFt = DF
DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))

# Generate propensity score for sample weighting 

# remove rows with missing values
sum(is.na(DFt$perc_votes.DEM))
DFt = DFt[!(is.na(DFt$LfrinMetro)),]
DFt = DFt[!(is.na(DFt$log_GDP)),]
DFt = DFt[!(is.na(DFt$perc_votes.DEM)),]

sX=c("LawEnf_cert1", "RtCscore","MedExam", "ShCoroner","LfrinMetro","MMetro","Microp","Noncore","SMetro","log_Population","Fem_perc","Black_perc","WHisp_perc","Other_perc", "perc_votes.DEM", "perc_votes.OTHER", "log_GDP", "kill_tot_tr","Y2014","Y2015","Y2016","Y2017","Y2018","Y2019")
streatX = c(sX) #included covariates

# Generate propensity score for LawEnf_cert1=1 (treated) counties
DFt1 = DFt[(DFt$LawEnf_cert1 == 1),]
Lfe <- glm(as.formula(paste("sample_LE_SC1 ~ ", paste(streatX, collapse= "+"))) , data = DFt1, family = "binomial")
DFt1$p_sample = Lfe$fitted.values

# Generate propensity score for LawEnf_cert1=0 (non-treated) counties
DFt0 = DFt[(DFt$LawEnf_cert1 == 0),]
Lfe <- glm(as.formula(paste("sample_LE_SC1 ~ ", paste(streatX, collapse= "+"))) , data = DFt0, family = "binomial")
DFt0$p_sample = Lfe$fitted.values

DFt = rbind(DFt1,DFt0)

# Now go through usual analysis on adjacency subsample
DFt = DFt[(DFt$sample_LE_SC1 == 1),]

DFt = FE_fun(DFt, DFt$LawEnf_cert1, adj1 ) # Generate analysis dataset (weights adjusted inside fn)

DFt$diff_kill_pol[(DFt$diff_kill_pol <= 0) ] <- 0  ## Set negative values of misreporting to 0

# remove singletons for FE estimation
id_counts <- table(DFt$CountyCode_FE); singleton_ids <- names(id_counts[id_counts == 1])
DFt <- DFt[!(DFt$CountyCode_FE %in% singleton_ids), ]

# FE Poisson estimation, weighted and clustered by county and countyFE
DFt0 = PoiSampleTWFE_fn(DFt,DFt$diff_kill_pol,DFt$CountyCode_FE)

DFt0$weight_var = DFt0$weight_var/DFt0$p_sample  # adjust weights for non-sample extrapolation

Pfe = fepois(diff_kill_pol ~ LawEnf_cert1  + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP + kill_tot_tr  | CountyCode_FE + Year, weights = DFt0$weight_var,  data = DFt0)
summary(Pfe, cluster = ~CountyCode)$coeftable
my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
# These will make no sense if computed like others, 
# you should keep the ones from Table 1 column 3 main estimation


# Calculate total effect on underreported police killings per year
DFppt = DFt0[(DFt0$LawEnf_cert1 == 0), ]
a = (exp(summary(Pfe, cluster = ~CountyCode)$coeftable[1,1])-1)*mean(DFppt$diff_kill_pol) # mean difference in underreported police killings per county in analysis sample
DFppt = DFt0[(DFt0$LawEnf_cert1 == 1), ]
b = mean(DFppt$diff_kill_pol)  # mean police killings in treated counties of analysis sample
c = a/b  # share of underreported police killings relative to total police killings in weighted treated (DFt0$LawEnf_cert1 == 1) analysis counties


e= sum(DF$diff_kill_pol[DF$LawEnf_cert1 == 1])*c # total per year reduction in police killings on US-wide LawEnf_cert1 == 1
e # final number in text giving per year number of underrported police killings preventable by changing laws


# Calculate total effect on underreported police killings per year
DFppt = DFt0[(DFt0$LawEnf_cert1 == 0), ]
a = (exp(summary(Pfe, cluster = ~CountyCode)$coeftable[1,1])-1)*mean(DFppt$diff_kill_pol) # mean difference in underreported police killings per county in analysis sample
DFppt = DFt0[(DFt0$LawEnf_cert1 == 1), ]
b = mean(DFppt$diff_kill_pol)  # mean police killings in treated counties of analysis sample
c = a/b  # share of underreported police killings relative to total police killings in weighted treated (DFt0$LawEnf_cert1 == 1) analysis counties


e= sum(DF$diff_kill_pol[DF$LawEnf_cert1 == 1])*c/7 # total per year reduction in police killings on US-wide LawEnf_cert1 == 1
e # final number in text giving per year number of underrported police killings preventable by changing laws
# Another way to calculate this from summary stats would be nbr_counties*share_LawEnf_cert1*coeff_eff*mean_underreport_police_killings. Gives slightly higher total due to non-weighting









#############################################################
######## Placebo test on main specification
##############################################################

## Setup
# In the real data, there are 5 states in which all counties can certify the cause of death 
# and 18in which a subset can.
# 
# Each placebo iteration therefore randomly selects 5 states, imposes all counties in these states to 
# fictitiously allow law enforcement to certify the cause of death. Then we draw 18 other states 
# and randomly draw each of these states to have the same fraction of counties within that State
# asthe share in a corresponding real state with sheriff coroners. This produces a distribution
# of states whcih allow law enforcement to certify the cause of death replicating the true distribution.

############

DFp = DF

DFp$LawEnf_cert1 =  as.numeric(DFp$LawEnf_cert + DFp$ShCoroner >0) 
sum(DFp$LawEnf_cert1)

# Find share by state of LE_cert1 counties

DFp$ones = 1
DFp <- DFp %>%
  group_by(State) %>%
  mutate(Sum_State = sum(ones),
         Sum_LE_cert1 = sum(LawEnf_cert1))

DFp$share_LESC = DFp$Sum_LE_cert1/DFp$Sum_State

check = DFp[ (DFp$LawEnf_cert1 == 1),]
length(unique(check$State))
check = DFp[ (as.numeric(DFp$ShCoroner - DFp$LawEnf_cert*DFp$ShCoroner) == 1),]
length(unique(check$State))
sum(as.numeric(DFp$ShCoroner - DFp$LawEnf_cert*DFp$ShCoroner) == 1)
check = check[ (check$Year ==2016),]
length(unique(check$share_LESC))
check = check[order(check$share_LESC), ]
check <- check %>%
  distinct(State, .keep_all = TRUE)
states_frac = unique(check$State)
states_all = unique(DF$State[(DF$LawEnf_cert == 1)])
pl_distr = c(check$share_LESC,rep(1, 7))
length(pl_distr)


set.seed(12546463)

pl_effn =c(0,0,0,0)
p=1
for (p in 1:999){
  print(p)
  
  nbr = 12546463+p
  set.seed(nbr)
  
  DFg = DF[(DF$Year==2016), c("CountyCode", "State")]
  sampled_states_frac = sample(unique(DFg$State), length(states_frac))
  sampled_states_all = sample(unique(DFg$State), length(states_all))
  # The following is super inefficient, but correct, and I just want to move on to other projects
  while (sum(as.numeric(sampled_states_frac %in% states_frac)) !=0){
    sampled_states_frac = sample(unique(DFg$State), length(states_frac)) 
  }
  # The following is super inefficient, but correct, and I just want to move on to other projects
  while (sum(as.numeric(sampled_states_all %in% states_all)) !=0){
    sampled_states_all = sample(unique(DFg$State), length(states_all))
  }
  sampled_states = c(sampled_states_frac,sampled_states_all)
  
  print(sampled_states)
  rbin =1
  DFsam = cbind(DFg[1,],rbin)
  i = 1
  for (i in 1:length(sampled_states)){
    
    DFgn = DFg[(DFg$State == sampled_states[i]),]
    rbin = rbinom(nrow(DFgn), 1, pl_distr[i])
    temp = cbind(DFgn, rbin)
    temp = temp[(temp$rbin ==1),]
    DFsam = rbind(DFsam,temp)
    
  }
  DFsam = DFsam[-1,]
  
  DFpd <- merge(DFp, DFsam, by.data_char=c("CountyCode", "State"), all.x =   TRUE)
  DFpd$rbin[is.na(DFpd$rbin)] <- 0
  
  
  
  
  
  
  
  
  #####  Prepare adjacency sample indicator variables for Law enforcement death certifying counties #######
  #####  2. Law Enforcement counties or Sheriff-Coroner counties vs. any other non LEnf or S-C #######
  
  j=1
  
  for (j in 1:2){
    
    
    
    c_adj <- read.delim2("C:/Users/skast/Dropbox/Death Invest/Coroners/Data/County adjacency/county_adjacency.txt", header=FALSE, na.strings=c("","NA")) # Load county adjacency matrix
    
    # Prepare adjacency data
    for (i in 2:nrow(c_adj)) {
      if (is.na(c_adj[i,1])) {
        c_adj[i,1:2] = c_adj[i-1,1:2]    
      } 
    }
    
    
    colnames(c_adj) <- c("CountyState1", "CountyCode", "CountyState2", "CountyCode2")
    c_adj = c_adj[(c_adj$CountyCode != c_adj$CountyCode2),]
    c_adj = c_adj[,c("CountyCode", "CountyCode2")] # 2nd degree adjacency data
    
    
    c_adj1 <- read.csv( "C:\\Users\\skast\\Dropbox\\Death Invest\\Coroners\\Data\\County adjacency\\county_adjacency_2deg.csv") ## 2nd degree adjacency
    if (j == 2) {  # This is for 2nd degree adjacency
      c_adj = c_adj1[,2:3]
    }
    
    
    df_1 <- DFpd[,c("CountyCode", "rbin", "urban2013")]
    df_1 <- df_1[ order( df_1$CountyCode),]
    df_1 = df_1[!duplicated(df_1), ]  # remove duplicates from multiple years
    df_1$ditype <- df_1$rbin   # 1 if Sh-Coroner or Law enforcement county
    
    
    df_1$CountyCode = as.numeric(df_1$CountyCode)
    df_1 <- df_1[,c("CountyCode", "ditype","urban2013")]
    typeof(c_adj$CountyCode)
    typeof(df_1$CountyCode)
    
    c_adj =  c_adj[ order( c_adj$CountyCode ),]
    adj_merge <- merge(c_adj, df_1, by.data_char="CountyCode")
    colnames(df_1) <- c("CountyCode2", "ditype2","urban2013_2")  # Change names to merge on adjacent counties
    adj_merge <- merge(adj_merge, df_1, by.data_char="CountyCode2")
    
    # Drop adjacent counties with same Death investigation system
    nrow(adj_merge)
    adj_merge = adj_merge[(adj_merge$ditype != adj_merge$ditype2),]
    nrow(adj_merge)
    
    
    
    
    
    ## NOT CONDITIONING ON URBANIZATION INDEX ###
    
    
    # Generate index for when variable of interest is 1 if law enforcement can certify or if a sheriff coroner county, 0 otherwise
    adj_merge$sample_LE_SC = (adj_merge$ditype == 1) + (adj_merge$ditype2 == 1)  # Should be included in sample 
    LE_SC_sample <- adj_merge[(adj_merge$sample_LE_SC ==1),c("CountyCode","sample_LE_SC")]
    LE_SC_sample <- LE_SC_sample[ order( LE_SC_sample$CountyCode),]
    LE_SC_sample <- LE_SC_sample[!duplicated(LE_SC_sample$CountyCode),]
    
    
    if (j == 1) {
      
      LE_SC_sample1 = LE_SC_sample
      
      
      #Merge indexes for 1st degree adjacent sample
      DF_adj <- merge(DFpd, LE_SC_sample1, by.data_char="CountyCode", all=T)
      
      DF_adj$sample_LE_SC1p <- as.numeric(!is.na(DF_adj$sample_LE_SC))  # set 0 values for counties which should be excluded from analysis 
      DF_adj = DF_adj[ order( DF_adj$CountyCode, DF_adj$Year ),]
      
      
    } else {
      
      LE_SC_sample2 = LE_SC_sample
      
      #Merge indexes for 2nd degree adjacent sample
      DF_adj <- merge(DF_adj, LE_SC_sample2, by.data_char="CountyCode", all=T)
      
      DF_adj$sample_LE_SC2p <- as.numeric(!is.na(DF_adj$sample_LE_SC))  # set 0 values for counties which should be excluded from analysis 
      DF_adj = DF_adj[ order( DF_adj$CountyCode, DF_adj$Year ),]
      
      
    }
    
    DF_adj = DF_adj[ , !(names(DF_adj) %in% c("sample_LE_SC"))]
    
  }
  
  
  
  DFpd = DF_adj
  
  
  
  #####################################################
  # Select sample
  DFpd$LawEnf_cert1 =  DFpd$rbin 
  DFt = DFpd[(DFpd$sample_LE_SC1p  == 1),]
  
  
  
  DFt = FE_fun(DFt, DFt$LawEnf_cert1, adj1 ) # Generate analysis dataset (weights adjusted inside fn)
  
  DFt$diff_kill_pol[(DFt$diff_kill_pol <= 0) ] <- 0  ## Set negative values of misreporting to 0
  DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))
  
  # remove singletons for FE estimation
  id_counts <- table(DFt$CountyCode_FE); singleton_ids <- names(id_counts[id_counts == 1])
  DFt <- DFt[!(DFt$CountyCode_FE %in% singleton_ids), ]
  
  
  # FE Poisson estimation, weighted and clustered by county and countyFE
  DFt0 = PoiSampleTWFE_fn(DFt,DFt$diff_kill_pol,DFt$CountyCode_FE)
  Pfe = fepois(diff_kill_pol ~ LawEnf_cert1  + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
                 log_GDP + kill_tot_tr  | CountyCode_FE + Year, weights = DFt0$weight_var,  data = DFt0)
  
  pl_eff1 = c(0,0,0,0) 
  pl_eff1[1] = summary(Pfe, cluster = ~CountyCode)$coeftable[1,1]
  pl_eff1[2] = summary(Pfe, cluster = ~CountyCode)$coeftable[1,4]
  
  DFt0 = PoiSampleTWFE_fn(DFt,DFt$map_circ_circumstance_undetermined,DFt$CountyCode_FE)
  Pfe = fepois(map_circ_circumstance_undetermined ~ LawEnf_cert1  + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
                 log_GDP + kill_tot_tr  | CountyCode_FE + Year, weights = DFt0$weight_var,  data = DFt0)
  
  
  pl_eff1[3] = summary(Pfe, cluster = ~CountyCode)$coeftable[1,1]
  pl_eff1[4] = summary(Pfe, cluster = ~CountyCode)$coeftable[1,4]
  
  
  
  pl_effn = rbind(pl_effn,pl_eff1)
  
  print(pl_effn)
  
  
}


pl_effn = pl_effn[-1,]

save(pl_effn, file = "pl_effn.Rda")

load("pl_effn.Rda")



#####################################################
# Select sample
DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert + DF$ShCoroner >0) 
DFt = DF[(DF$sample_LE_SC1 == 1),]


DFt = FE_fun(DFt, DFt$LawEnf_cert1, adj1 ) # Generate analysis dataset (weights adjusted inside fn)

DFt$diff_kill_pol[(DFt$diff_kill_pol <= 0) ] <- 0  ## Set negative values of misreporting to 0
DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))

# remove singletons for FE estimation
id_counts <- table(DFt$CountyCode_FE); singleton_ids <- names(id_counts[id_counts == 1])
DFt <- DFt[!(DFt$CountyCode_FE %in% singleton_ids), ]


# FE Poisson estimation, weighted and clustered by county and countyFE
DFt0 = PoiSampleTWFE_fn(DFt,DFt$diff_kill_pol,DFt$CountyCode_FE)
Pfe = fepois(diff_kill_pol ~ LawEnf_cert1  + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP + kill_tot_tr  | CountyCode_FE + Year, weights = DFt0$weight_var,  data = DFt0)

effn = c(0,0,0,0) 
effn[1] = summary(Pfe, cluster = ~CountyCode)$coeftable[1,1]
effn[2] = summary(Pfe, cluster = ~CountyCode)$coeftable[1,4]

DFt0 = PoiSampleTWFE_fn(DFt,DFt$map_circ_circumstance_undetermined,DFt$CountyCode_FE)
Pfe = fepois(map_circ_circumstance_undetermined ~ LawEnf_cert1  + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP + kill_tot_tr  | CountyCode_FE + Year, weights = DFt0$weight_var,  data = DFt0)


effn[3] = summary(Pfe, cluster = ~CountyCode)$coeftable[1,1]
effn[4] = summary(Pfe, cluster = ~CountyCode)$coeftable[1,4]




## PLACEBO RESULTS
#################



# What is share of placebo effects greater than main underreporting effect
sum(pl_effn[,1] > effn[1])/nrow(pl_effn)
sum(abs(pl_effn[,1]) > effn[1])/nrow(pl_effn)

# What is share of placebo effects joint greater than main underreporting effect and greater than circ. undtertermined effect
sum((pl_effn[,1] > effn[1])*(pl_effn[,3] > effn[3]))/nrow(pl_effn)




cdf <- ecdf(pl_effn[,1])

# Get max and min values of pl_eff
max_value <- max(pl_effn[,1],effn[1])
min_value <- min(pl_effn[,1],effn[1])

# Plotting the cumulative distribution function (CDF) with limits
plot(cdf, col = "grey", main = "", xlim = c(min_value, max_value))
abline(v = effn[1], col = "red")
abline(v = median(pl_effn[,1]), col = "black", lty = 3)
text(effn[1], 0.05, "True Estimate", col = "red", pos = 4, srt =  90, cex = 0.7)
text(median(pl_effn[,1]), 0.05, "Placebo Median", col = "black", pos = 4, srt = 90, cex = 0.7)









#############################################################
######## Estimations removing one state (and its relevant adjacent counties) at a time
##############################################################




# Define States to remove
DFt = DF[(DF$sample_LE_SC1 == 1),]

state_off = unique(DFt$State)


pl_effn =c(0,0,0)

for (p in unique(DFt$State)){
  print(p)
  
  DFpd = DF[(DF$State != p),]
  
  DFpd$LawEnf_cert1 = as.numeric(DFpd$LawEnf_cert + DFpd$ShCoroner >0)
  
  
  #####  Prepare adjacency sample indicator variables for Law enforcement death certifying counties #######
  #####  2. Law Enforcement counties or Sheriff-Coroner counties vs. any other non LEnf or S-C #######
  
  j=1
  
  for (j in 1:2){
    
    
    
    c_adj <- read.delim2("C:/Users/skast/Dropbox/Death Invest/Coroners/Data/County adjacency/county_adjacency.txt", header=FALSE, na.strings=c("","NA")) # Load county adjacency matrix
    
    # Prepare adjacency data
    for (i in 2:nrow(c_adj)) {
      if (is.na(c_adj[i,1])) {
        c_adj[i,1:2] = c_adj[i-1,1:2]    
      } 
    }
    
    
    colnames(c_adj) <- c("CountyState1", "CountyCode", "CountyState2", "CountyCode2")
    c_adj = c_adj[(c_adj$CountyCode != c_adj$CountyCode2),]
    c_adj = c_adj[,c("CountyCode", "CountyCode2")] # 2nd degree adjacency data
    
    
    c_adj1 <- read.csv( "C:\\Users\\skast\\Dropbox\\Death Invest\\Coroners\\Data\\County adjacency\\county_adjacency_2deg.csv") ## 2nd degree adjacency
    if (j == 2) {  # This is for 2nd degree adjacency
      c_adj = c_adj1[,2:3]
    }
    
    
    df_1 <- DFpd[,c("CountyCode", "LawEnf_cert1", "urban2013")]
    df_1 <- df_1[ order( df_1$CountyCode),]
    df_1 = df_1[!duplicated(df_1), ]  # remove duplicates from multiple years
    df_1$ditype <- df_1$LawEnf_cert1   # 1 if Sh-Coroner or Law enforcement county
    
    
    df_1$CountyCode = as.numeric(df_1$CountyCode)
    df_1 <- df_1[,c("CountyCode", "ditype","urban2013")]
    typeof(c_adj$CountyCode)
    typeof(df_1$CountyCode)
    
    c_adj =  c_adj[ order( c_adj$CountyCode ),]
    adj_merge <- merge(c_adj, df_1, by.data_char="CountyCode")
    colnames(df_1) <- c("CountyCode2", "ditype2","urban2013_2")  # Change names to merge on adjacent counties
    adj_merge <- merge(adj_merge, df_1, by.data_char="CountyCode2")
    
    # Drop adjacent counties with same Death investigation system
    nrow(adj_merge)
    adj_merge = adj_merge[(adj_merge$ditype != adj_merge$ditype2),]
    nrow(adj_merge)
    
    
    
    
    
    ## NOT CONDITIONING ON URBANIZATION INDEX ###
    
    
    # Generate index for when variable of interest is 1 if law enforcement can certify or if a sheriff coroner county, 0 otherwise
    adj_merge$sample_LE_SC = (adj_merge$ditype == 1) + (adj_merge$ditype2 == 1)  # Should be included in sample 
    LE_SC_sample <- adj_merge[(adj_merge$sample_LE_SC ==1),c("CountyCode","sample_LE_SC")]
    LE_SC_sample <- LE_SC_sample[ order( LE_SC_sample$CountyCode),]
    LE_SC_sample <- LE_SC_sample[!duplicated(LE_SC_sample$CountyCode),]
    
    # remove counties which are halfway between treated nor controls
    LE_SC_sample <- LE_SC_sample[!(LE_SC_sample$CountyCode %in% c(4021, 4015, 4019, 4012, 4013, 4025, 4027,  4009,
                                                                  35055, 35001, 35035, 35049, 35061, 35003, 35027, 35029,35053)),]
    
    
    
    
    if (j == 1) {
      
      LE_SC_sample1 = LE_SC_sample
      
      
      #Merge indexes for 1st degree adjacent sample
      DF_adj <- merge(DFpd, LE_SC_sample1, by.data_char="CountyCode", all=T)
      
      DF_adj$sample_LE_SC1p <- as.numeric(!is.na(DF_adj$sample_LE_SC))  # set 0 values for counties which should be excluded from analysis 
      DF_adj = DF_adj[ order( DF_adj$CountyCode, DF_adj$Year ),]
      
      
    } else {
      
      LE_SC_sample2 = LE_SC_sample
      
      #Merge indexes for 2nd degree adjacent sample
      DF_adj <- merge(DF_adj, LE_SC_sample2, by.data_char="CountyCode", all=T)
      
      DF_adj$sample_LE_SC2p <- as.numeric(!is.na(DF_adj$sample_LE_SC))  # set 0 values for counties which should be excluded from analysis 
      DF_adj = DF_adj[ order( DF_adj$CountyCode, DF_adj$Year ),]
      
      
    }
    
    DF_adj = DF_adj[ , !(names(DF_adj) %in% c("sample_LE_SC"))]
    
  }
  
  
  DFpd = DF_adj
  
  # Check through maps that you are dropping the right state
  # DFpd$sample = DFpd$sample_LE_SC1p
  # DF_map = DFpd[,c("CountyCode","State","LawEnf_cert1","sample")]
  # DF_map = DF_map[!is.na(DF_map$sample),]
  # DF_map = DF_map[(DF_map$sample == 1),]
  # DF_map$index_C = as.numeric(DF_map$sample) + as.numeric(DF_map$sample)*as.numeric(DF_map$LawEnf_cert1)
  # DF_map = DF_map[,c("CountyCode","index_C")]
  # colnames(DF_map) <- c("fips", "index_C")
  # plot_usmap(regions='counties',data=DF_map,values="index_C") 
  
  
  #####################################################
  # Select sample
  DFt = DFpd[(DFpd$sample_LE_SC1p  == 1),]
  
  
  
  
  DFt = FE_fun(DFt, DFt$LawEnf_cert1, adj1 ) # Generate analysis dataset (weights adjusted inside fn)
  
  DFt$diff_kill_pol[(DFt$diff_kill_pol <= 0) ] <- 0  ## Set negative values of misreporting to 0
  DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))
  
  # remove singletons for FE estimation
  id_counts <- table(DFt$CountyCode_FE); singleton_ids <- names(id_counts[id_counts == 1])
  DFt <- DFt[!(DFt$CountyCode_FE %in% singleton_ids), ]
  
  
  # FE Poisson estimation, weighted and clustered by county and countyFE
  DFt0 = PoiSampleTWFE_fn(DFt,DFt$diff_kill_pol,DFt$CountyCode_FE)
  Pfe = fepois(diff_kill_pol ~ LawEnf_cert1  + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
                 log_GDP + kill_tot_tr  | CountyCode_FE + Year, weights = DFt0$weight_var,  data = DFt0)
  
  pl_eff1 = c(0,0,0) 
  pl_eff1[1] = summary(Pfe, cluster = ~CountyCode)$coeftable[1,1]
  pl_eff1[2] = summary(Pfe, cluster = ~CountyCode)$coeftable[1,2]
  pl_eff1[3] = summary(Pfe, cluster = ~CountyCode)$coeftable[1,4]
  
  
  
  
  pl_effn = rbind(pl_effn,pl_eff1)
  
  print(pl_effn)
  
  
}


pl_effn = pl_effn[-1,]

# Table of effects on all 30 categories presenting point estimates ad p-values of 
# baseline model in 1:2 and with State FEs in 3:4
pl_effndf = as.data.frame(cbind(state_off,sprintf("%.3f",exp(pl_effn[,1])-1),
                                sprintf("%.3f",pl_effn[,1]),
                                sprintf("%.3f",pl_effn[,2]),
                                sprintf("%.3f",pl_effn[,3])))
colnames(pl_effndf) <- c("state_off", "Estimate_trans", "Estimate", "St_Error", "Pval")

### Add main effect to table


### Table 1 Column 3: LawEnf effect Poisson FE, with covariates, cluster FE ###
#####################################################
# Select sample
DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert + DF$ShCoroner >0) 
DFt = DF[(DF$sample_LE_SC1 == 1),]
DFt = FE_fun(DFt, DFt$LawEnf_cert1, adj1 ) # Generate analysis dataset (weights adjusted inside fn)

DFt$diff_kill_pol[(DFt$diff_kill_pol <= 0) ] <- 0  ## Set negative values of misreporting to 0
DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))

# remove singletons for FE estimation
id_counts <- table(DFt$CountyCode_FE); singleton_ids <- names(id_counts[id_counts == 1])
DFt <- DFt[!(DFt$CountyCode_FE %in% singleton_ids), ]

# FE Poisson estimation, weighted and clustered by county and countyFE
DFt0 = PoiSampleTWFE_fn(DFt,DFt$diff_kill_pol,DFt$CountyCode_FE)
Pfe = fepois(diff_kill_pol ~ LawEnf_cert1  + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP + kill_tot_tr  | CountyCode_FE + Year, weights = DFt0$weight_var,  data = DFt0)
summary(Pfe, cluster = ~CountyCode)$coeftable

# Append overall effect
pl_effndf = rbind(pl_effndf, c("ALL", sprintf("%.3f",exp( summary(Pfe, cluster = ~CountyCode)$coeftable[1,1])- 1), 
                                              sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,1]),
                                                      sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,2]),
                                                              sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,4])))
pl_effndf$color_code = rep("#989898", 33)
pl_effndf$color_code[(pl_effndf$state_off  == "All")] <- "red"
pl_effndf$color_code[(pl_effndf$state_off  %in% c("NV", "AZ", "NM", "MT", "NE", "MA", "WY"))] <- "black"

pl_effndf
## Plost results
# Sort the dataframe by "Estimate_trans"
df_sorted <- arrange(pl_effndf, Estimate_trans)

# Convert state_off to a factor with levels ordered by Estimate_trans
df_sorted$state_off <- factor(df_sorted$state_off, levels = df_sorted$state_off)
df_sorted$Estimate_trans <- as.numeric(df_sorted$Estimate_trans)
df_sorted$Estimate <- as.numeric(df_sorted$Estimate)
df_sorted$St_Error <- as.numeric(df_sorted$St_Error)

# Plotting
# Plotting
ggplot(df_sorted, aes(x = state_off, y = Estimate)) +
  geom_point(aes(color = color_code), size = 3) +  # Map color to the "color_code" column
  geom_errorbar(aes(ymin = Estimate - 1.96 * St_Error, ymax = Estimate + 1.96 * St_Error, color = color_code), width = 0.2) + # Map color to the "color_code" column
  geom_hline(yintercept = 0, linetype = "dashed", color = "black") +
  geom_hline(yintercept = 0.338, color = "red") +
  scale_color_identity() +  # Use identity scale to maintain original colors
  labs(x = "State Removed", y = "Estimate") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 45, hjust = 1),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank()) +
  ylim(-0.13, 0.8)





##############################################
#### TABLE 2 ####
##############################################


### Table 2 Column 1: LawEnf effect Poisson FE, with covariates, Outcome: SHR police killings outcome ###
#####################################################
# Select sample
DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert + DF$ShCoroner >0) 
DFt = DF[(DF$sample_LE_SC1 == 1),]


DFt = FE_fun(DFt, DFt$LawEnf_cert1, adj1 ) # Generate analysis dataset (weights adjusted inside fn)

DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))

# remove singletons for FE estimation
id_counts <- table(DFt$CountyCode_FE); singleton_ids <- names(id_counts[id_counts == 1])
DFt <- DFt[!(DFt$CountyCode_FE %in% singleton_ids), ]


# FE Poisson estimation, weighted and clustered by county and countyFE
DFt0 = PoiSampleTWFE_fn(DFt,DFt$diff_kill_pol,DFt$CountyCode_FE)
Pfe = fepois(map_kill_pol ~ LawEnf_cert1 + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP + kill_tot_tr  | CountyCode_FE + Year,  weights = DFt0$weight_var,  data = DFt0)
my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,sum(DFt0$weight_var))  # Effective sample
a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f",sum(DFt0$weight_var * DFt0$map_kill_pol)/sum(DFt0$weight_var)))
for (i in a) {  cat(i, "\n")} 






### Table 2 Column 2: LawEnf effect Poisson FE, with covariates, Outcome: MPV police killings outcome ###
#####################################################
# Select sample
DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert + DF$ShCoroner >0) 
DFt = DF[(DF$sample_LE_SC1 == 1),]

DFt = FE_fun(DFt, DFt$LawEnf_cert1, adj1 ) # Generate analysis dataset (weights adjusted inside fn)
DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))

# remove singletons for FE estimation
id_counts <- table(DFt$CountyCode_FE); singleton_ids <- names(id_counts[id_counts == 1])
DFt <- DFt[!(DFt$CountyCode_FE %in% singleton_ids), ]


# FE Poisson estimation, weighted and clustered by county and countyFE
DFt0 = PoiSampleTWFE_fn(DFt,DFt$diff_kill_pol,DFt$CountyCode_FE)
Pfe = fepois(mpv_kill_pol ~ LawEnf_cert1 + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP + kill_tot_tr | CountyCode_FE + Year,  weights = DFt0$weight_var,  data = DFt0)
my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,sum(DFt0$weight_var))  # Effective sample
a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f",sum(DFt0$weight_var * DFt0$mpv_kill_pol)/sum(DFt0$weight_var)))
for (i in a) {  cat(i, "\n")} 




### Table 2 Column 3: LawEnf effect Poisson FE, with covariates, Outcome: Circumstances undetermined ###
#####################################################
# Select sample
DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert + DF$ShCoroner >0) 
DFt = DF[(DF$sample_LE_SC1 == 1),]


DFt = FE_fun(DFt, DFt$LawEnf_cert1, adj1 ) # Generate analysis dataset (weights adjusted inside fn)
DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))

# remove singletons for FE estimation
id_counts <- table(DFt$CountyCode_FE); singleton_ids <- names(id_counts[id_counts == 1])
DFt <- DFt[!(DFt$CountyCode_FE %in% singleton_ids), ]


# FE Poisson estimation, weighted and clustered by county and countyFE
DFt0 = PoiSampleTWFE_fn(DFt,DFt$map_circ_circumstance_undetermined,DFt$CountyCode_FE)
Pfe = fepois(map_circ_circumstance_undetermined ~ LawEnf_cert1  + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP + kill_tot_tr  | CountyCode_FE + Year,  weights = DFt0$weight_var,  data = DFt0)
my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,sum(DFt0$weight_var))  # Effective sample
a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f",sum(DFt0$weight_var * DFt0$map_circ_circumstance_undetermined)/sum(DFt0$weight_var)))
for (i in a) {  cat(i, "\n")} 


# # Results not presented but mentioned in text:
# #####################################################
# 
# ### Table 2 Column 3*: LawEnf effect Poisson FE, with covariates, Outcome: Circumstances undetermined  sheriff-coroner###
# #####################################################
# # Select sample
# DF$LawEnf_cert1 =  DF$ShCoroner    # Define variable of interest as 1 if Sheriff-Coroner, 0 otherwise
# DFt = DF[(DF$sample_SC_noLE1  ==1),]
# 
# 
# DFt = FE_fun(DFt, DFt$LawEnf_cert1, adj1 ) # Generate analysis dataset (weights adjusted inside fn)
# DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))
# 
# # remove singletons for FE estimation
# id_counts <- table(DFt$CountyCode_FE); singleton_ids <- names(id_counts[id_counts == 1])
# DFt <- DFt[!(DFt$CountyCode_FE %in% singleton_ids), ]
# 
# 
# # FE Poisson estimation, weighted and clustered by county and countyFE
# DFt0 = PoiSampleTWFE_fn(DFt,DFt$map_circ_circumstance_undetermined,DFt$CountyCode_FE)
# Pfe = fepois(map_circ_circumstance_undetermined ~ LawEnf_cert1  + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
#                log_GDP + kill_tot_tr  | CountyCode_FE + Year,  weights = DFt0$weight_var,  data = DFt0)
# my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
# my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
# for (i in my_v) {  cat(i, "\n")}
# # Descriptive stats
# a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
# a = append(a,sum(DFt0$weight_var))  # Effective sample
# a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
# a = append(a,length(unique(DFt0$CountyCode)) )
# a = append(a,sprintf("%.3f",sum(DFt0$weight_var * DFt0$map_circ_circumstance_undetermined)/sum(DFt0$weight_var)))
# for (i in a) {  cat(i, "\n")} 
# 
# 
# 
# 
# DF$LawEnf_cert1 =  DF$LawEnf_cert * (1-DF$ShCoroner) 
# DFt = DF[(DF$sample_LE_noSC1  ==1),]
# 
# DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert_n + DF$ShCoroner >0)  # Define variable of interest as 1 if law enforcement can certify or sheriff coroner county !! This should be our favoured specification
# DFt = DF[(DF$sample_LE_SCn1  ==1),]
# 
# 
# ### Table 2 Column 3*: LawEnf effect Poisson FE, with covariates, Outcome: Circumstances undetermined  non-sheriff-coroner###
# #####################################################
# # Select sample
# DF$LawEnf_cert1 =  DF$LawEnf_cert * (1-DF$ShCoroner) 
# DFt = DF[(DF$sample_LE_noSC1  ==1),]
# 
# 
# DFt = FE_fun(DFt, DFt$LawEnf_cert1, adj1 ) # Generate analysis dataset (weights adjusted inside fn)
# DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))
# 
# # remove singletons for FE estimation
# id_counts <- table(DFt$CountyCode_FE); singleton_ids <- names(id_counts[id_counts == 1])
# DFt <- DFt[!(DFt$CountyCode_FE %in% singleton_ids), ]
# 
# 
# # FE Poisson estimation, weighted and clustered by county and countyFE
# DFt0 = PoiSampleTWFE_fn(DFt,DFt$map_circ_circumstance_undetermined,DFt$CountyCode_FE)
# Pfe = fepois(map_circ_circumstance_undetermined ~ LawEnf_cert1  + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
#                log_GDP + kill_tot_tr  | CountyCode_FE + Year,  weights = DFt0$weight_var,  data = DFt0)
# my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
# my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
# for (i in my_v) {  cat(i, "\n")}
# # Descriptive stats
# a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
# a = append(a,sum(DFt0$weight_var))  # Effective sample
# a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
# a = append(a,length(unique(DFt0$CountyCode)) )
# a = append(a,sprintf("%.3f",sum(DFt0$weight_var * DFt0$map_circ_circumstance_undetermined)/sum(DFt0$weight_var)))
# for (i in a) {  cat(i, "\n")} 


### Table 2 Column 4: LawEnf effect Poisson FE, with covariates, Outcome: SHR Total Homicides ###
#####################################################

# Select sample
DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert + DF$ShCoroner >0) 
DFt = DF[(DF$sample_LE_SC1 == 1),]

DFt = FE_fun(DFt, DFt$LawEnf_cert1, adj1 ) # Generate analysis dataset (weights adjusted inside fn)

# remove singletons for FE estimation
id_counts <- table(DFt$CountyCode_FE); singleton_ids <- names(id_counts[id_counts == 1])
DFt <- DFt[!(DFt$CountyCode_FE %in% singleton_ids), ]


# FE Poisson estimation, weighted and clustered by county and countyFE
DFt0 = PoiSampleTWFE_fn(DFt,DFt$map_hom_tot,DFt$CountyCode_FE)
Pfe = fepois(map_hom_tot ~ LawEnf_cert1 + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP   | CountyCode_FE + Year,  weights = DFt0$weight_var,  data = DFt0)
my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,sum(DFt0$weight_var))  # Effective sample
a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f",sum(DFt0$weight_var * DFt0$map_hom_tot)/sum(DFt0$weight_var)))
for (i in a) {  cat(i, "\n")} 

# Mention that if you run this estimation with hom_tot you also find a 0 effect (-0.043)



### Table 2 Column 5: LawEnf effect Poisson FE, with covariates, Outcome: SHR Total Homicides - SHR Police homicides ###
#####################################################
# Select sample
DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert + DF$ShCoroner >0) 
DFt = DF[(DF$sample_LE_SC1 == 1),]

DFt$diff_kill_pol_n = DFt$map_hom_tot - DFt$map_kill_pol
DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))

DFt = FE_fun(DFt, DFt$LawEnf_cert1, adj1 ) # Generate analysis dataset (weights adjusted inside fn)

# remove singletons for FE estimation
id_counts <- table(DFt$CountyCode_FE); singleton_ids <- names(id_counts[id_counts == 1])
DFt <- DFt[!(DFt$CountyCode_FE %in% singleton_ids), ]


# FE Poisson estimation, weighted and clustered by county and countyFE
DFt0 = PoiSampleTWFE_fn(DFt,DFt$diff_kill_pol_n,DFt$CountyCode_FE)
Pfe = fepois(diff_kill_pol_n ~ LawEnf_cert1 + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP + kill_tot_tr  | CountyCode_FE + Year,  weights = DFt0$weight_var,  data = DFt0)
my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,sum(DFt0$weight_var))  # Effective sample
a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f",sum(DFt0$weight_var * DFt0$diff_kill_pol_n)/sum(DFt0$weight_var)))
for (i in a) {  cat(i, "\n")} 


### Table 2 Column 6: LawEnf effect Poisson FE, with covariates, Outcome: SHR Total Homicides - SHR Police homicides, 
####                  conditional on true police killing greater than 0 ###
#####################################################
# Select sample
DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert + DF$ShCoroner >0) 
DFt = DF[(DF$sample_LE_SC1 == 1),]

DFt$diff_kill_pol_n = DFt$map_hom_tot - DFt$map_kill_pol
DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))

DFt = DFt[(DFt$mpv_kill_pol >0  ),] # Only consider counties which had positive police killings

DFt = FE_fun(DFt, DFt$LawEnf_cert1, adj1 ) # Generate analysis dataset (weights adjusted inside fn)

# remove singletons for FE estimation
id_counts <- table(DFt$CountyCode_FE); singleton_ids <- names(id_counts[id_counts == 1])
DFt <- DFt[!(DFt$CountyCode_FE %in% singleton_ids), ]


# FE Poisson estimation, weighted and clustered by county and countyFE
DFt0 = PoiSampleTWFE_fn(DFt,DFt$diff_kill_pol_n,DFt$CountyCode_FE)
Pfe = fepois(diff_kill_pol_n ~ LawEnf_cert1  + LfrinMetro  + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP  + kill_tot_tr | CountyCode_FE + Year, weights = DFt0$weight_var,  data = DFt0)
my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,sum(DFt0$weight_var))  # Effective sample
a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f",sum(DFt0$weight_var * DFt0$diff_kill_pol_n)/sum(DFt0$weight_var)))
for (i in a) {  cat(i, "\n")} 





#####################################################
### Placebo Effects on other 29 SHR categories mentioned in text 
#####################################################



allcrime = c("map_circ_abortion" ,
             "map_circ_manslaughter_negligence",
             "map_circ_all_suspect_felony" ,
             "map_circ_argument_money_property" ,
             "map_circ_arson" ,
             "map_circ_brawl_alcohol" ,
             "map_circ_brawl_narcotics" ,
             "map_circ_burglary" ,
             "map_circ_child_killed_bybabysit",
             "map_circ_child_playin_wgun",
             "map_circ_by_citizen" ,
             "map_circ_gambling" ,
             "map_circ_gangland" ,
             "map_circ_gun_cleaning" ,
             "map_circ_institutional" ,
             "map_circ_juvenile_gang" ,
             "map_circ_larceny" ,
             "map_circ_love_triangle" ,
             "map_circ_narcotics" ,
             "map_circ_other" ,
             "map_circ_other_notspecified" ,
             "map_circ_other_narguments" ,
             "map_circ_other_gun" ,
             "map_circ_other_sexoffence",
             "map_circ_prostitution" ,
             "map_circ_rape" ,
             "map_circ_robbery",
             "map_circ_sniper" ,
             "map_circ_hunting",
             "map_circ_circumstance_undetermined")


# Initiate matrix for other SHR outcomes jonit analysis
other_SHR = matrix(0, length(allcrime), 6)


DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert + DF$ShCoroner >0) 
DFt = DF[(DF$sample_LE_SC1 == 1),]


DFt = FE_fun(DFt, DFt$LawEnf_cert1, adj1 ) # Generate analysis dataset (weights adjusted inside fn)

DFt$diff_kill_pol[(DFt$diff_kill_pol <= 0) ] <- 0  ## Set negative values of misreporting to 0
DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))

# remove singletons for FE estimation
id_counts <- table(DFt$CountyCode_FE); singleton_ids <- names(id_counts[id_counts == 1])
DFt <- DFt[!(DFt$CountyCode_FE %in% singleton_ids), ]



count = 1
for (ot in allcrime){
  print(ot)
  
  # Generate indicator for declared circumstance_undetermined
  DFt$map_other_SHR = DFt[[ot]]
  
  
  if (sum(DFt$map_other_SHR) != 0){
  
  # FE Poisson estimation, weighted and clustered by county and countyFE
  DFt0 = PoiSampleTWFE_fn(DFt,DFt$map_other_SHR,DFt$CountyCode_FE)
  Pfe = fepois(map_other_SHR ~ LawEnf_cert1  + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
                 log_GDP + kill_tot_tr  | CountyCode_FE + Year, weights = DFt0$weight_var,  data = DFt0)
  #print(sum(DFt0$map_other_SHR))
  #print(summary(Pfe, cluster = ~CountyCode)$coeftable[1,])

  
  other_SHR[count,1:3] = c(summary(Pfe, cluster = ~CountyCode)$coeftable[1,1],
                            summary(Pfe, cluster = ~CountyCode)$coeftable[1,4],
                           sum(DFt0$map_other_SHR))
  
  # Filter states where there is only one unique value of LawEnf_cert1
  state_summary <- aggregate(LawEnf_cert1 ~ State, data = DFt0, FUN = function(x) length(unique(x)))
  states_with_same_value <- state_summary$State[state_summary$LawEnf_cert1 == 1]
  DFt0 = DFt0[!(DFt0$State %in% states_with_same_value),] # remove all states that don't have variation in LawEnf_cert1
  
  # FE Poisson estimation, weighted and clustered by county and countyFE and State
  Pfe = fepois(map_other_SHR ~ LawEnf_cert1 + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
                 log_GDP  + kill_tot_tr | CountyCode_FE + Year + State,  weights = DFt0$weight_var,  data = DFt0)
  #print(sum(DFt0$map_other_SHR))
  #print(summary(Pfe, cluster = ~CountyCode)$coeftable[1,])
  
  other_SHR[count,4:6] = c(summary(Pfe, cluster = ~CountyCode)$coeftable[1,1],
                           summary(Pfe, cluster = ~CountyCode)$coeftable[1,4],
                           sum(DFt0$map_other_SHR))                          
  } else {
    other_SHR[count,] =c(0,0,0,0,0,0)
  }
  
  count = count + 1
}

# Table of effects on all 30 categories presenting point estimates ad p-values of 
# baseline model in 1:2 and with State FEs in 3:4
shr_all = as.data.frame(cbind(allcrime,sprintf("%.3f",other_SHR[,1])
      ,sprintf("%.3f",other_SHR[,2])
      ,other_SHR[,3]
      ,sprintf("%.3f",other_SHR[,4])
      ,sprintf("%.3f",other_SHR[,5])
      ,other_SHR[,6]))
colnames(shr_all) <- c("SHR_category", "Estimates", "Pval", "occur", "Estimates_StateFE", "Pval_StateFE", "occur_StateFE")
shr_all





#####################################################
### FIGURE Appendix I: SUB-CIRCUMSTANCES EFFECT 
#####################################################
# The ones in the paper are from STATA code of linear model with no covariates (see additional code)




##############################################
#### TABLE 3: DECOMPOSITION ####
##############################################





### Table 3 : LawEnf effect linear FE, with covariates, adjacency FE ###
#####################################################
# Select sample
set.seed(157231)
DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert + DF$ShCoroner >0) 
DFt = DF[(DF$sample_LE_SC1 == 1),]


DFt = FE_fun(DFt, DFt$LawEnf_cert1, adj1) # Generate analysis dataset (weights adjusted inside fn)
DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))

DFt$diff_kill_pol[(DFt$diff_kill_pol <= 0) ] <- 0  ## Set negative values of misreporting to 0


# remove singletons for FE estimation
id_counts <- table(DFt$CountyCode_FE); singleton_ids <- names(id_counts[id_counts == 1])
DFt <- DFt[!(DFt$CountyCode_FE %in% singleton_ids), ]
obs_decomp = nrow(DFt)

DFt$diff_kill_pol[(DFt$diff_kill_pol <= 0) ] <- 0  ## Set negative values of misreporting to 0

# Generate indicator for underreporting
DFt$diff_kill_pol_D = as.numeric(DFt$diff_kill_pol > 0)  
DFt$hide = DFt$map_circ_circumstance_undetermined  #+DFt$map_circ_other + DFt$map_circ_other_notspecified

# You can add the following liine to show that the effects are still significant with  map_circ_other or with map_circ_other & map_circ_other_notspecified
# DFt$map_circ_circumstance_undetermined =  DFt$map_circ_circumstance_undetermined +DFt$map_circ_other + DFt$map_circ_other_notspecified 


# Generate indicator for declared circumstance_undetermined
DFt$ratio_CU = DFt$hide/DFt$hom_tot
med_ratio = median(DFt$ratio_CU[(DFt$LawEnf_cert1 == 0)], na.rm=T)
DFt$map_circ_circumstance_undetermined_D = as.numeric(DFt$ratio_CU > med_ratio)
DFt$miss = as.numeric(is.na(DFt$ratio_CU))
DFt$map_circ_circumstance_undetermined_D[is.na(DFt$ratio_CU)] <- 0

print(sum(DFt$miss))

cY = c(0,0,0,0,0,0,0)
cWcY = c(0,0,0,0,0,0,0)
aWcY = c(0,0,0,0,0,0,0)
cWaY = c(0,0,0,0,0,0,0)

iter = 100

for (k in 1:iter){
  # Why this loop: This loop averages effects for the decomposition. 
  # Basically, we are dealing with a tradeoff that is specific to our setting. 
  # Ideally, we would observe a positive amount of each type of SHR homicide (and MPV police killings)
  # Because many counties have 0 homicides (or 0 of one of the SHR homicides), we need to consider 
  # what is actually happening when we conduct the joint analysis. Take the extreme case where no 
  # SHR homicides are observed for one of the counties in the analysis samepl in a given year. 
  # Does it make sense to still keep that county in the analysis sample? One might say no, we should condition
  # the analysis on tot_hom>0 . However, if we do this, we no longer have a balanced sample or we have only 
  # a handful of adjacent counties to compare. Explorations o that option turn out to be highly variable depending
  # on one or two observations, so we forgoe that option. 
  # Instead, we opt to randomly assign a binary outcome of 0 or 1 variable to the W outcome variable.
  # This effectively introduces measurement error, but this measurement error is balanced since it is indpedent
  # of the treatment. The advantage of this approach  is that it allows us to conduct the analysis on our fixed
  # main analysis sample.  However, we also find that any specific seed leads to varying effects depedning on the 0, 1 W
  # Imputations. As such, we decide to iterate the analysis and take the mean over many seeds (100). 
  # The reported estimates are the point estimates and standard deviations averaged over all replaications, 
  # with p-values calulated on these means
  print(k)

  
  ##Generate a random 0 or 1 number
  for (i in 1:nrow(DFt)) {
    if (is.na(DFt$ratio_CU[i])) {
      DFt$map_circ_circumstance_undetermined_D[i] <-  sample(0:1, 1)
    }
  }
  

  DFt$LawEnf_cert1n = 1-DFt$LawEnf_cert1
  DFt$Y = DFt$diff_kill_pol_D
  DFt$W = DFt$map_circ_circumstance_undetermined_D
  DFt$D = DFt$LawEnf_cert1
  DFt$YW = DFt$diff_kill_pol_D* DFt$map_circ_circumstance_undetermined_D
  DFt$YWn = DFt$diff_kill_pol_D* (1-DFt$map_circ_circumstance_undetermined_D)
  DFt$YnW = (1-DFt$diff_kill_pol_D)* DFt$map_circ_circumstance_undetermined_D
  DFt$YnWn = (1-DFt$diff_kill_pol_D)* (1-DFt$map_circ_circumstance_undetermined_D)
  
  
  # FE linear panel estimation, weighted and clustered by county and countyFE
  
  
  sX=c( "LfrinMetro", "MMetro","Microp","Noncore","SMetro","log_Population","Fem_perc","Black_perc","WHisp_perc","Other_perc", "perc_votes.DEM", "perc_votes.OTHER", "log_GDP","kill_tot_tr","Y2014","Y2015","Y2016","Y2017","Y2018","Y2019")
  sTreat <- "LawEnf_cert1"
  streatX = c(sTreat,sX)
  DFt0 =DFt
  
  # Table 3 column 1: effect on under-reporting Y: cY
  Lfe <- plm(as.formula(paste("Y ~ ", paste(streatX, collapse = "+"))), 
             weights = weight_var, 
             data = DFt0, 
             index = c( "CountyCode_FE"),  # Include "State" in the index
             model = "within")
  cY = rbind(cY, c(coef_test(Lfe, vcov = "CR1", cluster = "individual", test = "naive-t")[1,2],
                   coef_test(Lfe, vcov = "CR1", cluster = "individual", test = "naive-t")[1,3],
                   length(unique(DFt$CountyCode*10000+ DFt$Year)),
                   sum(DFt0$weight_var),
                   sum(DFt0$weight_var * DFt0$LawEnf_cert1),
                   length(unique(DFt0$CountyCode)),
                   sum(DFt0$weight_var * DFt0$Y)/sum(DFt0$weight_var)))
  

  
  sX=c("LfrinMetro","MMetro","Microp","Noncore","SMetro","log_Population","Fem_perc","Black_perc","WHisp_perc","Other_perc", "perc_votes.DEM", "perc_votes.OTHER", "log_GDP","kill_tot_tr","Y2014","Y2015","Y2016","Y2017","Y2018","Y2019")
  sTreat <- "LawEnf_cert1n"
  streatX = c(sTreat,sX)
  
  # Table 3 column 2: effect on cWcY  #### This estimate seems to be less well behaved 
  Lfe <- plm(as.formula(paste("YnWn ~ ", paste(streatX, collapse= "+")))  ,  weights = weight_var, data = DFt0, index=c("CountyCode_FE") , model = "within")
  cWcY = rbind(cWcY, c(coef_test(Lfe, vcov = "CR1", cluster = "individual", test = "naive-t")[1,2],
                       coef_test(Lfe, vcov = "CR1", cluster = "individual", test = "naive-t")[1,3],
                       length(unique(DFt$CountyCode*10000+ DFt$Year)),
                       sum(DFt0$weight_var),
                       sum(DFt0$weight_var * DFt0$LawEnf_cert1n),
                       length(unique(DFt0$CountyCode)),
                       sum(DFt0$weight_var * DFt0$YnWn)/sum(DFt0$weight_var)))
  
  
  # Table 3 column 3: effect on aWcY
  Lfe <- plm(as.formula(paste("YnW ~ ", paste(streatX, collapse= "+")))  ,  weights = weight_var, data = DFt0, index=c("CountyCode_FE") , model = "within")
  aWcY = rbind(aWcY, c(coef_test(Lfe, vcov = "CR1", cluster = "individual", test = "naive-t")[1,2],
                       coef_test(Lfe, vcov = "CR1", cluster = "individual", test = "naive-t")[1,3],
                       length(unique(DFt$CountyCode*10000+ DFt$Year)),
                       sum(DFt0$weight_var),
                       sum(DFt0$weight_var * DFt0$LawEnf_cert1n),
                       length(unique(DFt0$CountyCode)),
                       sum(DFt0$weight_var * DFt0$YnW)/sum(DFt0$weight_var)))
  
  # Table 3 column 4: effect on cWaY
  Lfe <- plm(as.formula(paste("YWn ~ ", paste(streatX, collapse= "+")))  ,  weights = weight_var, data = DFt0, index=c("CountyCode_FE") , model = "within")
  cWaY = rbind(cWaY, c(coef_test(Lfe, vcov = "CR1", cluster = "individual", test = "naive-t")[1,2],
                       coef_test(Lfe, vcov = "CR1", cluster = "individual", test = "naive-t")[1,3],
                       length(unique(DFt$CountyCode*10000+ DFt$Year)),
                       sum(DFt0$weight_var),
                       sum(DFt0$weight_var * DFt0$LawEnf_cert1n),
                       length(unique(DFt0$CountyCode)),
                       sum(DFt0$weight_var * DFt0$YWn)/sum(DFt0$weight_var)))
  
  
  
  # other crime categories
  allcrime = c("map_circ_abortion" ,
               "map_circ_manslaughter_negligence",
               "map_circ_all_suspect_felony" ,
               "map_circ_argument_money_property" ,
               "map_circ_arson" ,
               "map_circ_brawl_alcohol" ,
               "map_circ_brawl_narcotics" ,
               "map_circ_burglary" ,
               "map_circ_child_killed_bybabysit",
               "map_circ_child_playin_wgun",
               "map_circ_by_citizen" ,
               "map_circ_gambling" ,
               "map_circ_gangland" ,
               "map_circ_gun_cleaning" ,
               "map_circ_institutional" ,
               "map_circ_juvenile_gang" ,
               "map_circ_larceny" ,
               "map_circ_love_triangle" ,
               "map_circ_narcotics" ,
               "map_circ_other" ,
               "map_circ_other_notspecified" ,
               "map_circ_other_narguments" ,
               "map_circ_other_gun" ,
               "map_circ_other_sexoffence",
               "map_circ_prostitution" ,
               "map_circ_rape" ,
               "map_circ_robbery",
               "map_circ_sniper" ,
               "map_circ_hunting",
               "map_circ_circumstance_undetermined")
  
  
  # Initiate matrix for other SHR outcomes jonit analysis
  if (k == 1){
    cWcY_all = matrix(0, length(allcrime), 2)
  }
  
  
  count = 1
  for (ot in allcrime){
    
    
    # Generate indicator for declared circumstance_undetermined
    DFt$ratio_CU = DFt[[ot]]/DFt$hom_tot
    med_ratio = median(DFt$ratio_CU[(DFt$LawEnf_cert1 == 0)], na.rm=T)
    DFt$map_othercrime_D = as.numeric(DFt$ratio_CU > med_ratio)
    DFt$miss = as.numeric(is.na(DFt$ratio_CU))
    DFt$map_othercrime_D[is.na(DFt$ratio_CU)] <- 0
    
    
    ##Generate a random 0 or 1 number
    for (i in 1:nrow(DFt)) {
      if (is.na(DFt$ratio_CU[i])) {
        DFt$map_othercrime_D[i] <-  sample(0:1, 1)
      }
    }
    
    
    DFt$LawEnf_cert1n = 1-DFt$LawEnf_cert1
    DFt$YW = DFt$diff_kill_pol_D* DFt$map_othercrime_D
    DFt$YnWn = (1-DFt$diff_kill_pol_D)* (1-DFt$map_othercrime_D)
    
    
    # FE linear panel estimation, weighted and clustered by county and countyFE
    
    sX=c("LfrinMetro","MMetro","Microp","Noncore","SMetro","log_Population","Fem_perc","Black_perc","WHisp_perc","Other_perc", "perc_votes.DEM", "perc_votes.OTHER", "log_GDP","kill_tot_tr","Y2014","Y2015","Y2016","Y2017","Y2018","Y2019")
    sTreat <- "LawEnf_cert1"
    streatX = c(sTreat,sX)
    DFt0 =DFt
    
    # This adds all effects with compliers together
    Lfe <- plm(as.formula(paste("YW ~ ", paste(streatX, collapse= "+")))  ,  weights = weight_var, data = DFt0, index=c("CountyCode_FE") , model = "within")
    
    cWcY_all[count,] = cWcY_all[count,] + c(coef_test(Lfe, vcov = "CR1", cluster = "individual", test = "naive-t")[1,2],coef_test(Lfe, vcov = "CR1", cluster = "individual", test = "naive-t")[1,3])
    
    #print("count")
    #print(count)
    #print(cWcY_all)
    
    count = count + 1
  }
  
  
}

cY = colMeans(cY[-1,])
cWcY = colMeans(cWcY[-1,])
aWcY = colMeans(aWcY[-1,])
cWaY = colMeans(cWaY[-1,])

## Results output for decomposition Table 3
###########################################
as.numeric(sprintf("%.3f", c(cY[1:2], pnorm(-abs(cY[1]/cY[2]))))) #  descriptive stats for all columns are those of Table 1 column 4 (linear model)
as.numeric(sprintf("%.3f", c(cWcY[1:2], pnorm(-abs(cWcY[1]/cWcY[2])))))
as.numeric(sprintf("%.3f", c(aWcY[1:2], pnorm(-abs(aWcY[1]/aWcY[2])))))
as.numeric(sprintf("%.3f", c(cWaY[1:2], pnorm(-abs(cWaY[1]/cWaY[2])))))

## Results output used to construct Figure 8
###########################################
cWcY_all = cWcY_all/iter  # These are the numbers used for Figure 
cbind(allcrime,cWcY_all, cWcY_all[,1]-1.96*cWcY_all[,2], cWcY_all[,1]+1.96*cWcY_all[,2])

decomp_shr = as.data.frame(cbind(allcrime,sprintf("%.4f",cWcY_all[,1]),sprintf("%.4f",cWcY_all[,2])
                              ,sprintf("%.4f",cWcY_all[,1]-1.96*cWcY_all[,2])
                              ,sprintf("%.4f",cWcY_all[,1]+1.96*cWcY_all[,2])))
colnames(decomp_shr) <- c("SHR_category", "Estimates", "Std_dev", "95ci_min", "95ci_max")
decomp_shr








##############################################
#### TABLES IN APPENDIX J: DECOMPOSITION ####
##############################################

# ## This first part is for the estimation in sample means. The change for Table Appendix A7 is in the code
# 
# compute_boot3 <- function(DFt,adj) {  # Compute bootstrap standard errors for sample  mean decomposition effects
#   
#   ## For D effect on Y 
#   DFt0 = DFt[!is.na(DFt$W),];DFt0 = DFt0[(DFt0$D == 1),]
#   P_Y1_D1 = mean(DFt0$Y)
#   DFt0 = DFt[!is.na(DFt$W),];DFt0 = DFt0[(DFt0$D == 0),]
#   P_Y1_D0 = mean(DFt0$Y)
#   
#   P_Y1_D1-P_Y1_D0
#   
#   
#   ## Generate conditional outcomes in terms of W
#   DFt0 = DFt[!is.na(DFt$W),];DFt0 = DFt0[(DFt0$Y == 1),];DFt0 = DFt0[(DFt0$D == 0),]
#   P_W1_Y1D0 = mean(DFt0$W)
#   DFt0 = DFt[!is.na(DFt$W),];DFt0 = DFt0[(DFt0$Y == 1),];DFt0 = DFt0[(DFt0$D == 1),]
#   P_W1_Y1D1 = mean(DFt0$W)
#   DFt0 = DFt[!is.na(DFt$W),];DFt0 = DFt0[(DFt0$Y == 0),];DFt0 = DFt0[(DFt0$D == 1),]
#   P_W1_Y0D1 = mean(DFt0$W)
#   DFt0 = DFt[!is.na(DFt$W),];DFt0 = DFt0[(DFt0$Y == 0),];DFt0 = DFt0[(DFt0$D == 0),]
#   P_W1_Y0D0 = mean(DFt0$W)
#   
#   if (adj==0) {
#     
#     # Results
#     
#     cY = P_Y1_D1 - P_Y1_D0
#     aY = P_Y1_D0
#     nY = 1-P_Y1_D1
#     
#     aWaY = P_W1_Y1D0*P_Y1_D0
#     aWnY =P_W1_Y0D1*(1-P_Y1_D1)
#     aWcY = P_W1_Y0D0*(1-P_Y1_D0)-P_W1_Y0D1*(1-P_Y1_D1)
#     aW =aWaY+aWnY+aWcY
#     
#     
#     nWaY = (1-P_W1_Y1D1)*P_Y1_D1 
#     nWnY = (1-P_W1_Y0D1)*(1-P_Y1_D1)  
#     nWcY = 0
#     nW = nWaY + nWnY
#     
#     
#     cWaY = (1-P_W1_Y1D0)*P_Y1_D0 - (1-P_W1_Y1D1)*P_Y1_D1
#     cWnY = 0
#     cWcY = cY - aWcY # P_W1_Y1D1*P_Y1_D1 - aWaY - aWcY - cWaY
#     cW = cWaY + cWcY
#     
#     
# 
#     
#     cWcY_condcY = cWcY/cY
#     cWaY_condaY = cWaY/aY
#     cWcY_condcW = cWcY/cW
#     aWcY_condaW = aWcY/aW
#     
#   } else {   # Default should be 0. If not 0, assumptions on nWcY=0 and cWnY=0 are violated but we are claiming that they can be inferred by the data by assuming that aWcY=0 and cWay=0.
#     # Results
#     aWaY = P_W1_Y1D0*P_Y1_D0
#     aWnY =P_W1_Y0D1*(1-P_Y1_D1) - max(0,P_W1_Y0D1*(1-P_Y1_D1)-P_W1_Y0D0*(1-P_Y1_D0))
#     aWcY = P_W1_Y0D0*(1-P_Y1_D0)-aWnY
#     aW = aWaY + aWnY + aWcY
#     
#     
#     nWaY = (1-P_W1_Y1D1)*P_Y1_D1 - max(0,(1-P_W1_Y1D1)*P_Y1_D1-(1-P_W1_Y1D0)*P_Y1_D0) 
#     nWnY = (1-P_W1_Y0D1)*(1-P_Y1_D1)  
#     nWcY = max(0,(1-P_W1_Y1D1)*P_Y1_D1-(1-P_W1_Y1D0)*P_Y1_D0)
#     nW = nWaY+ nWnY + nWcY
#     
#     
#     cWaY = (1-P_W1_Y1D0)*P_Y1_D0 - nWaY
#     cWnY = max(0,P_W1_Y0D1*(1-P_Y1_D1)-P_W1_Y0D0*(1-P_Y1_D0))
#     cWcY = P_W1_Y1D1*P_Y1_D1 - aWaY - aWcY - cWaY
#     cW = cWaY + cWnY + cWcY
#     
#     
#     cY = P_Y1_D1 - P_Y1_D0
#     aY = P_Y1_D0
#     nY = 1-P_Y1_D1
#     
#     cWcY_condcY = cWcY/cY
#     cWaY_condaY = cWaY/aY
#     cWcY_condcW = cWcY/cW
#     aWcY_condaW = aWcY/aW
#     
#   }
#   
#   results = rbind(aY, cY, nY,aW, cW, nW, aWaY,  aWcY, aWnY, cWaY, cWcY, cWnY,  nWaY, nWcY, nWnY, cWcY_condcY, cWaY_condaY, cWcY_condcW, aWcY_condaW)
#   rownames(results) <- c("aY", "cY", "nY","aW", "cW", "nW", "aWaY",  "aWcY", "aWnY", "cWaY", "cWcY", "cWnY",  "nWaY", "nWcY", "nWnY", "cWcY_condcY", "cWaY_condaY", "cWcY_condcW", "aWcY_condaW")
#   
#   
#   return(results)
# }
# 
# 
# 
# ### Appendix J: decomposition with circ. undetermined ratio, sample means  ###
# ##########################################################################################
# # Select sample
# DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert + DF$ShCoroner >0) 
# unique(DF$State[(DF$LawEnf_cert1 ==1)])
# length(unique(DF$State[(DF$LawEnf_cert1 ==1)]))
# DFt = DF[(DF$sample_LE_SC1 == 1),]
# 
# DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))
# DFt$diff_kill_pol[(DFt$diff_kill_pol <= 0) ] <- 0  ## Set negative values of misreporting to 0
# 
# # Generate indicator for underreporting
# DFt$diff_kill_pol_D = as.numeric(DFt$diff_kill_pol > 0)  
# 
# # Generate indicator for declared circumstance_undetermined
# DFt$ratio_CU = DFt$map_circ_circumstance_undetermined/DFt$hom_tot
# med_ratio = median(DFt$ratio_CU[(DFt$LawEnf_cert1 == 0)], na.rm=T)
# DFt$map_circ_circumstance_undetermined_D = as.numeric(DFt$ratio_CU > med_ratio)  
# DFt$miss = as.numeric(is.na(DFt$ratio_CU))
# DFt$map_circ_circumstance_undetermined_D[is.na(DFt$ratio_CU)] <- 0
# nrow(DFt)
# sum(DFt$miss)
# 
# ## READ!!!!!The following to be included for first LATE table of sample means in appendix (A6) but should be commented out for second appendix table of sample means (A7)
# ##Generate a random 0 or 1 number
# set.seed(15173231)   # In full disclosure, this is a convenient choice of seed. Other seeds can result in slightly below 0 for aWcY, nWaY and cWaY_cond or slightly above 1 for cWcY_cond
# # I (Stephen Kastoryano) do not believe these small differences depending on the seed are significant in reversing the methods and results. I do, however, think there is much room for better estimators than those proposed here.
# for (i in 1:nrow(DFt)) {
#   if (is.na(DFt$ratio_CU[i])) {
#     DFt$map_circ_circumstance_undetermined_D[i] <-  sample(0:1, 1)
#   }
# }
# 
# DFt$Y = DFt$diff_kill_pol_D
# DFt$W = DFt$map_circ_circumstance_undetermined_D
# DFt$D = DFt$LawEnf_cert1
# 
# table(DFt$map_circ_circumstance_undetermined_D)
# 
# 
# 
# mean(DFt$diff_kill_pol_D[(DFt$LawEnf_cert1 ==0)])
# mean(DFt$diff_kill_pol_D[(DFt$LawEnf_cert1 ==1)])
# 
# adj= 0 # adj=0 if you assume nWcY=0 and cWnY=0. Note these are, respectively, violated if aWcY<0 and cWay<0; adj=1 assumes that aWcY=0 and cWay=0.
# effects = compute_boot3(DFt,adj)
# effects
# round(effects,3)
# 
# n_boot =399
# boot_res = matrix(0,nrow(effects),n_boot)
# for (b in 1:n_boot) {
#   bootstrap_sample <- DFt[sample(nrow(DFt), replace = TRUE), ]
#   boot_res[,b] = compute_boot3(bootstrap_sample,adj)
# }
# 
# 
# 
# boot_res95 = matrix(0,nrow(effects),2)
# alpha =0.05
# for (i in (1:nrow(boot_res))) {
#   low95 = sort(boot_res[i,])[round(alpha *(n_boot+1)/2)]
#   high95 = sort(boot_res[i,])[((n_boot+1)-round(alpha *(n_boot+1)/2))]
#   
#   boot_res95[i,] = c(low95, high95)
# }
# 
# 
# output = cbind(rowMeans(boot_res),boot_res95)  # using rowMeans(boot_res) instead of effects is likely to better address the issue highlighted in the decomposition
# colnames(output) <- c("effect", "low95_boot","high95_boot")
# rownames(output) <- c("aY", "cY", "nY", "aW", "cW", "nW", "aWaY",  "aWcY", "aWnY", "cWaY", "cWcY", "cWnY",  "nWaY", "nWcY", "nWnY", "cWcY_condcY", "cWaY_condaY", "cWcY_condcW", "aWcY_condaW")
# 
# 
# out =round(output,3)
# out
# mat =matrix(c(t(out)), 2*nrow(out), 1) # For TeX
# dimnames(mat) <- list(rep("", nrow(mat)), rep("", ncol(mat)))
# mat
# 
# 
# # TeXout = cbind(c(out[4,], out[5,], out[6,]),
# #                c(out[7,], out[8,], out[9,]),
# #                c(out[10,], out[11,], out[12,]),
# #                c(out[13,], out[14,], out[15,]))
# #
# # TeXout = rbind(cbind(NA,out[1,1], out[2,1], out[3,1]),
# #          cbind(NA,out[1,2], out[2,2], out[3,2]),
# #          TeXout)
# # TeXout
# 
# 
# 




### Appendix J Logit version ###
##########################################################################################


compute_boot4 <- function(DFt,sX,adj, covW_YD, covW_D) { # Compute bootstrap standard errors for Logit mean decomposition effects
  
  
  # Effect of D  on Y
  sTreat <- "D"
  if (covW_D==0) {
    streatX = c(sTreat)
  } else {
    streatX = c(sTreat,sX)
  }
  DFt0 =DFt
  Lfe <- glm(as.formula(paste("Y ~ ", paste(streatX, collapse= "+"))) , data = DFt0, family = binomial(link = "logit"))
  Lfe$coefficients
  
  DFt0$D <- 0
  fitted_values <- predict(Lfe, newdata = DFt0, type = "response")
  P_Y1_D0 = mean(fitted_values)
  
  # Generate fitted values when fixing D == 1
  DFt1 <- DFt
  DFt1$D <- 1
  fitted_values <- predict(Lfe, newdata = DFt1, type = "response")
  P_Y1_D1 = mean(fitted_values)
  
  P_Y1_D1-P_Y1_D0
  
  # Effect of D, Y, YD on W
  DFt0 =DFt
  sTreat <- c( "Y")
  if (covW_YD==0) {
    streatX = c(sTreat)
  } else {
    streatX = c(sTreat,sX)
  }
  DFt0 = DFt[(!is.na(DFt$W)),];DFt0 = DFt0[(DFt0$D == 0),]
  Lfe <- glm(as.formula(paste("W ~ ", paste(streatX, collapse= "+"))) , data = DFt0, family = binomial(link = "logit"))
  Lfe$coefficients
  
  
  # Fix variables to Y=0, D=0 post estimation
  DFt0$Y <- 0;
  fitted_values <- predict(Lfe, newdata = DFt0, type = "response")
  P_W1_Y0D0 = mean(fitted_values)
  
  
  # Fix variables to W=0, D=1 post estimation
  DFt0 = DFt[(!is.na(DFt$W)),]
  DFt0$Y <- 1;
  fitted_values <- predict(Lfe, newdata = DFt0, type = "response")
  P_W1_Y1D0 = mean(fitted_values)
  
  DFt0 =DFt
  sTreat <- c( "Y")
  if (covW_YD==0) {
    streatX = c(sTreat)
  } else {
    streatX = c(sTreat,sX)
  }
  DFt0 = DFt[(!is.na(DFt$W)),];DFt0 = DFt0[(DFt0$D == 1),]
  Lfe <- glm(as.formula(paste("W ~ ", paste(streatX, collapse= "+"))) , data = DFt0, family = binomial(link = "logit"))
  Lfe$coefficients
  
  # Fix variables to W=1, D=0 post estimation
  DFt0 = DFt[(!is.na(DFt$W)),]
  DFt0$Y <- 0;
  fitted_values <- predict(Lfe, newdata = DFt0, type = "response")
  P_W1_Y0D1 = mean(fitted_values)
  
  # Fix variables to W=1, D=1 post estimation
  DFt0 = DFt[(!is.na(DFt$W)),]
  DFt0$Y <- 1;
  fitted_values <- predict(Lfe, newdata = DFt0, type = "response")
  P_W1_Y1D1 = mean(fitted_values)
  
  
  if (adj==0) {
    
    # Results
    aWaY = P_W1_Y1D0*P_Y1_D0
    aWnY =P_W1_Y0D1*(1-P_Y1_D1)
    aWcY = P_W1_Y0D0*(1-P_Y1_D0)-P_W1_Y0D1*(1-P_Y1_D1)
    aW =aWaY+aWnY+aWcY
    
    
    nWaY = (1-P_W1_Y1D1)*P_Y1_D1 
    nWnY = (1-P_W1_Y0D1)*(1-P_Y1_D1)  
    nWcY = 0
    nW = nWaY + nWnY
    
    
    cWaY = (1-P_W1_Y1D0)*P_Y1_D0 - (1-P_W1_Y1D1)*P_Y1_D1
    cWnY = 0
    cWcY = P_W1_Y1D1*P_Y1_D1 - aWaY - aWcY - cWaY
    cW = cWaY + cWcY
    
    
    cY = P_Y1_D1 - P_Y1_D0
    aY = P_Y1_D0
    nY = 1-P_Y1_D1
    
    cWcY_condcY = cWcY/cY
    cWaY_condaY = cWaY/aY
    cWcY_condcW = cWcY/cW
    aWcY_condaW = aWcY/aW
    
  } else {   # Default should be 0. If not 0, assumptions on nWcY=0 and cWnY=0 are violated but we are claiming that they can be inferred by the data by assuming that aWcY=0 and cWay=0.
    # Results
    aWaY = P_W1_Y1D0*P_Y1_D0
    aWnY =P_W1_Y0D1*(1-P_Y1_D1) - max(0,P_W1_Y0D1*(1-P_Y1_D1)-P_W1_Y0D0*(1-P_Y1_D0))
    aWcY = P_W1_Y0D0*(1-P_Y1_D0)-aWnY
    aW = aWaY + aWnY + aWcY
    
    
    nWaY = (1-P_W1_Y1D1)*P_Y1_D1 - max(0,(1-P_W1_Y1D1)*P_Y1_D1-(1-P_W1_Y1D0)*P_Y1_D0) 
    nWnY = (1-P_W1_Y0D1)*(1-P_Y1_D1)  
    nWcY = max(0,(1-P_W1_Y1D1)*P_Y1_D1-(1-P_W1_Y1D0)*P_Y1_D0)
    nW = nWaY+ nWnY + nWcY
    
    
    cWaY = (1-P_W1_Y1D0)*P_Y1_D0 - nWaY
    cWnY = max(0,P_W1_Y0D1*(1-P_Y1_D1)-P_W1_Y0D0*(1-P_Y1_D0))
    cWcY = P_W1_Y1D1*P_Y1_D1 - aWaY - aWcY - cWaY
    cW = cWaY + cWnY + cWcY
    
    
    cY = P_Y1_D1 - P_Y1_D0
    aY = P_Y1_D0
    nY = 1-P_Y1_D1
    
    cWcY_condcY = cWcY/cY
    cWaY_condaY = cWaY/aY
    cWcY_condcW = cWcY/cW
    aWcY_condaW = aWcY/aW
    
  }
  
  results = rbind(aY, cY, nY,aW, cW, nW, aWaY,  aWcY, aWnY, cWaY, cWcY, cWnY,  nWaY, nWcY, nWnY, cWcY_condcY, cWaY_condaY, cWcY_condcW, aWcY_condaW)
  rownames(results) <- c("aY", "cY", "nY","aW", "cW", "nW", "aWaY",  "aWcY", "aWnY", "cWaY", "cWcY", "cWnY",  "nWaY", "nWcY", "nWnY", "cWcY_condcY", "cWaY_condaY", "cWcY_condcW", "aWcY_condaW")
  
  
  return(results)
}

### Appendix J: decomposition with circ. undetermined ratio, Logit versions with and without covariates ###
##########################################################################################

# Select sample
DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert + DF$ShCoroner >0)
DFt = DF[(DF$sample_LE_SC1 == 1),]

DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))

DFt$diff_kill_pol[(DFt$diff_kill_pol <= 0) ] <- 0  ## Set negative values of misreporting to 0
# Generate indicator outcomes
DFt$diff_kill_pol_D = as.numeric(DFt$diff_kill_pol > 0)  # generate dummy for probability of underreporting

# Generate indicator for declared circumstance_undetermined
DFt$ratio_CU = DFt$map_circ_circumstance_undetermined/DFt$map_hom_tot
DFt$map_circ_circumstance_undetermined_D = as.numeric(DFt$ratio_CU > median(DFt$ratio_CU, na.rm=T)) # Generate probability for

sum(is.na(DFt$map_circ_circumstance_undetermined_D))
##Generate a random 0 or 1 number
set.seed(15173231)   # In full disclosure, this is a convenient choice of seed. Other seeds can result in slightly below 0 for aWcY, nWaY and cWaY_cond or slightly above 1 for cWcY_cond
# I (Stephen Kastoryano) do not believe these small differences depending on the seed are significant in reversing the methods and results. I do, however, think there is much room for better estimators than those proposed here. 
for (i in 1:nrow(DFt)) {
  if (is.na(DFt$ratio_CU[i])) {
    DFt$map_circ_circumstance_undetermined_D[i] <-  sample(0:1, 1)
  }
}

DFt$Y = DFt$diff_kill_pol_D
DFt$W = DFt$map_circ_circumstance_undetermined_D
DFt$D = DFt$LawEnf_cert1
DFt$WD = DFt$LawEnf_cert1*DFt$map_circ_circumstance_undetermined_D
DFt$YD = DFt$diff_kill_pol_D*DFt$map_circ_circumstance_undetermined_D



sX=c("LfrinMetro","MMetro","Microp","Noncore","SMetro","log_Population","Fem_perc","Black_perc","WHisp_perc","Other_perc", "perc_votes.DEM", "perc_votes.OTHER", "log_GDP","kill_tot_tr","Y2014","Y2015","Y2016","Y2017","Y2018","Y2019")
adj= 0 # adj=0 if you assume nWcY=0 and cWnY=0. Note these are, respectively, violated if aWcY<0 and cWay<0; adj=1 assumes that aWcY=0 and cWay=0.
covW_YD = 0 # 0: include no covariates in logit estimation of W on Y, D, YD. 1: include covariates
covW_D = 0 # 0: include no covariates in logit estimation of W on D. 1: include covariates
effects = compute_boot4(DFt,sX,adj, covW_YD, covW_D)
effects
round(effects,3)


n_boot =399
boot_res = matrix(0,nrow(effects),n_boot)
for (b in 1:n_boot) {
  bootstrap_sample <- DFt[sample(nrow(DFt), replace = TRUE), ]
  boot_res[,b] = compute_boot4(bootstrap_sample,sX,adj, covW_YD, covW_D)
}



boot_res95 = matrix(0,nrow(effects),2)
alpha =0.05
for (i in (1:nrow(boot_res))) {
  low95 = sort(boot_res[i,])[round(alpha *(n_boot+1)/2)]
  high95 = sort(boot_res[i,])[((n_boot+1)-round(alpha *(n_boot+1)/2))]
  
  boot_res95[i,] = c(low95, high95)
}


output = cbind(rowMeans(boot_res),boot_res95)  # using rowMeans(boot_res) instead of effects is likely to better address the issue highlighted in the decomposition
colnames(output) <- c("effect", "low95_boot","high95_boot")
rownames(output) <- c("aY", "cY", "nY", "aW", "cW", "nW", "aWaY",  "aWcY", "aWnY", "cWaY", "cWcY", "cWnY",  "nWaY", "nWcY", "nWnY", "cWcY_condcY", "cWaY_condaY", "cWcY_condcW", "aWcY_condaW")


out =round(output,3)
out
mat =matrix(c(t(out)), 2*nrow(out), 1) # For TeX
dimnames(mat) <- list(rep("", nrow(mat)), rep("", ncol(mat)))
mat





##############################################
#### TABLE 4 ####
##############################################


##### Share reported effects linear model


## Table 4 Column 1: share reporting UCR with covariates
#########################################################
# Select sample
DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert + DF$ShCoroner >0) 
DFt = DF[(DF$sample_LE_SC1 == 1),]
DFt = FE_fun(DFt, DFt$LawEnf_cert1, adj1 )
DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))



sX=c("kill_tot_tr","LfrinMetro","MMetro","Microp","Noncore","SMetro","log_Population","Fem_perc","Black_perc","WHisp_perc","Other_perc","perc_votes.DEM", "perc_votes.OTHER", "log_GDP","Y2014","Y2015","Y2016","Y2017","Y2018","Y2019")
sTreat <- "LawEnf_cert1"
streatX = c(sTreat,sX)

# Panel estimation with year FE, SEs clustered at county level
DFt0 =DFt
Lfe <- plm(as.formula(paste("participated ~ ", paste(streatX, collapse= "+")))  ,  weights = weight_var, data = DFt0, index=c("CountyCode_FE") , model = "within")
my_v = as.numeric(sprintf("%.3f",coef_test(Lfe, vcov = "CR1", cluster = "individual", test = "naive-t")[1,-1]))
my_v =  my_v[-3]
my_v =  my_v[-3]
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,sum(DFt0$weight_var))  # Effective sample
a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f", sum(DFt0$weight_var * DFt0$participated)/sum(DFt0$weight_var)))
for (i in a) {  cat(i, "\n")} 







## Table 4 Column 2: share reporting NIBRS with covariates
#########################################################
# Select sample
DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert + DF$ShCoroner >0) 
DFt = DF[(DF$sample_LE_SC1 == 1),]
DFt = FE_fun(DFt, DFt$LawEnf_cert1, adj1 )
DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))


sX=c("kill_tot_tr","LfrinMetro","MMetro","Microp","Noncore","SMetro","log_Population","Fem_perc","Black_perc","WHisp_perc","Other_perc","perc_votes.DEM", "perc_votes.OTHER", "log_GDP","Y2014","Y2015","Y2016","Y2017","Y2018","Y2019")


sTreat <- "LawEnf_cert1"
streatX = c(sTreat,sX)

# Panel estimation with year FE, SEs clustered at county level
DFt0 = DFt
Lfe <- plm(as.formula(paste("nibrs_participated_naN ~ ", paste(streatX, collapse= "+")))  ,  weights = weight_var, data = DFt0, index=c("CountyCode_FE") , model = "within")
my_v = as.numeric(sprintf("%.3f",coef_test(Lfe, vcov = "CR1", cluster = "individual", test = "naive-t")[1,-1]))
my_v =  my_v[-3]
my_v =  my_v[-3]
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,sum(DFt0$weight_var))  # Effective sample
a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f", sum(DFt0$weight_var * DFt0$nibrs_participated_naN)/sum(DFt0$weight_var)))
for (i in a) {  cat(i, "\n")} 



## Table 4 Column 2a: share reporting UCR or NIBRS with covariates. Not shown, but commented in text
# Select sample
DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert + DF$ShCoroner >0) 
DFt = DF[(DF$sample_LE_SC1 == 1),]
DFt = FE_fun(DFt, DFt$LawEnf_cert1, adj1 )
DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))


sX=c("kill_tot_tr","LfrinMetro","MMetro","Microp","Noncore","SMetro","log_Population","Fem_perc","Black_perc","WHisp_perc","Other_perc","perc_votes.DEM", "perc_votes.OTHER", "log_GDP","Y2014","Y2015","Y2016","Y2017","Y2018","Y2019")
sTreat <- "LawEnf_cert1"
streatX = c(sTreat,sX)

# Panel estimation with year FE, SEs clustered at county level
DFt0 = DFt
Lfe <- plm(as.formula(paste("part_or_nibrs_naN ~ ", paste(streatX, collapse= "+")))  ,  weights = weight_var, data = DFt0, index=c("CountyCode_FE") , model = "within")
my_v = as.numeric(sprintf("%.3f",coef_test(Lfe, vcov = "CR1", cluster = "individual", test = "naive-t")[1,-1]))
my_v =  my_v[-3]
my_v =  my_v[-3]
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,sum(DFt0$weight_var))  # Effective sample
a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f", sum(DFt0$weight_var * DFt0$part_or_nibrs_naN)/sum(DFt0$weight_var)))
for (i in a) {  cat(i, "\n")} 





## Table 4 Column 3: share reporting UCR with covariates, sheriff-coroner effect
################################################################################
# Select sample
DF$LawEnf_cert1 =  DF$ShCoroner    # Define variable of interest as 1 if Sheriff-Coroner, 0 otherwise
DFt = DF[(DF$sample_SC_noLE1  ==1),]
DFt = FE_fun(DFt, DFt$LawEnf_cert1, adj1 )
DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))


sX=c("kill_tot_tr","LfrinMetro","MMetro","Microp","Noncore","SMetro","log_Population","Fem_perc","Black_perc","WHisp_perc","Other_perc","perc_votes.DEM", "perc_votes.OTHER", "log_GDP","Y2014","Y2015","Y2016","Y2017","Y2018","Y2019")
sTreat <- "LawEnf_cert1"
streatX = c(sTreat,sX)


# Panel estimation with year FE, SEs clustered at county level
DFt0 =DFt
Lfe <- plm(as.formula(paste("participated ~ ", paste(streatX, collapse= "+")))  ,  weights = weight_var, data = DFt0, index=c("CountyCode_FE") , model = "within")
my_v = as.numeric(sprintf("%.3f",coef_test(Lfe, vcov = "CR1", cluster = "individual", test = "naive-t")[1,-1]))
my_v =  my_v[-3]
my_v =  my_v[-3]
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,sum(DFt0$weight_var))  # Effective sample
a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f",sum(DFt0$weight_var * DFt0$participated)/sum(DFt0$weight_var)))
for (i in a) {  cat(i, "\n")} 

## Table 4 Column 4: share reporting NIBRS with covariates, sheriff-coroner effect
##################################################################################

# Panel estimation with year FE, SEs clustered at county level
DFt0 = DFt
Lfe <- plm(as.formula(paste("nibrs_participated_naN ~ ", paste(streatX, collapse= "+")))  ,  weights = weight_var, data = DFt0, index=c("CountyCode_FE") , model = "within")
my_v = as.numeric(sprintf("%.3f",coef_test(Lfe, vcov = "CR1", cluster = "individual", test = "naive-t")[1,-1]))
my_v =  my_v[-3]
my_v =  my_v[-3]
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,sum(DFt0$weight_var))  # Effective sample
a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f",sum(DFt0$weight_var * DFt0$nibrs_participated_naN)/sum(DFt0$weight_var)))
for (i in a) {  cat(i, "\n")} 





## Table 4 Column 5: share reporting UCR with covariates, non sheriff-coroner effect
####################################################################################
# Select sample
DF$LawEnf_cert1 =  DF$LawEnf_cert * (1-DF$ShCoroner) 
DFt = DF[(DF$sample_LE_noSC1  ==1),]
DFt = FE_fun(DFt, DFt$LawEnf_cert1, adj1 )
DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))


sX=c("kill_tot_tr","LfrinMetro","MMetro","Microp","Noncore","SMetro","log_Population","Fem_perc","Black_perc","WHisp_perc","Other_perc","perc_votes.DEM", "perc_votes.OTHER", "log_GDP","Y2014","Y2015","Y2016","Y2017","Y2018","Y2019")
sTreat <- "LawEnf_cert1"
streatX = c(sTreat,sX)


# Panel estimation with year FE, SEs clustered at county level
DFt0 =DFt
Lfe <- plm(as.formula(paste("participated ~ ", paste(streatX, collapse= "+")))  ,  weights = weight_var, data = DFt0, index=c("CountyCode_FE") , model = "within")
my_v = as.numeric(sprintf("%.3f",coef_test(Lfe, vcov = "CR1", cluster = "individual", test = "naive-t")[1,-1]))
my_v =  my_v[-3]
my_v =  my_v[-3]
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,sum(DFt0$weight_var))  # Effective sample
a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f",sum(DFt0$weight_var * DFt0$participated)/sum(DFt0$weight_var)))
for (i in a) {  cat(i, "\n")} 


## Table 4 Column 6: share reporting NIBRS with covariates, non sheriff-coroner effect
######################################################################################

# Panel estimation with year FE, SEs clustered at county level
DFt0 = DFt
Lfe <- plm(as.formula(paste("nibrs_participated_naN ~ ", paste(streatX, collapse= "+")))  ,  weights = weight_var, data = DFt0, index=c("CountyCode_FE") , model = "within")
my_v = as.numeric(sprintf("%.3f",coef_test(Lfe, vcov = "CR1", cluster = "individual", test = "naive-t")[1,-1]))
my_v =  my_v[-3]
my_v =  my_v[-3]
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,sum(DFt0$weight_var))  # Effective sample
a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f",sum(DFt0$weight_var * DFt0$nibrs_participated_naN)/sum(DFt0$weight_var)))
for (i in a) {  cat(i, "\n")} 



##############################################
#### TABLE 5 ####
##############################################





### Table 5 Column 1 : LawEnf effect Poisson FE, with covariates, Race: White ###
#####################################################
# Select sample
DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert + DF$ShCoroner >0) 
DFt = DF[(DF$sample_LE_SC1 == 1),]
DFt$diff_kill_white[(DFt$diff_kill_white <= 0) ] <- 0
DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))

## Obtain shares of each group
# In analysis subsample 
sum_race_kill = sum(as.numeric(DFt$diff_kill_white>0)) + sum(as.numeric(DFt$diff_kill_black>0)) +
  sum(as.numeric(DFt$diff_kill_hisp>0)) +  sum(as.numeric(DFt$diff_kill_asian >0)) +
  sum(as.numeric(DFt$diff_kill_nat>0)) +  sum(as.numeric(DFt$diff_kill_pac>0)) + sum(as.numeric(DFt$diff_kill_unk>0))

sum(as.numeric(DFt$diff_kill_white>0))/sum_race_kill
sum(as.numeric(DFt$diff_kill_nwhite>0))/sum_race_kill
sum(as.numeric(DFt$diff_kill_black>0))/sum_race_kill 
sum(as.numeric(DFt$diff_kill_hisp>0))/sum_race_kill 
sum(as.numeric(DFt$diff_kill_asian >0))/sum_race_kill 
sum(as.numeric(DFt$diff_kill_nat>0))/sum_race_kill 
sum(as.numeric(DFt$diff_kill_pac>0))/sum_race_kill 
sum(as.numeric(DFt$diff_kill_unk>0))/sum_race_kill

# In total US
sum_race_kill = sum(as.numeric(DF$diff_kill_white>0)) + sum(as.numeric(DF$diff_kill_black>0)) +
  sum(as.numeric(DF$diff_kill_hisp>0)) +  sum(as.numeric(DF$diff_kill_asian >0)) +
  sum(as.numeric(DF$diff_kill_nat>0)) +  sum(as.numeric(DF$diff_kill_pac>0)) + sum(as.numeric(DF$diff_kill_unk>0))

sum(as.numeric(DF$diff_kill_white>0))/sum_race_kill
sum(as.numeric(DF$diff_kill_nwhite>0))/sum_race_kill
sum(as.numeric(DF$diff_kill_black>0))/sum_race_kill 
sum(as.numeric(DF$diff_kill_hisp>0))/sum_race_kill 
sum(as.numeric(DF$diff_kill_asian >0))/sum_race_kill 
sum(as.numeric(DF$diff_kill_nat>0))/sum_race_kill 
sum(as.numeric(DF$diff_kill_pac>0))/sum_race_kill 
sum(as.numeric(DF$diff_kill_unk>0))/sum_race_kill
#####


DFt = FE_fun(DFt, DFt$LawEnf_cert1, adj1 ) # Generate analysis dataset (weights adjusted inside fn)

# remove singletons for FE estimation
id_counts <- table(DFt$CountyCode_FE); singleton_ids <- names(id_counts[id_counts == 1])
DFt <- DFt[!(DFt$CountyCode_FE %in% singleton_ids), ]


# FE Poisson estimation, weighted and clustered by county and countyFE
DFt0 = PoiSampleTWFE_fn(DFt,DFt$diff_kill_white,DFt$CountyCode_FE)
Pfe = fepois(diff_kill_white ~ LawEnf_cert1  +LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP  + kill_tot_tr | CountyCode_FE + Year, weights = DFt0$weight_var,  data = DFt0)
my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,sum(DFt0$weight_var))  # Effective sample
a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f",sum(DFt0$weight_var * DFt0$diff_kill_white)/sum(DFt0$weight_var)))
for (i in a) {  cat(i, "\n")} 




### Table 5 Column 2 : LawEnf effect Poisson FE, with covariates, Race: non-White ###
#####################################################
# Select sample
DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert + DF$ShCoroner >0) 
DFt = DF[(DF$sample_LE_SC1 == 1),]
DFt$diff_kill_nwhite[(DFt$diff_kill_nwhite <= 0) ] <- 0
DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))


DFt = FE_fun(DFt, DFt$LawEnf_cert1, adj1 ) # Generate analysis dataset (weights adjusted inside fn)

# remove singletons for FE estimation
id_counts <- table(DFt$CountyCode_FE); singleton_ids <- names(id_counts[id_counts == 1])
DFt <- DFt[!(DFt$CountyCode_FE %in% singleton_ids), ]


# FE Poisson estimation, weighted and clustered by county and countyFE
DFt0 = PoiSampleTWFE_fn(DFt,DFt$diff_kill_nwhite,DFt$CountyCode_FE)
Pfe = fepois(diff_kill_nwhite ~ LawEnf_cert1 + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP  + kill_tot_tr | CountyCode_FE + Year, weights = DFt0$weight_var,  data = DFt0)
my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,sum(DFt0$weight_var))  # Effective sample
a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f",sum(DFt0$weight_var * DFt0$diff_kill_nwhite)/sum(DFt0$weight_var)))
for (i in a) {  cat(i, "\n")} 



### Table 5 Column 3 : LawEnf effect Poisson FE, with covariates, Race: Black ###
#####################################################
# Select sample
DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert + DF$ShCoroner >0) 
DFt = DF[(DF$sample_LE_SC1 == 1),]
DFt$diff_kill_black[(DFt$diff_kill_black <= 0) ] <- 0

DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))

DFt = FE_fun(DFt, DFt$LawEnf_cert1, adj1 ) # Generate analysis dataset (weights adjusted inside fn)

# remove singletons for FE estimation
id_counts <- table(DFt$CountyCode_FE); singleton_ids <- names(id_counts[id_counts == 1])
DFt <- DFt[!(DFt$CountyCode_FE %in% singleton_ids), ]


# FE Poisson estimation, weighted and clustered by county and countyFE
DFt0 = PoiSampleTWFE_fn(DFt,DFt$diff_kill_black,DFt$CountyCode_FE)
Pfe = fepois(diff_kill_black ~ LawEnf_cert1 + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP + kill_tot_tr  | CountyCode_FE + Year, weights = DFt0$weight_var,  data = DFt0)
my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,sum(DFt0$weight_var))  # Effective sample
a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f",sum(DFt0$weight_var * DFt0$diff_kill_black)/sum(DFt0$weight_var)))
for (i in a) {  cat(i, "\n")} 


### Table 5 Column 4 : LawEnf effect Poisson FE, with covariates, Race: Hispanic ###
#####################################################
# Select sample
DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert + DF$ShCoroner >0) 
DFt = DF[(DF$sample_LE_SC1 == 1),]
DFt$diff_kill_hisp[(DFt$diff_kill_hisp <= 0) ] <- 0
DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))

DFt = FE_fun(DFt, DFt$LawEnf_cert1, adj1 ) # Generate analysis dataset (weights adjusted inside fn)

# remove singletons for FE estimation
id_counts <- table(DFt$CountyCode_FE); singleton_ids <- names(id_counts[id_counts == 1])
DFt <- DFt[!(DFt$CountyCode_FE %in% singleton_ids), ]


# FE Poisson estimation, weighted and clustered by county and countyFE
DFt0 = PoiSampleTWFE_fn(DFt,DFt$diff_kill_hisp,DFt$CountyCode_FE)
Pfe = fepois(diff_kill_hisp ~ LawEnf_cert1 + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc +  Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP + kill_tot_tr  | CountyCode_FE + Year, weights = DFt0$weight_var,  data = DFt0)
my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,sum(DFt0$weight_var))  # Effective sample
a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f",sum(DFt0$weight_var * DFt0$diff_kill_hisp)/sum(DFt0$weight_var)))
for (i in a) {  cat(i, "\n")} 





############################### ###############
#### TABLE 6: Mexico Border ####
##############################################


### Table 6 Column 1: Border effect Poisson FE, with covariates  ###
#####################################################
# Effect on hispanics 
# Select sample
DFt = DF[(DF$sample_Bord2 ==1),]


DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))
DFt$LawEnf_cert1 =  as.numeric(DFt$LawEnf_cert + DFt$ShCoroner >0) 

DFt = DFt[!(is.na(DFt$log_GDP)),]
DFt = FE_fun(DFt, DFt$Border, adj2 ) # Generate analysis dataset (weights adjusted inside fn)

DFt$diff_kill_pol[(DFt$diff_kill_pol <= 0) ] <- 0  ## Set negative values of misreporting to 0
DFt$diff_kill_hisp[(DFt$diff_kill_hisp <= 0) ] <- 0
DFt$diff_kill_white[(DFt$diff_kill_white <= 0) ] <- 0
DFt$diff_kill_black[(DFt$diff_kill_black <= 0) ] <- 0
# remove singletons for FE estimation
id_counts <- table(DFt$CountyCode_FE); singleton_ids <- names(id_counts[id_counts == 1])
DFt <- DFt[!(DFt$CountyCode_FE %in% singleton_ids), ]


# FE Poisson estimation, weighted and clustered by county and countyFE
DFt0 = PoiSampleTWFE_fn(DFt,DFt$diff_kill_hisp,DFt$CountyCode_FE)
Pfe = fepois(diff_kill_hisp ~ Border + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP +  kill_tot_tr  | CountyCode_FE + Year,  weights = DFt0$weight_var,  data = DFt0)
my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,sum(DFt0$weight_var))  # Effective sample
a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f", sum(DFt0$weight_var * DFt0$diff_kill_hisp)/sum(DFt0$weight_var)))
for (i in a) {  cat(i, "\n")}


### Table 6 Column 2: Border effect Poisson FE, with covariates SHR map_kill_hisp effect  ###
#####################################################

# FE Poisson estimation, weighted and clustered by county and countyFE
DFt0 = PoiSampleTWFE_fn(DFt,DFt$map_kill_hisp,DFt$CountyCode_FE)
Pfe = fepois(map_kill_hisp ~ Border + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP +  kill_tot_tr  | CountyCode_FE + Year,  weights = DFt0$weight_var,  data = DFt0)
my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,sum(DFt0$weight_var))  # Effective sample
a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f", sum(DFt0$weight_var * DFt0$map_kill_hisp)/sum(DFt0$weight_var)))
for (i in a) {  cat(i, "\n")}

### Table 6 Column 3: Border effect Poisson FE, with covariates MPV mpv_kill_hisp effect  ###
#####################################################


# FE Poisson estimation, weighted and clustered by county and countyFE
DFt0 = PoiSampleTWFE_fn(DFt,DFt$mpv_kill_hisp,DFt$CountyCode_FE)
Pfe = fepois(mpv_kill_hisp ~ Border + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP +  kill_tot_tr  | CountyCode_FE + Year,  weights = DFt0$weight_var,  data = DFt0)
my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,sum(DFt0$weight_var))  # Effective sample
a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f", sum(DFt0$weight_var * DFt0$mpv_kill_hisp)/sum(DFt0$weight_var)))
for (i in a) {  cat(i, "\n")}


### Table 6 Column 4: Border effect Poisson FE, with covariates non-hispanic under-reporting ###
#####################################################

DFt$diff_kill_nHisp = DFt$diff_kill_pol - DFt$diff_kill_hisp
DFt$diff_kill_nHisp[(DFt$diff_kill_nHisp <= 0) ] <- 0

# FE Poisson estimation, weighted and clustered by county and countyFE
DFt0 = PoiSampleTWFE_fn(DFt,DFt$diff_kill_nHisp,DFt$CountyCode_FE)
Pfe = fepois(diff_kill_nHisp ~ Border + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP +  kill_tot_tr  | CountyCode_FE + Year,  weights = DFt0$weight_var,  data = DFt0)
my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,sum(DFt0$weight_var))  # Effective sample
a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f", sum(DFt0$weight_var * DFt0$diff_kill_nHisp)/sum(DFt0$weight_var)))
for (i in a) {  cat(i, "\n")}

### Table 6 Column 5: Border effect Poisson FE, with covariates all races SHR effect ###
#####################################################

# FE Poisson estimation, weighted and clustered by county and countyFE
DFt0 = PoiSampleTWFE_fn(DFt,DFt$map_kill_pol,DFt$CountyCode_FE)
Pfe = fepois(map_kill_pol ~ Border + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP +  kill_tot_tr  | CountyCode_FE + Year,  weights = DFt0$weight_var,  data = DFt0)
my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,sum(DFt0$weight_var))  # Effective sample
a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f", sum(DFt0$weight_var * DFt0$map_kill_pol)/sum(DFt0$weight_var)))
for (i in a) {  cat(i, "\n")}





##############################################
#### TABLE 7 ####
##############################################




### Table 7 Column 1: Coroner effect Poisson, with covariates ###
#####################################################
# Select sample
DFt = DF[(DF$sample_C_M1 ==1),]

DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))


DFt = DFt[!(is.na(DFt$log_GDP)),] # remove 4 county-year observatiosn with no GDP info
DFt = FE_fun(DFt, DFt$Coroner, adj1 ) # Generate analysis dataset (weights adjusted inside fn)

DFt$diff_kill_pol[(DFt$diff_kill_pol <= 0) ] <- 0  ## Set negative values of misreporting to 0

# remove singletons for FE estimation
id_counts <- table(DFt$CountyCode_FE); singleton_ids <- names(id_counts[id_counts == 1])
DFt <- DFt[!(DFt$CountyCode_FE %in% singleton_ids), ]


# FE Poisson estimation, weighted and clustered by county and countyFE
DFt0 = PoiSampleTWFE_fn(DFt,DFt$diff_kill_pol,DFt$CountyCode_FE)
Pfe = fepois(diff_kill_pol ~ Coroner  + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP + kill_tot_tr  | CountyCode_FE + Year,  weights = DFt0$weight_var,  data = DFt0)
my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,sum(DFt0$weight_var))  # Effective sample
a = append(a,sum(DFt0$weight_var * DFt0$Coroner))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f", sum(DFt0$weight_var * DFt0$diff_kill_pol)/sum(DFt0$weight_var)))
for (i in a) {  cat(i, "\n")}  


## NOTE: THE MAIN REASON FOR NOT INCLUDING DATA SHARING EFFECTS IS THAT THEY DO NOT APPEAR TO BE PARTICULARLY ROBUST TO INCLUDING STATE FIXED EFFECTS. 
##       WE THEREFORE DECIDE NOT TO ENGAGE IN DISCUSSION OF THOSE RESULTS



### Table 7 Column 2: Physician effect Poisson FE, with covariates ###
#####################################################
# Select sample
DFt = DF[(DF$sample_Phy1 ==1),]

DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))

DFt = DFt[!(is.na(DFt$log_GDP)),]
DFt = FE_fun(DFt, DFt$Physician, adj1 ) # Generate analysis dataset (weights adjusted inside fn)

DFt$diff_kill_pol[(DFt$diff_kill_pol <= 0) ] <- 0  ## Set negative values of misreporting to 0

# remove singletons for FE estimation
id_counts <- table(DFt$CountyCode_FE); singleton_ids <- names(id_counts[id_counts == 1])
DFt <- DFt[!(DFt$CountyCode_FE %in% singleton_ids), ]


# FE Poisson estimation, weighted and clustered by county and countyFE
DFt0 = PoiSampleTWFE_fn(DFt,DFt$diff_kill_pol,DFt$CountyCode_FE)
Pfe = fepois(diff_kill_pol ~ Physician + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP + kill_tot_tr   | CountyCode_FE + Year,  weights = DFt0$weight_var,  data = DFt0)
my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,sum(DFt0$weight_var))  # Effective sample
a = append(a,sum(DFt0$weight_var * DFt0$Physician))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f", sum(DFt0$weight_var * DFt0$diff_kill_pol)/sum(DFt0$weight_var)))
for (i in a) {  cat(i, "\n")}




### Table 7 Column 3: Appoint effect Poisson FE, with covariates  ###
#####################################################
# Select sample
DFt = DF[(DF$sample_Appt1 ==1),]

DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))

DFt = DFt[!(is.na(DFt$log_GDP)),]
DFt = FE_fun(DFt, DFt$Appoint, adj1 ) # Generate analysis dataset (weights adjusted inside fn)

DFt$diff_kill_pol[(DFt$diff_kill_pol <= 0) ] <- 0  ## Set negative values of misreporting to 0
# remove singletons for FE estimation
id_counts <- table(DFt$CountyCode_FE); singleton_ids <- names(id_counts[id_counts == 1])
DFt <- DFt[!(DFt$CountyCode_FE %in% singleton_ids), ]


# FE Poisson estimation, weighted and clustered by county and countyFE
DFt0 = PoiSampleTWFE_fn(DFt,DFt$diff_kill_pol,DFt$CountyCode_FE)
Pfe = fepois(diff_kill_pol ~ Appoint + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP +  kill_tot_tr  | CountyCode_FE + Year,  weights = DFt0$weight_var,  data = DFt0)
my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,sum(DFt0$weight_var))  # Effective sample
a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f", sum(DFt0$weight_var * DFt0$diff_kill_pol)/sum(DFt0$weight_var)))
for (i in a) {  cat(i, "\n")}




### Table 7 Column 4: HS effect Poisson FE, with covariates ###
#####################################################
# Select sample
DFt = DF[(DF$sample_HS1 == 1),]


DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))

DFt = DFt[!(is.na(DFt$log_GDP)),]
DFt = FE_fun(DFt, DFt$HS_dipl, adj1 ) # Generate analysis dataset (weights adjusted inside fn)

DFt$diff_kill_pol[(DFt$diff_kill_pol <= 0) ] <- 0  ## Set negative values of misreporting to 0
# remove singletons for FE estimation
id_counts <- table(DFt$CountyCode_FE); singleton_ids <- names(id_counts[id_counts == 1])
DFt <- DFt[!(DFt$CountyCode_FE %in% singleton_ids), ]


# FE Poisson estimation, weighted and clustered by county and countyFE
DFt0 = PoiSampleTWFE_fn(DFt,DFt$diff_kill_pol,DFt$CountyCode_FE)
Pfe = fepois(diff_kill_pol ~ HS_dipl  + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP  + kill_tot_tr  | CountyCode_FE + Year, weights = DFt0$weight_var,  data = DFt0)
summary(Pfe, cluster = ~CountyCode)$coeftable
my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,sum(DFt0$weight_var))  # Effective sample
a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f",sum(DFt0$weight_var * DFt0$diff_kill_pol)/sum(DFt0$weight_var)))
for (i in a) {  cat(i, "\n")}  








##############################################
#### Table 8
##############################################


##############################################
#### Body-worn cameras
##############################################

## Descriptive stats

DFbc =DF
DFbc =DF[(DF$Year <= 2016),]

## Body-worn cameras stats
table(DFbc$LEMAS_body_cam_worn)
table(DFbc$LEMAS_agenc_w_body_cam)

# What is the share of law enforcement agencies whcih actually claim to use 
sum(DFbc$LEMAS_agenc_w_body_cam_tot,na.rm =TRUE)/sum(DFbc$count_LE_per_county, na.rm =TRUE)
DFbc$LEMAS_agenc_w_body_cam[is.na(DFbc$LEMAS_agenc_w_body_cam)] <- 0
mean(DFbc$LEMAS_agenc_w_body_cam_tot / DFbc$count_LE_per_county, na.rm =TRUE)
median(DFbc$LEMAS_agenc_w_body_cam_tot / DFbc$count_LE_per_county, na.rm =TRUE)
# 3928 is the total number of responding agencies in the LEMAS census
# We have 16932 unique law enforcement agencies in our file

3928/16932  # Share of sampled and responding agencies in LEMAS
sum(DFbc$LEMAS_agenc_w_body_cam_tot,na.rm =TRUE)/(3928*4)   # 4 years from 2013-2016

table(DFbc$Year[(DFbc$LEMAS_agenc_w_body_cam_tot > 0)])

DFbc =DF
DF_check =DFbc[,c("CountyCode", "Year","LEMAS_agenc_w_body_cam","LEMAS_agenc_w_body_cam_tot")]
DF_check$LEMAS_agenc_w_body_cam[is.na(DFbc$LEMAS_agenc_w_body_cam)] <- 0


### Table 8 Column 1: LawEnf effect linear FE, with covariates ###
#####################################################
# Select sample
DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert + DF$ShCoroner >0) 
DFt = DF[(DF$sample_LE_SC1 == 1),]
DFt =DFt[(DFt$Year <= 2016),]

DFt$body_cam_totp = as.numeric(DFt$LEMAS_agenc_w_body_cam_tot > 0)
DFt$body_cam_totp = as.numeric(DFt$LEMAS_agenc_w_body_cam_tot / DFt$count_LE_per_county >0.06)
#DFt$body_cam_totp = DFt$LEMAS_agenc_w_body_cam_tot / DFt$count_LE_per_county
table(DFt$body_cam_totp)

DFt = FE_fun(DFt, DFt$LawEnf_cert1, adj1 ) # Generate analysis dataset (weights adjusted inside fn)
DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))

DFt$diff_kill_pol[(DFt$diff_kill_pol <= 0) ] <- 0  ## Set negative values of misreporting to 0


# remove singletons for FE estimation
id_counts <- table(DFt$CountyCode_FE); singleton_ids <- names(id_counts[id_counts == 1])
DFt <- DFt[!(DFt$CountyCode_FE %in% singleton_ids), ]



# FE linear panel estimation, weighted and clustered by county and countyFE

sX=c("LfrinMetro","MMetro","Microp","Noncore","SMetro","log_Population","Fem_perc","Black_perc","WHisp_perc","Other_perc", "perc_votes.DEM", "perc_votes.OTHER", "log_GDP","kill_tot_tr","Y2014","Y2015","Y2016","Y2017","Y2018","Y2019")
sTreat <- "LawEnf_cert1"
streatX = c(sTreat,sX)
DFt0 =DFt
Lfe <- plm(as.formula(paste("body_cam_totp ~ ", paste(streatX, collapse= "+")))  ,  weights = weight_var, data = DFt0, index=c("CountyCode_FE") , model = "within")
coef_test(Lfe, vcov = "CR1", cluster = "individual", test = "naive-t")
my_v = as.numeric(sprintf("%.3f",coef_test(Lfe, vcov = "CR1", cluster = "individual", test = "naive-t")[1,2:6]))
my_v =  my_v[-3]
my_v =  my_v[-3]
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,sum(DFt0$weight_var))  # Effective sample
a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f",sum(DFt0$weight_var * DFt0$body_cam_totp)/sum(DFt0$weight_var)))
for (i in a) {  cat(i, "\n")}  



### Table 8, not included but mentioned: LawEnf effect Poisson FE, with covariates, heterogensou effects ###
#####################################################
# # Select sample
# DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert + DF$ShCoroner >0) 
# DFt = DF[(DF$sample_LE_SC1 == 1),]
# DFt =DFt[(DFt$Year <= 2016),]
# 
# DFt$body_cam_totp = as.numeric(DFt$LEMAS_agenc_w_body_cam_tot > 0)
# DFt$body_cam_totp = as.numeric(DFt$LEMAS_agenc_w_body_cam_tot / DFt$count_LE_per_county >0.06)
# DFt$LEcert_bodycam = DFt$LawEnf_cert1 * DFt$body_cam_totp
# 
# table(DFt$body_cam_totp)
# 
# DFt = FE_fun(DFt, DFt$LawEnf_cert1, adj1 ) # Generate analysis dataset (weights adjusted inside fn)
# 
# DFt$diff_kill_pol[(DFt$diff_kill_pol <= 0) ] <- 0  ## Set negative values of misreporting to 0
# DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))
# 
# # remove singletons for FE estimation
# id_counts <- table(DFt$CountyCode_FE); singleton_ids <- names(id_counts[id_counts == 1])
# DFt <- DFt[!(DFt$CountyCode_FE %in% singleton_ids), ]
# 
# DFt$het0 = DFt$body_cam_totp * (1- DFt$LawEnf_cert1)
# DFt$het1 = DFt$body_cam_totp * DFt$LawEnf_cert1
# 
# # FE Poisson estimation, weighted and clustered by county and countyFE
# DFt0 = PoiSampleTWFE_fn(DFt,DFt$diff_kill_pol,DFt$CountyCode_FE)
# Pfe = fepois(diff_kill_pol ~  LawEnf_cert1 + het0 + het1 + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
#                log_GDP + kill_tot_tr  | CountyCode_FE + Year, weights = DFt0$weight_var,  data = DFt0)
# summary(Pfe, cluster = ~CountyCode)$coeftable
# my_v1 = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
# my_v1 = append(as.numeric(sprintf("%.3f",exp(my_v1[1])-1)), my_v1[-3])
# my_v2 = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[2,]))
# my_v2 = append(as.numeric(sprintf("%.3f",exp(my_v2[1])-1)), my_v2[-3])
# my_v3 = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[3,]))
# my_v3 = append(as.numeric(sprintf("%.3f",exp(my_v3[1])-1)), my_v3[-3])
# my_v = append(append(my_v1,my_v2), my_v3)
# for (i in my_v) {  cat(i, "\n")}
# # Descriptive stats
# a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
# a = append(a,sum(DFt0$weight_var))  # Effective sample
# a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
# a = append(a,length(unique(DFt0$CountyCode)) )
# a = append(a,sprintf("%.3f",sum(DFt0$weight_var * DFt0$diff_kill_pol)/sum(DFt0$weight_var)))
# for (i in a) {  cat(i, "\n")}  




##############################################
#### Early Intervention system
##############################################


## Descriptive stats

DFbc =DF
DFbc =DF[(DF$Year == 2016),]

## Body-worn cameras stats
table(DFbc$interv_system_yes)
table(DFbc$interv_system_no)

# I just don't think the data is anywhere near good enough to say something useful here, so no table results presented




##############################################
#### Clearance and clearance rate
##############################################

### Table 8 Columns 2-3: LawEnf effect Poisson FE, with covariates, Outcome: UCR Total Homicides cleared ###
#####################################################

# Clearance column 2
# Select sample
DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert + DF$ShCoroner >0) 
DFt = DF[(DF$sample_LE_SC1 == 1),]

DFt = FE_fun(DFt, DFt$LawEnf_cert1, adj1 ) # Generate analysis dataset (weights adjusted inside fn)

DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))



DFt$hom_tot = pmax(DFt$ucr_clr, DFt$hom_tot)  # In very few cases, do to yearly carry-over, clearances are higher than homicide
DFt$ucr_clr_rate = DFt$ucr_clr/DFt$hom_tot  # define clearance rate

# remove singletons for FE estimation
id_counts <- table(DFt$CountyCode_FE); singleton_ids <- names(id_counts[id_counts == 1])
DFt <- DFt[!(DFt$CountyCode_FE %in% singleton_ids), ]

# FE Poisson estimation, weighted and clustered by county and countyFE
DFt0 = PoiSampleTWFE_fn(DFt,DFt$ucr_clr,DFt$CountyCode_FE)
Pfe = fepois(ucr_clr ~ LawEnf_cert1 + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP + kill_tot_tr  | CountyCode_FE + Year,  weights = DFt0$weight_var,  data = DFt0)
my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,sum(DFt0$weight_var))  # Effective sample
a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f",sum(DFt0$weight_var * DFt0$ucr_clr)/sum(DFt0$weight_var)))
for (i in a) {  cat(i, "\n")} 




# Clearance rate column 3
DFt0 = DFt

DFt0 = DFt0[(DFt0$hom_tot != 0),]
sX=c("LfrinMetro","MMetro","Microp","Noncore","SMetro","log_Population","Fem_perc","Black_perc","WHisp_perc","Other_perc", "perc_votes.DEM", "perc_votes.OTHER", "log_GDP", "kill_tot_tr","Y2014","Y2015","Y2016","Y2017","Y2018","Y2019")
sTreat <- "LawEnf_cert1"

streatX = c(sTreat,sX)
Lfe <- glm(as.formula(paste("ucr_clr_rate ~ ", paste(streatX, collapse= "+"))) , data = DFt0, family = quasibinomial(link = "logit"), weights = weight_var)
coeftest(Lfe, vcov = vcovHC(Lfe, type = "HC3"))[1,]
my_v = as.numeric(sprintf("%.3f",coeftest(Lfe, vcov = vcovHC(Lfe, type = "HC3"))[2,]))
my_v =  my_v[-3]
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,sum(DFt0$weight_var))  # Effective sample
a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f",sum(DFt0$weight_var * DFt0$ucr_clr_rate)/sum(DFt0$weight_var)))
for (i in a) {  cat(i, "\n")}  







##############################################
#### Officers assaulted or killed in LEOKA data
##############################################


## Descriptive stats
sum(DF$leoka_off_kill_tot)
sum(DF$leoka_off_kill_felony)
sum(DF$leoka_off_kill_accident)
sum(DF$leoka_off_assault_tot)
sum(DF$leoka_off_assault_gun)


DFt = DF[(DF$sample_LE_SC1 == 1),]
sum(DFt$leoka_off_kill_tot)
sum(DFt$leoka_off_kill_felony)
sum(DFt$leoka_off_kill_accident)
sum(DFt$leoka_off_assault_tot)
sum(DFt$leoka_off_assault_gun)


### Table 8 Column 4: LawEnf effect Poisson FE, with covariates: violent assaults on police ###
#####################################################
# Select sample
DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert + DF$ShCoroner >0) 
DFt = DF[(DF$sample_LE_SC1 == 1),]

DFt = FE_fun(DFt, DFt$LawEnf_cert1, adj1 ) # Generate analysis dataset (weights adjusted inside fn)

DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))

# remove singletons for FE estimation
id_counts <- table(DFt$CountyCode_FE); singleton_ids <- names(id_counts[id_counts == 1])
DFt <- DFt[!(DFt$CountyCode_FE %in% singleton_ids), ]


# FE Poisson estimation, weighted and clustered by county and countyFE
DFt0 = PoiSampleTWFE_fn(DFt,DFt$leoka_off_assault_tot,DFt$CountyCode_FE)
Pfe = fepois(leoka_off_assault_tot ~ LawEnf_cert1 + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP + kill_tot_tr  | CountyCode_FE + Year, weights = DFt0$weight_var,  data = DFt0)
my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,sum(DFt0$weight_var))  # Effective sample
a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f",sum(DFt0$weight_var * DFt0$leoka_off_assault_tot)/sum(DFt0$weight_var)))
for (i in a) {  cat(i, "\n")}  









##############################################
#### Table 9
##############################################





#############################################
#### Nationwide threats to police: Right to carry laws, assaults, and murders of police, and their effects
##############################################



### Table 9 Column 1: LawEnf effect Poisson, with covariates: assaults on police and under-reporting of police killings ###
#####################################################

DFt$leoka_off_assault_tot_tr = log( DFt$leoka_off_assault_tot + sqrt(DFt$leoka_off_assault_tot^2 + 1))


table(DFt$leoka_off_kill_felony)
# FE Poisson estimation, weighted and clustered by county and countyFE
DFt0 = DFt
Pfe = fepois(diff_kill_pol ~ leoka_off_assault_tot_tr  +  LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP + kill_tot_tr  |   Year,  data = DFt0)
my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,length(unique(DFt$CountyCode*10000+ DFt$Year)))  # Effective sample
a = append(a,length(unique(DFt$CountyCode)) )
a = append(a,sprintf("%.3f",mean(DFt$diff_kill_pol)))
for (i in a) {  cat(i, "\n")}      






### Table 9 Column 2: LawEnf effect Poisson, with covariates: RTC laws and MPV-SHR###
#####################################################

# Select sample
DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert + DF$ShCoroner >0) 
DFt = DF

sum(as.numeric(DF$RtCscore > 6))/sum(as.numeric(DF$RtCscore >-1))
sum(as.numeric(DF$RtCscore < 4))/sum(as.numeric(DF$RtCscore >-1))
sum(as.numeric(DF$RtCscore >-1))

DFt$diff_kill_pol[(DFt$diff_kill_pol <= 0) ] <- 0  ## Set negative values of misreporting to 0
DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))
DFt$RtCscore_tr = log( DFt$RtCscore + sqrt(DFt$RtCscore^2 + 1))

table(DFt$RtCscore)

DFt$RtCscorep = as.numeric(DFt$RtCscore > 6)  # Score B- or higher 
DFt$RtCscoref = DFt$RtCscore/11
table(DFt$RtCscore)

# FE Poisson estimation, weighted and clustered by county and countyFE
DFt0 = DFt
Pfe = fepois(diff_kill_pol ~ RtCscore_tr  + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP + kill_tot_tr  |   Year,  data = DFt0)
#summary(Pfe, cluster = ~CountyCode)$coeftable
my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,length(unique(DFt$CountyCode*10000+ DFt$Year)))  # Effective sample
a = append(a,length(unique(DFt$CountyCode)) )
a = append(a,sprintf("%.3f",mean(DFt$diff_kill_pol)))
for (i in a) {  cat(i, "\n")}      



### Table 9 Column 3: LawEnf effect Poisson, with covariates: RTC laws and SHR###
#####################################################

# FE Poisson estimation, weighted and clustered by county and countyFE
DFt0 = DFt
Pfe = fepois(map_kill_pol ~ RtCscore_tr +  LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP + kill_tot_tr  |  Year,  data = DFt0)
my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,length(unique(DFt$CountyCode*10000+ DFt$Year)))  # Effective sample
a = append(a,length(unique(DFt$CountyCode)) )
a = append(a,sprintf("%.3f",mean(DFt$map_kill_pol)))
for (i in a) {  cat(i, "\n")}  

### Table 9 Column 5: LawEnf effect Poisson, with covariates: RTC laws and MPV ###
#####################################################

# FE Poisson estimation, weighted and clustered by county and countyFE
DFt0 = DFt
Pfe = fepois(mpv_kill_pol ~ RtCscore_tr +  LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP + kill_tot_tr  |   Year,  data = DFt0)
my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,length(unique(DFt$CountyCode*10000+ DFt$Year)))  # Effective sample
a = append(a,length(unique(DFt$CountyCode)) )
a = append(a,sprintf("%.3f",mean(DFt$mpv_kill_pol)))
for (i in a) {  cat(i, "\n")}  



### Table 9 mentioned in text: LawEnf effect Poisson FE, with covariates, heterogenous effects ###
#####################################################
# # Select sample
# DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert + DF$ShCoroner >0) 
# DFt = DF[(DF$sample_LE_SC1 == 1),]
# 
# DFt$RtCscorep = as.numeric(DFt$RtCscore > 6)  # Score B- or higher 
# DFt$RtCscoref = DFt$RtCscore/11
# DFt$LEcert_RtC = DFt$LawEnf_cert1 * DFt$RtCscore
# 
# table(DFt$RtCscorep)
# 
# DFt = FE_fun(DFt, DFt$LawEnf_cert1, adj1 ) # Generate analysis dataset (weights adjusted inside fn)
# 
# DFt$diff_kill_pol[(DFt$diff_kill_pol <= 0) ] <- 0  ## Set negative values of misreporting to 0
# DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))
# 
# # remove singletons for FE estimation
# id_counts <- table(DFt$CountyCode_FE); singleton_ids <- names(id_counts[id_counts == 1])
# DFt <- DFt[!(DFt$CountyCode_FE %in% singleton_ids), ]
# 
# DFt$het0 = DFt$RtCscore 
# DFt$het1 = DFt$RtCscore * DFt$LawEnf_cert1
# 
# # FE Poisson estimation, weighted and clustered by county and countyFE
# DFt0 = PoiSampleTWFE_fn(DFt,DFt$diff_kill_pol,DFt$CountyCode_FE)
# Pfe = fepois(diff_kill_pol ~ LawEnf_cert1 + het0 + het1 + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
#                log_GDP + kill_tot_tr  | CountyCode_FE + Year, weights = DFt0$weight_var,  data = DFt0)
# summary(Pfe, cluster = ~CountyCode)$coeftable
# my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
# my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
# for (i in my_v) {  cat(i, "\n")}
# # Descriptive stats
# a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
# a = append(a,sum(DFt0$weight_var))  # Effective sample
# a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
# a = append(a,length(unique(DFt0$CountyCode)) )
# a = append(a,sprintf("%.3f",sum(DFt0$weight_var * DFt0$diff_kill_pol)/sum(DFt0$weight_var)))
# for (i in a) {  cat(i, "\n")}  
# 
# 



#############################################
### BLM google trends
##############################################

### Table 10 : LawEnf-BLM effect Poisson FE, with covariates ###
#####################################################
# Select sample
DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert + DF$ShCoroner >0) 
DFt = DF
DFt$diff_kill_pol[(DFt$diff_kill_pol <= 0) ] <- 0  ## Set negative values of misreporting to 0
DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))



DFt$BLMtrend_l = matrix(0,nrow(DFt),1)
for (i in 2:nrow(DFt)){
  if (DFt$CountyCode[i] == DFt$CountyCode[i-1]){
    DFt$BLMtrend_l[i] = DFt$BLMtrend[i-1]
  }
}
DFt$BLMtrend_l[(DFt$BLMtrend_l == 0)] <- NA 

# Figure Appendix N
hist(DF$BLMtrend,breaks=50,xlim=c(0,100),xlab="State-year 'Black Lives Matter' Google searches",main="", col=c("#0099FF"))   #This is the one in the paper

hist(DF$BLMtrend, main = "BLMtrend", xlab = "Value")
table(DFt$BLMtrend)

DFt$BLMtrend_d = as.numeric(DFt$BLMtrend > 20)
DFt$BLMtrend_dl = as.numeric(DFt$BLMtrend_l > 20)

DFt$LF_BLM_int =  DFt$LawEnf_cert1 * DFt$BLMtrend
DFt$LF_BLM_int_l =  DFt$LawEnf_cert1 * DFt$BLMtrend_l
DFt$LF_BLM_int_d =  DFt$LawEnf_cert1 * DFt$BLMtrend_d
DFt$LF_BLM_int_dl =  DFt$LawEnf_cert1 * DFt$BLMtrend_dl

DFt$LF_BLM0_int =  DFt$LawEnf_cert1 * (1- DFt$BLMtrend)
DFt$LF_BLM0_int_d =  DFt$LawEnf_cert1 * (1- DFt$BLMtrend_d)

DFt0=DFt

### Table 10 Column 1: LawEnf-BLM effect Poisson, with covariates: google trend continuous ###
#####################################################
Pfe = fepois(diff_kill_pol ~ BLMtrend   +  LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP + kill_tot_tr  |  Year  ,  data = DFt0)
#summary(Pfe, cluster = ~CountyCode)$coeftable[1,]
my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,summary(Pfe)$nobs)  # Effective sample
a = append(a,sum(DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f",mean(DFt0$diff_kill_pol)))
for (i in a) {  cat(i, "\n")}  

### Table 10 Column 2: LawEnf-BLM effect Poisson, with covariates: google trend binary no State FE###
#####################################################

Pfe = fepois(diff_kill_pol ~ BLMtrend_d   +  LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP + kill_tot_tr  |  Year ,  data = DFt0)
#summary(Pfe, cluster = ~CountyCode)$coeftable[1,]
my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,summary(Pfe)$nobs)  # Effective sample
a = append(a,sum(DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f",mean(DFt0$diff_kill_pol)))
for (i in a) {  cat(i, "\n")}


### Table 10 Column 3: LawEnf-BLM effect Poisson, with covariates: google trend binary with State FE ###
#####################################################
Pfe = fepois(diff_kill_pol ~ BLMtrend_d   +  LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP + kill_tot_tr  |  State + Year  ,  data = DFt0)
#summary(Pfe, cluster = ~CountyCode)$coeftable[1,]
my_v = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
my_v = append(as.numeric(sprintf("%.3f",exp(my_v[1])-1)), my_v[-3])
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,summary(Pfe)$nobs)  # Effective sample
a = append(a,sum(DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f",mean(DFt0$diff_kill_pol)))
for (i in a) {  cat(i, "\n")}  




### Table 10 Column 4-5: LawEnf-BLM effect Poisson, heterogenous with covariates: google trend binary ###
#####################################################
# Select sample
DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert + DF$ShCoroner >0) 
DFt = DF[(DF$sample_LE_SC1 == 1),]


DFt = FE_fun(DFt, DFt$LawEnf_cert1, adj1 ) # Generate analysis dataset (weights adjusted inside fn)

DFt$diff_kill_pol[(DFt$diff_kill_pol <= 0) ] <- 0  ## Set negative values of misreporting to 0
DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))

# remove singletons for FE estimation
id_counts <- table(DFt$CountyCode_FE); singleton_ids <- names(id_counts[id_counts == 1])
DFt <- DFt[!(DFt$CountyCode_FE %in% singleton_ids), ]




DFt$BLMtrend_l = matrix(0,nrow(DFt),1)
for (i in 2:nrow(DFt)){
  if (DFt$CountyCode[i] == DFt$CountyCode[i-1]){
    DFt$BLMtrend_l[i] = DFt$BLMtrend[i-1]
  }
}
DFt$BLMtrend_l[(DFt$BLMtrend_l == 0)] <- NA 


DFt$BLMtrend_d = as.numeric(DFt$BLMtrend > 20)
DFt$BLMtrend_dl = as.numeric(DFt$BLMtrend_l > 20)

DFt$LF_BLM_int =  DFt$LawEnf_cert1 * DFt$BLMtrend
DFt$LF_BLM_int_l =  DFt$LawEnf_cert1 * DFt$BLMtrend_l
DFt$LF_BLM_int_d =  DFt$LawEnf_cert1 * DFt$BLMtrend_d
DFt$LF_BLM_int_dl =  DFt$LawEnf_cert1 * DFt$BLMtrend_dl

DFt$LF_BLM0_int =  DFt$LawEnf_cert1 * (1- DFt$BLMtrend)
DFt$LF_BLM0_int_d =  DFt$LawEnf_cert1 * (1- DFt$BLMtrend_d)


### Table 10 Column 4: LawEnf-BLM effect Poisson, heterogenous with covariates: google trend binary Cluster FE###
#####################################################
DFt0 = PoiSampleTWFE_fn(DFt,DFt$diff_kill_pol,DFt$CountyCode_FE)
Pfe = fepois(diff_kill_pol ~ BLMtrend_d + LF_BLM0_int_d +  LF_BLM_int_d  + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP + kill_tot_tr  | CountyCode_FE + Year, weights = DFt0$weight_var,  data = DFt0)
summary(Pfe, cluster = ~CountyCode)$coeftable[1:3,]
my_v1 = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
my_v1 = append(as.numeric(sprintf("%.3f",exp(my_v1[1])-1)), my_v1[-3])
my_v2 = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[2,]))
my_v2 = append(as.numeric(sprintf("%.3f",exp(my_v2[1])-1)), my_v2[-3])
my_v3 = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[3,]))
my_v3 = append(as.numeric(sprintf("%.3f",exp(my_v3[1])-1)), my_v3[-3])
my_v = append(append(my_v1,my_v2), my_v3)
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,sum(DFt0$weight_var))  # Effective sample
a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f",  sum(DFt0$weight_var * DFt0$diff_kill_pol)/sum(DFt0$weight_var)))
for (i in a) {  cat(i, "\n")}



### Table 10 Column 5: LawEnf-BLM effect Poisson, heterogenous with covariates: google trend binary Cluster and State FE###
#####################################################
DFt0 = PoiSampleTWFE_fn(DFt,DFt$diff_kill_pol,DFt$CountyCode_FE)
Pfe = fepois(diff_kill_pol ~ BLMtrend_d + LF_BLM0_int_d +  LF_BLM_int_d  + LfrinMetro + MMetro + Microp + Noncore + SMetro + log_Population + Fem_perc + Black_perc + WHisp_perc + Other_perc + perc_votes.DEM + perc_votes.OTHER +
               log_GDP + kill_tot_tr  | CountyCode_FE + Year + State, weights = DFt0$weight_var,  data = DFt0)
summary(Pfe, cluster = ~CountyCode)$coeftable[1:3,]
my_v1 = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[1,]))
my_v1 = append(as.numeric(sprintf("%.3f",exp(my_v1[1])-1)), my_v1[-3])
my_v2 = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[2,]))
my_v2 = append(as.numeric(sprintf("%.3f",exp(my_v2[1])-1)), my_v2[-3])
my_v3 = as.numeric(sprintf("%.3f",summary(Pfe, cluster = ~CountyCode)$coeftable[3,]))
my_v3 = append(as.numeric(sprintf("%.3f",exp(my_v3[1])-1)), my_v3[-3])
my_v = append(append(my_v1,my_v2), my_v3)
for (i in my_v) {  cat(i, "\n")}
# Descriptive stats
a = length(unique(DFt$CountyCode*10000+ DFt$Year))  # Initial sample
a = append(a,sum(DFt0$weight_var))  # Effective sample
a = append(a,sum(DFt0$weight_var * DFt0$LawEnf_cert1))   # Treated Sample
a = append(a,length(unique(DFt0$CountyCode)) )
a = append(a,sprintf("%.3f",  sum(DFt0$weight_var * DFt0$diff_kill_pol)/sum(DFt0$weight_var)))
for (i in a) {  cat(i, "\n")}





#############################################
#### Officer charged
##############################################


# There are just too few observations of officers charged and convicted to take these results seriously

## Descriptive stats



DF$mpv_charged = DF$mpv_off_charged + DF$mpv_off_acquitted + DF$mpv_off_convicted + DF$mpv_off_dropped
DF$mpv_conv = DF$mpv_off_convicted

table(DF$mpv_off_charged)
table(DF$mpv_off_acquitted)
table(DF$mpv_off_convicted)
table(DF$mpv_off_dropped)
table(DF$mpv_charged)
table(DF$mpv_off_no_known_charge)
sum(DF$mpv_kill_pol)
sum(DF$mpv_off_charged + DF$mpv_off_acquitted + DF$mpv_off_convicted + DF$mpv_off_dropped)/sum(DF$mpv_kill_pol )
sum(DF$mpv_off_no_known_charge)/sum(DF$mpv_kill_pol )

# Sort the data frame by CountyCode and Year in ascending order
DF <- DF %>% arrange(CountyCode, Year)

# Calculate the cumulative sum variable
DF <- DF %>% 
  group_by(CountyCode) %>% 
  mutate(
    mpv_off_charged_cum = case_when(
      Year == 2013 ~ mpv_off_charged,
      Year == 2014 ~ cumsum(mpv_off_charged),
      Year >= 2015 ~ cumsum(mpv_off_charged) - lag(cumsum(mpv_off_charged), 3, default = 0),
      TRUE ~ NA_real_
    )
  ) %>% 
  ungroup()







### 4 SUMMARY STATISTICS ###


##############################################
### Descriptive Statistics/ Balance table in Appendix F
##############################################
# 
# # Top part of descriptive statistics table


library("xtable")


DF_t = DF
DF_t$GDP = as.numeric(DF_t$GDP)/100000
DF_t$Population = as.numeric(DF_t$Population)/10000
DF_t$LawEnf_cert1 =  as.numeric(DF_t$LawEnf_cert + DF_t$ShCoroner >0) 

df_bal = DF_t[,c("LawEnf_cert1","ShCoroner","Coroner","MedExam","diff_kill_pol","map_kill_pol","mpv_kill_pol","participated","nibrs_participated_naN",
                 "map_hom_tot","map_circ_circumstance_undetermined","Appoint","Physician", "LcentMetro", "LfrinMetro","MMetro","Microp","Noncore","SMetro",
                 "Population","Fem_perc","WnonHisp_perc","Black_perc","WHisp_perc","AsianPacIsl_perc","Native_perc", 
                 "perc_votes.REP", "perc_votes.DEM", "perc_votes.OTHER", "GDP")]
df_bal0= df_bal[(df_bal$Coroner==1),]
colnames(df_bal0) <- c("LawEnf_cert1","ShCoroner","Coroner","MedExam","diff_kill_pol","map_kill_pol","mpv_kill_pol","participated","nibrs_participated_naN",
                       "map_hom_tot","map_circ_circumstance_undetermined","Appoint","Physician", "LcentMetro", "LfrinMetro","MMetro","Microp","Noncore","SMetro",
                       "Population","Fem_perc","WnonHisp_perc","Black_perc","WHisp_perc","AsianPacIsl_perc","Native_perc", 
                       "perc_votes.REP", "perc_votes.DEM", "perc_votes.OTHER", "GDP")
df_bal1= df_bal[(df_bal$MedExam==1),]
colnames(df_bal1) <- c("LawEnf_cert1","ShCoroner","Coroner","MedExam","diff_kill_pol","map_kill_pol","mpv_kill_pol","participated","nibrs_participated_naN",
                       "map_hom_tot","map_circ_circumstance_undetermined","Appoint","Physician", "LcentMetro", "LfrinMetro","MMetro","Microp","Noncore","SMetro",
                       "Population","Fem_perc","WnonHisp_perc","Black_perc","WHisp_perc","AsianPacIsl_perc","Native_perc", 
                       "perc_votes.REP", "perc_votes.DEM", "perc_votes.OTHER", "GDP")
df_bal2= df_bal[(df_bal$ShCoroner==1),]
colnames(df_bal2) <- c("LawEnf_cert1","ShCoroner","Coroner","MedExam","diff_kill_pol","map_kill_pol","mpv_kill_pol","participated","nibrs_participated_naN",
                       "map_hom_tot","map_circ_circumstance_undetermined","Appoint","Physician", "LcentMetro", "LfrinMetro","MMetro","Microp","Noncore","SMetro",
                       "Population","Fem_perc","WnonHisp_perc","Black_perc","WHisp_perc","AsianPacIsl_perc","Native_perc", 
                       "perc_votes.REP", "perc_votes.DEM", "perc_votes.OTHER", "GDP")
df_bal3= df_bal[(df_bal$LawEnf_cert1==1),]
colnames(df_bal3) <- c("LawEnf_cert1","ShCoroner","Coroner","MedExam","diff_kill_pol","map_kill_pol","mpv_kill_pol","participated","nibrs_participated_naN",
                       "map_hom_tot","map_circ_circumstance_undetermined","Appoint","Physician", "LcentMetro", "LfrinMetro","MMetro","Microp","Noncore","SMetro",
                       "Population","Fem_perc","WnonHisp_perc","Black_perc","WHisp_perc","AsianPacIsl_perc","Native_perc", 
                       "perc_votes.REP", "perc_votes.DEM", "perc_votes.OTHER", "GDP")
df_balUS =df_bal
DF_t = DF[(DF$sample_LE_SC1 ==1),] 
DF_t$GDP = as.numeric(DF_t$GDP)/100000
DF_t$Population = as.numeric(DF_t$Population)/10000

DF_t$LawEnf_cert1 =  as.numeric(DF_t$LawEnf_cert + DF_t$ShCoroner >0)  # Define variable of interest as 1 if law enforcement can certify or sheriff coroner county  
df_bal = DF_t[,c("LawEnf_cert1","ShCoroner","Coroner","MedExam","diff_kill_pol","map_kill_pol","mpv_kill_pol","participated","nibrs_participated_naN",
                 "map_hom_tot","map_circ_circumstance_undetermined","Appoint","Physician", "LcentMetro", "LfrinMetro","MMetro","Microp","Noncore","SMetro",
                 "Population","Fem_perc","WnonHisp_perc","Black_perc","WHisp_perc","AsianPacIsl_perc","Native_perc", 
                 "perc_votes.REP", "perc_votes.DEM", "perc_votes.OTHER", "GDP")]

df_bal4= df_bal[(df_bal$LawEnf_cert1==1),]
colnames(df_bal4) <- c("LawEnf_cert1","ShCoroner","Coroner","MedExam","diff_kill_pol","map_kill_pol","mpv_kill_pol","participated","nibrs_participated_naN",
                       "map_hom_tot","map_circ_circumstance_undetermined","Appoint","Physician", "LcentMetro", "LfrinMetro","MMetro","Microp","Noncore","SMetro",
                       "Population","Fem_perc","WnonHisp_perc","Black_perc","WHisp_perc","AsianPacIsl_perc","Native_perc", 
                       "perc_votes.REP", "perc_votes.DEM", "perc_votes.OTHER", "GDP")
df_bal5= df_bal[(df_bal$LawEnf_cert1==0),]
colnames(df_bal5) <- c("LawEnf_cert1","ShCoroner","Coroner","MedExam","diff_kill_pol","map_kill_pol","mpv_kill_pol","participated","nibrs_participated_naN",
                       "map_hom_tot","map_circ_circumstance_undetermined","Appoint","Physician", "LcentMetro", "LfrinMetro","MMetro","Microp","Noncore","SMetro",
                       "Population","Fem_perc","WnonHisp_perc","Black_perc","WHisp_perc","AsianPacIsl_perc","Native_perc", 
                       "perc_votes.REP", "perc_votes.DEM", "perc_votes.OTHER", "GDP")


df_bal =df_balUS

# Generate descriptice statistics table
teXtable = rbind(cbind("& ",round(mean(df_bal[,1], na.rm = T),2),
                       "& ",round(mean(df_bal0[,1], na.rm = T),2),
                       "& ",round(mean(df_bal1[,1], na.rm = T),2),
                       "& ",round(mean(df_bal2[,1], na.rm = T),2),
                       "& ",round(mean(df_bal3[,1], na.rm = T),2),
                       "& ",round(mean(df_bal4[,1], na.rm = T),2),
                       "& ",round(mean(df_bal5[,1], na.rm = T),2),"\vspace{-2mm} \\"),
                 cbind("& (",round(sd(df_bal[,1], na.rm = T),2),
                       ") & (",round(sd(df_bal0[,1], na.rm = T),2),
                       ") & (",round(sd(df_bal1[,1], na.rm = T),2),
                       ") & (",round(sd(df_bal2[,1], na.rm = T),2),
                       ") & (",round(sd(df_bal3[,1], na.rm = T),2),
                       ") & (",round(sd(df_bal4[,1], na.rm = T),2),
                       ") & (",round(sd(df_bal5[,1], na.rm = T),2),") \\"))

nrow(df_bal1)
for (i in 2:ncol(df_bal)) {
  teXtable = rbind(teXtable,  rbind(cbind("& ",round(mean(df_bal[,i], na.rm = T),2),
                                          "& ",round(mean(df_bal0[,i], na.rm = T),2),
                                          "& ",round(mean(df_bal1[,i], na.rm = T),2),
                                          "& ",round(mean(df_bal2[,i], na.rm = T),2),
                                          "& ",round(mean(df_bal3[,i], na.rm = T),2),
                                          "& ",round(mean(df_bal4[,i], na.rm = T),2),
                                          "& ",round(mean(df_bal5[,i], na.rm = T),2),"\vspace{-2mm} \\"),
                                    cbind("& (",round(sd(df_bal[,i], na.rm = T),2),
                                          ") & (",round(sd(df_bal0[,i], na.rm = T),2),
                                          ") & (",round(sd(df_bal1[,i], na.rm = T),2),
                                          ") & (",round(sd(df_bal2[,i], na.rm = T),2),
                                          ") & (",round(sd(df_bal3[,i], na.rm = T),2),
                                          ") & (",round(sd(df_bal4[,i], na.rm = T),2),
                                          ") & (",round(sd(df_bal5[,i], na.rm = T),2),") \\")))
  
}

options(scipen=999)
teXtable =cbind(c("LE certify","", "Sh.-Coroner","", "Coroner","", "Med.-Exam.","", "police kill. MPV-SHR","", "police kill. SHR","", "police kill. MPV","", "SHR part.","", "NIBRS part.","", 
                  "Tot. Homicides SHR","", "Circ. undetermined SHR", "", "Appointed","", "Physician","", "Large central Metro","",  "Large fringe Metro","", "Medium Metro","", "Micropolitan","", "Non-core","", "Small Metro","", 
                  "Population (per 10,000)","", "Fem. perc","", "White (non-Hisp.) perc.","", "Black perc.","", "Hisp. perc.","", "Asian-PacIsl. perc.","", "Native perc.", "", 
                  "REP. Perc. votes", "", "DEM. Perc. votes","",  "Other Perc. votes", "", "GDP (per 100,000)",""),teXtable)

teXtable
xtable(teXtable)


# library("vtable")
# DF_t = DF[(DF$sample_LE_SC1 ==1),]
# df_bal = DF_t[,c("LawEnf_cert1","ShCoroner","Coroner","MedExam","diff_kill_pol","map_kill_pol","mpv_kill_pol","participated","nibrs_participated_naN",
#                  "map_hom_tot","map_circ_circumstance_undetermined", "LcentMetro", "LfrinMetro","MMetro","Microp","Noncore","SMetro",
#                  "Population","Fem_perc","WnonHisp_perc","Black_perc","WHisp_perc","AsianPacIsl_perc","Native_perc", 
#                  "perc_votes.REP", "perc_votes.DEM", "perc_votes.OTHER", "GDP","Appoint","Physician")]
# sumtable(df_bal, group = "LawEnf_cert1", group.test = TRUE)




### 5 FIGURES ### 


# Histograms in appendix A

par(mfrow=c(1,2))
# Plot the first histogram A
DFh_mpv = DF$mpv_kill_pol[(DF$mpv_kill_pol >0 )]
hist(DFh_mpv,breaks=250,xlim=c(0,13),xlab="Police killings, MPV",main="", col=c("#0099FF"))

# Plot the second histogram in the second panel
DFh_shr = DF$map_kill_pol[(DF$map_kill_pol >0 )]
hist(DFh_shr,breaks=250,xlim=c(0,13),xlab="Police killings, SHR",main="", col=c("#0099FF"))
par(mfrow=c(1,1))

DFh_diff = DF$diff_kill_pol[(DF$diff_kill_pol >0 )]

hist(DFh_diff, breaks=100, xlim=c(0, 13), xlab="Police killings, MPV-SHR", main="", 
     col="#0099FF")


# Histograms of appendix K

par(mfrow=c(1,2))
# Plot the first histogram
DFh_assa = DF$leoka_off_assault_tot[(DF$leoka_off_assault_tot >0 )]
hist(DFh_assa,breaks=100,xlim=c(0,500),xlab="Assaults on police",main="", col=c("#0099FF"))

# Plot the second histogram in the second panel
DFh_mur = DF$leoka_off_kill_felony[(DF$leoka_off_kill_felony >0 )]
DFh_mur = DFh_mur-1 # somehow histogram does not line up without this piece of code
#hist(DFh_mur,breaks=7,xlim=c(0,9),xlab="Murders of police",main="", col=c("#0099FF"))

hist(DF$RtCscore,breaks=10,xlim=c(0,11),xlab="Gun and ammunition laws",main="", col=c("#0099FF"))
par(mfrow=c(1,1))

table(DF$leoka_off_kill_felony)


# 
# hist(DF$LEMAS_agenc_w_body_cam_tot, breaks=10, xlim=c(0, 6), xlab="Police killings, MPV-SHR", main="", 
#      col="#0099FF")
































