##### Dependencies and session info
# 
# R version 4.2.2 (2022-10-31 ucrt)
# Platform: x86_64-w64-mingw32/x64 (64-bit)
# Running under: Windows 10 x64 (build 19045)
#
# attached base packages:
#  stats     graphics  grDevices utils     datasets  methods   base     
# 
# other attached packages:
#  dplyr_1.1.2      ggplot2_3.4.4    sf_1.0-15        foreign_0.8-86   openxlsx_4.2.5.2 haven_2.5.4      labelled_2.12.0 
# 
# loaded via a namespace (and not attached):
#  zip_2.3.0          Rcpp_1.0.12        pillar_1.9.0       compiler_4.2.2     class_7.3-22       forcats_1.0.0      tools_4.2.2        lifecycle_1.0.4   
#  tibble_3.2.1       gtable_0.3.4       pkgconfig_2.0.3    rlang_1.1.1        cli_3.4.1          DBI_1.2.1          rstudioapi_0.15.0  e1071_1.7-14      
#  s2_1.1.6           withr_3.0.0        generics_0.1.3     vctrs_0.6.3        hms_1.1.3          classInt_0.4-10    grid_4.2.2         tidyselect_1.2.0  
#  glue_1.6.2         R6_2.5.1           fansi_1.0.3        farver_2.1.1       readr_2.1.5        tzdb_0.4.0         magrittr_2.0.3     units_0.8-5       
#  scales_1.3.0       colorspace_2.0-3   labeling_0.4.3     KernSmooth_2.23-22 utf8_1.2.2         proxy_0.4-27       stringi_1.8.3      wk_0.9.1          
#  munsell_0.5.0  

library(tidyverse)
library(dplyr)
library(usmap)
library(ggplot2)
library(reshape2)

# load dataframe
#load("C:/Users/gr925268/Dropbox/Coroners/Data/Dataset (R files)/DF_analysis.Rda")
load("C:/Users/gr925268/Dropbox/Coroners/Police_code/DF_analysis.Rda")

###########################################################
### FIGURE 1 paper
# name on overleaf: Pkill_totals

# Create a data frame with 7 rows and an unspecified number of columns
d <- data.frame(matrix(ncol = , nrow = 7))

# Add the 'Year' column to the data frame
d$Year <- c(2013, 2014, 2015, 2016, 2017, 2018, 2019)

# Calculate and assign values to the 'mpv_kill_pol' (total police killings coming from the 
# Mapping police violence dataset) column based on years

d$mpv_kill_pol <- c(
  sum(DF$mpv_kill_pol[(DF$Year == 2013)]),
  sum(DF$mpv_kill_pol[(DF$Year == 2014)]),
  sum(DF$mpv_kill_pol[(DF$Year == 2015)]),
  sum(DF$mpv_kill_pol[(DF$Year == 2016)]),
  sum(DF$mpv_kill_pol[(DF$Year == 2017)]),
  sum(DF$mpv_kill_pol[(DF$Year == 2018)]),
  sum(DF$mpv_kill_pol[(DF$Year == 2019)])
)

# Calculate and assign values to the 'mpv_kill_pol' (total police killings coming from the 
# Murder accountability project which reports the  Supplemetnary homicide data from the FBI dataset) 
# column based on years

d$map_kill_pol <- c(
  sum(DF$map_kill_pol[(DF$Year == 2013)]),
  sum(DF$map_kill_pol[(DF$Year == 2014)]),
  sum(DF$map_kill_pol[(DF$Year == 2015)]),
  sum(DF$map_kill_pol[(DF$Year == 2016)]),
  sum(DF$map_kill_pol[(DF$Year == 2017)]),
  sum(DF$map_kill_pol[(DF$Year == 2018)]),
  sum(DF$map_kill_pol[(DF$Year == 2019)])
)

# Assign values to the 'nvss_kill_tot' column, 
# NVSS stands for Nationa Vital Statisics System
d$nvss_kill_tot <- c(489, 485, 515, 537, 603, 608, 655)

# Remove the first column from the data frame
d <- d[, -1]

# Rename the column names
colnames(d) <- c("Year", "MPV", "FBI-SHR", "NVSS")

# Reshape the data frame from wide to long format
d <- melt(d, id.vars = 'Year', variable.name = 'Data')

# Create a line plot using ggplot
ggplot(d, aes(Year, value)) +
  geom_line(aes(colour = Data), size = 1) +
  ylab("Total police killings") +
  xlab("Year") +
  theme_bw() +
  theme_classic() +
  theme(legend.position = c(0.1, 0.85)) +
  scale_x_continuous(breaks = round(seq(min(d$Year), max(d$Year), by = 1), 1)) +
  ylim(0, 1550) +
  scale_colour_grey(start = 0.2, end = 0.8)

# Save the plot as a PNG file
ggsave("Pkill_totals.png", width = 10, height = 6, dpi = 300)

###########################################################
### FIGURE 2 paper
# name on overleaf: CDC_Deat_inv_sys


# Read the CSV file into the MEC data frame - this data comes from the CDC website (https://www.cdc.gov/phlp/publications/coroner/death.html)
MEC <- read.csv("C:/Users/gr925268/Dropbox/Coroners/Data/Dataset (R files)/Death Investigation Systems, By State (1).csv")

# Create a new data frame with 'state' and 'System' columns
df <- data.frame(
  state = MEC$State,
  System = MEC$System
)

# Remove NAsrow from the data frame
# Identify rows with complete observations (no NAs)
complete_rows <- complete.cases(df)

# Create a new data frame without rows containing NAs
df <- df[complete_rows, ]


# Convert the 'System' column to a factor and then to character
df$System <- as.factor(df$System)
df$System <- as.character(df$System)

# Plot the US map with regions as states, using the 'System' column as values
plot_usmap(regions = 'states', data = df, values = "System", labels = TRUE, alpha = 0.7, color = "gray52") +
  scale_fill_manual(values = c("4" = "gray47",
                               "1" = "grey85",
                               "2" = "gray0",
                               "3" = "white"),
                    labels = c("Centralized state ME",
                               "Coroner",
                               "ME",
                               "Mix ME and Coroner"
                    ),
                    name = "") +
  theme(legend.position = "top", legend.text = element_text(size = 20),
        legend.key.height = unit(1, 'cm'),
        legend.key.width = unit(1, 'cm'))

# Save the plot as a PNG file
ggsave("C:/Users/gr925268/Dropbox/Coroners/Data/Figures/CDC_Deat_inv_sys.png", width = 10, height = 6, dpi = 300)


#################################################
# LE state level

DF_map = DF[, c( "State", "LawEnf_cert", "ShCoroner")]

DF_map <- aggregate( LawEnf_cert+ShCoroner ~State, DF_map, FUN = mean  )

# Renaming the column names in DF_map
colnames(DF_map) <- c("state", "LawEnf_cert")

# Assuming DF is your data frame
DF_map$new_column <- ifelse(DF_map$LawEnf_cert > 0 & DF_map$LawEnf_cert < 1, 0.5,
                        ifelse(DF_map$LawEnf_cert >= 1, 1, DF_map$LawEnf_cert))
DF_map <- DF_map[,-2]
colnames(DF_map) <- c("state", "LawEnf_cert")

# Updating the values of 'Coroner' column in DF_map
# Changing 1 to "Coroner" and 0 to "Other"
DF_map$LawEnf_cert[DF_map$LawEnf_cert == 1 ]<-  "Yes-Statewide"
DF_map$LawEnf_cert[DF_map$LawEnf_cert == 0.5 ]<-  "County-Mix"
DF_map$LawEnf_cert[DF_map$LawEnf_cert == 0 ]<-  "No-Statewide"

plot_usmap(regions='state',data=DF_map,values="LawEnf_cert", labels = TRUE, alpha = 0.7, color = "gray52") +

  scale_fill_manual(values=c("Yes-Statewide"="grey0","No-Statewide"="white", "County-Mix" = "grey60"), name= "")+
  
  # Customizing the theme and legend appearance
  theme(legend.position = "bottom", legend.text = element_text(size=20), 
        legend.key.height= unit(1, 'cm'),
        legend.key.width= unit(1, 'cm'))

# Save the plot as a PNG file
ggsave("C:/Users/gr925268/Dropbox/Coroners/Data/Figures/LE_cert.png", width = 10, height = 6, dpi = 300)



#######load and transform data for the map-figure representation
load ("C:/Users/gr925268/Dropbox/Coroners/Police_code/DF_analysis.Rda")
#### ggplot is updated to 2020 but  Copper River and Chugach belonged to Valdez-Cordova 
# census area but left it in 2019 to join the Unorganized Borough so need to duplicate the 
# Valdez-Cordova info to match the 2013-2019 situation

#DF$CountyCode <- as.numeric(DF$CountyCode)

# NEED TO CHANGE ALASKA COUNTIES: COPPER RIVER AND CHUGACH
DF[21994,] <- DF[645,]
DF[21994,1] <- "02066"
DF[21995,] <- DF[645,]
DF[21995,1] <- "02063"


###########################################################
### FIGURE 9 paper
# name on overleaf: map7_counties_shcoroner.png
# name old file MAP7

# Selecting specific columns from the dataframe DF
DF_map = DF[,c("CountyCode","State","ShCoroner")]

# Re-selecting only the 'CountyCode' and 'ShCoroner' columns in DF_map
DF_map = DF_map[,c("CountyCode","ShCoroner")]

# Updating the values of 'ShCoroner' column in DF_map
# Changing 1 to "ShCoroner" and 0 to "Other"
DF_map$ShCoroner[DF_map$ShCoroner == 1 ]<-  "Sheriff-Coroner"
DF_map$ShCoroner[DF_map$ShCoroner == 0 ]<-  "Other"

# Renaming the column names in DF_map
colnames(DF_map) <- c("fips", "System")

DF_map$System <- as.character(DF_map$System)
DF_map$fips<- as.numeric(DF_map$fips)
# Plotting a US map using the 'counties' regions and the data from DF_map
# Coloring the regions based on the values in the 'System' column
plot_usmap(regions='counties',data=DF_map,values="System", color = "gray25") +
  
  # Manually specifying the fill colors for the legend
  # Setting "ShCoroner" to grey25 and "Other" to white
  scale_fill_manual(values=c("Sheriff-Coroner"="grey52","Other"="white"), guide = guide_legend(reverse=TRUE), name= "")+
  
  # Customizing the theme and legend appearance
  theme(legend.position = "bottom", legend.text = element_text(size=20), 
        legend.key.height= unit(1, 'cm'),
        legend.key.width= unit(1, 'cm'))

# Save the plot as a PNG file
ggsave("C:/Users/gr925268/Dropbox/Coroners/Data/Figures/map7_counties_shcoroner.png", width = 10, height = 6, dpi = 300)



###########################################################
### FIGURE 3 paper
# name on overleaf: map2_MAP.png
# name old file MAP2


# Select the columns "CountyCode", "State", and "map_kill_pol" from the DF data frame
DF_map = DF[, c("CountyCode", "State", "map_kill_pol")]

# Remove rows with missing values in the "map_kill_pol" column from DF_map
DF_map = DF_map[!is.na(DF_map$map_kill_pol), ]

# Keep only the columns "CountyCode" and "map_kill_pol" in DF_map
DF_map = DF_map[, c("CountyCode", "map_kill_pol")]

# Aggregate the "map_kill_pol" column by CountyCode, calculating the mean
DF_map = aggregate(map_kill_pol ~ CountyCode, data = DF_map, FUN = mean)

# Rename the column names of DF_map to "fips" and "map_kill_pol"
colnames(DF_map) <- c("fips", "map_kill_pol")

# Filter out rows where the "map_kill_pol" column is greater than 0
DF_map = DF_map[(DF_map$map_kill_pol > 0), ]

# Plot the US map with county-level data using DF_map
plot_usmap(regions = 'counties', data = DF_map, values = "map_kill_pol", color = "gray25") +
  scale_fill_binned(low = "lightsteelblue1", high = "grey52", na.value = "white",
                    guide = guide_coloursteps(even.steps = FALSE), name = "") +
  theme(legend.position = "right", legend.text = element_text(size = 20),
        legend.key.height = unit(1, 'cm'),
        legend.key.width = unit(1, 'cm'))

# Save the plot as a PNG file
ggsave("C:/Users/gr925268/Dropbox/Coroners/Data/Figures/map2_MAP.png", width = 10, height = 6, dpi = 300)

###########################################################
### FIGURE 4 paper
# name on overleaf: map1_MPV.png
# name old file MAP1

# Select the columns "CountyCode", "State", and "mpv_kill_pol" from the DF data frame
DF_map = DF[, c("CountyCode", "State", "mpv_kill_pol")]

# Remove rows with missing values in the "mpv_kill_pol" column from DF_map
DF_map = DF_map[!is.na(DF_map$mpv_kill_pol), ]

# Keep only the columns "CountyCode" and "mpv_kill_pol" in DF_map
DF_map = DF_map[, c("CountyCode", "mpv_kill_pol")]

# Aggregate the "mpv_kill_pol" column by CountyCode, calculating the mean
DF_map = aggregate(mpv_kill_pol ~ CountyCode, data = DF_map, FUN = mean)

# Rename the column names of DF_map to "fips" and "mpv_kill_pol"
colnames(DF_map) <- c("fips", "mpv_kill_pol")

# Filter out rows where the "mpv_kill_pol" column is greater than 0
DF_map = DF_map[(DF_map$mpv_kill_pol > 0), ]

# Plot the US map with county-level data using DF_map
plot_usmap(regions = 'counties', data = DF_map, values = "mpv_kill_pol", color = "gray25") +
  scale_fill_binned(low = "lightsteelblue1", high = "grey52", na.value = "white",
                    guide = guide_coloursteps(even.steps = FALSE), name = "") +
  theme(legend.position = "right", legend.text = element_text(size = 20),
        legend.key.height = unit(1, 'cm'),
        legend.key.width = unit(1, 'cm'))

# Save the plot as a PNG file
ggsave("C:/Users/gr925268/Dropbox/Coroners/Data/Figures/map1_MPV.png", width = 10, height = 6, dpi = 300)


###########################################################
### FIGURE 5 paper
# name on overleaf: map3_misreported_nbr.png
# name old file MAP3

# Select the columns "CountyCode", "State", and "diff_kill_tot_p" from the DF data frame
DF_map = DF[, c("CountyCode", "State", "diff_kill_pol_p")]

# Remove rows with missing values in the "diff_kill_pol_p" column from DF_map
DF_map = DF_map[!is.na(DF_map$diff_kill_pol_p), ]

# Keep only the columns "CountyCode" and "diff_kill_pol_p" in DF_map
DF_map = DF_map[, c("CountyCode", "diff_kill_pol_p")]

# Aggregate the "diff_kill_pol_p" column by CountyCode, calculating the mean
DF_map = aggregate(diff_kill_pol_p ~ CountyCode, data = DF_map, FUN = mean)

# Multiply the values in the "diff_kill_pol_p" column by the number of years
DF_map$diff_kill_pol_p = DF_map$diff_kill_pol_p * 7

# Rename the column names of DF_map to "fips" and "diff_kill_pol_p"
colnames(DF_map) <- c("fips", "diff_kill_pol_p")

# Filter out rows where the "diff_kill_pol_p" column is greater than 0
DF_map = DF_map[(DF_map$diff_kill_pol_p > 0), ]

# Plot the US map with county-level data using DF_map
plot_usmap(regions = 'counties', data = DF_map, values = "diff_kill_pol_p", color = "gray25") +
  scale_fill_binned(low = "lightsteelblue1", high = "grey52", na.value = "white",
                    guide = guide_coloursteps(even.steps = FALSE), name = "") +
  theme(legend.position = "right", legend.text = element_text(size = 20),
        legend.key.height = unit(1, 'cm'),
        legend.key.width = unit(1, 'cm'))

# Save the plot as a PNG file
ggsave("C:/Users/gr925268/Dropbox/Coroners/Data/Figures/map3_misreported_nbr.png", width = 10, height = 6, dpi = 300)


###########################################################
### FIGURE 6 paper
# name on overleaf: share_reported.png
# name old file share_reported.png (3.1)


###########################################################
### FIGURE 7 paper
# name on overleaf: map4_counties_med_ex.png
# name old file MAP4
# Select the columns "CountyCode", "State", and "MedExam" from the DF data frame
DF_map = DF[, c("CountyCode", "State", "MedExam")]

# Keep only the columns "CountyCode" and "MedExam" in DF_map
DF_map = DF_map[, c("CountyCode", "MedExam")]

# Replace the values in the "MedExam" column: 1 with "MedExam" and 0 with "Other"
DF_map$MedExam[DF_map$MedExam == 1] <- "Medical Examiner"
DF_map$MedExam[DF_map$MedExam == 0] <- "Other"

# Rename the column names of DF_map to "fips" and "System"
colnames(DF_map) <- c("fips", "System")

# Plot the US map with county-level data using DF_map
plot_usmap(regions = 'counties', data = DF_map, values = "System", color = "gray25") +
  scale_fill_manual(values = c("Other" = "white", alpha = 0.25, "Medical Examiner" = "grey52"), name = "") +
  theme(legend.position = "bottom", legend.text = element_text(size = 20),
        legend.key.height = unit(0.5, 'cm'),
        legend.key.width = unit(0.5, 'cm'))

# Save the plot as a PNG file
ggsave("C:/Users/gr925268/Dropbox/Coroners/Data/Figures/map4_counties_med_ex.png", width = 10, height = 6, dpi = 300)


###########################################################
### FIGURE 8 paper
# name on overleaf: map5_counties_coroner.png
# name old file MAP5
# Selecting specific columns from the dataframe DF
DF_map = DF[,c("CountyCode","State","Coroner")]

# Removing rows where the value of 'Coroner' is "Na"
DF_map = DF_map[!(DF_map$Coroner == "Na"),]

# Re-selecting only the 'CountyCode' and 'Coroner' columns in DF_map
DF_map = DF_map[,c("CountyCode","Coroner")]

# Updating the values of 'Coroner' column in DF_map
# Changing 1 to "Coroner" and 0 to "Other"
DF_map$Coroner[DF_map$Coroner == 1 ]<-  "Coroner"
DF_map$Coroner[DF_map$Coroner == 0 ]<-  "Other"

# Renaming the column names in DF_map
colnames(DF_map) <- c("fips", "System")

# Plotting a US map using the 'counties' regions and the data from DF_map
# Coloring the regions based on the values in the 'System' column
# Using gray52 as the overall map color
plot_usmap(regions='counties',data=DF_map,values="System", color = "gray25") +
  
  # Manually specifying the fill colors for the legend
  # Setting "Other" to white and "Coroner" to grey25
  # Providing an empty name for the legend
  scale_fill_manual(values=c("Other"="white", "Coroner"="grey52"), name= "")+
  
  # Customizing the theme and legend appearance
  theme(legend.position = "bottom", legend.text = element_text(size=20), 
        legend.key.height= unit(1, 'cm'),
        legend.key.width= unit(1, 'cm'))

# Save the plot as a PNG file
ggsave("C:/Users/gr925268/Dropbox/Coroners/Data/Figures/map5_counties_coroner.png", width = 10, height = 6, dpi = 300)

###########################################################
### FIGURE 9 paper
# name on overleaf: map7_counties_shcoroner.png
# name old file MAP7

# Selecting specific columns from the dataframe DF
DF_map = DF[,c("CountyCode","State","ShCoroner")]

# Re-selecting only the 'CountyCode' and 'ShCoroner' columns in DF_map
DF_map = DF_map[,c("CountyCode","ShCoroner")]

# Updating the values of 'ShCoroner' column in DF_map
# Changing 1 to "ShCoroner" and 0 to "Other"
DF_map$ShCoroner[DF_map$ShCoroner == 1 ]<-  "Sheriff-Coroner"
DF_map$ShCoroner[DF_map$ShCoroner == 0 ]<-  "Other"

# Renaming the column names in DF_map
colnames(DF_map) <- c("fips", "System")

# Plotting a US map using the 'counties' regions and the data from DF_map
# Coloring the regions based on the values in the 'System' column
plot_usmap(regions='counties',data=DF_map,values="System", color = "gray25") +
  
  # Manually specifying the fill colors for the legend
  # Setting "ShCoroner" to grey25 and "Other" to white
  scale_fill_manual(values=c("Sheriff-Coroner"="grey52","Other"="white"), guide = guide_legend(reverse=TRUE), name= "")+
  
  # Customizing the theme and legend appearance
  theme(legend.position = "bottom", legend.text = element_text(size=20), 
        legend.key.height= unit(1, 'cm'),
        legend.key.width= unit(1, 'cm'))

# Save the plot as a PNG file
ggsave("C:/Users/gr925268/Dropbox/Coroners/Data/Figures/map7_counties_shcoroner.png", width = 10, height = 6, dpi = 300)



###########################################################
### FIGURE 10 paper
# name on overleaf: map6_counties_lawenf.png
# name old file MAP6

# Creating a new variable 'LawEnf_cert1' in the dataframe DF
# The value is 1 if law enforcement can certify or sheriff coroner county, and 0 otherwise
DF$LawEnf_cert1 = as.numeric(DF$LawEnf_cert + DF$ShCoroner > 0)

# Selecting specific columns from the dataframe DF and assigning it to DF_map
DF_map = DF[,c("CountyCode","State","LawEnf_cert1")]

# Re-selecting only the 'CountyCode' and 'LawEnf_cert1' columns in DF_map
DF_map = DF_map[,c("CountyCode","LawEnf_cert1")]

# Updating the values of 'LawEnf_cert1' column in DF_map
# Changing 1 to "LawEnf" and 0 to "Other"
DF_map$LawEnf_cert1[DF_map$LawEnf_cert1 == 1 ]<- "Law Enforcement certifying"
DF_map$LawEnf_cert1[DF_map$LawEnf_cert1 == 0 ]<- "Other"

# Renaming the column names in DF_map
colnames(DF_map) <- c("fips", "System")

# Plotting a US map using the 'counties' regions and the data from DF_map
# Coloring the regions based on the values in the 'System' column
plot_usmap(regions='counties',data=DF_map,values="System", color = "gray25") +
  
  # Manually specifying the fill colors for the legend
  scale_fill_manual(values=c("Other"="white", "Law Enforcement certifying"="grey52"), name= "")+
  
  # Customizing the theme and legend appearance
  theme(legend.position = "bottom", legend.text = element_text(size=20), 
        legend.key.height= unit(1, 'cm'),
        legend.key.width= unit(1, 'cm'))
# Save the plot as a PNG file
ggsave("C:/Users/gr925268/Dropbox/Coroners/Data/Figures/map6_counties_lawenf.png", width = 10, height = 6, dpi = 300)





###########################################################
### FIGURE 11 paper
# name on overleaf: map8_adj_Lenf_other.png
# name old file MAP8

# Creating a new variable 'LawEnf_cert1' in the dataframe DF
# The value is 1 if law enforcement can certify or sheriff coroner county, and 0 otherwise
DF$LawEnf_cert1 = as.numeric(DF$LawEnf_cert + DF$ShCoroner > 0)

# Creating a new variable 'sample' in the dataframe DF
# The value is taken from the 'sample_LE_SC1' column
DF$sample = DF$sample_LE_SC1

# Selecting specific columns from the dataframe DF and assigning it to DF_map
DF_map = DF[,c("CountyCode","State","LawEnf_cert1","sample")]

# Removing rows with missing values in the 'sample' column in DF_map
DF_map = DF_map[!is.na(DF_map$sample),]

# Selecting only rows where the 'sample' value is 1 in DF_map
DF_map = DF_map[(DF_map$sample == 1),]

# Creating a new variable 'index_C' in DF_map
# The value is calculated based on the 'sample' and 'LawEnf_cert1' columns
DF_map$index_C = as.numeric(DF_map$sample) + as.numeric(DF_map$sample) * as.numeric(DF_map$LawEnf_cert1)

# Selecting specific columns from the dataframe DF_map
DF_map = DF_map[,c("CountyCode","index_C")]

# Converting the 'index_C' column to character type in DF_map
DF_map$index_C <- as.character(DF_map$index_C)

# Renaming the column names in DF_map
colnames(DF_map) <- c("fips", "index_C")

# Plotting a US map using the 'counties' regions and the data from DF_map
plot_usmap(regions='counties',data=DF_map,values="index_C", color = "gray25") +
  
  # Binning the fill values into a color scale from "lightsteelblue1" to "grey25"
  # Assigning "white" for missing values
  scale_fill_binned(low="lightsteelblue1", high="grey52", na.value="white",
                    guide = guide_coloursteps(even.steps = FALSE)) +
  
  # Manually specifying the fill colors for the legend
  # Assigning "lightsteelblue1" to 1 and "grey25" to 2
  # Assigning "white" for missing values
  scale_fill_manual(values=c("1"="lightsteelblue1", "2"="grey55"),
                    labels=c(" Law Enforcement non-certifying", "Law Enforcement certifying"),
                    na.value="white", name="") +
  
  # Customizing the theme and legend appearance
  theme(legend.position = "bottom", legend.text = element_text(size=15),
        legend.key.height = unit(1, 'cm'),
        legend.key.width = unit(1, 'cm'))

# Save the plot as a PNG file
ggsave("C:/Users/gr925268/Dropbox/Coroners/Data/Figures/map8_adj_Lenf_other.png", width = 10, height = 6, dpi = 300)


###########################################################
### FIGURE 12 paper
# name on overleaf: map9_adj_Cor_ME.png
# name old file MAP9

# Creating a new variable 'sample' in the dataframe DF
# The value is taken from the 'sample_C_M1' column
DF$sample = DF$sample_C_M1

# Selecting specific columns from the dataframe DF and assigning it to DF_map
DF_map = DF[,c("CountyCode","State","Coroner","sample")]

# Removing rows with missing values in the 'sample' column in DF_map
DF_map = DF_map[!is.na(DF_map$sample),]

# Removing rows where the 'Coroner' value is "Na" in DF_map
DF_map = DF_map[!(DF_map$Coroner == "Na"),]

# Selecting only rows where the 'sample' value is 1 in DF_map
DF_map = DF_map[(DF_map$sample == 1),]

# Creating a new variable 'index_C' in DF_map
# The value is calculated based on the 'sample' and 'Coroner' columns
DF_map$index_C = as.numeric(DF_map$sample) + as.numeric(DF_map$sample) * as.numeric(DF_map$Coroner)

# Selecting specific columns from the dataframe DF_map
DF_map = DF_map[,c("CountyCode","index_C")]

# Converting the 'index_C' column to character type in DF_map
DF_map$index_C <- as.character(DF_map$index_C)

# Renaming the column names in DF_map
colnames(DF_map) <- c("fips", "index_C")

# Plotting a US map using the 'counties' regions and the data from DF_map
plot_usmap(regions='counties',data=DF_map,values="index_C", color = "gray25") +
  
  # Binning the fill values into a color scale from "lightsteelblue1" to "grey25"
  # Assigning "white" for missing values
  scale_fill_binned(low="lightsteelblue1", high="grey52", na.value="white",
                    guide = guide_coloursteps(even.steps = FALSE)) +
  
  # Manually specifying the fill colors for the legend
  # Assigning "lightsteelblue1" to 1 and "grey25" to 2
  # Assigning "white" for missing values
  scale_fill_manual(values=c("1"="lightsteelblue1", "2"="grey52"),
                    labels=c("Medical Examiner", "Coroner"),
                    na.value="white", name="") +
  
  # Customizing the theme and legend appearance
  theme(legend.position = "bottom", legend.text = element_text(size=20),
        legend.key.height = unit(1, 'cm'),
        legend.key.width = unit(1, 'cm'))



# Save the plot as a PNG file
ggsave("C:/Users/gr925268/Dropbox/Coroners/Data/Figures/map9_adj_Cor_ME.png", width = 10, height = 6, dpi = 300)

#############################################################
############################################################
################ APPENDIX #################################



###########################################################
### FIGURE 1 APPENDIX
# name old file urbanization.png
#### URBANIZATION
# load data
load("C:/Users/gr925268/Dropbox/Coroners/Data/Dataset (R files)/DF_analysis.Rda")


# Selecting rows from the dataframe DF where the 'Year' column is equal to 2019
# Selecting columns 1 to 8, namely CountyCode, Yearm State, County, urban2013, Coroner, MedExam, SHCoroner
DF_map = DF[(DF$Year == 2019),c(1:8)]

# Aggregating the 'Coroner' column based on the 'urban2013' column in DF_map
# The sum is calculated for each unique value in the 'urban2013' column
urb_Cor <- aggregate(Coroner~ urban2013 , data = DF_map, FUN = sum)

# Aggregating the 'MedExam' column based on the 'urban2013' column in DF_map
# The sum is calculated for each unique value in the 'urban2013' column
urb_ME <- aggregate(MedExam ~ urban2013 , data = DF_map, FUN = sum)

# Aggregating the 'ShCoroner' column based on the 'urban2013' column in DF_map
# The sum is calculated for each unique value in the 'urban2013' column
urb_ShC <- aggregate(ShCoroner ~ urban2013 , data = DF_map, FUN = sum)

# Merging the three aggregated dataframes (urb_Cor, urb_ME, urb_ShC) based on the 'urban2013' column
urb_st_dis <- merge(urb_Cor, urb_ME, by=c("urban2013"), all=T)
urb_st_dis <- merge(urb_st_dis, urb_ShC, by=c("urban2013"), all=T)

# Creating an empty matrix called 'urbanization' with 6 rows and 3 columns
urbanization = matrix(nrow = 6, ncol = 3, byrow = TRUE)

# Assigning row names to the 'urbanization' matrix
# These row names represent different levels of urbanization
rownames(urbanization) <- c("LargeCentralMetro", "LargeFringeMetro", "MediumMetro", "SmallMetro", "Micropolitan", "NonCore")

# Assigning column names to the 'urbanization' matrix
# These column names represent different variables
colnames(urbanization) <- c("Coroner", "MedExam", "ShCoroner")

# Populating the 'urbanization' matrix with values from the 'urb_st_dis' dataframe
urbanization[1:3, 1] <- urb_st_dis[1:3, 2]
urbanization[1:3, 2] <- urb_st_dis[1:3, 3]
urbanization[1:3, 3] <- urb_st_dis[1:3, 4]
urbanization[4, 1] <- urb_st_dis[6, 2]
urbanization[4, 2] <- urb_st_dis[6, 3]
urbanization[4, 3] <- urb_st_dis[6, 4]
urbanization[5:6, 1] <- urb_st_dis[4:5, 2]
urbanization[5:6, 2] <- urb_st_dis[4:5, 3]
urbanization[5:6, 3] <- urb_st_dis[4:5, 4]

# Creating a bar plot of the transposed 'urbanization' matrix
# The 'beside' argument places the bars side by side
# Customizing the legend text with variable names
# Setting the y-axis label to "Counties", Adjusting the y-axis limits based on the range of values in 'urbanization'
barplot(t(as.matrix(urbanization)), beside = TRUE, legend.text = c("Coroner", "MedExam", "ShCoroner"),
        ylab = "Counties", ylim = range(pretty(c(0, urbanization))),
        args.legend = list(x = "top", horiz = TRUE, bty = "n"))

# Save the plot as a PNG file
ggsave("C:/Users/gr925268/Dropbox/Coroners/Data/Figures/urbanization.png", width = 10, height = 6, dpi = 300)


###########################################################
### FIGURE 2 APPENDIX
# name old file RACE coverage by system.png
#### COVERAGE BY RACE

# Select specific columns from the DF data frame
DF_et = DF[c(1:4, 5:9, 14, 16:20)]

# Multiply percentage columns by population column to get absolute values
DF_et$Native_perc <- DF_et$Native_perc * DF_et$Population
DF_et$AsianPacIsl_perc <- DF_et$AsianPacIsl_perc * DF_et$Population
DF_et$Black_perc <- DF_et$Black_perc * DF_et$Population
DF_et$WHisp_perc <- DF_et$WHisp_perc * DF_et$Population
DF_et$WnonHisp_perc <- DF_et$WnonHisp_perc * DF_et$Population

# Aggregate mean values by CountyCode
Native <- aggregate(Native_perc ~ CountyCode, data = DF_et, FUN = mean)
AsianPc <- aggregate(AsianPacIsl_perc ~ CountyCode, data = DF_et, FUN = mean)
Black <- aggregate(Black_perc ~ CountyCode, data = DF_et, FUN = mean)
Whisp <- aggregate(WHisp_perc ~ CountyCode, data = DF_et, FUN = mean)
WNonhisp <- aggregate(WnonHisp_perc ~ CountyCode + Coroner + MedExam + ShCoroner, data = DF_et, FUN = mean)

# Merge the aggregated data frames
st_dis <- merge(Native, AsianPc, by = "CountyCode", all = TRUE)
st_dis <- merge(st_dis, Black, by = "CountyCode", all = TRUE)
st_dis <- merge(st_dis, Whisp, by = "CountyCode", all = TRUE)
st_dis <- merge(st_dis, WNonhisp, by = "CountyCode", all = TRUE)

# Aggregate mean values by Coroner, MedExam, and ShCoroner for each race:
Cor_Na <- aggregate(Native_perc ~ Coroner, data = st_dis, FUN = mean)
ME_Na <- aggregate(Native_perc ~ MedExam, data = st_dis, FUN = mean)
ShC_Na <- aggregate(Native_perc ~ ShCoroner, data = st_dis, FUN = mean)

Cor_As <- aggregate(AsianPacIsl_perc ~ Coroner, data = st_dis, FUN = mean)
ME_As <- aggregate(AsianPacIsl_perc ~ MedExam, data = st_dis, FUN = mean)
ShC_As <- aggregate(AsianPacIsl_perc ~ ShCoroner, data = st_dis, FUN = mean)

Cor_Bl <- aggregate(Black_perc ~ Coroner, data = st_dis, FUN = mean)
ME_Bl <- aggregate(Black_perc ~ MedExam, data = st_dis, FUN = mean)
ShC_Bl <- aggregate(Black_perc ~ ShCoroner, data = st_dis, FUN = mean)

Cor_hisp <- aggregate(WHisp_perc ~ Coroner, data = st_dis, FUN = mean)
ME_hisp <- aggregate(WHisp_perc ~ MedExam, data = st_dis, FUN = mean)
ShC_hisp <- aggregate(WHisp_perc ~ ShCoroner, data = st_dis, FUN = mean)

Cor_wh <- aggregate(WnonHisp_perc ~ Coroner, data = st_dis, FUN = mean)
ME_wh <- aggregate(WnonHisp_perc ~ MedExam, data = st_dis, FUN = mean)
ShC_wh <- aggregate(WnonHisp_perc ~ ShCoroner, data = st_dis, FUN = mean)

# Create a matrix for the table
table1 <- matrix(nrow = 5, ncol = 3, byrow = TRUE)
colnames(table1) <- c('Coroner', 'MedExam', 'ShCoroner')
rownames(table1) <- c('Nat_am', 'Asian', 'Black', 'Hisp', 'White')

# Fill in the table with the aggregated mean values
table1[1, 1] <- Cor_Na[2, 2]
table1[1, 2] <- ME_Na[2, 2]
table1[1, 3] <- ShC_Na[2, 2]
table1[2, 1] <- Cor_As[2, 2]
table1[2, 2] <- ME_As[2, 2]
table1[2, 3] <- ShC_As[2, 2]
table1[3, 1] <- Cor_Bl[2, 2]
table1[3, 2] <- ME_Bl[2, 2]
table1[3, 3] <- ShC_Bl[2, 2]
table1[4, 1] <- Cor_hisp[2, 2]
table1[4, 2] <- ME_hisp[2, 2]
table1[4, 3] <- ShC_hisp[2, 2]
table1[5, 1] <- Cor_wh[2, 2]
table1[5, 2] <- ME_wh[2, 2]
table1[5, 3] <- ShC_wh[2, 2]

# Create a bar plot of the table
barplot(t(as.matrix(table1)), beside = TRUE, legend.text = c("Coroner", "MedExam", "ShCoroner"),
        ylab = "Population coverage", ylim = range(pretty(c(0, table1))),
        args.legend = list(x = "top", horiz = TRUE, bty = "n"))


# Save the plot as a PNG file
ggsave("C:/Users/gr925268/Dropbox/Coroners/Data/Figures/Ethnicity coverage by system.png", width = 10, height = 6, dpi = 300)



library(usmap)
library(ggplot2)
#######load and transform data for the map-figure representation
load("C:/Users/gr925268/Dropbox/Coroners/Data/Dataset (R files)/DF_analysis.Rda")

#### ggplot is updated to 2020 but  Copper River and Chugach belonged to Valdez-Cordova 
# census area but left it in 2019 to join the Unorganized Borough so need to duplicate the 
# Valdez-Cordova info to match the 2013-2019 situation
# NEED TO CHANGE ALASKA COUNTIES: COPPER RIVER AND CHUGACH
DF[21994,] <- DF[645,]
DF[21994,1] <- "02066"
DF[21995,] <- DF[645,]
DF[21995,1] <- "02063"

###########################################################
### FIGURE 3-8 APPENDIX - MAPS BY ETHNICITY
# PREPARE TABLE FOR MAP AND MPV KILLINGS BY ETHNICITY


### BLACK KILLINGS
### FIGURE 3a APPENDIX - MAP
### MAP BLACK KILLINGS
# name on overleaf: ethn_map_black.png

# Calculate normalized values for map_kill_black
DF$map_kill_black <- DF$map_kill_black / (DF$Black_perc * DF$Population)

# Select relevant columns for DF_map
DF_map <- DF[, c("CountyCode", "State", "map_kill_black")]

# Remove rows with missing values for map_kill_black
DF_map <- DF_map[!is.na(DF_map$map_kill_black), ]

# Select only CountyCode and map_kill_black columns
DF_map <- DF_map[, c("CountyCode", "map_kill_black")]

# Aggregate mean values of map_kill_black by CountyCode
DF_map <- aggregate(map_kill_black ~ CountyCode, data = DF_map, FUN = mean)

# Rename column names
colnames(DF_map) <- c("fips", "map_kill_black")

# Remove rows with map_kill_black values greater than 0
DF_map <- DF_map[(DF_map$map_kill_black > 0), ]

# Plot map Misreported data
plot_usmap(regions = 'counties', data = DF_map, values = "map_kill_black", color = "gray25") +
  scale_fill_binned(low = "lightsteelblue1", high = "grey53", na.value = "white",
                    guide = guide_coloursteps(even.steps = FALSE), name = "") +
  theme(legend.position = "right", legend.text = element_text(size = 20), 
        legend.key.height = unit(1, 'cm'),
        legend.key.width = unit(1, 'cm'))

# Save the plot as a PNG file
ggsave("C:/Users/gr925268/Dropbox/Coroners/Data/Figures/ethn_map_black.png", width = 10, height = 6, dpi = 300)

### FIGURE 3b APPENDIX - MPV
### MPV BLACK KILLINGS
# name on overleaf: ethn_mpv_black.png

# Calculate normalized values for mpv_kill_black
DF$mpv_kill_black <- DF$mpv_kill_black / (DF$Black_perc * DF$Population)

# Select relevant columns for DF_mpv
DF_mpv <- DF[, c("CountyCode", "State", "mpv_kill_black")]

# Remove rows with missing values for mpv_kill_black
DF_mpv <- DF_mpv[!is.na(DF_mpv$mpv_kill_black), ]

# Select only CountyCode and mpv_kill_black columns
DF_mpv <- DF_mpv[, c("CountyCode", "mpv_kill_black")]

# Aggregate mean values of mpv_kill_black by CountyCode
DF_mpv <- aggregate(mpv_kill_black ~ CountyCode, data = DF_mpv, FUN = mean)

# Rename column names
colnames(DF_mpv) <- c("fips", "mpv_kill_black")

# Remove rows with mpv_kill_black values greater than 0
DF_mpv <- DF_mpv[(DF_mpv$mpv_kill_black > 0), ]

# Plot mpv Misreported data
plot_usmap(regions = 'counties', data = DF_mpv, values = "mpv_kill_black", color = "gray25") +
  scale_fill_binned(low = "lightsteelblue1", high = "grey52", na.value = "white",
                    guide = guide_coloursteps(even.steps = FALSE), name = "") +
  theme(legend.position = "right", legend.text = element_text(size = 20), 
        legend.key.height = unit(1, 'cm'),
        legend.key.width = unit(1, 'cm'))

# Save the plot as a PNG file
ggsave("C:/Users/gr925268/Dropbox/Coroners/Data/Figures/ethn_mpv_black.png", width = 10, height = 6, dpi = 300)

###########################################################
### FIGURE 4 APPENDIX - MAPS BY ETHNICITY
### HISPANIC KILLINGS


### FIGURE 4a APPENDIX - MAPS BY ETHNICITY
## MAP white HISPANIC KILLINGS 
# name on overleaf: ethn_map_hisp.png

# look at the share of map_kill_hispanic over the white hispanic population
DF$map_kill_hisp <- DF$map_kill_hisp / (DF$WHisp_perc * DF$Population)

# Select relevant columns for DF_map
DF_map <- DF[, c("CountyCode", "State", "map_kill_hisp")]

# Remove rows with missing values for map_kill_hisp
DF_map <- DF_map[!is.na(DF_map$map_kill_hisp), ]

# Select only CountyCode and map_kill_hisp columns
DF_map <- DF_map[, c("CountyCode", "map_kill_hisp")]

# Aggregate mean values of map_kill_hisp by CountyCode
DF_map <- aggregate(map_kill_hisp ~ CountyCode, data = DF_map, FUN = mean)

# Rename column names
colnames(DF_map) <- c("fips", "map_kill_hisp")

# Remove rows with map_kill_hisp values greater than 0
DF_map <- DF_map[(DF_map$map_kill_hisp > 0), ]

# Plot map Misreported data
plot_usmap(regions = 'counties', data = DF_map, values = "map_kill_hisp", color = "gray25") +
  scale_fill_binned(low = "lightsteelblue1", high = "grey52", na.value = "white",
                    guide = guide_coloursteps(even.steps = FALSE), name = "") +
  theme(legend.position = "right", legend.text = element_text(size = 20), 
        legend.key.height = unit(1, 'cm'),
        legend.key.width = unit(1, 'cm'))

# Save the plot as a PNG file
ggsave("C:/Users/gr925268/Dropbox/Coroners/Data/Figures/ethn_map_hisp.png", width = 10, height = 6, dpi = 300)

### FIGURE 4b APPENDIX - MAPS BY ETHNICITY
## MPV HISPANIC KILLINGS 
###############################  !!!! this one includes also 8 obs from black_hispanics
# name on overleaf: ethn_mpv_hisp.png

# look at the share of map_kill_hispanic over the white hispanic population
DF$mpv_kill_hisp <- DF$mpv_kill_hisp / (DF$WHisp_perc * DF$Population)

# Select relevant columns for DF_map
DF_map <- DF[, c("CountyCode", "State", "mpv_kill_hisp")]

# Remove rows with missing values for mpv_kill_hisp
DF_map <- DF_map[!is.na(DF_map$mpv_kill_hisp), ]

# Select only CountyCode and mpv_kill_hisp columns
DF_map <- DF_map[, c("CountyCode", "mpv_kill_hisp")]

# Aggregate mean values of mpv_kill_hisp by CountyCode
DF_map <- aggregate(mpv_kill_hisp ~ CountyCode, data = DF_map, FUN = mean)

# Rename column names
colnames(DF_map) <- c("fips", "mpv_kill_hisp")

# Remove rows with mpv_kill_hisp values greater than 0
DF_map <- DF_map[(DF_map$mpv_kill_hisp > 0), ]

# Plot map Misreported data
plot_usmap(regions = 'counties', data = DF_map, values = "mpv_kill_hisp", color = "gray25") +
  scale_fill_binned(low = "lightsteelblue1", high = "grey52", na.value = "white",
                    guide = guide_coloursteps(even.steps = FALSE), name = "") +
  theme(legend.position = "right", legend.text = element_text(size = 20), 
        legend.key.height = unit(1, 'cm'),
        legend.key.width = unit(1, 'cm'))

# Save the plot as a PNG file
ggsave("C:/Users/gr925268/Dropbox/Coroners/Data/Figures/ethn_mpv_hisp.png", width = 10, height = 6, dpi = 300)
                                

###########################################################
### FIGURE 5 APPENDIX - MAPS BY ETHNICITY
### WHITE KILLINGS 

### FIGURE 5a APPENDIX - MAPS BY ETHNICITY
#### MAP WHITE KILLINGS
# name on overleaf: ethn_map_white.png

# Normalize the 'map_kill_white' variable by dividing it by the product of 'WnonHisp_perc' and 'Population'
DF$map_kill_white <- DF$map_kill_white / (DF$WnonHisp_perc * DF$Population)

# Select the relevant columns ('CountyCode', 'State', 'map_kill_white')
DF_map = DF[,c("CountyCode","State","map_kill_white")]

# Remove rows with missing values for 'map_kill_white'
DF_map = DF_map[!is.na(DF_map$map_kill_white),]

# Select the columns 'CountyCode' and 'map_kill_white'
DF_map = DF_map[,c("CountyCode","map_kill_white")]

# Aggregate the data by 'CountyCode' and calculate the mean of 'map_kill_white'
DF_map = aggregate( map_kill_white ~ CountyCode, data = DF_map, FUN=mean)

# Rename the column names to 'fips' and 'map_kill_white'
colnames(DF_map) <- c("fips", "map_kill_white")

# Filter out rows where 'map_kill_white' is greater than 0
DF_map = DF_map[(DF_map$map_kill_white > 0),]

# Plot the map with 'map_kill_white' values
plot_usmap(regions='counties',data=DF_map,values="map_kill_white", color = "gray25") +
  scale_fill_binned(low="lightsteelblue1", high="grey52",na.value="white",
                    guide = guide_coloursteps(even.steps = FALSE), name= "") +
  theme(legend.position = "right", legend.text = element_text(size=20), 
        legend.key.height= unit(1, 'cm'),
        legend.key.width= unit(1, 'cm'))

# Save the plot as a PNG file
ggsave("C:/Users/gr925268/Dropbox/Coroners/Data/Figures/ethn_map_white.png", width = 10, height = 6, dpi = 300)


### FIGURE 5b APPENDIX - MAPS BY ETHNICITY
### MPV WHITE KILLINGS
# name on overleaf: ethn_mpv_white.png

# Normalize the 'mpv_kill_white' variable by dividing it by the product of 'WnonHisp_perc' and 'Population'
DF$mpv_kill_white <- DF$mpv_kill_white / (DF$WnonHisp_perc * DF$Population)

# Select the relevant columns ('CountyCode', 'State', 'mpv_kill_white')
DF_map = DF[,c("CountyCode","State","mpv_kill_white")]

# Remove rows with missing values for 'mpv_kill_white'
DF_map = DF_map[!is.na(DF_map$mpv_kill_white),]

# Select the columns 'CountyCode' and 'mpv_kill_white'
DF_map = DF_map[,c("CountyCode","mpv_kill_white")]

# Aggregate the data by 'CountyCode' and calculate the mean of 'mpv_kill_white'
DF_map = aggregate( mpv_kill_white ~ CountyCode, data = DF_map, FUN=mean)

# Rename the column names to 'fips' and 'mpv_kill_white'
colnames(DF_map) <- c("fips", "mpv_kill_white")

# Filter out rows where 'mpv_kill_white' is greater than 0
DF_map = DF_map[(DF_map$mpv_kill_white > 0),]

# Plot the map with 'mpv_kill_white' values
plot_usmap(regions='counties',data=DF_map,values="mpv_kill_white", color = "gray25") +
  scale_fill_binned(low="lightsteelblue1", high="grey52",na.value="white",
                    guide = guide_coloursteps(even.steps = FALSE), name= "") +
  theme(legend.position = "right", legend.text = element_text(size=20), 
        legend.key.height= unit(1, 'cm'),
        legend.key.width= unit(1, 'cm'))
  
# Save the plot as a PNG file
  ggsave("C:/Users/gr925268/Dropbox/Coroners/Data/Figures/ethn_mpv_white.png", width = 10, height = 6, dpi = 300)

  
###########################################################
### FIGURE 6 APPENDIX - MAPS BY ETHNICITY
### Asian, Native Americans and Unknown Race
  
  ### FIGURE 6a APPENDIX - MAPS BY ETHNICITY
  ### MAP ASIAN KILLINGS
  # name on overleaf: ethn_map_asian_pac_is.png
  
  # Calculate the rate of Asian and Pacific Islander killings per population
  DF$map_asian_pac_is <- (DF$map_kill_asian + DF$map_kill_pacif_isl) / (DF$AsianPacIsl_perc * DF$Population)
  
  # Extract relevant columns from the data frame
  DF_map = DF[,c("CountyCode","State","map_asian_pac_is")]
  DF_map = DF_map[!is.na(DF_map$map_asian_pac_is),]
  DF_map = DF_map[,c("CountyCode","map_asian_pac_is")]
  
  # Calculate the mean rate of Asian and Pacific Islander killings per county
  DF_map = aggregate(map_asian_pac_is ~ CountyCode, data = DF_map, FUN = mean) 
  colnames(DF_map) <- c("fips", "map_asian_pac_is")
  DF_map = DF_map[(DF_map$map_asian > 0),]
  
  # Plot map of misreported data
  plot_usmap(regions='counties',data=DF_map,values="map_asian_pac_is", color = "gray25") +
    scale_fill_binned(low = "lightsteelblue1", high = "grey52", na.value = "white",
                      guide = guide_coloursteps(even.steps = FALSE), name = "") +
    theme(legend.position = "right", legend.text = element_text(size = 20), 
          legend.key.height = unit(1, 'cm'),
          legend.key.width = unit(1, 'cm'))
  
  # Save the plot as a PNG file
  ggsave("C:/Users/gr925268/Dropbox/Coroners/Data/Figures/ethn_map_asian_pac_is.png", width = 10, height = 6, dpi = 300)
  
  ### FIGURE 6b APPENDIX - MAPS BY ETHNICITY
  ### MAP ASIAN KILLINGS
  # name on overleaf: ethn_mpv_asian_pac_is.png
  
  # Calculate the rate of Asian and Pacific Islander killings per population using MPV (Mapping Police Violence) data
  DF$mpv_asian_pac_is <- (DF$mpv_kill_asian + DF$mpv_kill_pacif_isl) / (DF$AsianPacIsl_perc * DF$Population)
  
  # Extract relevant columns from the data frame
  DF_map = DF[,c("CountyCode","State","mpv_asian_pac_is")]
  DF_map = DF_map[!is.na(DF_map$mpv_asian_pac_is),]
  DF_map = DF_map[,c("CountyCode","mpv_asian_pac_is")]
  
  # Calculate the mean rate of Asian and Pacific Islander killings per county using MPV data
  DF_map = aggregate(mpv_asian_pac_is ~ CountyCode, data = DF_map, FUN = mean) 
  colnames(DF_map) <- c("fips", "mpv_asian_pac_is")
  DF_map = DF_map[(DF_map$mpv_asian_pac_is > 0),]
  
  # Plot map of misreported data using MPV data
  plot_usmap(regions='counties',data=DF_map,values="mpv_asian_pac_is", color = "gray25")+
    scale_fill_binned(low="lightsteelblue1", high="grey52",na.value="white",
                      guide = guide_coloursteps(even.steps = FALSE), name= "")+
    theme(legend.position = "right", legend.text = element_text(size=20), 
          legend.key.height= unit(1, 'cm'),
          legend.key.width= unit(1, 'cm'))
  
  # Save the plot as a PNG file
  ggsave("C:/Users/gr925268/Dropbox/Coroners/Data/Figures/ethn_mpv_asian_pac_is.png", width = 10, height = 6, dpi = 300)
  ### FIGURE 6c APPENDIX - MAPS BY ETHNICITY
  ### MAP NATIVE AMERICAN KILLINGS
  # name on overleaf: ethn_map_native.png
  
  # Calculate the rate of Native American killings per population
  DF$map_kill_nativ_am <- DF$map_kill_nativ_am / (DF$Native_perc * DF$Population)
  
  # Extract relevant columns from the data frame
  DF_map = DF[,c("CountyCode","State","map_kill_nativ_am")]
  DF_map = DF_map[!is.na(DF_map$map_kill_nativ_am),]
  DF_map = DF_map[,c("CountyCode","map_kill_nativ_am")]
  
  # Calculate the mean rate of Native American killings per county
  DF_map = aggregate(map_kill_nativ_am ~ CountyCode, data = DF_map, FUN = mean) 
  colnames(DF_map) <- c("fips", "map_kill_nativ_am")
  DF_map = DF_map[(DF_map$map_kill_nativ_am > 0),]
  
  # Plot map of misreported data
  plot_usmap(regions='counties',data=DF_map,values="map_kill_nativ_am", color = "gray25") +
    scale_fill_binned(low = "lightsteelblue1", high = "grey52", na.value = "white",
                      guide = guide_coloursteps(even.steps = FALSE), name = "") +
    theme(legend.position = "right", legend.text = element_text(size = 20), 
          legend.key.height = unit(1, 'cm'),
          legend.key.width = unit(1, 'cm'))
  
  # Save the plot as a PNG file
  ggsave("C:/Users/gr925268/Dropbox/Coroners/Data/Figures/ethn_map_native.png", width = 10, height = 6, dpi = 300)
  
  ### FIGURE 6d APPENDIX - MAPS BY ETHNICITY
  ### MPV NATIVE AMERICAN KILLINGS
  # name on overleaf: ethn_mpv_native.png
  
  # Calculate the rate of Native American killings per population using MPV data
  DF$mpv_kill_nativ_am <- DF$mpv_kill_nativ_am / (DF$Native_perc * DF$Population)
  
  # Extract relevant columns from the data frame
  DF_map = DF[,c("CountyCode","State","mpv_kill_nativ_am")]
  DF_map = DF_map[!is.na(DF_map$mpv_kill_nativ_am),]
  DF_map = DF_map[,c("CountyCode","mpv_kill_nativ_am")]
  
  # Calculate the mean rate of Native American killings per county using MPV data
  DF_map = aggregate(mpv_kill_nativ_am ~ CountyCode, data = DF_map, FUN = mean) 
  colnames(DF_map) <- c("fips", "mpv_kill_nativ_am")
  DF_map = DF_map[(DF_map$mpv_kill_nativ_am > 0),]
  
  # Plot map of misreported data using MPV data
  plot_usmap(regions='counties',data=DF_map,values="mpv_kill_nativ_am", color = "gray25") +
    scale_fill_binned(low = "lightsteelblue1", high = "grey52", na.value = "white",
                      guide = guide_coloursteps(even.steps = FALSE), name = "") +
    theme(legend.position = "right", legend.text = element_text(size = 20), 
          legend.key.height = unit(1, 'cm'),
          legend.key.width = unit(1, 'cm'))
  
  # Save the plot as a PNG file
  ggsave("C:/Users/gr925268/Dropbox/Coroners/Data/Figures/ethn_mpv_native.png", width = 10, height = 6, dpi = 300)
  
  ### FIGURE 6e APPENDIX - MAPS BY ETHNICITY
  ### MAP Unknown ethnicity KILLINGS
  # name on overleaf: ethn_map_unknown.png
  # Calculate the rate of unknown ethnicity killings
  DF$map_kill_unkn_race <- DF$map_kill_unkn_race / DF$Population
  
  # Create a new data frame with selected columns
  DF_map = DF[,c("CountyCode","State","map_kill_unkn_race")]
  
  # Remove rows with missing values in map_kill_unkn_race
  DF_map = DF_map[!is.na(DF_map$map_kill_unkn_race),]
  
  # Keep only the CountyCode and map_kill_unkn_race columns
  DF_map = DF_map[,c("CountyCode","map_kill_unkn_race")]
  
  # Aggregate data by CountyCode, calculating the mean of map_kill_unkn_race
  DF_map = aggregate(map_kill_unkn_race ~ CountyCode, data = DF_map, FUN = mean)
  
  # Rename the columns of DF_map
  colnames(DF_map) <- c("fips", "map_kill_unkn_race")
  
  # Filter out rows with map_kill_unkn_race greater than 0
  DF_map = DF_map[(DF_map$map_kill_unkn_race > 0),]
  
  # Plot the map of misreported data
  plot_usmap(regions='counties',data=DF_map,values="map_kill_unkn_race", color = "gray25") +
    scale_fill_binned(low = "lightsteelblue1", high = "grey52", na.value = "white",
                      guide = guide_coloursteps(even.steps = FALSE), name = "") +
    theme(legend.position = "right", legend.text = element_text(size = 20), 
          legend.key.height = unit(1, 'cm'),
          legend.key.width = unit(1, 'cm'))
  
  # Save the plot as a PNG file
  ggsave("C:/Users/gr925268/Dropbox/Coroners/Data/Figures/ethn_map_unknown.png", width = 10, height = 6, dpi = 300)
  
  # Perform similar operations for MPV Unknown ethnicity killings
  ### FIGURE 6f APPENDIX - MAPS BY ETHNICITY
  ### MPV Unknown ethnicity KILLINGS
  # name on overleaf: ethn_mpv_unknown.png
  
  # Calculate the rate of unknown ethnicity killings
  DF$mpv_kill_unkn_race <- DF$mpv_kill_unkn_race / DF$Population
  
  # Create a new data frame with selected columns
  DF_map = DF[,c("CountyCode","State","mpv_kill_unkn_race")]
  
  # Remove rows with missing values in mpv_kill_unkn_race
  DF_map = DF_map[!is.na(DF_map$mpv_kill_unkn_race),]
  
  # Keep only the CountyCode and mpv_kill_unkn_race columns
  DF_map = DF_map[,c("CountyCode","mpv_kill_unkn_race")]
  
  # Aggregate data by CountyCode, calculating the mean of mpv_kill_unkn_race
  DF_map = aggregate(mpv_kill_unkn_race ~ CountyCode, data = DF_map, FUN = mean)
  
  # Rename the columns of DF_map
  colnames(DF_map) <- c("fips", "mpv_kill_unkn_race")
  
  # Filter out rows with mpv_kill_unkn_race greater than 0
  DF_map = DF_map[(DF_map$mpv_kill_unkn_race > 0),]
  
  # Plot the map of misreported data
  plot_usmap(regions='counties',data=DF_map,values="mpv_kill_unkn_race", color = "gray25") +
    scale_fill_binned(low = "lightsteelblue1", high = "grey55", na.value = "white",
                      guide = guide_coloursteps(even.steps = FALSE), name = "") +
    theme(legend.position = "right", legend.text = element_text(size = 20), 
          legend.key.height = unit(1, 'cm'),
          legend.key.width = unit(1, 'cm'))
  
  # Save the plot as a PNG file
  ggsave("C:/Users/gr925268/Dropbox/Coroners/Data/Figures/ethn_mpv_unknown.png", width = 10, height = 6, dpi = 300)
#   
# OLD MAP, SEE LINE 1451 FOR NEW VERSION
# ### MAP Circ. undetermined + Circ. other + Circ. other not specified 
# # name on overleaf: map_circumstsance_undetermined.png
# 
# # Create a new data frame with selected columns
# DF_map = DF[,c("CountyCode", "State", "map_circ_circumstance_undetermined")]
#   
# # Remove rows with missing values in map_circ_circumstance_undetermined
# DF_map = DF_map[!is.na(DF_map$map_circ_circumstance_undetermined),]
# # Keep only the required columns
# DF_map = DF_map[,c("CountyCode","map_circ_circumstance_undetermined")]
#   
# # Aggregate data by CountyCode, calculating the mean of (map_circ_circumstance_undetermined + map_circ_other + map_circ_other_notspecified) / map_hom_tot
#  #DF_map = aggregate((map_circ_circumstance_undetermined + map_circ_other + map_circ_other_notspecified) / map_hom_tot ~ CountyCode, data = DF_map, FUN = mean)
# DF_map = aggregate(map_circ_circumstance_undetermined ~ CountyCode, data = DF_map, FUN = mean)
# # Rename the columns of DF_map
# colnames(DF_map) <- c("fips","map_circ_undetermined")
#   
# 
# DF_map = DF_map[(DF_map$map_circ_undetermined > 0),]
#   
#   # Plot the map of misreported data
#   plot_usmap(regions='counties', data=DF_map, values="map_circ_undetermined", color="gray52") +
#     scale_fill_binned(low="lightsteelblue1", high="grey25", na.value="white",
#                       guide = guide_coloursteps(even.steps = FALSE), name="") +
#     theme(legend.position="right", legend.text=element_text(size=20),
#           legend.key.height=unit(1, 'cm'),
#           legend.key.width=unit(1, 'cm'))
#   
#   # Save the plot as a PNG file
#   ggsave("C:/Users/gr925268/Dropbox/Coroners/Data/Figures/map_circumstsance_undetermined.png", width=10, height=6, dpi=300)
  
  
##################################################
  # FIGURE 20 Appointed vs Elected analysis sample
  
  # Prepare map data Adjacent Appointed
  DF$sample = DF$sample_Appt1
  DF_map = DF[,c("CountyCode","State","Appoint","sample")]
  DF_map = DF_map[!is.na(DF_map$sample),]
  DF_map = DF_map[(DF_map$sample == 1),]
  DF_map$index_C = as.numeric(DF_map$sample) + as.numeric(DF_map$sample)*as.numeric(DF_map$Appoint)
  DF_map = DF_map[,c("CountyCode","index_C")]
  colnames(DF_map) <- c("fips", "index_C")
  DF_map$index_C <- as.character(DF_map$index_C)
  
  plot_usmap(regions='counties',data=DF_map,values="index_C", color = "gray25") +
    
    # Binning the fill values into a color scale from "lightsteelblue1" to "grey25"
    # Assigning "white" for missing values
    scale_fill_binned(low="lightsteelblue1", high="grey52", na.value="white",
                      guide = guide_coloursteps(even.steps = FALSE)) +
    
    # Manually specifying the fill colors for the legend
    # Assigning "lightsteelblue1" to 1 and "grey25" to 2
    # Assigning "white" for missing values
    scale_fill_manual(values=c("1"="lightsteelblue1", "2"="grey52"),
                      labels=c("Elected", "Appointed"),
                      na.value="white", name="") +
    
    # Customizing the theme and legend appearance
    theme(legend.position = "bottom", legend.text = element_text(size=20),
          legend.key.height = unit(1, 'cm'),
          legend.key.width = unit(1, 'cm'))
  
  # Save the plot as a PNG file
  ggsave("C:/Users/gr925268/Dropbox/Coroners/Data/Figures/App_adj.png", width=10, height=6, dpi=300)
  
  
  ##################################################
  # FIGURE 21 Physician vs non-Physician analysis sample
  
  # Prepare map data Adjacent Physician
  DF$sample = DF$sample_Phy1
  DF_map = DF[,c("CountyCode","State","Physician","sample")]
  DF_map = DF_map[!is.na(DF_map$sample),]
  DF_map = DF_map[(DF_map$sample == 1),]
  DF_map$index_C = as.numeric(DF_map$sample) + as.numeric(DF_map$sample)*as.numeric(DF_map$Physician)
  DF_map = DF_map[,c("CountyCode","index_C")]
  colnames(DF_map) <- c("fips", "index_C")
  DF_map$index_C <- as.character(DF_map$index_C)
  
  plot_usmap(regions='counties',data=DF_map,values="index_C", color = "gray25") +
    
    # Binning the fill values into a color scale from "lightsteelblue1" to "grey25"
    # Assigning "white" for missing values
    scale_fill_binned(low="lightsteelblue1", high="grey52", na.value="white",
                      guide = guide_coloursteps(even.steps = FALSE)) +
    
    # Manually specifying the fill colors for the legend
    # Assigning "lightsteelblue1" to 1 and "grey25" to 2
    # Assigning "white" for missing values
    scale_fill_manual(values=c("1"="lightsteelblue1", "2"="grey52"),
                      labels=c("Non-Physician", "Physician"),
                      na.value="white", name="") +
    
    # Customizing the theme and legend appearance
    theme(legend.position = "bottom", legend.text = element_text(size=20),
          legend.key.height = unit(1, 'cm'),
          legend.key.width = unit(1, 'cm'))
  
  ggsave("C:/Users/gr925268/Dropbox/Coroners/Data/Figures/Phy_adj.png", width=10, height=6, dpi=300)
  
  
  
  
  
  
  
  
  
  ##################################################
  # FIGURE 20a Appointed vs  Elected counties
  
  # Prepare map data Adjacent Appointed
  DF_map = DF[,c("CountyCode","Appoint")]

  # Replace the values in the "Appoint" column: 1 with "Appoint" and 0 with "Other"
  DF_map$Appoint[DF_map$Appoint == 1] <- "Appoint"
  DF_map$Appoint[DF_map$Appoint == 0] <- "Elected"

  colnames(DF_map) <- c("fips", "System")
  # Plot the US map with county-level data using DF_map
  plot_usmap(regions = 'counties', data = DF_map, values = "System", color = "gray25") +
    scale_fill_manual(values = c("Elected" = "white", alpha = 0.25, "Appoint" = "grey52"), name = "") +
    theme(legend.position = "bottom", legend.text = element_text(size = 20),
          legend.key.height = unit(1, 'cm'),
          legend.key.width = unit(1, 'cm'))
  
  # Save the plot as a PNG file
  ggsave("C:/Users/gr925268/Dropbox/Coroners/Data/Figures/AppoitvsElect.png", width = 10, height = 6, dpi = 300)
  
  
  
  
  ##################################################
  # FIGURE 21a Physician vs non-Physician counties

  DF_map = DF[,c("CountyCode","Physician")]

  # Replace the values in the "Appoint" column: 1 with "Appoint" and 0 with "Other"
  DF_map$Physician[DF_map$Physician == 1] <- "Physician"
  DF_map$Physician[DF_map$Physician == 0] <- "Non-Physician"
  
  colnames(DF_map) <- c("fips", "System")
  
  # Plot the US map with county-level data using DF_map
  plot_usmap(regions = 'counties', data = DF_map, values = "System", color = "gray25") +
    scale_fill_manual(values = c("Non-Physician" = "white", alpha = 0.25, "Physician" = "grey52"), name = "") +
    theme(legend.position = "bottom", legend.text = element_text(size = 20),
          legend.key.height = unit(1, 'cm'),
          legend.key.width = unit(1, 'cm'))
  
  # Save the plot as a PNG file
  ggsave("C:/Users/gr925268/Dropbox/Coroners/Data/Figures/PhysvsNonPhys.png", width = 10, height = 6, dpi = 300)
  

# YEARS OF UNDERREPORTING 
# DF$diff_kill_pol > 0
  
  DF$diff_kill_pol_D = as.numeric(DF$diff_kill_pol > 0) 
  # Create a new data frame with selected columns
  DF_map = DF[,c("CountyCode","diff_kill_pol_D")]
  
  # Remove rows with missing values in diff_kill_pol_D
  DF_map = DF_map[!is.na(DF_map$diff_kill_pol_D),]
  
  
  # Keep only the required columns
  DF_map = DF_map[,c("CountyCode","diff_kill_pol_D")]
  # Aggregate the "diff_kill_pol_D" column by CountyCode, calculating the mean
  DF_map = aggregate(diff_kill_pol_D ~ CountyCode, data = DF_map, FUN = mean)

  # Multiply the values in the "diff_kill_pol_D" column by the number of years
  DF_map$diff_kill_pol_D = DF_map$diff_kill_pol_D * 7
  
  # Rename the column names of DF_map to "fips" and "diff_kill_pol_D"
  colnames(DF_map) <- c("fips", "diff_kill_pol_D")
  
  # Filter out rows where the "diff_kill_pol_D" column is greater than 0
  DF_map = DF_map[(DF_map$diff_kill_pol_D > 0), ]
  
  # Plot the US map with county-level data using DF_map
  plot_usmap(regions = 'counties', data = DF_map, values = "diff_kill_pol_D", color = "gray25") +
    scale_fill_binned(low = "lightsteelblue1", high = "grey52", na.value = "white",
                      guide = guide_coloursteps(even.steps = FALSE), name = "") +
    theme(legend.position = "right", legend.text = element_text(size = 20),
          legend.key.height = unit(1, 'cm'),
          legend.key.width = unit(1, 'cm'))
  
  # Save the plot as a PNG file
  ggsave("C:/Users/gr925268/Dropbox/Coroners/Data/Figures/kill_pol_D_misrep_nbr.png", width = 10, height = 6, dpi = 300)

# MEAN OF UNDEREPORTIN
  
  # DF$diff_kill_pol > 0
  
  DF$diff_kill_pol_D = as.numeric(DF$diff_kill_pol > 0) 
  # Create a new data frame with selected columns
  DF_map = DF[,c("CountyCode","diff_kill_pol_D")]
  
  # Remove rows with missing values in diff_kill_pol_D
  DF_map = DF_map[!is.na(DF_map$diff_kill_pol_D),]
  
  
  # Keep only the required columns
  DF_map = DF_map[,c("CountyCode","diff_kill_pol_D")]
  # Aggregate the "diff_kill_pol_D" column by CountyCode, calculating the mean
  DF_map = aggregate(diff_kill_pol_D ~ CountyCode, data = DF_map, FUN = mean)
  # Rename the columns of DF_map
  colnames(DF_map) <- c("fips","diff_kill_pol_D")
  
  # Filter out rows with diff_kill_pol_D greater than 0
  DF_map = DF_map[(DF_map$diff_kill_pol_D > 0),]
  
  # Plot the map of misreported data
  plot_usmap(regions='counties', data=DF_map, values="diff_kill_pol_D", color="gray25") +
    scale_fill_binned(low="lightsteelblue1", high="grey52", na.value="white",
                      guide = guide_coloursteps(even.steps = FALSE), name="") +
    theme(legend.position="right", legend.text=element_text(size=20),
          legend.key.height=unit(1, 'cm'),
          legend.key.width=unit(1, 'cm'))
  
  # Save the plot as a PNG file
  ggsave("C:/Users/gr925268/Dropbox/Coroners/Data/Figures/diff_kill_pol_mean.png", width = 10, height = 6, dpi = 300)
  
  
  
  
  
### LATE
  DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert + DF$ShCoroner >0) 
  unique(DF$State[(DF$LawEnf_cert1 ==1)])
  length(unique(DF$State[(DF$LawEnf_cert1 ==1)]))
  DFt = DF[(DF$sample_LE_SC1 == 1),]
  DFt=DF
  
  DFt$kill_tot_tr = log( DFt$hom_tot + sqrt(DFt$hom_tot^2 + 1))
  DFt$diff_kill_pol[(DFt$diff_kill_pol <= 0) ] <- 0  ## Set negative values of misreporting to 0
  
  # Generate indicator for underreporting
  DFt$diff_kill_pol_D = as.numeric(DFt$diff_kill_pol > 0)  
  
  # Generate indicator for declared circumstance_undetermined
  DFt$ratio_CU = DFt$map_circ_circumstance_undetermined/DFt$hom_tot
  med_ratio = median(DFt$ratio_CU[(DFt$LawEnf_cert1 == 0)], na.rm=T)
  DFt$map_circ_circumstance_undetermined_D = as.numeric(DFt$ratio_CU > med_ratio) 
  DFt$map_circ_circumstance_undetermined_D[is.na(DFt$ratio_CU)] <- 0
  # Create a new data frame with selected columns
  DF_map = DFt[,c("CountyCode","map_circ_circumstance_undetermined_D")]
  
  # Remove rows with missing values in diff_kill_pol_D
  DF_map = DF_map[!is.na(DF_map$map_circ_circumstance_undetermined_D),]
  
  DF_map = aggregate(map_circ_circumstance_undetermined_D ~ CountyCode, data = DF_map, FUN = mean)
  
  # Multiply the values in the "map_circ_circumstance_undetermined_D" column by the number of years
  DF_map$map_circ_circumstance_undetermined_D = DF_map$map_circ_circumstance_undetermined_D * 7
  
  # Rename the column names of DF_map to "fips" and "map_circ_circumstance_undetermined_D"
  colnames(DF_map) <- c("fips", "map_circ_circumstance_undetermined_D")
  
  # Filter out rows where the "map_circ_circumstance_undetermined_D" column is greater than 0
  DF_map = DF_map[(DF_map$map_circ_circumstance_undetermined_D > 0), ]
  
  # Plot the US map with county-level data using DF_map
  plot_usmap(regions = 'counties', data = DF_map, values = "map_circ_circumstance_undetermined_D", color = "gray25") +
    scale_fill_binned(low = "lightsteelblue1", high = "grey52", na.value = "white",
                      guide = guide_coloursteps(even.steps = FALSE), name = "") +
    theme(legend.position = "right", legend.text = element_text(size = 20),
          legend.key.height = unit(1, 'cm'),
          legend.key.width = unit(1, 'cm'))
  
  # Save the plot as a PNG file
  ggsave("C:/Users/gr925268/Dropbox/Coroners/Data/Figures/circ_und_D_mis_nbr.png", width = 10, height = 6, dpi = 300)
  
  
  
  #############################################################
  ############################################################
  # winsorized graph (mean capped at 5) THIS IS THE ONE ONE THE PAPER
  
  
  DF_map = DF[,c("CountyCode", "State", "map_circ_circumstance_undetermined")]
  
  # Remove rows with missing values in map_circ_circumstance_undetermined
  DF_map = DF_map[!is.na(DF_map$map_circ_circumstance_undetermined),]
  # Keep only the required columns
  DF_map = DF_map[,c("CountyCode","map_circ_circumstance_undetermined")]
  
  percentile_95 = quantile(DF_map$map_circ_circumstance_undetermined, 0.95)
  
  # Winsorize the variable at the 95th percentile
  DF_map$map_circ_circumstance_undetermined[DF_map$map_circ_circumstance_undetermined > percentile_95] <- percentile_95
  
  # Aggregate data by CountyCode, calculating the mean of (map_circ_circumstance_undetermined + map_circ_other + map_circ_other_notspecified) / map_hom_tot
  #DF_map = aggregate((map_circ_circumstance_undetermined + map_circ_other + map_circ_other_notspecified) / map_hom_tot ~ CountyCode, data = DF_map, FUN = mean)
  DF_map = aggregate(map_circ_circumstance_undetermined ~ CountyCode, data = DF_map, FUN = mean)
  # Rename the columns of DF_map
  colnames(DF_map) <- c("fips","map_circ_undetermined")
  
  
  DF_map = DF_map[(DF_map$map_circ_undetermined > 0),]
  
  
  n_bins <- 5
  
  # Create labels for each bin
  bin_labels <- c("2","3","4","5+")
  
  # Plot the map of misreported data
  plot_usmap(regions='counties', data=DF_map, values="map_circ_undetermined", color="gray25") +
    scale_fill_binned(low="lightsteelblue1", high="grey52", na.value="white",
                      guide = guide_coloursteps(even.steps = FALSE), name="", labels = bin_labels) +
    theme(legend.position="right", legend.text=element_text(size=20),
          legend.key.height=unit(1, 'cm'),
          legend.key.width=unit(1, 'cm'))
  
  
 
  
  # Save the plot as a PNG file
  ggsave("C:/Users/gr925268/Dropbox/Coroners/Data/Figures/map_circumstsance_undetermined.jpg", width=10, height=6, dpi=300)
  
  
###################################
####
# IPUMS
  
  
  ###########################################################
  ### IRREGULAR HISPANICS
  # name old file MAP1
    DF_map = DF[, c("CountyCode", "State", "ipums_irr_hisp")]
  
  # Remove rows with missing values in the "ipums_irr_hisp" column from DF_map
  DF_map = DF_map[!is.na(DF_map$ipums_irr_hisp), ]
  
  # Keep only the columns "CountyCode" and "ipums_irr_hisp" in DF_map
  DF_map = DF_map[, c("CountyCode", "ipums_irr_hisp")]
  
  # Aggregate the "ipums_irr_hisp" column by CountyCode, calculating the mean
  DF_map = aggregate(ipums_irr_hisp ~ CountyCode, data = DF_map, FUN = mean)
  
  # Rename the column names of DF_map to "fips" and "ipums_irr_hisp"
  colnames(DF_map) <- c("fips", "ipums_irr_hisp")
  
  # Filter out rows where the "ipums_irr_hisp" column is greater than 0
  DF_map = DF_map[(DF_map$ipums_irr_hisp > 0), ]
  
  # Plot the US map with county-level data using DF_map
  plot_usmap(regions = 'counties', data = DF_map, values = "ipums_irr_hisp", color = "gray25") +
    scale_fill_binned(low = "lightsteelblue1", high = "grey52", na.value = "white",
                      guide = guide_coloursteps(even.steps = FALSE), name = "") +
    theme(legend.position = "right", legend.text = element_text(size = 20),
          legend.key.height = unit(1, 'cm'),
          legend.key.width = unit(1, 'cm'))
  
  # Save the plot as a PNG file
  ggsave("ipums_irr.png", width = 10, height = 6, dpi = 300)
  
  
  
  ###########################################################
  ### IRREGULAR HISPANICS PERC ov hisp
  # name old file MAP1
  DF_map = DF[, c("CountyCode", "State", "ipums_p_irr_ovhisp_fips")]
  
  # Remove rows with missing values in the "ipums_p_irr_ovhisp_fips" column from DF_map
  DF_map = DF_map[!is.na(DF_map$ipums_p_irr_ovhisp_fips), ]
  
  # Keep only the columns "CountyCode" and "ipums_p_irr_ovhisp_fips" in DF_map
  DF_map = DF_map[, c("CountyCode", "ipums_p_irr_ovhisp_fips")]
  
  # Aggregate the "ipums_p_irr_ovhisp_fips" column by CountyCode, calculating the mean
  DF_map = aggregate(ipums_p_irr_ovhisp_fips ~ CountyCode, data = DF_map, FUN = mean)
  
  # Rename the column names of DF_map to "fips" and "ipums_p_irr_ovhisp_fips"
  colnames(DF_map) <- c("fips", "ipums_p_irr_ovhisp_fips")
  
  # Filter out rows where the "ipums_p_irr_ovhisp_fips" column is greater than 0
  DF_map = DF_map[(DF_map$ipums_p_irr_ovhisp_fips > 0), ]
  
  # Plot the US map with county-level data using DF_map
  plot_usmap(regions = 'counties', data = DF_map, values = "ipums_p_irr_ovhisp_fips", color = "gray25") +
    scale_fill_binned(low = "lightsteelblue1", high = "grey52", na.value = "white",
                      guide = guide_coloursteps(even.steps = FALSE), name = "") +
    theme(legend.position = "right", legend.text = element_text(size = 20),
          legend.key.height = unit(1, 'cm'),
          legend.key.width = unit(1, 'cm'))
  
  # Save the plot as a PNG file
  ggsave("ipums_irr_ovhisp.png", width = 10, height = 6, dpi = 300)
 
  ###########################################################
  ### IRREGULAR HISPANICS ov tot pop
  # name old file MAP1
  DF_map = DF[, c("CountyCode", "State", "ipums_p_irr_ovpop_fips")]
  
  # Remove rows with missing values in the "ipums_p_irr_ovpop_fips" column from DF_map
  DF_map = DF_map[!is.na(DF_map$ipums_p_irr_ovpop_fips), ]
  
  # Keep only the columns "CountyCode" and "ipums_p_irr_ovpop_fips" in DF_map
  DF_map = DF_map[, c("CountyCode", "ipums_p_irr_ovpop_fips")]
  
  # Aggregate the "ipums_p_irr_ovpop_fips" column by CountyCode, calculating the mean
  DF_map = aggregate(ipums_p_irr_ovpop_fips ~ CountyCode, data = DF_map, FUN = mean)
  
  # Rename the column names of DF_map to "fips" and "ipums_p_irr_ovpop_fips"
  colnames(DF_map) <- c("fips", "ipums_p_irr_ovpop_fips")
  
  # Filter out rows where the "ipums_p_irr_ovpop_fips" column is greater than 0
  DF_map = DF_map[(DF_map$ipums_p_irr_ovpop_fips > 0), ]
  
  # Plot the US map with county-level data using DF_map
  plot_usmap(regions = 'counties', data = DF_map, values = "ipums_p_irr_ovpop_fips", color = "gray25") +
    scale_fill_binned(low = "lightsteelblue1", high = "grey52", na.value = "white",
                      guide = guide_coloursteps(even.steps = FALSE), name = "") +
    theme(legend.position = "right", legend.text = element_text(size = 20),
          legend.key.height = unit(1, 'cm'),
          legend.key.width = unit(1, 'cm'))
  
  # Save the plot as a PNG file
  ggsave("C:/Users/gr925268/Dropbox/Coroners/Data/Figures/ipums_irr_ovpop.png", width = 10, height = 6, dpi = 300)
  


  
  # Prepare map data Mexico border
  DFt = DF[(DF$sample_Bord2 ==1),]
  DF_map = DFt[,c("CountyCode","State","Border")]
  DF_map = DF_map[,c("CountyCode","Border")]
  colnames(DF_map) <- c("fips", "Border")
  DF_map$Border <- as.factor(DF_map$Border)
  

  # Plot the US map with county-level data using DF_map
  plot_usmap(regions = 'counties', data = DF_map, values = "Border", color = "gray52") +
    scale_fill_manual(values = c("0" = "lightsteelblue1", "1" = "grey25"),
                      labels = c("Inland", "Border"),
                      na.value = "white", name = "") +
    # Customizing the theme and legend appearance
    theme(legend.position = "bottom", legend.text = element_text(size = 20),
          legend.key.height = unit(1, 'cm'),
          legend.key.width = unit(1, 'cm'))
  
  # Save the plot as a PNG file
  ggsave("C:/Users/gr925268/Dropbox/Coroners/Data/Figures/map_mexicoborder.png", width = 10, height = 6, dpi = 300) 
  
  
  
  
  
  
################################################
  #############################################
    ##########################################
    # modified on march 29th

  
  #####################1
# Law enforcement non-certifying vs. Sheriff-coroner or native
load("C:/Users/gr925268/Dropbox/Coroners/Police_code/DF_analysis.Rda")
  DF[21994,] <- DF[645,]
  DF[21994,1] <- "02066"
  DF[21995,] <- DF[645,]
  DF[21995,1] <- "02063"
  
  DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert_n + DF$ShCoroner >0)  # Define variable of interest as 1 if law enforcement can certify or sheriff coroner county !! This should be our favoured specification
  DF$sample = DF$sample_LE_SCn1
  DF_map = DF[,c("CountyCode","State","LawEnf_cert1","sample")]
  DF_map = DF_map[!is.na(DF_map$sample),]
  DF_map = DF_map[(DF_map$sample == 1),]
  DF_map$index_C = as.numeric(DF_map$sample) + as.numeric(DF_map$sample)*as.numeric(DF_map$LawEnf_cert1)
  DF_map = DF_map[,c("CountyCode","index_C")]
  colnames(DF_map) <- c("fips", "index_C")
  plot_usmap(regions='counties',data=DF_map,values="index_C")
  
  
  
  DF$LawEnf_cert1 =  as.numeric(DF$LawEnf_cert_n + DF$ShCoroner >0) 
  # Creating a new variable 'sample' in the dataframe DF
  # The value is taken from the 'sample_LE_SCn1' column
  DF$sample = DF$sample_LE_SCn1
  
  # Selecting specific columns from the dataframe DF and assigning it to DF_map
  DF_map <- DF[,c("CountyCode", "State", "LawEnf_cert1", "sample")]

  # Removing rows with missing values in the 'sample' column in DF_map
  DF_map = DF_map[!is.na(DF_map$sample),]
  
  # Selecting only rows where the 'sample' value is 1 in DF_map
  DF_map = DF_map[(DF_map$sample == 1),]
  
  # Creating a new variable 'index_C' in DF_map
  # The value is calculated based on the 'sample' and 'LawEnf_cert1' columns
  DF_map$index_C = as.numeric(DF_map$sample) + as.numeric(DF_map$sample) * as.numeric(DF_map$LawEnf_cert1)
  
  # Selecting specific columns from the dataframe DF_map
  DF_map = DF_map[,c("CountyCode","index_C")]
  
  # Converting the 'index_C' column to character type in DF_map
  DF_map$index_C <- as.character(DF_map$index_C)
  
  # Renaming the column names in DF_map
  colnames(DF_map) <- c("fips", "index_C")
  
  # Plotting a US map using the 'counties' regions and the data from DF_map
  plot_usmap(regions='counties',data=DF_map,values="index_C", color = "gray25") +
    
    # Binning the fill values into a color scale from "lightsteelblue1" to "grey25"
    # Assigning "white" for missing values
    scale_fill_binned(low="lightsteelblue1", high="grey52", na.value="white",
                      guide = guide_coloursteps(even.steps = FALSE)) +
    
    # Manually specifying the fill colors for the legend
    # Assigning "lightsteelblue1" to 1 and "grey25" to 2
    # Assigning "white" for missing values
    scale_fill_manual(values=c("1"="lightsteelblue1", "2"="grey55"),
                      labels=c(" Law Enforcement non-certifying", "Law Enforcement certifying"),
                      na.value="white", name="") +
    
    # Customizing the theme and legend appearance
    theme(legend.position = "bottom", legend.text = element_text(size=15),
          legend.key.height = unit(1, 'cm'),
          legend.key.width = unit(1, 'cm'))
  
  # Save the plot as a PNG file
  ggsave("C:/Users/gr925268/Dropbox/Coroners/Data/Figures/lawenf_nocer_she_cor_native.png", width = 10, height = 6, dpi = 300)

#################### 2
  # Law enforcement non-certifying vs. Sheriff-coroner subset
  # Creating a new variable 'LawEnf_cert1' in the dataframe DF
  # The value is 1 if law enforcement can certify or sheriff coroner county, and 0 otherwise
  DF$LawEnf_cert1 =  DF$ShCoroner 
  
  # Creating a new variable 'sample' in the dataframe DF
  # The value is taken from the 'DF$sample_SC_noLE1' column
  DF$sample = DF$sample_SC_noLE1
  
  # Selecting specific columns from the dataframe DF and assigning it to DF_map
  DF_map = DF[,c("CountyCode","State","LawEnf_cert1","sample")]
  
  # Removing rows with missing values in the 'sample' column in DF_map
  DF_map = DF_map[!is.na(DF_map$sample),]
  
  # Selecting only rows where the 'sample' value is 1 in DF_map
  DF_map = DF_map[(DF_map$sample == 1),]
  
  # Creating a new variable 'index_C' in DF_map
  # The value is calculated based on the 'sample' and 'LawEnf_cert1' columns
  DF_map$index_C = as.numeric(DF_map$sample) + as.numeric(DF_map$sample) * as.numeric(DF_map$LawEnf_cert1)
  
  # Selecting specific columns from the dataframe DF_map
  DF_map = DF_map[,c("CountyCode","index_C")]
  
  # Converting the 'index_C' column to character type in DF_map
  DF_map$index_C <- as.character(DF_map$index_C)
  
  # Renaming the column names in DF_map
  colnames(DF_map) <- c("fips", "index_C")
  
  # Plotting a US map using the 'counties' regions and the data from DF_map
  plot_usmap(regions='counties',data=DF_map,values="index_C", color = "gray25") +
    
    # Binning the fill values into a color scale from "lightsteelblue1" to "grey25"
    # Assigning "white" for missing values
    scale_fill_binned(low="lightsteelblue1", high="grey52", na.value="white",
                      guide = guide_coloursteps(even.steps = FALSE)) +
    
    # Manually specifying the fill colors for the legend
    # Assigning "lightsteelblue1" to 1 and "grey25" to 2
    # Assigning "white" for missing values
    scale_fill_manual(values=c("1"="lightsteelblue1", "2"="grey55"),
                      labels=c(" Law Enforcement non-certifying", "Law Enforcement certifying"),
                      na.value="white", name="") +
    
    # Customizing the theme and legend appearance
    theme(legend.position = "bottom", legend.text = element_text(size=15),
          legend.key.height = unit(1, 'cm'),
          legend.key.width = unit(1, 'cm'))
  
  # Save the plot as a PNG file
  ggsave("C:/Users/gr925268/Dropbox/Coroners/Data/Figures/lawenf_nocer_she_cor.png", width = 10, height = 6, dpi = 300)
  
  
  # Law enforcement non-certifying vs. Non-sheriff-coroner subset
  DF$LawEnf_cert1 =  DF$LawEnf_cert * (1-DF$ShCoroner)
  DF$sample = DF$sample_LE_noSC1
  DF_map = DF[,c("CountyCode","State","LawEnf_cert1","sample")]
  DF_map = DF_map[!is.na(DF_map$sample),]
  DF_map = DF_map[(DF_map$sample == 1),]
  DF_map$index_C = as.numeric(DF_map$sample) + as.numeric(DF_map$sample)*as.numeric(DF_map$LawEnf_cert1)
  DF_map = DF_map[,c("CountyCode","index_C")]
  colnames(DF_map) <- c("fips", "index_C")
 
  # Law enforcement non-certifying vs. Non-sheriff-coroner subset
  # Creating a new variable 'LawEnf_cert1' in the dataframe DF
  # The value is 1 if law enforcement can certify or sheriff coroner county, and 0 otherwise
  DF$LawEnf_cert1 =  DF$LawEnf_cert * (1-DF$ShCoroner)
  
  # Creating a new variable 'sample' in the dataframe DF
  # The value is taken from the 'DF$sample_SC_noLE1' column
  DF$sample = DF$sample_LE_noSC1
  
  # Selecting specific columns from the dataframe DF and assigning it to DF_map
  DF_map = DF[,c("CountyCode","State","LawEnf_cert1","sample")]
  
  # Removing rows with missing values in the 'sample' column in DF_map
  DF_map = DF_map[!is.na(DF_map$sample),]
  
  # Selecting only rows where the 'sample' value is 1 in DF_map
  DF_map = DF_map[(DF_map$sample == 1),]
  
  # Creating a new variable 'index_C' in DF_map
  # The value is calculated based on the 'sample' and 'LawEnf_cert1' columns
  DF_map$index_C = as.numeric(DF_map$sample) + as.numeric(DF_map$sample) * as.numeric(DF_map$LawEnf_cert1)
  
  # Selecting specific columns from the dataframe DF_map
  DF_map = DF_map[,c("CountyCode","index_C")]
  
  # Converting the 'index_C' column to character type in DF_map
  DF_map$index_C <- as.character(DF_map$index_C)
  
  # Renaming the column names in DF_map
  colnames(DF_map) <- c("fips", "index_C")
  
  # Plotting a US map using the 'counties' regions and the data from DF_map
  plot_usmap(regions='counties',data=DF_map,values="index_C", color = "gray25") +
    
    # Binning the fill values into a color scale from "lightsteelblue1" to "grey25"
    # Assigning "white" for missing values
    scale_fill_binned(low="lightsteelblue1", high="grey52", na.value="white",
                      guide = guide_coloursteps(even.steps = FALSE)) +
    
    # Manually specifying the fill colors for the legend
    # Assigning "lightsteelblue1" to 1 and "grey25" to 2
    # Assigning "white" for missing values
    scale_fill_manual(values=c("1"="lightsteelblue1", "2"="grey55"),
                      labels=c(" Law Enforcement non-certifying", "Law Enforcement certifying"),
                      na.value="white", name="") +
    
    # Customizing the theme and legend appearance
    theme(legend.position = "bottom", legend.text = element_text(size=15),
          legend.key.height = unit(1, 'cm'),
          legend.key.width = unit(1, 'cm'))
  
  # Save the plot as a PNG file
  ggsave("C:/Users/gr925268/Dropbox/Coroners/Data/Figures/lawenf_nocer_nonsher.png", width = 10, height = 6, dpi = 300)

  
  
  
  
  