
Project: Strategic Bureaucratic Opacity: Evidence from Death Investigation Laws and Police Killings                                                                    
Authors: Elda Celislami, Stephen Kastoryano, Giovanni Mastrobuoni                                     

Code Authors: Elda Celislami, Stephen Kastoryano
Date  : 20 May 2024 
                                       
Purpose: The encompassing .zip file contains only the necessary datasets to produce final 
	 table and figure outputs using steps 3 & 4 of the below. Additional datasets to build all data
	 from source are available on request. Dependencies listed in .R files.

	 The main dataset for use is DF_analysis.Rda
                                              

Run in following order:

1. dataset construction.R (E. Celislami):  
	inputs: " county_complete.rda"; "County_deathsystem.csv"
		"Underlying Cause of Death, 2013-2020.txt"
		"Underlying Cause of Death, autopsy 2013.txt"
		"Underlying Cause of Death, autopsy 2014.txt"
		"Underlying Cause of Death, autopsy 2015.txt"
		"Underlying Cause of Death, autopsy 2016.txt"
		"Underlying Cause of Death, autopsy 2017.txt"
		"Underlying Cause of Death, autopsy 2018.txt"
		"Underlying Cause of Death, autopsy 2019.txt"
		"Underlying Cause of Death, autopsy 2020.txt"
		"cc-est2019-alldata.csv"
		"MPV13_22.csv"
		"uszips.csv"
		"output.csv "
		"SHR76_20.sav"
		"MPV_october.RDA"
		"scorecard.csv"
		"37302-0001-Data.rda"
		"37323-0001-Data.rda"
		"da36164.0001.csv"
		"38251-0001-Data.rda"
		"CC_meco.csv"
		"38251-0001-Data.rda"
		"DataX and meco.csv"
		"UCR65_21.csv"
		"leoka_yearly_1960_2021.rds"
		"dataset_ready_all.csv"
		"ipums_usa_identified_counties.xlsx"
		"PUMA2000_PUMA2010_crosswalk.xls"
		"irregular hispanic/2010puma_fips.csv"
	output: DF.Rda for DataPrep.R

2. DataPrep.R (S. Kastoryano): change path setwd("...") to local folder
	inputs: DF.Rda; countypres_2000-2020.csv; GDPbycounty.csv;
                county_adjacency.txt; county_adjacency_2deg.csv;
                RighttoCarry_Giffords.csv; ucr13_19_final.csv 
        output: DF_analysis.Rda for Tables.R

3. figures_maps_commented.R (E. Celislami): 
	inputs: "Death Investigation Systems, By State (1).csv"
		"DF_analysis.Rda"
	output: Figures in paper

4. Tables.R (S. Kastoryano):
	inputs: DF_analysis.Rda from DataPrep.R; adj1.Rda; adj2.Rda
	output: Results and summary statistics tables 
   

