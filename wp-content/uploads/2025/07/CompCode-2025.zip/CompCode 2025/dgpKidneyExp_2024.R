########################################################################
##  Paper Title: Causally Evaluating Selection: Biological, 
##               Behavioral and Institutional Effects on
##               the Kidney Transplant Waitlist
#####
##
##  Purpose: Plot Kaplan-Meier curves and estimate dynamic treatment effects for figures and
##           tables in Appendix: Dynamic discrete choice model of candidate behavior
##
##  Reproducibility Information: see end of code for environment info
##                                                                    
##  Author: Stephen Kastoryano                                        
##  Date  : 30 June 2024                                         
##
##  input:  "DGPsampleER.m", "DGPsampleER_min.m" from DGPsim.ox is duration output from DGP dynamic
##                         discrete choice model
##          "simDGPval_3060.txt", simDGPval_3060_min.txt"  from DGPsimVal_2024.R are true DGP effect values
##
##  output: In relevant appendix (see above): Kaplan-Meier plots for simulated positive and negative treatment effect,
##          + DGP MSE statistics + dynamic evaluation of estimator figures
##     
##                                                                    
##  Instructions: 
##      - To obtain positive and negative effects Kaplan-Meier plots run twice setting nega=0 and nega=1 on line 45
##      - To obtain simulation results must vary code line 71 to obs = 5000, 3000, 1000, 500 for Table 3 frame 1,2,3
##      - To obtain dynamic performance plots must set nega=0 and obs = 5000 
##  
##  
########################################################################


library("survival") 
library("survminer") 
library(missForest)
library(dplyr)
library(Hmisc)
library(MASS)
library(ggplot2)

## Load Data ##
###############

setwd("C:/Users/skast/Dropbox/ContDurMA/CompCode 2023")

nega = 1  # positive treatment effect is =0, negative treatment effect =1

if (nega==0){
  mDatS <-read.table("DGPsampleER.m",skip = 1)     # duration output from DGP dynamic discrete choice model
} else {
  mDatS <-read.table("DGPsampleER_min.m",skip = 1)     # duration output from DGP dynamic discrete choice model
}
colnames(mDatS, do.NULL = FALSE)
colnames(mDatS) <- c("vA", "vE", "vZtilda", "vZ", "vPrS","vdurSstar", "vOututil","vdurE","vW")


NOcovariates = 1  #  Equal to 0 for analysis with covariates, 1 for analysis and calibration with no covariates


vCe <- as.numeric(mDatS["vdurE"] < max(mDatS["vdurE"]))  # Observed exit if =1, otherwise =0
vCs <- as.numeric(mDatS["vdurSstar"] < mDatS["vdurE"])  # Observed treatment if =1, otherwise =0 note this is correct because there are no observations with vdurSstar = vdurE <5001

mDat <- cbind(mDatS["vdurE"],vCe,mDatS["vdurSstar"],vCs,mDatS["vZ"],mDatS["vA"],mDatS["vOututil"],mDatS["vE"])
colnames(mDat, do.NULL = FALSE)
colnames(mDat) <- c("vdurE", "vCe", "vdurS", "vCs", "vZ", "vA","vOututil","vE")


set.seed(532783521)
obs <- dim(mDat)[1]

# Select fraction of observations for MSE stats calculations 
obs <- 5000   # Change this to 5000, 3000, 1000 or 500 for other entries of Table 5
mDataSsample <- mDat[sample(nrow(mDat), obs), ]
mDat <- mDataSsample



## Data Preparation #######################################
###########################################################

#
# Declaring the different durations and indicators:
#   vdurE= time until exit		          // the first possible day of exit is at t=2
#   vCe = exit indicator =1 if exit observed =0 if censored
#   vdurS = time until treatment,		 // the first possible day of treatment is at t=1
#   vCs = treatment indicator =1 if treatment observed =0 if censored
#   vZ  = 1 if subject to regime with anticipated treatment, = 0 with unanticipated treatment
#   vA  = observed variable 'ability' takes discrete integer values in [1,6]
#   vOututil = accepted utility at exit 
#   vE  = unobserved variable 'effort' takes discrete integer values in [1,3]
#   mX  = matrix of time 0 covariates
#
##  Warning!! first time period must be t=1 !!   ##



vdurE <- mDat$vdurE
vCe <- mDat$vCe
vdurS <- mDat$vdurS
vCs <- mDat$vCs
vCs <- as.numeric(vdurS <= vdurE )* vCs          # adjust treatment indicator if time to treatment censored before exit occurs
vdurS <- vdurS * as.numeric(vdurS <= vdurE ) + vdurE * as.numeric(vdurS > vdurE ) 


vZ <- 1-mDat$vZ                          # Regime  (switching just for graphs)


if (NOcovariates == 0) {
  
  mX <- cbind(mDat$vA)
  #mX <- cbind(mDat$vA, mDat$vE)
  #mX <- cbind(as.numeric(mDat$vA==2),as.numeric(mDat$vA==3),as.numeric(mDat$vA==4),as.numeric(mDat$vA==5),as.numeric(mDat$vA==6)) # Enter ability variable fully stratified (leave vE, effort variable as unobserved)
  #mX <- cbind(as.numeric(mDat$vA==2),as.numeric(mDat$vA==3),as.numeric(mDat$vA==4),as.numeric(mDat$vA==5),as.numeric(mDat$vA==6),
  #            as.numeric(mDat$vE==2),as.numeric(mDat$vE==3)) 
  #mX <- matrix(0,NROW(mDat),2)

}else{
  mX <- matrix(0,NROW(mDat),2) # no covariates for analysis, and for calibration of duration dependence terms
} 
mX1 = mX  # Line for efficient coding in ML estimation

##############################################################################################
## PLOT KALPLAN-MEIER SURVIVOR CURVES by Z TYPES

vdurEn = vdurE*as.numeric(vdurE <= vdurS ) + vdurS*as.numeric(vdurE > vdurS )
vCen =  as.numeric(vdurE == vdurEn)* vCe



df =as.data.frame(cbind(vdurE,vCe,vZ))
print(ggsurvplot(
  fit = survfit(Surv(df$vdurE,df$vCe) ~ vZ, data = df), 
  xlab = "Period", 
  ylab = "Survival probability",
  conf.int = TRUE,
  censor.size=0.1, 
  size = 0.2,
  xlim=c(0, 100),
  break.time.by = 10,
  ylim=c(0,1),
  font.legend = c(14, "plain", "black"),
  legend.title="Regime",
  legend.labs = c("Z0","Z1"),
  legend = c(0.85, 0.8),
  palette = c("gray10", "gray60")))
if (nega==0){
  ggsave("Figures\\Surv_sim.png", width = 6, height = 4)
} else {
  ggsave("Figures\\Surv_sim_min.png", width = 6, height = 4)
}

df =as.data.frame(cbind(vdurEn,vCen,vZ))
print(ggsurvplot(
  fit = survfit(Surv(df$vdurEn,df$vCen) ~ vZ, data = df), 
  xlab = "Period", 
  ylab = "Survival probability with censoring",
  conf.int = TRUE,
  censor.size=0.1, 
  size = 0.2,
  xlim=c(0, 100),
  break.time.by = 10,
  ylim=c(0,1),
  font.legend = c(14, "plain", "black"),
  legend.title="Regime",
  legend.labs = c("Z0","Z1"),
  legend = c(0.85, 0.8),
  palette = c("gray10", "gray60")))
if (nega==0){
  ggsave("Figures\\SurvC_sim.png", width = 6, height = 4)
} else {
  ggsave("Figures\\SurvC_sim_min.png", width = 6, height = 4)
}

df =as.data.frame(cbind(vdurS,vCs,vZ))
print(ggsurvplot(
  fit = survfit(Surv(df$vdurS,df$vCs) ~ vZ, data = df), 
  xlab = "Period", 
  ylab = "Treatment probability",
  conf.int = TRUE,
  censor.size=0.1, 
  size = 0.2,
  xlim=c(0, 100),
  break.time.by = 10,
  ylim=c(0,1),
  font.legend = c(14, "plain", "black"),
  legend.title="Regime",
  legend.labs = c("Z0","Z1"),
  legend = c(0.85, 0.2),
  palette = c("gray10", "gray60"),fun = "event"))
if (nega==0){
  ggsave("Figures\\SurvT_sim.png", width = 6, height = 4)
} else {
  ggsave("Figures\\SurvT_sim_min.png", width = 6, height = 4)
}


# Generate Hazard rates 
vHazTX_0 <- matrix(0,max(vdurE),1)
vHazTX_1 <- matrix(0,max(vdurE),1)
# Generate hazard rates
for (t in 1:(max(vdurE)-1)) {
  denomTX_0 = sum((as.numeric(vdurS == t)*as.numeric(vCs == 1)+as.numeric(vdurS > t))*as.numeric(vZ == 0))
  vHazTX_0[t] = sum(as.numeric(vdurS == t)*as.numeric(vCs == 1)*as.numeric(vZ == 0))/denomTX_0
  
  denomTX_1 = sum((as.numeric(vdurS == t)*as.numeric(vCs == 1)+as.numeric(vdurS > t))*as.numeric(vZ == 1))
  vHazTX_1[t] = sum(as.numeric(vdurS == t)*as.numeric(vCs == 1)*as.numeric(vZ == 1))/denomTX_1
}

## Plot hazard
x <- 1:100
y_0 <- vHazTX_0[1:100]
y_1 <- vHazTX_1[1:100]

haz_frame = data.frame(cbind("Period"=x,Z1=y_1,Z0=y_0))
#Reshape data from wide to long
df2 <- gather(haz_frame,Regime,val,c(Z1,Z0))

print(ggplot(df2,aes(x = Period, y = val)) +
        geom_smooth(aes(colour = Regime),se = F) +
        ylab("Treatment hazard") +
        theme_bw() +
        theme_classic() +
        scale_color_grey(start = 0.4, end = 0.75) +
        theme(legend.position = c(0.85, 0.50)) + 
        theme(legend.text = element_text(size=15)) +
        theme(legend.title = element_text(size=15)) +
        theme(legend.key.height= unit(0.8, 'cm'),legend.key.width= unit(1.5, 'cm')) +
        scale_x_continuous(breaks = seq(0, 100, by = 12)) +
        theme(axis.title.x = element_text(size=14,  family="sans",colour="black")) +
        theme(axis.title.y = element_text(size=14,  family="sans",colour="black")) +
        theme(axis.text = element_text(face="bold")))
if (nega==0){
  ggsave("Figures\\Thaz_sim.png", width = 6, height = 4)
} else {
  ggsave("Figures\\Thaz_sim_min.png", width = 6, height = 4)
}


##############################################################################################

 
vZ <- 1-vZ    # Switching back to original

### Generate right censoring and random censoring in sample ###
Rcens <- 60   # Right Censoring: Cuttoff to avoid estimation fit to be leveraged by observations beyond outcome evaluation point

vCe <- vCe * as.numeric(vdurE <= Rcens  ) 
vdurE <- vdurE * as.numeric(vdurE <= Rcens  ) + Rcens * as.numeric(vdurE > Rcens  )
vCs <- vCs * as.numeric(vdurS <= Rcens  ) 
vdurS <- vdurS * as.numeric(vdurS <= Rcens  ) + Rcens * as.numeric(vdurS > Rcens  )
#vCe <- vCe * (1- vCe * as.numeric(vdurS < vdurE ) * as.numeric(vCs == 0 ))
#vdurE <- vdurE - (vdurE - vdurS) * as.numeric(vdurS < vdurE ) * as.numeric(vCs == 0 ) 



print(" Fraction of right censored observations:")
print(sum(1-vCe)/obs)


Randcens <- 0.5519-(sum(1-vCe)/obs)  # Have that ~50% of the sample is censored
rbinomCens <- 1-as.numeric(sample(1:obs, obs, replace=F) <= Randcens*obs)   # 1 is not censored
rdurCens <- round(runif(obs)*vdurE)
vCe <- vCe * rbinomCens
vdurE <- vdurE * rbinomCens + rdurCens * (1-rbinomCens)
vCs <- vCs * as.numeric(vdurS <= vdurE  )
vdurS <- vdurS * as.numeric(vdurS <= vdurE ) + vdurE * as.numeric(vdurS > vdurE )

print(" Fraction of censored observations:")
print(sum(1-vCe)/obs)

vTime <- seq(max(vdurE))


# Check values
sum(as.numeric(vdurS > vdurE))   ## NEEDS TO BE 0 !
sum(as.numeric(vdurS < vdurE)*as.numeric(vCs == 0))   ## NEEDS TO BE 0 !


## Check exit and treatment densities 
summary(vdurS)
plot(density(vdurS), main="Treatment Density",
     xlab="Time")
quantile(vdurS, probs=c(0,0.05,0.10,0.15,0.20,0.25,0.30,0.35,0.40,0.45,0.50,0.55,0.60,0.65,0.70,0.75,0.80,0.85,0.90, 0.95, 1))
summary(vdurE)
plot(density(vdurE), main="Exit Density",
     xlab="Time")
quantile(vdurE, probs=c(0,0.05,0.10,0.15,0.20,0.25,0.30,0.35,0.40,0.45,0.50,0.55,0.60,0.65,0.70,0.75,0.80,0.85,0.90, 0.95, 1))


## Define cuttoffs of piecewise duration dependence terms 
dmax <- max(vdurE) 
d <- c(10,10,10,10,10,dmax-50)   
d <- c(30,dmax-30)

## Summary Statistics #############################################



## Table summary statistics covariates ##

cat("Total observations =" , length(vdurE))
cat("Z=1 treated observations =" , sum(vZ*vCs))
cat("Z=1 non-treated observations =" , sum(vZ*(1-vCs)))
cat("Z=0 treated observations =" , sum((1-vZ)*vCs))
cat("Z=0 non-treated observations =" , sum((1-vZ)*(1-vCs)))

## Functions ##############################################

PHlikbuildFn <- function(par,dE,dS,Cs,Z,Durdep) {    # Function: generate time varying part of exit and treatment densities
  # Initialisation of Exit and Treatment hazards
  denshE <- matrix(0,NROW(dE),2)  # col 1 for prob survival, col 2 for hazard
  denshS <- matrix(0,NROW(dE),2)  # col 1 for prob survival, col 2 for hazard
  
  if (Durdep == 0) {
    for (i in 1:NROW(d)) # For every duration dependence of dependent variable fill
    {  
      denshS[,1] <- denshS[,1] + d[i] * exp(par[i] + Z*par[NROW(d)+i]) * as.numeric(dS > d[i]) +
        exp(par[i] + Z*par[NROW(d)+i]) * dS * as.numeric(dS > 0) * as.numeric(dS <= d[i])
      
      denshS[,2] <- denshS[,2] + exp(par[i] + Z*par[NROW(d)+i]) * as.numeric(dS > 0) * as.numeric(dS <= d[i])
      
      denshE[,1] <- denshE[,1] +
        as.numeric(dE > d[i]) *
        (d[i] * exp(par[2*NROW(d)+i] + Z*par[3*NROW(d)+i]) * as.numeric(dS > d[i]) +
           d[i] * exp(par[2*NROW(d)+i] + Z*par[3*NROW(d)+i]) * exp(par[4*NROW(d)+i] + Z*par[5*NROW(d)+i]) * as.numeric(dS <= 0) +
           exp(par[2*NROW(d)+i] + Z*par[3*NROW(d)+i]) * (dS-1  + exp(par[4*NROW(d)+i] + Z*par[5*NROW(d)+i]) * (d[i]-(dS-1))) * 
           as.numeric(dS > 0) * as.numeric(dS <= d[i])) +
        as.numeric(dE > 0) * as.numeric(dE <= d[i]) * 
        (exp(par[2*NROW(d)+i] + Z*par[3*NROW(d)+i]) * 
           (dS-1 +(1-Cs)*as.numeric(dE == dS) + exp(par[4*NROW(d)+i] + Z*par[5*NROW(d)+i]) * (dE - (dS-1 +(1-Cs)*as.numeric(dE == dS)))) * as.numeric(dS > 0) +
           exp(par[2*NROW(d)+i] + Z*par[3*NROW(d)+i]) * exp(par[4*NROW(d)+i] + Z*par[5*NROW(d)+i]) * dE * as.numeric(dS <= 0))  
      
      denshE[,2] <- denshE[,2] + exp(par[2*NROW(d)+i] + Z*par[3*NROW(d)+i]) * as.numeric(dE > 0) * as.numeric(dE <= d[i]) * as.numeric(dS == dE)*(1-Cs) + 
        exp(par[2*NROW(d)+i ]+ Z*par[3*NROW(d)+i]) * exp(par[4*NROW(d)+i] + Z*par[5*NROW(d)+i]) *
        as.numeric(dE > 0) * as.numeric(dE <= d[i]) * (as.numeric(dS < dE) + as.numeric(dS == dE)*Cs)
      
      dE <- dE - d[i]
      dS <- dS - d[i]
    }
  }
  else {
    parZ1s  <- par[(NROW(d)+1)]
    parZ10e <- par[(2*NROW(d)+2)]
    parZ01e <- par[(2*NROW(d)+3)]
    parZ11e <- par[(2*NROW(d)+4)]
    
    # For every duration dependence of dependent variable fill
    for (i in 1:NROW(d)) 
    {  
      denshS[,1] <- denshS[,1] + d[i] * exp(par[i] + Z*parZ1s) * as.numeric(dS > d[i]) +       
        exp(par[i] + Z*parZ1s) * dS * as.numeric(dS > 0) * as.numeric(dS <= d[i])
      
      denshS[,2] <- denshS[,2] + exp(par[i] + Z*parZ1s) * as.numeric(dS > 0) * as.numeric(dS <= d[i])  
      
      denshE[,1] <- denshE[,1] +
        as.numeric(dE > d[i]) *
        (d[i] * exp(par[NROW(d)+1+i] + Z*parZ10e) * as.numeric(dS > d[i]) +
           d[i] * exp(par[NROW(d)+1+i] + Z*parZ10e) * exp(parZ01e + Z*parZ11e) * as.numeric(dS <= 0) +
           exp(par[NROW(d)+1+i] + Z*parZ10e) * (dS-1  + exp(parZ01e + Z*parZ11e) * (d[i]-(dS-1))) * 
           as.numeric(dS > 0) * as.numeric(dS <= d[i])) +
        as.numeric(dE > 0) * as.numeric(dE <= d[i]) * 
        (exp(par[NROW(d)+1+i] + Z*parZ10e) * 
           (dS-1 +(1-Cs)*as.numeric(dE == dS) + exp(parZ01e + Z*parZ11e) * (dE - (dS-1 +(1-Cs)*as.numeric(dE == dS)))) * as.numeric(dS > 0) +
           exp(par[2*NROW(d)+i] + Z*parZ10e) * exp(parZ01e + Z*parZ11e) * dE * as.numeric(dS <= 0))  
      
      denshE[,2] <- denshE[,2] + exp(par[NROW(d)+1+i] + Z*parZ10e) * as.numeric(dE > 0) * as.numeric(dE <= d[i]) * as.numeric(dS == dE)*(1-Cs) + 
        exp(par[NROW(d)+1+i]+ Z*parZ10e) * exp(parZ01e + Z*parZ11e) *
        as.numeric(dE > 0) * as.numeric(dE <= d[i]) * (as.numeric(dS < dE) + as.numeric(dS == dE)*Cs)
      
      dE <- dE - d[i]
      dS <- dS - d[i]
    }
  }
  
  return( cbind(denshE,denshS) )
}  # Function: generate time varying part of exit and treatment densities

CovarEffFn <- function(par,Durdep) {  # Function: Construct covariate effects on hazard
  
  if (sum(mX)==0) {
    mxb <- matrix(0,NROW(mDat),2)
  } else if (ncol(mX1)==1)  {
    if (Durdep == 0) { 
      mxb <- cbind(mX%*%par[(6*NROW(d)+1)],mX%*%par[(6*NROW(d)+2)])
    }
    else {
      mxb <- cbind(mX%*%par[(2*NROW(d)+5)], mX%*%par[(2*NROW(d)+6)])
    }
  } else  {
    if (Durdep == 0) { 
      mxb <- cbind(mX%*%par[(6*NROW(d)+1):(6*NROW(d)+NCOL(mX))],mX%*%par[(6*NROW(d)+NCOL(mX)+1):(6*NROW(d)+2*NCOL(mX))])
    }
    else {
      mxb <- cbind(mX%*%par[(2*NROW(d)+5):(2*NROW(d)+4+NCOL(mX))], mX%*%par[(2*NROW(d)+4+NCOL(mX)+1):(2*NROW(d)+4+2*NCOL(mX))])
    }
  }
  
  
  return ( mxb) 
}  # Function: Construct covariate effects on hazard

PHloglikFn <- function(par) {            # Function: generate loglikelihood function
  
  # Duration until exit, duration until training
  xb <-  CovarEffFn(par,Durdep)
  xbS <- exp(xb[,1])              # Matrix of Explanatory variables affecting treatment
  xbE <- exp(xb[,2])	  # Matrix of Explanatory variables affecting exit  
  
  densh <- PHlikbuildFn(par,vdurE,vdurS,vCs,vZ,Durdep)
  denshE <- densh[,1:2]
  denshS <- densh[,3:4]
  
  
  ## Generating likelihood fnuction to be minimized ##
  lik = (xbE * denshE[,2])^vCe * exp(- xbE * denshE[,1]) * (xbS * denshS[,2])^vCs * exp(- xbS * denshS[,1])
  logl <- log(lik)
  
  return(logl)
}  # Function: generate loglikelihood function

PHlikFn <- function(par) {            # Function: loglikelihood function to be minimized
  logl <- PHloglikFn(par)
  #print("PARAMETER");print(par)
  
  loglik <- -mean(logl)
}  # Function: loglikelihood function to be minimized

derivPHlikFn	<- function(par) {  	 # Function: estimate score matrix for Delta method
  
  scorePH <- matrix(0,obs,NROW(par))
  for (j in 1:NROW(par)) 
  { 
    d0 <- max(c(abs(0.0005*par[j]),0.0005))		# increment in dx of dloglik(x)/dx
    p <- par
    p[j] <- p[j] + d0
    z1 <- PHloglikFn(p)
    p <- par
    p[j] <- p[j] - d0
    z2 <- PHloglikFn(p)
    scorePH[,j] <- ((z1-z2)/(2*d0))
  }
  
  return(scorePH)  # returns obs. x nbr. parameters score matrix
}  # Function: estimate score matrix for Delta method

LikparamFn <- function(CovLik,Durdep) {   # Function: Estimate parameters of hazard model
  
  if (Durdep == 0) { 
    print("## Hazard model parameter estimation with piecewise constant duration dependence ################################")
    print("# par[1:NROW(d)] duration dependence for treatment hazard under Z=0")
    print("# par[(NROW(d)+1):(2*NROW(d))] duration dependence for treatment hazard under Z=1")
    print("# par[(2*NROW(d)+1):(3*NROW(d))] duration dependence for exit hazard under Z=0 and vdurS>vdurE (no treatment)")
    print("# par[(3*NROW(d)+1):(4*NROW(d))] duration dependence for exit hazard under Z=1 and vdurS>vdurE (no treatment)")
    print("# par[(4*NROW(d)+1):(5*NROW(d))] duration dependence for exit hazard under Z=0 and vdurS<=vdurE (treatment)")
    print("# par[(5*NROW(d)+1):(6*NROW(d))] duration dependence for exit hazard under Z=1 and vdurS<=vdurE (treatment)")
    print("# par[(6*NROW(d)+1):(6*NROW(d)+NCOL(mX))] covariate effects on treatment hazard")
    print("# par[(6*NROW(d)+NCOL(mX)+1):(6*NROW(d)+2*NCOL(mX))] covariate effects on exit hazard")
    print("#################################################################################################################")
    
    
    if (sum(mX)==0) {
      par <- matrix(0,6*NROW(d),1)
    } else if (ncol(mX1)==1)  {
      par <- matrix(0,6*NROW(d)+2,1)
    } else  {
      par <- matrix(0,6*NROW(d)+2*NCOL(mX),1)
    }
  }
  else {
    print("## Proportional Hazard model parameter estimation with proportional effect of each randomization on duration dependence ########")
    print("# par[1:NROW(d)] duration dependence for treatment hazard under Z=0")
    print("# par[(NROW(d)+1)] proportional effect of Z=1 on treatment duration dependence relative to Z=0")
    print("# par[(NROW(d)+2):(2*NROW(d)+1)] duration dependence for exit hazard under Z=0 and vdurS>vdurE (no treatment)")
    print("# par[(2*NROW(d)+2)] proportional effect of Z=1 and vdurS>vdurE on exit duration dependence (no treatment)")
    print("# par[(2*NROW(d)+3)] proportional effect of Z=0 and vdurS<=vdurE on exit duration dependence (treatment)")
    print("# par[(2*NROW(d)+4)] proportional effect of Z=1 and vdurS<=vdurE on exit duration dependence (treatment)")
    print("# par[(2*NROW(d)+5):(2*NROW(d)+4+NCOL(mX))] covariate effects on treatment hazard")
    print("# par[(2*NROW(d)+4+NCOL(mX)+1):(2*NROW(d)+4+2*NCOL(mX))] covariate effects on exit hazard")
    print("################################################################################################################################")
    
    
    if (sum(mX)==0) {
      par <- matrix(0,(2*NROW(d)+4),1)
    } else if (ncol(mX1)==1)  {
      par <- matrix(0,(2*NROW(d)+4+2),1)
    } else  {
      par <- matrix(0,(2*NROW(d)+4+2*NCOL(mX)),1)
    }
  }
  
  PHestim <- optim(par,PHlikFn,method = "BFGS", hessian = TRUE)
  par <- PHestim$par
  
  if (CovLik == 0) {        # Variance- Covariance Matrix
    scorePH <- derivPHlikFn(par)
    covPH <- solve(t(scorePH)%*%scorePH) }       # This version may not be possible if matrix to be inverted is singular
  else { 
    Hess <- PHestim$hessian
    covPH <- Hess  }
  sdev <- sqrt(diag(covPH))    # Standard Errors of parameters
  
  # Calculate p-values
  iNull <- 0   # H_0=0 is null hypothesis
  tTest <- (abs(par-iNull))/sdev   # t-test	conditional probability	 	 
  PvalT <- 2*(1-pt(tTest,obs-NROW(par)))
  
  
  print("Output of Log-likelihood Estimation")
  print(c("parameter","stand. dev.", "p-values"))
  print(cbind(par,sdev,PvalT))
  
  return( cbind(par,sdev,covPH) )  # Output is nbr. parameters x 3 matrix of parameter, standard deviation and P-values
}  # Function: Estimate parameters of hazard model

EffectprepFn <- function(par, Durdep, s, tau, mSurEz1, indSurZ) { # Function: Generates counterfactual treatment times and unweighted estimates
  
  
  # Duration until exit, duration until training 
  xb <-  CovarEffFn(par,Durdep)
  xbS <- exp(xb[,1])              # Matrix of Explanatory variables affecting treatment
  xbE <- exp(xb[,2])	  # Matrix of Explanatory variables affecting exit 
  
  t <- matrix(tau,obs,1)      # exit time 
  s0 <- matrix(s,obs,1)       # treatment time 
    
  # B0 effects
  Z <- matrix(0,obs,1)  ## Obtain survivors at all t when Z=0
  SurEz0t <- exp(- xbE * PHlikbuildFn(par,t,t,matrix(0,obs,1),Z,Durdep)[,1])      # Z=0 non-treat counterfactual survivor function
  vB0 <- SurEz0t
  
  # BZ effects
  Z <- matrix(1,obs,1)  ## Obtain survivors at all t when Z=1
  SurEz1t <- exp(- xbE * PHlikbuildFn(par,t,t,matrix(0,obs,1),Z,Durdep)[,1]) 
  vBZ <- SurEz1t-SurEz0t
  
  
  # BS effects
  Z <- matrix(0,obs,1)  ## Obtain survivors at all t when Z=0
  SurEz0ts <- exp(- xbE * PHlikbuildFn(par,t,s0,matrix(1,obs,1),Z,Durdep)[,1]) 
  vBS <- SurEz0ts-SurEz0t
  
  
  # BZS effects
  Z <- matrix(1,obs,1)  ## Obtain survivors at all t when Z=0
  SurEz1ts <- exp(- xbE * PHlikbuildFn(par,t,s0,matrix(1,obs,1),Z,Durdep)[,1]) 
  vBZS <- SurEz1ts-SurEz1t - vBS
  
  
  return( cbind(vB0, vBZ, vBS, vBZS))  # Output is obs x 4 matrix of unweighted causal effects
} # Function: Generates counterfactual treatment times and unweighted estimates

MeaneffectFn <- function(par, Durdep, mins, dS, dT, dTmov) {  # Function: Estimate time varying and average effects over treatment time interval [mins:mins+dS]
  
  # Duration until exit, duration until training 
  xb <-  CovarEffFn(par,Durdep)
  xbS <- exp(xb[,1])              # Matrix of Explanatory variables affecting treatment
  xbE <- exp(xb[,2])	  # Matrix of Explanatory variables affecting exit 
  
  Wden <- matrix(0,obs,max(vdurE))
  WdenST <- matrix(0,obs,max(vdurE))
  mDensSh <- matrix(0,obs,2)
  mDensS <- matrix(0,obs,max(vdurE))
  
  for (tt in 1:(mins+dS)) 
  {
    ddS <- matrix(tt,obs,1)
    #mSurEz0[,tt] <- exp(- xbE * PHlikbuildFn(par,ddS,ddS,matrix(0,obs,1),matrix(0,obs,1),Durdep)[,1]) # survival probability for Z=0 under no treatment  
    mDensSh <- PHlikbuildFn(par,ddS,ddS,matrix(1,obs,1),matrix(1,obs,1),Durdep)[,3:4]       # probability (density) of treatment at S=s under Z=1
    mDensS[,tt] <- (xbS * mDensSh[,2]) * exp(- xbS * mDensSh[,1])    # generate probability of treatment at S=s under Z=1 (numerator of weight function)
    Wden[,tt] <- sum(mDensS[,tt])*matrix(1,obs,1)                    # generate denominator of wATThat
  }
  
  wEff <- mDensS/Wden        # weights for effects on potentially treated wATThat
  
  
  mDelta <- matrix(0,4,(dS+1))    # matrix of causal effects for each s for potential treated at S=s
  colnames(mDelta) <- paste('PotTreat at s=',mins:(mins+dS))
  
  
  DeltaAvg <- matrix(0,4,1)
  for (s in mins:(mins+dS)) 
  {
    if (dTmov==0)
    { tau <- dT }
    else
    { tau <- s+dT }
    
    SurEz0 <- exp(- xbE * PHlikbuildFn(par,matrix(s,obs,1),matrix(s,obs,1),matrix(0,obs,1),matrix(0,obs,1),Durdep)[,1])
    
    unweightEst <- EffectprepFn(par, Durdep, s, tau)   # Output is obs x 4 matrix of unweighted causal effects
    mDelta[,(s-mins+1)] <- t(colSums(wEff[,s] * unweightEst)) 
    
    DeltaAvg <- DeltaAvg + colSums(mDensS[,s]/sum(Wden[1,mins:(mins+dS)]) * unweightEst)
    
  }
  colnames(DeltaAvg) <- c("avg. PotTreat")
  
  
  # Generate Intention to Treat: note: this is note a very robust estimation strategy for the ITT effects.
  DeltaITT <- matrix(0,4,1)
  colnames(DeltaITT) <- c("ITT")
  if (mins == 1 )                  # Generate Intention to treat of Z when mins=1
  { 
    mtempZ <- cbind(vdurE,vCe,vdurS,vCs,vZ,xbE)
    mtempZ1 = mtempZ[(mtempZ[,5]==1),]
    mtempZ0 = mtempZ[(mtempZ[,5]==0),]
    
    mtempZ1 = mtempZ1[!(as.numeric(mtempZ1[,1]<dT)*(1-mtempZ1[,1])),]  # remove death censored observations for ITT calculation (bias effects since they censor treatment)
    mtempZ0 = mtempZ0[!(as.numeric(mtempZ0[,1]<dT)*(1-mtempZ0[,1])),]  # remove death censored observations for ITT calculation
    
    
    ddtt1 <- matrix(dT,length(mtempZ1),1)
    ddtt0 <- matrix(dT,length(mtempZ0),1)
    SurEz1 <- exp(- mtempZ1[,6:ncol(mtempZ1)] * PHlikbuildFn(par,ddtt1,mtempZ1[,3],mtempZ1[,4],mtempZ1[,5],Durdep)[,1])
    SurEz0 <- exp(- mtempZ0[,6:ncol(mtempZ0)] * PHlikbuildFn(par,ddtt0,mtempZ0[,3],mtempZ0[,4],mtempZ0[,5],Durdep)[,1])
    DeltaITT[1] <- (sum(SurEz1)/length(SurEz1)-sum(SurEz0)/length(SurEz0))
    
    #DeltaITT[1] <- (sum((vdurE <= dT)*vCe*vZ )/sum(vZ)-sum((vdurE <= dT)*vCe*(1-vZ) )/sum(1-vZ))
  } 
  
  DiffPrTreat <- matrix(0,4,1) 
  DiffPrTreatsum <- 0
  
  # Effect of regime on probability of treatment
  ddtt <- matrix((mins+dS),obs,1)
  ProbTreatz1 <- PHlikbuildFn(par,ddtt,ddtt,matrix(1,obs,1),matrix(1,obs,1),Durdep)[,3]  # generate treatment survival at S=s under Z=1
  ProbTreatz0 <- PHlikbuildFn(par,ddtt,ddtt,matrix(1,obs,1),matrix(0,obs,1),Durdep)[,3]  # generate treatment survival at S=s under Z=0
  DiffPrTreat <-sum(exp(- xbS * ProbTreatz1) - exp(- xbS * ProbTreatz0))/obs
  #print(DiffPrTreat)
  
  
  Effectout <- cbind(DiffPrTreat,DeltaITT,DeltaAvg,mDelta)
  
  return( Effectout )  # return 4 x ((dS+1)+3) matrix of: Regime effect on Treatment + ITT effects + average effects over  [mins:mins+dS] +time varyin effects over  [mins:mins+dS] 
}

EffectFn <- function(par, Durdep, mins, dS, dT, dTmov, varP, plGr)	{ # Function: Estimate standard errors and print results
  
  mEffects <- MeaneffectFn(par, Durdep, mins, dS, dT, dTmov) # return 20 x ((dS+1)+3): Regime effect on Treatment + matrix of ITT effects + average effects over  [mins:mins+dS] +time varyin effects over  [mins:mins+dS] 
  rownames(mEffects) <- c("vB0 (par)", "vB0ns (par)", "vB0cs (par)", "vB0as (par)", "vBZ (par)", "vBZcs (par)", "vBZas (par)", "vBS (par)", "vBScs (par)", "vBSas (par)", "vBZS (par)", "vPns (par)", "vPcs (par)", "vPas (par)", "vB0as_lrt (par)", "vBZcs_lrt (par)", "vBZas_lrt (par)", "vBScs_lrt (par)", "vBSas_lrt (par)","vBZScs_lrt (par)")
  print(mEffects) 
  
  #print("Computing Standard Errors: ")
  scoreEff <- array(0,dim=c(NROW(mEffects),NCOL(mEffects),NROW(par)))
  
  save(varP,file="varP.Rda")
  #print(varP)
  
  time1 <- 0
  time2 <- 0
  ptm <- proc.time()  # Start the clock!
  for (j in 1:NROW(par)) 
  { 
    d0 <- max(c(abs(0.0005*par[j]),0.0005))		# increment in dx of dloglik(x)/dx
    p <- par
    p[j] <- p[j] + d0
    z1 <- MeaneffectFn(p, Durdep, mins, dS, dT, dTmov)
    p <- par
    p[j] <- p[j] - d0
    z2 <- MeaneffectFn(p, Durdep, mins, dS, dT, dTmov)
    scoreEff[,,j] <- (z1-z2)/(2*d0)
    
    # print(j)
    # print(scoreEff[,,j])
    
    time1 <- time1+1 ; timeN <-  (proc.time() - ptm);time2 <- (time2*(time1-1) + timeN[3])/time1    # Stop the clock
    ptm <- proc.time()  # Start the clock
    print("Approximate minutes remaining =");print((NROW(par)-j)*(time2/60))
  }
  
  
  
  mEffse <- matrix(0,NROW(mEffects),NCOL(mEffects))
  mEffpval <- matrix(0,NROW(mEffects),NCOL(mEffects))
  for (k in 1:NCOL(mEffects)) 
  {
    
    
    scoreEff[,k,]%*%varP%*%t(scoreEff[,k,])
    
    varE <- scoreEff[,k,]%*%varP%*%t(scoreEff[,k,])
    mEffse[,k] <- sqrt(diag(varE))
    mEffpval[,k] <- 2*(1-pt(abs(mEffects[,k])/mEffse[,k],obs-NROW(par)))  # Calculate p-values with null hypothesis =0
    
  }
  
  rownames(mEffse) <- c("vB0 (se)", "vBZ (se)",  "vBS (se)", "vBZS (se)")
  
  colnames(mEffse) <- colnames(mEffects)
  rownames(mEffpval) <- c("vB0 (Pv)",  "vBZ (Pv)", "vBS (Pv)", "vBZS (Pv)")
  
  colnames(mEffpval) <- colnames(mEffects)
  
  # if (plGr==1 & dS > 0)
  # {
  #   graphEffectsFn(mins,dS, dT,mEffects,mEffse) 
  # }
  #print(mEffects)
  #print(mEffse)
  #print(mEffpval)
  
  mEffprint <- rbind(mEffects[1,],mEffse[1,],mEffpval[1,],mEffects[2,],mEffse[2,],mEffpval[2,],
                     mEffects[3,],mEffse[3,],mEffpval[3,],mEffects[4,],mEffse[4,],mEffpval[4,])
  rownames(mEffprint) <- c("vB0", "    (se)","  [P-val]",
                           "vBZ", "    (se)","  [P-val]", 
                           "vBS", "    (se)","  [P-val]",
                           "vBZS", "    (se)","  [P-val]")
  
  
  
  print("---------------------------------------------------------------------------------------------------------------------")
  print(c("mins=",mins, "mins+dS=", (mins+dS),"dT=",dT, "dTmov=",dTmov))
  print("Effects at each s = "); print( format(round(mEffprint[,4:(dS+4)], 3), nsmall = 3))
  print("Average Regime effect on Treatment Survival at mins+dS = ");print(format(round(cbind(mEffprint[1:3,1]), 3), nsmall = 3))
  print("ITT effect of policy regime Z (this is not rigorously estimated) = ");print(format(round(cbind(mEffprint[1:3,2]), 3), nsmall = 3))
  print("Avg. Effect over support of s = ");print(format(round(cbind(mEffprint[,3]), 3), nsmall = 3))
  
  
  
  
  print("---------------------------------------------------------------------------------------------------------------------")
  
  
  return( rbind(mEffects,mEffse,mEffpval) )
}  

graphEffectsFn <- function(mins,dS, dT,mEffects,mEffse) 	{
  
  #cbind(DeltaITT,DeltaAvg,DeltaAvgST,mDelta,mDeltaST)
  save(mEffects,file="mEffects.Rda")
  save(mEffse,file="mEffse.Rda")
  
  load("mEffects.Rda") 
  load("mEffse.Rda") 
  
  
  if (nega==0){
    simDGPval <- t(read.table("simDGPval_3060.txt") )
  } else {
    simDGPval <- t(read.table("simDGPval_3060_min.txt") )
  }
  
  # generate 95% conf. bands and plot effects
  mEf <- mEffects[c(1,5,8,11:14),(NCOL(mEffects)-(dS)):NCOL(mEffects)]
  mEfse <- mEffse[c(1,5,8,11:14),(NCOL(mEffects)-(dS)):NCOL(mEffects)]
  m95up <- mEf+ 1.96*mEfse
  m95lo <- mEf- 1.96*mEfse
  simDGP <- simDGPval[1:7,]  # When generating DGP values, I calculated effects in probability of death, so I convert in the graphs into probability of survival
  
  
  
  
  # get the range for the x and y axis 
  
  vT <- seq(dS+1)+(mins-1)
  plotData0a <- as.data.frame(cbind(vT, mEf[1,1:(1+dS)],m95lo[1,1:(1+dS)],m95up[1,1:(1+dS)]))
  plotData0b <- as.data.frame(cbind(vT,(1-simDGP[1,])))
  print(ggplot(data=plotData0a, aes(x=vT, y=plotData0a[,2], ymin=plotData0a[,3], ymax=plotData0a[,4])) + 
          geom_line() + 
          ylim(0, 0.8) +
          geom_ribbon(alpha=0.2) + 
          geom_hline(yintercept=0, linetype="dashed", color = "red", size=1) +
          geom_line(data = plotData0b, aes(x = vT, y = plotData0b[,2]),  color = "blue", size=1) +
          theme_bw() +
          xlab("Time at treatment") + 
          ylab("B0 Effect"))
  if (nega==0){
    ggsave("Figures\\B0_sim.png", width = 6, height = 2)
  } else {
    ggsave("Figures\\B0_sim_min.png", width = 6, height = 2)
  }
  
  
  vT <- seq(dS+1)+(mins-1)
  plotData1a <- as.data.frame(cbind(vT, mEf[2,1:(1+dS)],m95lo[2,1:(1+dS)],m95up[2,1:(1+dS)]))
  plotData1b <- as.data.frame(cbind(vT,-simDGP[2,]))
  print(ggplot(data=plotData1a, aes(x=vT, y=plotData1a[,2], ymin=plotData1a[,3], ymax=plotData1a[,4])) + 
          geom_line() + 
          ylim(0, 0.8) +
          geom_ribbon(alpha=0.2) + 
          geom_hline(yintercept=0, linetype="dashed", color = "red", size=1) +
          geom_line(data = plotData1b, aes(x = vT, y = plotData1b[,2]),  color = "blue", size=1) +
          theme_bw() +
          xlab("Time at treatment") + 
          ylab("BZ Effect"))
  if (nega==0){
    ggsave("Figures\\BZ_sim.png", width = 6, height = 2)
  } else {
    ggsave("Figures\\BZ_sim_min.png", width = 6, height = 2)
  }

  plotData2a <- as.data.frame(cbind(vT, mEf[3,1:(1+dS)],m95lo[3,1:(1+dS)],m95up[3,1:(1+dS)]))
  plotData2b <- as.data.frame(cbind(vT,-simDGP[3,]))
  print(ggplot(data=plotData2a, aes(x=vT, y=plotData2a[,2], ymin=plotData2a[,3], ymax=plotData2a[,4]))  + 
          geom_line() + 
          ylim(-0.8, 0.05) +
          geom_ribbon(alpha=0.2) + 
          geom_hline(yintercept=0, linetype="dashed", color = "red", size=1) +
          geom_line(data = plotData2b, aes(x = vT, y = plotData2b[,2]), color = "blue", size=1) +
          theme_bw() +
          xlab("Time at treatment") + 
          ylab("BS Effect"))
  if (nega==0){
    ggsave("Figures\\BS_sim.png", width = 6, height = 2)
  } else {
    ggsave("Figures\\BS_sim_min.png", width = 6, height = 2)
  }

  plotData3a <- as.data.frame(cbind(vT, mEf[4,1:(1+dS)],m95lo[4,1:(1+dS)],m95up[4,1:(1+dS)]))
  plotData3b <- as.data.frame(cbind(vT,-simDGP[4,]))
  print(ggplot(data=plotData3a, aes(x=vT, y=plotData3a[,2], ymin=plotData3a[,3], ymax=plotData3a[,4])) + 
          geom_line() + 
          ylim(-0.8,0.05) +
          geom_ribbon(alpha=0.2) +
          geom_hline(yintercept=0, linetype="dashed", color = "red", size=1) +
          geom_line(data = plotData3b, aes(x = vT, y = plotData3b[,2]), color = "blue", size=1) +
          theme_bw() +
          xlab("Time at treatment") + 
          ylab("BZS Effect") +
          theme(legend.position="top"))
  if (nega==0){
    ggsave("Figures\\BZS_sim.png", width = 6, height = 2)
  } else {
    ggsave("Figures\\BZS_sim_min.png", width = 6, height = 2)
  }

  
  plotData4a <- as.data.frame(cbind(vT, mEf[5,1:(1+dS)],m95lo[5,1:(1+dS)],m95up[5,1:(1+dS)]))
  plotData4b <- as.data.frame(cbind(vT,simDGP[5,]))
  print(ggplot(data=plotData4a, aes(x=vT, y=plotData4a[,2], ymin=plotData4a[,3], ymax=plotData4a[,4])) + 
          geom_line() + 
          geom_ribbon(alpha=0.2) +
          geom_hline(yintercept=0, linetype="dashed", color = "red", size=1) +
          geom_line(data = plotData4b, aes(x = vT, y = plotData4b[,2]), color = "blue", size=1) +
          theme_bw() +
          xlab("Time at treatment") + 
          ylab("Probability of being never survivor") +
          theme(legend.position="top"))
  
  plotData5a <- as.data.frame(cbind(vT, mEf[6,1:(1+dS)],m95lo[6,1:(1+dS)],m95up[6,1:(1+dS)]))
  plotData5b <- as.data.frame(cbind(vT,simDGP[6,]))
  print(ggplot(data=plotData5a, aes(x=vT, y=plotData5a[,2], ymin=plotData5a[,3], ymax=plotData5a[,4])) + 
          geom_line() + 
          geom_ribbon(alpha=0.2) +
          geom_hline(yintercept=0, linetype="dashed", color = "red", size=1) +
          geom_line(data = plotData5b, aes(x = vT, y = plotData5b[,2]), color = "blue", size=1) +
          theme_bw() +
          xlab("Time at treatment") + 
          ylab("Probability of being complier survivor") +
          theme(legend.position="top"))
  
  
  plotData6a <- as.data.frame(cbind(vT, mEf[7,1:(1+dS)],m95lo[7,1:(1+dS)],m95up[7,1:(1+dS)]))
  plotData6b <- as.data.frame(cbind(vT,simDGP[7,]))
  print(ggplot(data=plotData6a, aes(x=vT, y=plotData6a[,2], ymin=plotData6a[,3], ymax=plotData6a[,4])) + 
          geom_line() + 
          geom_ribbon(alpha=0.2) +
          geom_hline(yintercept=0, linetype="dashed", color = "red", size=1) +
          geom_line(data = plotData6b, aes(x = vT, y = plotData6b[,2]), color = "blue", size=1) +
          theme_bw() +
          xlab("Time at treatment") + 
          ylab("Probability of being always survivor") +
          theme(legend.position="top"))
  
  
  
  return(1)
}




## Results Output #############################################

# CovLik  -> Covariance of parameters from likelihood estimation: 0 for calculation using outer product score, 1 using hessian.
# Durdep  -> Specification of duration dependence term: 0 piecewise constant for each randomization (policy regime
#            and treatments); 1 common piecewise constant duration dependence with constant 
#            proportional effects for each randomization  (policy regime and treatments)       
# mins    -> Initial period for multiple treatment estimation
# dS      -> Treatment interval over which Mean effect calculated
# dT      -> To define post treatment evaluation Length (along with dTmov)
# dTmov   -> Post treatment evaluation length: 1 if fixed at a constant dT; 0 if reducing with s, ie dT-s, for increasing s (end
#                                              evaluation period FIXED so must have mins+dS <= dT)
# plGr    -> Produce plots of effects: 0 no plot of effects, 1 plot of time varying effects

CovLik <- 1; Durdep <- 0;  

Likpar <- LikparamFn(CovLik,Durdep)

if (nega==0){
  save(Likpar,file="Likpar.Rda")
} else {
  save(Likpar,file="Likpar_min.Rda")
}

if (nega==0){
  load("Likpar.Rda") 
} else {
  load("Likpar_min.Rda") 
}

par <- Likpar[,1:2] 
covPH <- Likpar[,3:NCOL(Likpar)]


mins <- 1; dS <- 29; dT <- Rcens; dTmov <- 0; plGr <- 1; 
mOutput <- EffectFn(par,Durdep, mins, dS, dT, dTmov, covPH, plGr)

## Table summary statistics covariates ##

cat("Total observations =" , length(vdurE))
cat("Z=1 treated observations =" , sum(vZ*vCs))
cat("Z=1 non-treated observations =" , sum(vZ*(1-vCs)))
cat("Z=0 treated observations =" , sum((1-vZ)*vCs))
cat("Z=0 non-treated observations =" , sum((1-vZ)*(1-vCs)))








# > sessionInfo()
# R version 4.3.1 (2023-06-16 ucrt)
# Platform: x86_64-w64-mingw32/x64 (64-bit)
# Running under: Windows 11 x64 (build 22631)
# 
# Matrix products: default
# 
# 
# locale:
#   [1] LC_COLLATE=English_United Kingdom.utf8  LC_CTYPE=English_United Kingdom.utf8    LC_MONETARY=English_United Kingdom.utf8
# [4] LC_NUMERIC=C                            LC_TIME=English_United Kingdom.utf8    
# 
# time zone: Europe/London
# tzcode source: internal
# 
# attached base packages:
#   [1] stats     graphics  grDevices utils     datasets  methods   base     
# 
# other attached packages:
#   [1] MASS_7.3-60     Hmisc_5.1-0     dplyr_1.1.2     missForest_1.5  survminer_0.4.9 ggpubr_0.6.0    ggplot2_3.4.2   survival_3.5-5 
# 
