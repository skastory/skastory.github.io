########################################################################
##  Paper Title: Causally Evaluating Selection: Biological, 
##               Behavioral and Institutional Effects on
##               the Kidney Transplant Waitlist
#####
##                                                                    
##  Purpose: Generate descriptive statistics in Appendix: 'Descriptive Statistics and Data selection'
##
##  Reproducibility Information: see end of code for environment info 
##                                                                    
##  Author: Stephen Kastoryano                                        
##  Date  : 30 June 2024                                                 
##                                                      
##           
##  input:  "DF_pre.RData", "DF_post.RData", "DF_all.RData" from KidneyExp_clean
##          
##
##  output: Descriptive statistics table with normalized difference values
##           
##
##  Instructions: Run several times setting blood_types = 0, 1, 2 on line 47 for 
##                normalized difference values on AB, B and A subgroups in columns 2-4
##
##                                                                    
######################################################################################


library("dplyr")
library("tidyr")
library("xtable")




setwd("C:/Users/skast/Dropbox/ContDurMA/CompCode 2023")

set.seed(5327456)


####################
### LOAD DATA, DEFINE SAMPLE
####################



post2015 = 0   # Equal to 0 for pre-2015 reform analysis, 1 for post-2015 reform analysis, 2 for pre- and post-2015 figures
blood_types = 0   # Equal to 0 for AB vs O type, 1 for B vs O type, 2 for A vs O type, 3 for all
livingdon = 0     # 0 for baseline without living donor transplant candidates,Equal to 1 if we want to keep living donor transplants in data
calentry = 0      # 0 for baseline 2002-6-01 -- 2014-12-01, 1 for 2002-6-01 -- 2008-9-01, 2 for 2008-9-01 -- 2014-12-01. Ensures 6 years and 3 months of calendar entries for each 
covadj = 0        # 0 for baseline, 1 for specification with additional adjustments on covariates to check small differences in balance are not driving selection on observables  
race = 0          # 0 for baseline all, 1 for white, 2 for non-white
biosex = 0        # 0 for baseline all, 1 for male, 2 for female
diab_ent = 0       # 0 for baseline all, 1 for diabetes at entry, 2 no diabetes at entry
diab_t2 = 0       # 0 for baseline all, 1 for Type 2 diabetes as main reason for transplant, 2 for not Type 2 diabetes as main reason for transplant
hcv_pos_don = 0   # 0 is baseline not removing candidates who would accept HCV positive donor kidney (very unhealthy kidney), 1 if removing
cpra = 0          # 0 is baseline removing candidates who have CPRA above 0, 1 if all CPRA included
Dtau = 3

##  Load files 
# if (post2015 == 0){
#   if (calentry == 0) {
#     load("DF_pre.RData")
#   } else if (calentry == 1) {
#     load("DF_pre0208.RData")  
#   } else {
#     load("DF_pre0814.RData") 
#   }
# } else if (post2015 == 1){
#   load("DF_post.RData")
# } else {
#   load("DF_all.RData") 
# }

load("DF_pre.RData")
DF1 = DF
load("DF_post.RData")
DF2 = DF

sum(as.numeric(DF2$CAN_ACTIVATE_DT - DF2$CAN_DIAL_DT)<0, na.rm= T)

sum(is.na(DF$DIAL_ENTRY_time))/nrow(DF)
sum((DF$DIAL_ENTRY))/nrow(DF)
sum(is.na(DF$DIAL_ENTRY))/nrow(DF)

#DF = DF[(DF$DIAL_ENTRY_time >=1 & DF$DIAL_ENTRY_time <365),]
#DF = DF[(DF$DIAL_ENTRY_time >=1 & DF$DIAL_ENTRY_time != max(DF$DIAL_ENTRY_time)),]



if (race == 1){
  DF1 = DF1[(DF1$CAN_RACE_SRTR == "WHITE"),]
  DF2 = DF2[(DF2$CAN_RACE_SRTR == "WHITE"),]
} else if (race == 2){
  DF1 = DF1[(DF1$CAN_RACE_SRTR != "WHITE"),]
  DF2 = DF2[(DF2$CAN_RACE_SRTR != "WHITE"),]
}
nrow(DF)



if (cpra == 0){
  DF1 =DF1[(DF1$CANHX_CPRA == 0),]   # only keep CPRA == 0 people. So excluding all individuals with antibodies
  DF2 =DF2[(DF2$CANHX_CPRA == 0),]   # only keep CPRA == 0 people. So excluding all individuals with antibodies
  
}



##############################################
### Descriptive Statistics/ Balance table
##############################################
# 
# # Top part of descriptive statistics table



DF_t = DF1

df_bal = DF_t[,c("WHITE" , "ASIAN", "BLACK", "OTHER_NONWHITE", "CAN_AGE_AT_LISTING", "CAN_PREV_TX", 
                 "DIAB_ENTRY", "DIAL_ENTRY", "DIAL_ENTRY_time","CAN_DGN_POLY","CAN_DGN_HYPE","CAN_DGN_GLOM", "CAN_DGN_OTHE", "FEMALE",
                 "CAN_BMI", "CAN_MALIG", "CAN_ACPT_HBC_POS1", "CAN_ACPT_HCV_POS1", "CAN_FUNCTN_STATn", 
                 "CAN_EDUCATION_HS","CAN_EDUCATION_COL","CAN_EDUCATION_COLDEG",
                   "CAN_ABO")]
df_bal0= df_bal[(df_bal$CAN_ABO == "O"),-ncol(df_bal)]
df_bal1= df_bal[(df_bal$CAN_ABO == "AB"),-ncol(df_bal)]
df_bal2= df_bal[(df_bal$CAN_ABO == "B"),-ncol(df_bal)]
df_bal3= df_bal[(df_bal$CAN_ABO == "A"),-ncol(df_bal)]


DF_t = DF2


df_bal = DF_t[,c("WHITE" , "ASIAN", "BLACK", "OTHER_NONWHITE", "CAN_AGE_AT_LISTING", "CAN_PREV_TX", 
                 "DIAB_ENTRY", "DIAL_ENTRY", "DIAL_ENTRY_time","CAN_DGN_POLY","CAN_DGN_HYPE","CAN_DGN_GLOM", "CAN_DGN_OTHE", "FEMALE",
                 "CAN_BMI", "CAN_MALIG", "CAN_ACPT_HBC_POS1", "CAN_ACPT_HCV_POS1", "CAN_FUNCTN_STATn", 
                 "CAN_EDUCATION_HS","CAN_EDUCATION_COL","CAN_EDUCATION_COLDEG",
                 "CAN_ABO")]
df_bal4= df_bal[(df_bal$CAN_ABO == "O"),-ncol(df_bal)]
df_bal5= df_bal[(df_bal$CAN_ABO == "AB"),-ncol(df_bal)]




# Generate descriptice statistics table
teXtable = rbind(cbind("& ",round(mean(df_bal0[,1], na.rm = T),2),
                       "& ",round(mean(df_bal1[,1], na.rm = T),2),
                       "& ",round(mean(df_bal2[,1], na.rm = T),2),
                       "& ",round(mean(df_bal3[,1], na.rm = T),2),
                       "& &  ",round(mean(df_bal4[,1], na.rm = T),2),
                       "& ",round(mean(df_bal5[,1], na.rm = T),2),"\vspace{-2mm} \\"),
                 cbind("& (",round(sd(df_bal0[,1], na.rm = T),2),
                       ") & (",round(sd(df_bal1[,1], na.rm = T),2),
                       ") & (",round(sd(df_bal2[,1], na.rm = T),2),
                       ") & (",round(sd(df_bal3[,1], na.rm = T),2),
                       ") & &  (",round(sd(df_bal4[,1], na.rm = T),2),
                       ") & (",round(sd(df_bal5[,1], na.rm = T),2),") \\"))

nrow(df_bal1)
for (i in 2:ncol(df_bal0)) {
  teXtable = rbind(teXtable,  rbind(cbind("& ",round(mean(df_bal0[,i], na.rm = T),2),
                                          "& ",round(mean(df_bal1[,i], na.rm = T),2),
                                          "& ",round(mean(df_bal2[,i], na.rm = T),2),
                                          "& ",round(mean(df_bal3[,i], na.rm = T),2),
                                          "& & ",round(mean(df_bal4[,i], na.rm = T),2),
                                          "& ",round(mean(df_bal5[,i], na.rm = T),2),"\vspace{-2mm} \\"),
                                    cbind("& (",round(sd(df_bal0[,i], na.rm = T),2),
                                          ") & (",round(sd(df_bal1[,i], na.rm = T),2),
                                          ") & (",round(sd(df_bal2[,i], na.rm = T),2),
                                          ") & (",round(sd(df_bal3[,i], na.rm = T),2),
                                          ") & &  (",round(sd(df_bal4[,i], na.rm = T),2),
                                          ") & (",round(sd(df_bal5[,i], na.rm = T),2),") \\")))
  
}

options(scipen=999)
teXtable =cbind(c("WHITE" ,"", "ASIAN", "","BLACK", "","OTHER_NONWHITE", "","CAN_AGE_AT_LISTING","", "CAN_PREV_TX", "",
                  "DIAB_ENTRY", "","DIAL_ENTRY","", "DIAL_ENTRY_time", "", "CAN_DGN_POLY","","CAN_DGN_HYPE","","CAN_DGN_GLOM","", "CAN_DGN_OTHE", "", "FEMALE","",
                  "CAN_BMI","", "CAN_MALIG","", "CAN_ACPT_HBC_POS1","", "CAN_ACPT_HCV_POS1", "", "CAN_FUNCTN_STATn", "",
                  "CAN_EDUCATION_HS", "","CAN_EDUCATION_COL", "","CAN_EDUCATION_COLDEG",""),teXtable)



teXtable
xtable(teXtable)


DF_t = DF1
DF_t = DF_t[(DF_t$CAN_RACE_SRTR == "WHITE"),] # Only consier white candidates

df_bal = DF_t[,c("CAN_AGE_AT_LISTING", "CAN_PREV_TX", 
                 "DIAB_ENTRY", "DIAL_ENTRY", "DIAL_ENTRY_time","CAN_DGN_POLY","CAN_DGN_HYPE","CAN_DGN_GLOM", "CAN_DGN_OTHE", "FEMALE",
                 "CAN_BMI", "CAN_MALIG", "CAN_ACPT_HBC_POS1", "CAN_ACPT_HCV_POS1", "CAN_FUNCTN_STATn", 
                 "CAN_EDUCATION_HS","CAN_EDUCATION_COL","CAN_EDUCATION_COLDEG","REC_A_MM_EQUIV_TX","REC_B_MM_EQUIV_TX","REC_DR_MM_EQUIV_TX",
                 "DON_ORG_SHARED","DON_AGE","DON_WGT_KG","DON_CAD_DON_COD_ANOX","DON_CAD_DON_COD_CERE","DON_CAD_DON_COD_HEAD",
                 "DON_CAD_DON_COD_TUMO","DON_CAD_DON_COD_OTHE",
                 "CAN_ABO")]
df_bal6= df_bal[(df_bal$CAN_ABO == "O"),-ncol(df_bal)]
df_bal7= df_bal[(df_bal$CAN_ABO == "AB"),-ncol(df_bal)]



####### Descriptive stats for analysis of treated at t=1
#####################################################


DF_t = DF1
DF_t = DF_t[(DF_t$CAN_RACE_SRTR == "WHITE"),] # Only consier white candidates

DF_t$vdurE <- round(DF_t$durDE/30.437)   # Make analyiss on monthly level
DF_t$vdurE <- DF_t$vdurE*(DF_t$vdurE > 0) +  (DF_t$vdurE == 0)
DF_t$vCe <- DF_t$durDEC
DF_t$vdurS <- round(DF_t$durTX/30.437)   # Make analyiss on monthly level
DF_t$vdurS <- DF_t$vdurS*(DF_t$vdurS > 0) +  (DF_t$vdurS == 0)
DF_t$vCs <- DF_t$durTXC 

DF_t$vCs <- as.numeric(DF_t$vdurS <= DF_t$vdurE )* DF_t$vCs          # adjust treatment indicator if time to treatment censored before exit occurs
DF_t$vdurS <- DF_t$vdurS * as.numeric(DF_t$vdurS <= DF_t$vdurE ) + DF_t$vdurE * as.numeric(DF_t$vdurS > DF_t$vdurE ) 



# The following is to avoid leverage of right tail observations
Rcens = 72  # This number is just to make the pre- and post- 2015 analysis completely comparable

DF_t$vCe <- DF_t$vCe * as.numeric(DF_t$vdurE <= Rcens  ) 
DF_t$vdurE <- DF_t$vdurE * as.numeric(DF_t$vdurE <= Rcens  ) + Rcens * as.numeric(DF_t$vdurE > Rcens  )
DF_t$vCs <- DF_t$vCs * as.numeric(DF_t$vdurS <= Rcens  ) 
DF_t$vdurS <- DF_t$vdurS * as.numeric(DF_t$vdurS <= Rcens  ) + Rcens * as.numeric(DF_t$vdurS > Rcens  )
DF_t$vCe <- DF_t$vCe * (1- DF_t$vCe * as.numeric(DF_t$vdurS < DF_t$vdurE ) * as.numeric(DF_t$vCs == 0 ))
DF_t$vdurE <- DF_t$vdurE - (DF_t$vdurE - DF_t$vdurS) * as.numeric(DF_t$vdurS < DF_t$vdurE ) * as.numeric(DF_t$vCs == 0 ) 

DF_t = DF_t[(DF_t$CAN_ABO != "A"),]   # Drop type A blood types 
DF_t = DF_t[(DF_t$CAN_ABO != "B"),]   # Drop type B blood types 

Dtau <- 3  # Choose treatment window for t=1 Should show for Dtau = 3 in main and Dtau = 1 and Dtau = 6 in appendix
DF_t = DF_t[((DF_t$vdurS <= Dtau)* (DF_t$vCs == 1) == 1),]  # Select treated at t=1

df_bal = DF_t[,c("CAN_AGE_AT_LISTING", "CAN_PREV_TX", 
                 "DIAB_ENTRY", "DIAL_ENTRY", "DIAL_ENTRY_time","CAN_DGN_POLY","CAN_DGN_HYPE","CAN_DGN_GLOM", "CAN_DGN_OTHE", "FEMALE",
                 "CAN_BMI", "CAN_MALIG", "CAN_ACPT_HBC_POS1", "CAN_ACPT_HCV_POS1", "CAN_FUNCTN_STATn", 
                 "CAN_EDUCATION_HS","CAN_EDUCATION_COL","CAN_EDUCATION_COLDEG","REC_A_MM_EQUIV_TX","REC_B_MM_EQUIV_TX","REC_DR_MM_EQUIV_TX",
                 "DON_ORG_SHARED","DON_AGE","DON_WGT_KG","DON_CAD_DON_COD_ANOX","DON_CAD_DON_COD_CERE","DON_CAD_DON_COD_HEAD",
                 "DON_CAD_DON_COD_TUMO","DON_CAD_DON_COD_OTHE",
                 "CAN_ABO")]


df_bal8= df_bal[(df_bal$CAN_ABO == "O"),-ncol(df_bal)]
df_bal9= df_bal[(df_bal$CAN_ABO == "AB"),-ncol(df_bal)]



# Generate descriptice statistics table
teXtable = rbind(cbind("& ",round(mean(df_bal6[,1], na.rm = T),2),
                       "& ",round(mean(df_bal7[,1], na.rm = T),2),
                    "& &  ",round(mean(df_bal8[,1], na.rm = T),2),
                       "& ",round(mean(df_bal9[,1], na.rm = T),2),"\vspace{-2mm} \\"),
                 cbind("& (",round(sd(df_bal6[,1], na.rm = T),2),
                       ") & (",round(sd(df_bal7[,1], na.rm = T),2),
                       ") & &  (",round(sd(df_bal8[,1], na.rm = T),2),
                       ") & (",round(sd(df_bal9[,1], na.rm = T),2),") \\"))

nrow(df_bal6)
teXtable
for (i in 2:ncol(df_bal6)) {
  teXtable = rbind(teXtable,  rbind(cbind("& ",round(mean(df_bal6[,i], na.rm = T),2),
                                          "& ",round(mean(df_bal7[,i], na.rm = T),2),
                                          "& & ",round(mean(df_bal8[,i], na.rm = T),2),
                                          "& ",round(mean(df_bal9[,i], na.rm = T),2),"\vspace{-2mm} \\"),
                                    cbind("& (",round(sd(df_bal6[,i], na.rm = T),2),
                                          ") & (",round(sd(df_bal7[,i], na.rm = T),2),
                                          ") & &  (",round(sd(df_bal8[,i], na.rm = T),2),
                                          ") & (",round(sd(df_bal9[,i], na.rm = T),2),") \\")))
  
}

teXtable
options(scipen=999)
teXtable =cbind(c("CAN_AGE_AT_LISTING","", "CAN_PREV_TX", "",
                  "DIAB_ENTRY", "","DIAL_ENTRY","", "DIAL_ENTRY_time", "", "CAN_DGN_POLY","","CAN_DGN_HYPE","","CAN_DGN_GLOM","", "CAN_DGN_OTHE", "", "FEMALE","",
                  "CAN_BMI","", "CAN_MALIG","", "CAN_ACPT_HBC_POS1","", "CAN_ACPT_HCV_POS1", "", "CAN_FUNCTN_STATn", "",
                  "CAN_EDUCATION_HS", "","CAN_EDUCATION_COL", "","CAN_EDUCATION_COLDEG","",
                  "REC_A_MM_EQUIV_TX",  "","REC_B_MM_EQUIV_TX", "","REC_DR_MM_EQUIV_TX", "",
                  "DON_ORG_SHARED", "","DON_AGE","","DON_WGT_KG", "","DON_CAD_DON_COD_ANOX", "","DON_CAD_DON_COD_CERE", "","DON_CAD_DON_COD_HEAD", "",
                  "DON_CAD_DON_COD_TUMO", "","DON_CAD_DON_COD_OTHE",  ""),teXtable)



teXtable
xtable(teXtable)




## Normalised difference
#####################################################
#####################################################

## Pre reform
DF_t = DF1

library(tableone)
df_bal = DF_t[,c("WHITE" , "ASIAN", "BLACK", "OTHER_NONWHITE", "CAN_AGE_AT_LISTING", "CAN_PREV_TX", 
                 "DIAB_ENTRY", "DIAL_ENTRY", "DIAL_ENTRY_time","CAN_DGN_POLY","CAN_DGN_HYPE","CAN_DGN_GLOM", "CAN_DGN_OTHE", "FEMALE",
                 "CAN_BMI", "CAN_MALIG", "CAN_ACPT_HBC_POS1", "CAN_ACPT_HCV_POS1", "CAN_FUNCTN_STATn", 
                 "CAN_EDUCATION_HS","CAN_EDUCATION_COL","CAN_EDUCATION_COLDEG",
                 "CAN_ABO")]
if (blood_types == 0) {
  df_bal0= df_bal[(df_bal$CAN_ABO != "A"),]
  df_bal0= df_bal0[(df_bal0$CAN_ABO != "B"),]
}else if (blood_types == 1){
  df_bal0= df_bal[(df_bal$CAN_ABO != "AB"),]
  df_bal0= df_bal0[(df_bal0$CAN_ABO != "A"),]
}else if (blood_types == 2){
  df_bal0= df_bal[(df_bal$CAN_ABO != "AB"),]
  df_bal0= df_bal0[(df_bal0$CAN_ABO != "B"),]
}


balance_table <- CreateTableOne(vars = names(df_bal0)[1:(ncol(df_bal)-1)], strata = "CAN_ABO", data = df_bal0)

# Calculate the standardized mean difference (SMD)
calculate_smd <- function(var, data) {
  o_values <- data[data$CAN_ABO == "O", var]
  non_o_values <- data[data$CAN_ABO != "O", var]
  
  mean_diff <- mean(o_values, na.rm = TRUE) - mean(non_o_values, na.rm = TRUE)
  pooled_sd <- sqrt((var(o_values, na.rm = TRUE) + var(non_o_values, na.rm = TRUE)) / 2)
  
  smd <- abs(round(mean_diff / pooled_sd,2))
  return(smd)
}

# Add SMD to the balance table
# Create a data frame for SMD values
smd_data <- data.frame(
  Variable = names(df_bal0)[1:(ncol(df_bal0)-1)],
  SMD = sapply(names(df_bal0)[1:(ncol(df_bal0)-1)], function(var) calculate_smd(var, df_bal0))
)

# Extract the underlying data frame from the TableOne object
balance_table_df <- print(balance_table, include = FALSE)
dim(smd_data)
# Combine the balance table and the SMD data frame
combined_table <- cbind(balance_table_df, rbind(NA,smd_data)[,2])

# Print the updated combined table
print(combined_table, nonnormal = "all")




## Post reform
DF_t = DF2


library(tableone)
df_bal = DF_t[,c("WHITE" , "ASIAN", "BLACK", "OTHER_NONWHITE", "CAN_AGE_AT_LISTING", "CAN_PREV_TX", 
                 "DIAB_ENTRY", "DIAL_ENTRY", "DIAL_ENTRY_time","CAN_DGN_POLY","CAN_DGN_HYPE","CAN_DGN_GLOM", "CAN_DGN_OTHE", "FEMALE",
                 "CAN_BMI", "CAN_MALIG", "CAN_ACPT_HBC_POS1", "CAN_ACPT_HCV_POS1", "CAN_FUNCTN_STATn", 
                 "CAN_EDUCATION_HS","CAN_EDUCATION_COL","CAN_EDUCATION_COLDEG",
                 "CAN_ABO")]
if (blood_types == 0) {
  df_bal0= df_bal[(df_bal$CAN_ABO != "A"),]
  df_bal0= df_bal0[(df_bal0$CAN_ABO != "B"),]
}else if (blood_types == 1){
  df_bal0= df_bal[(df_bal$CAN_ABO != "AB"),]
  df_bal0= df_bal0[(df_bal0$CAN_ABO != "A"),]
}else if (blood_types == 2){
  df_bal0= df_bal[(df_bal$CAN_ABO != "AB"),]
  df_bal0= df_bal0[(df_bal0$CAN_ABO != "B"),]
}


balance_table <- CreateTableOne(vars = names(df_bal0)[1:(ncol(df_bal)-1)], strata = "CAN_ABO", data = df_bal0)

# Calculate the standardized mean difference (SMD)
calculate_smd <- function(var, data) {
  o_values <- data[data$CAN_ABO == "O", var]
  non_o_values <- data[data$CAN_ABO != "O", var]
  
  mean_diff <- mean(o_values, na.rm = TRUE) - mean(non_o_values, na.rm = TRUE)
  pooled_sd <- sqrt((var(o_values, na.rm = TRUE) + var(non_o_values, na.rm = TRUE)) / 2)
  
  smd <- abs(round(mean_diff / pooled_sd,2))
  return(smd)
}

# Add SMD to the balance table
# Create a data frame for SMD values
smd_data <- data.frame(
  Variable = names(df_bal0)[1:(ncol(df_bal0)-1)],
  SMD = sapply(names(df_bal0)[1:(ncol(df_bal0)-1)], function(var) calculate_smd(var, df_bal0))
)

# Extract the underlying data frame from the TableOne object
balance_table_df <- print(balance_table, include = FALSE)
dim(smd_data)
# Combine the balance table and the SMD data frame
combined_table <- cbind(balance_table_df, rbind(NA,smd_data)[,2])

# Print the updated combined table
print(combined_table, nonnormal = "all")




## Pre reform white
DF_t = DF1
DF_t = DF_t[(DF_t$CAN_RACE_SRTR == "WHITE"),] # Only consier white candidates


library(tableone)
df_bal = DF_t[,c("CAN_AGE_AT_LISTING", "CAN_PREV_TX", 
                 "DIAB_ENTRY", "DIAL_ENTRY", "DIAL_ENTRY_time","CAN_DGN_POLY","CAN_DGN_HYPE","CAN_DGN_GLOM", "CAN_DGN_OTHE", "FEMALE",
                 "CAN_BMI", "CAN_MALIG", "CAN_ACPT_HBC_POS1", "CAN_ACPT_HCV_POS1", "CAN_FUNCTN_STATn", 
                 "CAN_EDUCATION_HS","CAN_EDUCATION_COL","CAN_EDUCATION_COLDEG","REC_A_MM_EQUIV_TX","REC_B_MM_EQUIV_TX","REC_DR_MM_EQUIV_TX",
                 "DON_ORG_SHARED","DON_AGE","DON_WGT_KG","DON_CAD_DON_COD_ANOX","DON_CAD_DON_COD_CERE","DON_CAD_DON_COD_HEAD",
                 "DON_CAD_DON_COD_TUMO","DON_CAD_DON_COD_OTHE",
                 "CAN_ABO")]
if (blood_types == 0) {
  df_bal0= df_bal[(df_bal$CAN_ABO != "A"),]
  df_bal0= df_bal0[(df_bal0$CAN_ABO != "B"),]
}else if (blood_types == 1){
  df_bal0= df_bal[(df_bal$CAN_ABO != "AB"),]
  df_bal0= df_bal0[(df_bal0$CAN_ABO != "A"),]
}else if (blood_types == 2){
  df_bal0= df_bal[(df_bal$CAN_ABO != "AB"),]
  df_bal0= df_bal0[(df_bal0$CAN_ABO != "B"),]
}


balance_table <- CreateTableOne(vars = names(df_bal0)[1:(ncol(df_bal)-1)], strata = "CAN_ABO", data = df_bal0)

# Calculate the standardized mean difference (SMD)
calculate_smd <- function(var, data) {
  o_values <- data[data$CAN_ABO == "O", var]
  non_o_values <- data[data$CAN_ABO != "O", var]
  
  mean_diff <- mean(o_values, na.rm = TRUE) - mean(non_o_values, na.rm = TRUE)
  pooled_sd <- sqrt((var(o_values, na.rm = TRUE) + var(non_o_values, na.rm = TRUE)) / 2)
  
  smd <- abs(round(mean_diff / pooled_sd,2))
  return(smd)
}

# Add SMD to the balance table
# Create a data frame for SMD values
smd_data <- data.frame(
  Variable = names(df_bal0)[1:(ncol(df_bal0)-1)],
  SMD = sapply(names(df_bal0)[1:(ncol(df_bal0)-1)], function(var) calculate_smd(var, df_bal0))
)

# Extract the underlying data frame from the TableOne object
balance_table_df <- print(balance_table, include = FALSE)
dim(smd_data)
# Combine the balance table and the SMD data frame
combined_table <- cbind(balance_table_df, rbind(NA,smd_data)[,2])

# Print the updated combined table
print(combined_table, nonnormal = "all")





####### Normalised difference for analysis of treated at t=1
#####################################################
DF_t = DF1
DF_t = DF_t[(DF_t$CAN_RACE_SRTR == "WHITE"),] # Only consier white candidates

DF_t$vdurE <- round(DF_t$durDE/30.437)   # Make analyiss on monthly level
DF_t$vdurE <- DF_t$vdurE*(DF_t$vdurE > 0) +  (DF_t$vdurE == 0)
DF_t$vCe <- DF_t$durDEC
DF_t$vdurS <- round(DF_t$durTX/30.437)   # Make analyiss on monthly level
DF_t$vdurS <- DF_t$vdurS*(DF_t$vdurS > 0) +  (DF_t$vdurS == 0)
DF_t$vCs <- DF_t$durTXC 

DF_t$vCs <- as.numeric(DF_t$vdurS <= DF_t$vdurE )* DF_t$vCs          # adjust treatment indicator if time to treatment censored before exit occurs
DF_t$vdurS <- DF_t$vdurS * as.numeric(DF_t$vdurS <= DF_t$vdurE ) + DF_t$vdurE * as.numeric(DF_t$vdurS > DF_t$vdurE ) 



# The following is to avoid leverage of right tail observations
Rcens = 72  # This number is just to make the pre- and post- 2015 analysis completely comparable

DF_t$vCe <- DF_t$vCe * as.numeric(DF_t$vdurE <= Rcens  ) 
DF_t$vdurE <- DF_t$vdurE * as.numeric(DF_t$vdurE <= Rcens  ) + Rcens * as.numeric(DF_t$vdurE > Rcens  )
DF_t$vCs <- DF_t$vCs * as.numeric(DF_t$vdurS <= Rcens  ) 
DF_t$vdurS <- DF_t$vdurS * as.numeric(DF_t$vdurS <= Rcens  ) + Rcens * as.numeric(DF_t$vdurS > Rcens  )
DF_t$vCe <- DF_t$vCe * (1- DF_t$vCe * as.numeric(DF_t$vdurS < DF_t$vdurE ) * as.numeric(DF_t$vCs == 0 ))
DF_t$vdurE <- DF_t$vdurE - (DF_t$vdurE - DF_t$vdurS) * as.numeric(DF_t$vdurS < DF_t$vdurE ) * as.numeric(DF_t$vCs == 0 ) 

if (blood_types == 0) {
  DF_t= DF_t[(DF_t$CAN_ABO != "A"),]
  DF_t= DF_t[(DF_t$CAN_ABO != "B"),]
}else if (blood_types == 1){
  DF_t= DF_t[(DF_t$CAN_ABO != "AB"),]
  DF_t= DF_t[(DF_t$CAN_ABO != "A"),]
}else if (blood_types == 2){
  DF_t= df_bal[(df_bal$CAN_ABO != "AB"),]
  DF_t= DF_t[(DF_t$CAN_ABO != "B"),]
}

Dtau <- 3  # Choose treatment window for t=1 Should show for Dtau = 3 in main and Dtau = 1 and Dtau = 6 in appendix
DF_t = DF_t[((DF_t$vdurS <= Dtau)* (DF_t$vCs == 1) == 1),]  # Select treated at t=1

df_bal = DF_t[,c( "CAN_AGE_AT_LISTING", "CAN_PREV_TX", 
                  "DIAB_ENTRY", "DIAL_ENTRY", "DIAL_ENTRY_time","CAN_DGN_POLY","CAN_DGN_HYPE","CAN_DGN_GLOM", "CAN_DGN_OTHE", "FEMALE",
                  "CAN_BMI", "CAN_MALIG", "CAN_ACPT_HBC_POS1", "CAN_ACPT_HCV_POS1", "CAN_FUNCTN_STATn", 
                  "CAN_EDUCATION_HS","CAN_EDUCATION_COL","CAN_EDUCATION_COLDEG","REC_A_MM_EQUIV_TX","REC_B_MM_EQUIV_TX","REC_DR_MM_EQUIV_TX",
                  "DON_ORG_SHARED","DON_AGE","DON_WGT_KG","DON_CAD_DON_COD_ANOX","DON_CAD_DON_COD_CERE","DON_CAD_DON_COD_HEAD",
                  "DON_CAD_DON_COD_TUMO","DON_CAD_DON_COD_OTHE",
                  "CAN_ABO")]

if (blood_types == 0) {
  df_bal0= df_bal[(df_bal$CAN_ABO != "A"),]
  df_bal0= df_bal0[(df_bal0$CAN_ABO != "B"),]
}else if (blood_types == 1){
  df_bal0= df_bal[(df_bal$CAN_ABO != "AB"),]
  df_bal0= df_bal0[(df_bal0$CAN_ABO != "A"),]
}else if (blood_types == 2){
  df_bal0= df_bal[(df_bal$CAN_ABO != "AB"),]
  df_bal0= df_bal0[(df_bal0$CAN_ABO != "B"),]
}

balance_table <- CreateTableOne(vars = names(df_bal0)[1:(ncol(df_bal)-1)], strata = "CAN_ABO", data = df_bal0)

# Calculate the standardized mean difference (SMD)
calculate_smd <- function(var, data) {
  o_values <- data[data$CAN_ABO == "O", var]
  non_o_values <- data[data$CAN_ABO != "O", var]
  
  mean_diff <- mean(o_values, na.rm = TRUE) - mean(non_o_values, na.rm = TRUE)
  pooled_sd <- sqrt((var(o_values, na.rm = TRUE) + var(non_o_values, na.rm = TRUE)) / 2)
  
  smd <- abs(round(mean_diff / pooled_sd,2))
  return(smd)
}

# Add SMD to the balance table
# Create a data frame for SMD values
smd_data <- data.frame(
  Variable = names(df_bal0)[1:(ncol(df_bal0)-1)],
  SMD = sapply(names(df_bal0)[1:(ncol(df_bal0)-1)], function(var) calculate_smd(var, df_bal0))
)

# Extract the underlying data frame from the TableOne object
balance_table_df <- print(balance_table, include = FALSE)
dim(smd_data)
# Combine the balance table and the SMD data frame
combined_table <- cbind(balance_table_df, rbind(NA,smd_data)[,2])

# Print the updated combined table
print(combined_table, nonnormal = "all")




# > sessionInfo()
# R version 4.3.1 (2023-06-16 ucrt)
# Platform: x86_64-w64-mingw32/x64 (64-bit)
# Running under: Windows 11 x64 (build 22631)
# 
# Matrix products: default
# 
# 
# locale:
#   [1] LC_COLLATE=English_United Kingdom.utf8  LC_CTYPE=English_United Kingdom.utf8    LC_MONETARY=English_United Kingdom.utf8
# [4] LC_NUMERIC=C                            LC_TIME=English_United Kingdom.utf8    
# 
# time zone: Europe/London
# tzcode source: internal
# 
# attached base packages:
#   [1] stats     graphics  grDevices utils     datasets  methods   base     
# 
# other attached packages:
#   [1] tableone_0.13.2 xtable_1.8-4    tidyr_1.3.0     dplyr_1.1.2  

