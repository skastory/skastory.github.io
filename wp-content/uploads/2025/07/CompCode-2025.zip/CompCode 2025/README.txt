
Project: Causally Evaluating Selection on the Kidney Transplant Waitlist
                                                                    
Author: Stephen P. Kastoryano                                        
Date  : July 2025   
                                       
Purpose: Generate all Figures and Tables 
                                              

Files: 

For results using OPTN/SRTR Kidney data (Main text and Appendix)
- KidneyExp_clean.R cleans and prepares SRTR kidney data for analysis by blood type:
  input:  "cand_kipa.sas7bdat" - SRTR kidney data. 
           Contact SRTR to request data at https://www.srtr.org/requesting-srtr-data/data-requests/
  output: "DF_pre.RData", "DF_post.RData" - for KidneyExp_KM.R, KidneyExp_descstats.R, KidneyExp_Estim1.R, KidneyExp_EstimDTE.R

- KidneyExp_KM.R plot Survival probabilities and transplant hazard curves
 input:  "DF_pre.RData", "DF_post.RData", "DF_all.RData" from KidneyExp_clean
 output: Figures 1 and 3 in Text and All pre-transplant survival figures in Appendix C: 'Additional results: dynamic treatment effect analyses'.
     
- KidneyExp_descstats.R  Generate descriptive statistics in Appendix: 'Descriptive Statistics and Data selection'
 input:  "DF_pre.RData", "DF_post.RData", "DF_all.RData" from KidneyExp_clean
 output: Descriptive statistics table with normalized difference values in appendix Table A1

- KidneyExp_Estim1.R  Estimate of period t=1 effects and heterogenous effects on treatment and survival 
 input:  "DF_pre.RData", "DF_post.RData", "DF_all.RData" from KidneyExp_clean
 output: Figure 4 in Text, in appendix D: Figures A5b and A5c, and Table A2 and Appendix E All Figures: Additional Results: effects on transplanted and overall

- KidneyExp_EstimDTE.R
 input:  "DF_pre.RData", "DF_post.RData", "DF_all.RData" from KidneyExp_clean
 output: Figures 2 and 3 in Text and All pre-transplant effects figures in  Appendix C: 'Additional results: dynamic treatment effect analyses'. Also Figure A5a

- KidneyExp_EstimDTE_ML.R
 input:  "DF_pre.RData", "DF_post.RData", "DF_all.RData" from KidneyExp_clean
 output: Figures 2 and 3 in Text and All pre-transplant effects figures in Appendices: 'Additional figures and estimates on subgroups' & 'Selection on education'
 



For Dynamic Discrete Choice Simulation results (Main text and Appendix)
- DGPsim.ox generates data from DDC model 
 outputs: 
    * "DGPsampleER.m", "DGPsampleER_min.m" - for dgpLARTE.R
    * "DGPz1c.m","DGPz1S.m","DGPz1Sc.m", "DGPz0cER.m","DGPz0SER.m","DGPz0ScER.m"
      "DGPz1c_min.m","DGPz1S_min.m","DGPz1Sc_min.m", "DGPz0cER_min.m","DGPz0SER_min.m","DGPz0ScER_min.m" - for DGPsimVal_2024.R

- DGPsimVal_2024.R calculates true effect values for DDC model for figures and results in Appendix: Dynamic discrete choice model of candidate behavior 
  input:  "DGPz1c.m","DGPz1S.m","DGPz1Sc.m", "DGPz0cER.m","DGPz0SER.m","DGPz0ScER.m"
          "DGPz1c_min.m","DGPz1S_min.m","DGPz1Sc_min.m", "DGPz0cER_min.m","DGPz0SER_min.m","DGPz0ScER_min.m"  - from DGPsim.ox
  output: "simDGPval_3060.txt" and "simDGPval_3060_min.txt" for dgpKidneyExp_2024.R

- dgpKidneyExp_2024.R Plot Kaplan-Meier curves and estimate dynamic treatment effects for figures and tables in Appendix: Dynamic    discrete choice model of candidate behavior
 input:  "DGPsampleER.m", "DGPsampleER_min.m" from DGPsim.ox 
         "simDGPval_3060.txt", simDGPval_3060_min.txt"  from DGPsimVal_2024.R 
 output: In relevant appendix (see above): Kaplan-Meier plots for simulated positive and negative treatment effect,
         + DGP MSE statistics + dynamic evaluation of estimator figures


