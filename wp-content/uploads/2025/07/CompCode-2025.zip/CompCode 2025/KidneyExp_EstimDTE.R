########################################################################
##  Paper Title: Causally Evaluating Selection: Biological, 
##               Behavioral and Institutional Effects on
##               the Kidney Transplant Waitlist
#####
##                                                                    
##  Purpose: Estimating Dynamic Treatment Decomposition Effects 
##
##  Reproducibility Information: see end of code for environment info 
##                                                                    
##  Author: Stephen Kastoryano                                        
##  Date  : 30 June 2024                                                 
##                                                      
##           
##  input:  "DF_pre.RData", "DF_post.RData", "DF_all.RData" from KidneyExp_clean
##          
##
##  output: Figures 2 and 3 in Text and All pre-transplant effects figures in Appendices: 'Additional figures and estimates on subgroups' & 'Selection on education'
##           
##
##  Instructions: Set post2015 = 0, cov_incl = 0, all other variable parameters to 0 for Figure 2a
##                Set post2015 = 0, cov_incl = 1, all other variable parameters to 0 for Figure 2b
##                Set post2015 = 0, cov_incl = 2, all other variable parameters to 0 for Figure 2c
##                Set post2015 = 1, cov_incl = 2, all other variable parameters to 0 for Figure 2d
##                Set post2015 = 0, cov_incl = 2, blood_types = 1 all other variable parameters to 0 for Figure 3c
##                Set post2015 = 0, cov_incl = 2, blood_types = 2 all other variable parameters to 0 for Figure 3d
##                Set cov_incl = 2, all others 0 except in turn switch on livingdon = 1; race =1; race=2; biosex=1; biosex=2 for pre-transplant effects plots in Figures Appendix 'Additional figures and estimates on subgroups': Pre-transplant survival and effect βz for different subsamples. 
##                Set cov_incl = 2, all others 0 except in turn switch on educ_adj = 1; educD =1; educD=2; educD=3; race=1 & educD=2; for pre-transplant effects plots in Figures Appendix 'Selection on education': Pre-transplant survival and effect βz for different subsamples
##                Set cov_incl = 3, all others 0 for Figure Appendix 'Selection on education': Effects with education covariate Figure
##                Set cov_incl = 3, educ_adj = 1 and all others 0 for Figure Appendix 'Selection on education': Effects after re-balancing with education covariates
##
##                                                                    
######################################################################################  

#library(survival, lib.loc="C:\\Users\\Stephen Kastoryano\\Documents\\R\\win-library\\3.6")
#library(survminer, lib.loc="C:\\Users\\Stephen Kastoryano\\Documents\\R\\win-library\\3.6")

#library(missForest)
library(dplyr)
#library(Hmisc)
library(MASS)
library(ggplot2)
library(reshape2)
library(MatchIt)
library(optmatch)
library(fastDummies)


## Load Data ##
###############

setwd("/home/users/vi923167/LARTE_2023")
#setwd("C:/Users/skast/Dropbox/ContDurMA/CompCode 2023")



set.seed(5327456)

# Fixed parameters
ANmonth = 2      # Analysis conducted at ANmonth monthly level so if ANmonth= 2, 2 months is one time unit
Rcens = 60/ANmonth      # This number of 60 is just to make the pre- and post- 2015 analysis completely comparable

# Variable parameters
post2015 = 0   # Equal to 0 for pre-2015 reform analysis, 1 for post-2015 reform analysis, 2 for pre- and post-2015 figures
cov_incl = 1      # Baseline should be 2. 0 for kidney allocation mechanism covariates, 1 for no covariates, 2 for kidney allocation mechanism covariates and additional health covariates, 3 for kidney allocation mechanism covariates and additional health and education covariates  
blood_types = 0   # 0 for AB vs O type, 1 for B vs O type, 2 for A vs O type, 3 for all
livingdon = 0     # 0 for baseline without living donor transplant candidates,Equal to 1 if we want to keep living donor transplants in data
calentry = 0      # 0 for baseline 2002-6-01 -- 2014-12-01, 1 for 2002-6-01 -- 2008-9-01, 2 for 2008-9-01 -- 2014-12-01. Ensures 6 years and 3 months of calendar entries for each 
race = 1          # 0 for baseline all, 1 for white, 2 for non-white
biosex = 0        # 0 for baseline all, 1 for male, 2 for female
diab_ent = 0       # 0 for baseline all, 1 for diabetes at entry, 2 no diabetes at entry
diab_t2 = 0       # 0 for baseline all, 1 for Type 2 diabetes as main reason for transplant, 2 for not Type 2 diabetes as main reason for transplant
hcv_pos_don = 0   # 0 is baseline not removing candidates who would accept HCV positive donor kidney (very unhealthy kidney), 1 if removing
cpra = 0          # 0 is baseline removing candidates who have CPRA above 0, 1 if all CPRA included (code only set for cpra=0)
dial <- 0         # 0 for baseline controlling for dialysis status and time on dialysis at entry, 1 not controlling for dialysis status and time on dialysis at entry
educD <- 0         # 0 is baseline including everyone, 1 includes HS degree or less, 2 includes 'some college', 3 includes at least a college degree,  4 includes at least 'some college'      
educ_adj = 0      # 0 is baseline without re-balancing education for O vs AB blood group, 1 when re-balancing education for O vs AB blood group (only to be used in O vs AB comparison)     
p_score_m = 1     # 0 is baseline without NN matching on p-score, 1 is with matching.

##  Load files 
if (post2015 == 0){
  if (calentry == 0) {
    load("DF_pre.RData")
  } else if (calentry == 1) {
    load("DF_pre0208.RData")  
  } else {
    load("DF_pre0814.RData") 
  }
}else{
  load("DF_post.RData")
}

table(DF$DIAL_ENTRY)

####################
### DATA SELECTION
####################


## Select blood types for comparison

if (blood_types == 0) {  # AB vs O
  # These lines must be include for AB vs. O analysis
  DF = DF[(DF$CAN_ABO != "A"),]   # Drop type A blood types 
  DF = DF[(DF$CAN_ABO != "B"),]   # Drop type B blood types 
  print(table(DF$CAN_ABO))
} else if (blood_types == 1) {  # B vs O
  DF = DF[(DF$CAN_ABO != "A"),]   # Drop type A blood types 
  DF = DF[(DF$CAN_ABO != "AB"),]   # Drop type AB blood types 
  print(table(DF$CAN_ABO))
} else if (blood_types == 2) {  # A vs O
  DF = DF[(DF$CAN_ABO != "B"),]   # Drop type B blood types 
  DF = DF[(DF$CAN_ABO != "AB"),]   # Drop type AB blood types 
  print(table(DF$CAN_ABO))
}


if (cpra == 0){
  DF =DF[(DF$CANHX_CPRA == 0),]   # only keep CPRA == 0 people. So excluding all individuals with antibodies
}
nrow(DF)
## Include living donors or not
if (livingdon == 0){
  DF =DF[(DF$DON_TY !="L"),]   # remove anyone who received kidney from living donor
}
nrow(DF)


if (race == 1){
  DF = DF[(DF$CAN_RACE_SRTR == "WHITE"),]
} else if (race == 2){
  DF = DF[(DF$CAN_RACE_SRTR != "WHITE"),]
}
nrow(DF)


if (biosex == 1){
  DF = DF[(DF$FEMALE == 0),]
} else if (biosex == 2){
  DF = DF[(DF$FEMALE == 1),]
}

if (diab_ent == 1){
  DF = DF[(DF$DIAB_ENTRY == 1 ),]
} else if (diab_ent == 2){
  DF = DF[(DF$DIAB_ENTRY == 0 ),]
}

if (diab_t2 == 1){
  DF = DF[(DF$CAN_DGN == 3070 ),]
} else if (diab_t2 == 2){
  DF = DF[(DF$CAN_DGN != 3070 ),]
}

if (hcv_pos_don == 1){
  DF = DF[(DF$CAN_ACPT_HCV_POS1==0 ),]   # Drop anyone who would accept an HCV positive donor
}



## EPTS score AT ENTRY! for new kidney allocation analysis at t=1
if (post2015 == 1){
  if (dial == 0){
    DF$DIAL_ENTRY_time_yr = round(DF$DIAL_ENTRY_time/ 365.25)
    DF$DIAL_ENTRY_time_yr[is.na(DF$DIAL_ENTRY_time_yr)] <- 0
    DF$DIAL_ENTRY[is.na(DF$DIAL_ENTRY)] <- 0
    DF$EPTSscore = 0.047 * max(DF$CAN_AGE_AT_LISTING - 25, 0) - 0.015 * DF$DIAB_ENTRY * max(DF$CAN_AGE_AT_LISTING - 25, 0) +
      0.398 * DF$CAN_PREV_TX - 0.237 * DF$DIAB_ENTRY * DF$CAN_PREV_TX +
      0.315 * log(DF$DIAL_ENTRY_time_yr + 1) - 0.099 * DF$DIAB_ENTRY * log(DF$DIAL_ENTRY_time_yr + 1) +
      0.130 * (1-DF$DIAL_ENTRY) - 0.348 * DF$DIAB_ENTRY * (1-DF$DIAL_ENTRY) + 1.262 * DF$DIAB_ENTRY
  }else{
    DF$EPTSscore = 0.047 * max(DF$CAN_AGE_AT_LISTING - 25, 0) - 0.015 * DF$DIAB_ENTRY * max(DF$CAN_AGE_AT_LISTING - 25, 0) +
      0.398 * DF$CAN_PREV_TX - 0.237 * DF$DIAB_ENTRY * DF$CAN_PREV_TX 
  }
  
  
  threshold <- quantile(DF$EPTSscore, 0.2)
  # Create a new variable DF$EPTSlow20 which represents prioritised candidates
  DF$EPTSlow20 <- ifelse(DF$EPTSscore <= threshold, 1, 0)
  
}


if (educD == 1) {  # includes HS degree or less
  DF = DF[!is.na(DF$CAN_EDUCATION_HS),]
  DF = DF[(DF$CAN_EDUCATION_HS == 1),]
} else if (educD == 2) {  # includes 'some college'
  DF = DF[!is.na(DF$CAN_EDUCATION_COL),]
  DF = DF[(DF$CAN_EDUCATION_COL == 1),] 
} else if (educD == 3) {  # includes some college degree
  DF = DF[!is.na(DF$CAN_EDUCATION_COLDEG),]
  DF = DF[(DF$CAN_EDUCATION_COLDEG == 1),]
} else if (educD == 4) {  # includes HS or less
  DF = DF[!is.na(DF$CAN_EDUCATION_COLDEG),]
  DF = DF[!is.na(DF$CAN_EDUCATION_COL),]
  DF = DF[(DF$CAN_EDUCATION_COLDEG == 1 | DF$CAN_EDUCATION_COL == 1),]
}


if (educ_adj == 1){
  ### This code ensures that the distribution of education balanced
  set.seed(123)  # For reproducibility
  
  share_to_drop = 0.18
  num_to_drop <- round(share_to_drop*sum(as.numeric(DF$CAN_EDUCATION_HS == 1)* as.numeric(DF$CAN_ABO == 'O'),na.rm=T))
  # Filter rows that match the criteria
  rows_to_consider <- DF %>%
    filter(CAN_EDUCATION_HS == 1, CAN_ABO == 'O')
  
  # Randomly sample the rows to drop
  ids_to_drop <- sample(rows_to_consider$PERS_ID, num_to_drop)
  
  # Create an index of rows to keep
  DF_updated <- DF %>%
    filter(!PERS_ID %in% ids_to_drop)
  
  # Return the dataframe with specified rows dropped
  DF <- DF_updated
}



#   main: c("DIAL_ENTRY_time", "CAN_BMI","CAN_DGN_POLY","CAN_DGN_HYPE","CAN_DGN_GLOM", "CAN_LISTING_CTR_ID") 
#   potential bad control c("CAN_FUNCTN_STATn") # Note this is not used in Wolfe study. education variable should be added to this 
#   extra with high share missing: c("CAN_TOT_ALBUMIN", "CAN_TOT_ALBUMIN_miss")
















if (p_score_m == 0){
  
  DF = DF[,c("durDE", "durDEC", "durTX","durTXC", "CAN_ABO", "CAN_ACPT_HBC_POS1","CAN_ACPT_HCV_POS1", "CAN_MIN_PEAK_CREAT_5up", "CAN_AGE_AT_LISTING_41","CAN_AGE_AT_LISTING_51","CAN_AGE_AT_LISTING_58","CAN_AGE_AT_LISTING_65","CAN_AGE_AT_LISTING_65up", "CAN_EDUCATION_HS","CAN_EDUCATION_COL","CAN_EDUCATION_COLDEG","CAN_BMI_under19","CAN_BMI_1925","CAN_BMI_2630","CAN_BMI_over30", "CAN_WGT_KG", "CAN_HGT_CM", "CAN_MALIG", "ASIAN", "BLACK", "OTHER_NONWHITE","WHITE","CAN_PREV_TX","FEMALE","DIAB_ENTRY", "DIAL_ENTRY", "DIAL_time_1YRplus", "CANHX_CPRA","CAN_AGE_AT_LISTING","CAN_BMI", "CAN_DGN_POLY","CAN_DGN_HYPE","CAN_DGN_GLOM" )]
  
  
  ### Imputing missing values on the X (this matters as dropping them shifts results)
  ## It doesn't make much of a difference in the results which I use (it matters more that I just don't drop the variables), but might in your application
  ## 1. imputing mode (fast)
  impute_mode <- function(df) {
    for (col in names(df)) {
      if (any(is.na(df[[col]]))) {  # Check if column has missing values
        mode_val <- names(sort(table(df[[col]]), decreasing = TRUE))[1]  # Get mode
        df[[col]][is.na(df[[col]])] <- mode_val  # Impute mode
      }
    }
    return(df)
  }
  
  DF <- impute_mode(DF)  # Apply function to your dataframe
  # DF[] <- lapply(DF, function(x) {
  #   if (is.character(x)) as.numeric(x) else x
  # })
  
  ## 2. Tree based approach (takes time)
  # DF2 <- mice(DF2, method = "cart", m = 5)  # Uses Classification and Regression Trees (CART)
  
  nrow(DF)
  mDat <- DF[complete.cases(DF), ]  # drop missing rows
  nrow(mDat)
  
  
  
} else {
  
  
  
  DF = DF[,c("durDE", "durDEC", "durTX","durTXC", "CAN_ABO", "CAN_ACPT_HBC_POS1","CAN_ACPT_HCV_POS1", "CAN_EDUCATION_HS","CAN_EDUCATION_COL","CAN_EDUCATION_COLDEG", "CAN_MALIG", "CAN_PREV_TX","FEMALE","DIAB_ENTRY", "DIAL_ENTRY", "CAN_AGE_AT_LISTING_51", "CAN_AGE_AT_LISTING_58", "CAN_AGE_AT_LISTING_65","CAN_AGE_AT_LISTING_65up","CAN_BMI_under19","CAN_BMI_1925","CAN_BMI_2630","CAN_BMI_over30",   "ASIAN", "BLACK", "OTHER_NONWHITE","WHITE", "DIAL_time_1YRplus", "CAN_DGN_POLY","CAN_DGN_HYPE","CAN_DGN_GLOM", "CAN_LISTING_CTR_ID"  )]
  
  
  
  ### Imputing missing values on the X (this matters as dropping them shifts results)
  ## It doesn't make much of a difference in the results which I use (it matters more that I just don't drop the variables), but might in your application
  ## 1. imputing mode (fast)
  impute_mode <- function(df) {
    for (col in names(df)) {
      if (any(is.na(df[[col]]))) {  # Check if column has missing values
        mode_val <- names(sort(table(df[[col]]), decreasing = TRUE))[1]  # Get mode
        df[[col]][is.na(df[[col]])] <- mode_val  # Impute mode
      }
    }
    return(df)
  }
  #DF =  dummy_cols(DF, select_columns = "CAN_LISTING_CTR_ID", remove_first_dummy = FALSE)
  
  
  
  # Step 3: Collapse centers with <400 obs
  center_counts <- table(DF$CAN_LISTING_CTR_ID)
  large_centers <- names(center_counts[center_counts >= 400])
  
  # Step 3a: Create grouping variable
  DF$CTR_GROUPED <- ifelse(DF$CAN_LISTING_CTR_ID %in% large_centers,
                           NA, "OTHER")  # NA for large centers, "OTHER" for small
  DF$CTR_GROUPED <- factor(DF$CTR_GROUPED, exclude = NULL)  # keep NAs
  
  # Step 3b: Dummy code ONLY large centers
  DF_large_only <- DF[DF$CAN_LISTING_CTR_ID %in% large_centers, , drop = FALSE]
  DF_dummies <- dummy_cols(DF, select_columns = "CAN_LISTING_CTR_ID", remove_first_dummy = FALSE)
  keep_dummy_names <- paste0("CAN_LISTING_CTR_ID_", large_centers)
  dummy_cols_to_keep <- keep_dummy_names[keep_dummy_names %in% names(DF_dummies)]
  DF <- cbind(DF, DF_dummies[, dummy_cols_to_keep, drop = FALSE])
  
  # Step 3c: Remove all other `CAN_LISTING_CTR_ID_` columns if any were auto-added
  DF <- DF[, !grepl("^CAN_LISTING_CTR_ID_", names(DF)) | names(DF) %in% dummy_cols_to_keep]
  
  # Step 4: Drop original center ID
  DF$CAN_LISTING_CTR_ID <- NULL
  
  DF$CTR_GROUPED <- ifelse(DF$CTR_GROUPED == "OTHER", 1, 0)
  
  
  # Step 5: Clean and impute
  DF <- impute_mode(DF)
  
  # DF[] <- lapply(DF, function(x) {
  #   if (is.character(x)) as.numeric(x) else x
  # })
  
  ## 2. Tree based approach (takes time)
  # DF2 <- mice(DF2, method = "cart", m = 5)  # Uses Classification and Regression Trees (CART)
  
  DF <- na.omit(DF)
  DF$Z <- 1-as.numeric(DF$CAN_ABO == "O")
  
  # Step 6: Define matching variables
  
  
  if (race != 0){
    exact_vars <- c()
  } else {
    exact_vars <- c("WHITE","BLACK","ASIAN","OTHER_NONWHITE")
    
  }
  
  
  
  
  
  
  # Step 1: Find all large center dummy variable names in DF
  large_center_vars <- grep("^CAN_LISTING_CTR_ID_", names(DF), value = TRUE)
  
  # Step 2: Add small center indicator variable name
  small_center_var <- "CTR_GROUPED"
  
  # Step 3: Append to your existing match_vars
  match_vars <- c("CAN_ACPT_HBC_POS1","CAN_ACPT_HCV_POS1", "CAN_EDUCATION_HS","CAN_EDUCATION_COL", "CAN_MALIG", "CAN_PREV_TX","FEMALE","DIAB_ENTRY", "DIAL_ENTRY", "CAN_AGE_AT_LISTING_51", "CAN_AGE_AT_LISTING_58", "CAN_AGE_AT_LISTING_65","CAN_AGE_AT_LISTING_65up","CAN_BMI_under19","CAN_BMI_1925","CAN_BMI_2630","CAN_BMI_over30",   "DIAL_time_1YRplus", "CAN_DGN_POLY","CAN_DGN_HYPE","CAN_DGN_GLOM")
  
  match_vars <- c(match_vars, large_center_vars)
  match_vars
  print(match_vars)
  
  # Step 7: Run MatchIt
  fml <- as.formula(paste("Z ~", paste(match_vars, collapse = " + ")))
  
  
  # Run the underlying logit model used by MatchIt
  logit_model <- glm(fml, data = DF, family = binomial)
  
  # View summary or time it
  print(summary(logit_model))
  
  

  
  
  if (race != 0){
    match_out <- matchit(fml,
                         data = DF,
                         method = "nearest",
                         replace = FALSE)
  } else {
    match_out <- matchit(fml,
                         data = DF,
                         method = "nearest",
                         exact = as.formula(paste("~", paste(exact_vars, collapse = " + "))),
                         replace = FALSE)
  }
  
  
  # Perform nearest neighbor matching with Mahalanobis distance (nonparametric)
  
  
  # m.out <- matchit(
  #   Z ~ CAN_ACPT_HBC_POS1 + CAN_ACPT_HCV_POS1, 
  #   data = mDat, 
  #   method = "nearest",
  #   exact = exact_vars,
  #   replace = FALSE
  # )
  
  
  
  
  # Check matching result
  summary(match_out)
  
  # Extract matched data
  matched_data <- match.data(match_out)
  
  # Extract matched dataset
  mDat_matched <- match.data(match_out)
  
  # View summary of matching
  print(summary(match_out))
  
  # Recode Z to be consistent with rest of code
  mDat_matched$Z = 1-mDat_matched$Z
  
  mDat = mDat_matched
  
}












#### To be discarded later
# mDat1 <- mDat[(mDat$CAN_ABO == "AB"), ]
# dim(mDat1)
# mDat2 <- mDat[(mDat$CAN_ABO == "O"), ]
# mDat2 <- mDat2[sample(nrow(mDat2), nrow(mDat1)), ]
# mDat <- rbind(mDat1,mDat2)
# mDat <- mDat[sample(nrow(mDat),1000), ]
# obs <- nrow(mDat)
# dim(mDat)
# table(mDat$CAN_ABO)
#############



## Data Preparation #######################################
###########################################################

## Declaring the different durations and indicators:
#   vdurE= time until exit		          
#   vCe = exit indicator =1 if exit observed =0 if censored
#   vdurS = time until treatment,		 
#   vCs = treatment indicator =1 if treatment observed =0 if censored
#   vZ  = 0 if subject to baseline policy regime, = 1 subject to new policy regime
#   mX  = matrix of time 0 covariates
#
##  Warning!! first time period must be t=1 !!   ##



## Include all time t=0 covariates here, do not include intercept, otherwise multicollinearity with duration dependence terms d.
if (cov_incl == 0) {
  if (livingdon == 0 & hcv_pos_don == 0 & cpra == 0 & post2015 ==0){
    mX <- cbind(mDat$CAN_AGE_AT_LISTING_51, mDat$CAN_AGE_AT_LISTING_58, mDat$CAN_AGE_AT_LISTING_65, mDat$CAN_AGE_AT_LISTING_65up )   # Blood type covariate matrix
  } else if (livingdon == 0 & hcv_pos_don == 0 & cpra == 0 & post2015 ==1) {
    mX <- cbind(mDat$CAN_AGE_AT_LISTING_51, mDat$CAN_AGE_AT_LISTING_58, mDat$CAN_AGE_AT_LISTING_65, mDat$CAN_AGE_AT_LISTING_65up, mDat$CAN_PREV_TX, mDat$DIAB_ENTRY, mDat$DIAL_ENTRY, mDat$EPTSlow20)   # Blood type covariate matrix
  } else if (livingdon == 1 & hcv_pos_don == 0 & cpra == 0 & post2015 ==0) {
    mX <- cbind(mDat$CAN_AGE_AT_LISTING_51, mDat$CAN_AGE_AT_LISTING_58, mDat$CAN_AGE_AT_LISTING_65, mDat$CAN_AGE_AT_LISTING_65up )   # Blood type covariate matrix
  } else {
    stop("Error: must set: hcv_pos_don == 0 & cpra == 0.")
  }
} else if (cov_incl == 1) {
  mX <- matrix(0,NROW(mDat),2) # no covariates for analysis, and for calibration of duration dependence terms , 
} else if (cov_incl == 2) {
  mX <- cbind(mDat$CAN_AGE_AT_LISTING_51, mDat$CAN_AGE_AT_LISTING_58, mDat$CAN_AGE_AT_LISTING_65, mDat$CAN_AGE_AT_LISTING_65up, mDat$CAN_PREV_TX, mDat$DIAB_ENTRY , mDat$DIAL_ENTRY, mDat$DIAL_time_1YRplus, mDat$CAN_BMI_1925, mDat$CAN_BMI_2630, mDat$CAN_BMI_over30, mDat$FEMALE,mDat$ASIAN, mDat$BLACK, mDat$OTHER_NONWHITE,  mDat$CAN_MALIG,  mDat$CAN_ACPT_HBC_POS1, mDat$CAN_ACPT_HCV_POS1, mDat$CAN_DGN_POLY, mDat$CAN_DGN_HYPE, mDat$CAN_DGN_GLOM) #  all covariates except education ones
} else {
  mX <- cbind(mDat$CAN_AGE_AT_LISTING_51, mDat$CAN_AGE_AT_LISTING_58, mDat$CAN_AGE_AT_LISTING_65, mDat$CAN_AGE_AT_LISTING_65up, mDat$CAN_PREV_TX, mDat$DIAB_ENTRY ,  mDat$DIAL_ENTRY, mDat$DIAL_time_1YRplus,   mDat$CAN_BMI_1925, mDat$CAN_BMI_2630, mDat$CAN_BMI_over30, mDat$FEMALE,mDat$ASIAN, mDat$BLACK, mDat$OTHER_NONWHITE,  mDat$CAN_MALIG,  mDat$CAN_ACPT_HBC_POS1, mDat$CAN_ACPT_HCV_POS1, mDat$CAN_DGN_POLY, mDat$CAN_DGN_HYPE, mDat$CAN_DGN_GLOM, mDat$CAN_EDUCATION_COL, mDat$CAN_EDUCATION_COLDEG)   # all covariates
}

### Missing values in mX matrix. Not used ##
# mX.imp <- missForest(mX) #impute missing values, using all parameters as default values
# mXframe <- mX.imp$ximp   #check imputed values
# mXframe <- round(mXframe)
# save(mXframe,file="C:\\Users\\Stephen Kastoryano\\Dropbox\\ContDurMA\\Comp code\\mXframeJobArr.Rda")

# load("D:\\Dropbox\\ContDurMA\\Comp code\\mXframeJobArr.Rda")
# mX <- matrix(as.numeric(mXframe),NROW(mX),NCOL(mX))
# mX <- mX[,1:16]
###

## Set duration and censoring variables here:
# <<INPUT>> #
vdurE <- round(mDat$durDE/(ANmonth*30.437))   # Make analysis on ANmonth*30.437 level
vdurE <- vdurE*(vdurE > 0) +  (vdurE == 0)
vCe <- mDat$durDEC
vdurS <- round(mDat$durTX/(ANmonth*30.437))   # Make analysis on ANmonth*30.437 level
vdurS <- vdurS*(vdurS > 0) +  (vdurS == 0)
vCs <- mDat$durTXC 



vZ <- as.numeric(mDat$CAN_ABO == "O")                     # Regime=1 if blood=O




## Clean duration variables and check values 
vCs <- as.numeric(vdurS <= vdurE )* vCs          # adjust treatment indicator if time to treatment censored before exit occurs
vdurS <- vdurS * as.numeric(vdurS <= vdurE ) + vdurE * as.numeric(vdurS > vdurE ) 
vCe <- vCe * as.numeric(vdurE <= Rcens  ) 
vdurE <- vdurE * as.numeric(vdurE <= Rcens  ) + Rcens * as.numeric(vdurE > Rcens  )
vCs <- vCs * as.numeric(vdurS <= Rcens  ) 
vdurS <- vdurS * as.numeric(vdurS <= Rcens  ) + Rcens * as.numeric(vdurS > Rcens  )
vCe <- vCe * (1- vCe * as.numeric(vdurS < vdurE ) * as.numeric(vCs == 0 ))
vdurE <- vdurE - (vdurE - vdurS) * as.numeric(vdurS < vdurE ) * as.numeric(vCs == 0 ) 

# Final data
mDat <- cbind(vdurE,vCe,vdurS,vCs, vZ, mX)
dim(mDat)
mDat <- mDat[complete.cases(mDat), ]  # drop missing rows
dim(mDat)
# !!!!! NOTE: Make sure you hold same observations with and without covariates
dim(mDat)


mDat <- matrix(as.numeric(unlist(mDat)), nrow = nrow(mDat))

vdurE = mDat[,1]
vCe = mDat[,2]
vdurS = mDat[,3]
vCs = mDat[,4]
vZ = mDat[,5]
vTime <- seq(max(vdurE))
obs <- NROW(vdurE)  ## number of observations
mX1 = mX
mX = mDat[,6:NCOL(mDat)]

nrow(mX)

cat("Total observations =" , nrow(mDat))
cat("O observations =" , sum(vZ))
cat("AB observations =" , sum(1-vZ))
cat("O treated observations =" , sum(vZ*vCs))
cat("O non-treated observations =" , sum(vZ*(1-vCs)))
cat("not-O treated observations =" , sum((1-vZ)*vCs))
cat("not-O non-treated observations =" , sum((1-vZ)*(1-vCs)))






# Check values
sum(as.numeric(vdurS > vdurE))   ## NEEDS TO BE 0 !
sum(as.numeric(vdurS < vdurE)*as.numeric(vCs == 0))   ## NEEDS TO BE 0 !

### Exit and treatment densities  ##

# summary(vdurS)
# vdurS1 <- vdurS[as.logical(vCs == 1)]
# #vdurS1 <- vdurS1[as.logical(vdurS1 >1)] # play around with this to get a better idea of shape of density
# plot(density(vdurS1), main="Kidney Transplant Density", xlab="Time")
# quantile(vdurS1, probs=c(0,0.05,0.10,0.15,0.20,0.25,0.30,0.35,0.40,0.45,0.50,0.55,0.60,0.65,0.70,0.75,0.80,0.85,0.90, 0.95, 1))
# summary(vdurE)
# vdurE1 <- vdurE[as.logical(vCe == 1)]
# #vdurE1 <- vdurE1[as.logical(vdurE1 >1)]   # play around with this to get a better idea of shape of density
# plot(density(vdurE1), main="Death Density", xlab="Time")
# quantile(vdurE1, probs=c(0,0.05,0.10,0.15,0.20,0.25,0.30,0.35,0.40,0.45,0.50,0.55,0.60,0.65,0.70,0.75,0.80,0.85,0.90, 0.95, 1))


##  Define cuttoffs of piecewise duration dependence terms based on calibration matching no covariate estimation and KM survival probabilities
dmax <- max(vdurE)

d <- c(6,6,6,6,6,(dmax-30))










## Functions ##############################################
###########################################################


PHlikbuildFn <- function(par,dE,dS,Cs,Z,Durdep) {    # Function: generate time varying part of exit and treatment densities
  # Initialisation of Exit and Treatment hazards
  denshE <- matrix(0,NROW(dE),2)  # col 1 for prob survival, col 2 for hazard
  denshS <- matrix(0,NROW(dE),2)  # col 1 for prob survival, col 2 for hazard
  
  if (Durdep == 0) {
    for (i in 1:NROW(d)) # For every duration dependence of dependent variable fill
    {  
      denshS[,1] <- denshS[,1] + d[i] * exp(par[i] + Z*par[NROW(d)+i]) * as.numeric(dS > d[i]) +
        exp(par[i] + Z*par[NROW(d)+i]) * dS * as.numeric(dS > 0) * as.numeric(dS <= d[i])
      
      denshS[,2] <- denshS[,2] + exp(par[i] + Z*par[NROW(d)+i]) * as.numeric(dS > 0) * as.numeric(dS <= d[i])
      
      denshE[,1] <- denshE[,1] +
        as.numeric(dE > d[i]) *
        (d[i] * exp(par[2*NROW(d)+i] + Z*par[3*NROW(d)+i]) * as.numeric(dS > d[i]) +
           d[i] * exp(par[2*NROW(d)+i] + Z*par[3*NROW(d)+i]) * exp(par[4*NROW(d)+i] + Z*par[5*NROW(d)+i]) * as.numeric(dS <= 0) +
           exp(par[2*NROW(d)+i] + Z*par[3*NROW(d)+i]) * (dS-1  + exp(par[4*NROW(d)+i] + Z*par[5*NROW(d)+i]) * (d[i]-(dS-1))) * 
           as.numeric(dS > 0) * as.numeric(dS <= d[i])) +
        as.numeric(dE > 0) * as.numeric(dE <= d[i]) * 
        (exp(par[2*NROW(d)+i] + Z*par[3*NROW(d)+i]) * 
           (dS-1 +(1-Cs)*as.numeric(dE == dS) + exp(par[4*NROW(d)+i] + Z*par[5*NROW(d)+i]) * (dE - (dS-1 +(1-Cs)*as.numeric(dE == dS)))) * as.numeric(dS > 0) +
           exp(par[2*NROW(d)+i] + Z*par[3*NROW(d)+i]) * exp(par[4*NROW(d)+i] + Z*par[5*NROW(d)+i]) * dE * as.numeric(dS <= 0))  
      
      denshE[,2] <- denshE[,2] + exp(par[2*NROW(d)+i] + Z*par[3*NROW(d)+i]) * as.numeric(dE > 0) * as.numeric(dE <= d[i]) * as.numeric(dS == dE)*(1-Cs) + 
        exp(par[2*NROW(d)+i ]+ Z*par[3*NROW(d)+i]) * exp(par[4*NROW(d)+i] + Z*par[5*NROW(d)+i]) *
        as.numeric(dE > 0) * as.numeric(dE <= d[i]) * (as.numeric(dS < dE) + as.numeric(dS == dE)*Cs)
      
      dE <- dE - d[i]
      dS <- dS - d[i]
    }
  }
  else {
    parZ1s  <- par[(NROW(d)+1)]
    parZ10e <- par[(2*NROW(d)+2)]
    parZ01e <- par[(2*NROW(d)+3)]
    parZ11e <- par[(2*NROW(d)+4)]
    
    # For every duration dependence of dependent variable fill
    for (i in 1:NROW(d)) 
    {  
      denshS[,1] <- denshS[,1] + d[i] * exp(par[i] + Z*parZ1s) * as.numeric(dS > d[i]) +       
        exp(par[i] + Z*parZ1s) * dS * as.numeric(dS > 0) * as.numeric(dS <= d[i])
      
      denshS[,2] <- denshS[,2] + exp(par[i] + Z*parZ1s) * as.numeric(dS > 0) * as.numeric(dS <= d[i])  
      
      denshE[,1] <- denshE[,1] +
        as.numeric(dE > d[i]) *
        (d[i] * exp(par[NROW(d)+1+i] + Z*parZ10e) * as.numeric(dS > d[i]) +
           d[i] * exp(par[NROW(d)+1+i] + Z*parZ10e) * exp(parZ01e + Z*parZ11e) * as.numeric(dS <= 0) +
           exp(par[NROW(d)+1+i] + Z*parZ10e) * (dS-1  + exp(parZ01e + Z*parZ11e) * (d[i]-(dS-1))) * 
           as.numeric(dS > 0) * as.numeric(dS <= d[i])) +
        as.numeric(dE > 0) * as.numeric(dE <= d[i]) * 
        (exp(par[NROW(d)+1+i] + Z*parZ10e) * 
           (dS-1 +(1-Cs)*as.numeric(dE == dS) + exp(parZ01e + Z*parZ11e) * (dE - (dS-1 +(1-Cs)*as.numeric(dE == dS)))) * as.numeric(dS > 0) +
           exp(par[2*NROW(d)+i] + Z*parZ10e) * exp(parZ01e + Z*parZ11e) * dE * as.numeric(dS <= 0))  
      
      denshE[,2] <- denshE[,2] + exp(par[NROW(d)+1+i] + Z*parZ10e) * as.numeric(dE > 0) * as.numeric(dE <= d[i]) * as.numeric(dS == dE)*(1-Cs) + 
        exp(par[NROW(d)+1+i]+ Z*parZ10e) * exp(parZ01e + Z*parZ11e) *
        as.numeric(dE > 0) * as.numeric(dE <= d[i]) * (as.numeric(dS < dE) + as.numeric(dS == dE)*Cs)
      
      dE <- dE - d[i]
      dS <- dS - d[i]
    }
  }
  
  return( cbind(denshE,denshS) )
}  # Function: generate time varying part of exit and treatment densities

CovarEffFn <- function(par,Durdep) {  # Function: Construct covariate effects on hazard
  
  if (sum(mX)==0) {
    mxb <- matrix(0,NROW(mDat),2)
  } else if (ncol(mX1)==1)  {
    if (Durdep == 0) { 
      mxb <- cbind(mX%*%par[(6*NROW(d)+1)],mX%*%par[(6*NROW(d)+2)])
    }
    else {
      mxb <- cbind(mX%*%par[(2*NROW(d)+5)], mX%*%par[(2*NROW(d)+6)])
    }
  } else  {
    if (Durdep == 0) { 
      mxb <- cbind(mX%*%par[(6*NROW(d)+1):(6*NROW(d)+NCOL(mX))],mX%*%par[(6*NROW(d)+NCOL(mX)+1):(6*NROW(d)+2*NCOL(mX))])
    }
    else {
      mxb <- cbind(mX%*%par[(2*NROW(d)+5):(2*NROW(d)+4+NCOL(mX))], mX%*%par[(2*NROW(d)+4+NCOL(mX)+1):(2*NROW(d)+4+2*NCOL(mX))])
    }
  }
  
  
  return ( mxb) 
}  # Function: Construct covariate effects on hazard

PHloglikFn <- function(par) {            # Function: generate loglikelihood function
  
  # Duration until exit, duration until training
  xb <-  CovarEffFn(par,Durdep)
  xbS <- exp(xb[,1])              # Matrix of Explanatory variables affecting treatment
  xbE <- exp(xb[,2])	  # Matrix of Explanatory variables affecting exit  
  
  densh <- PHlikbuildFn(par,vdurE,vdurS,vCs,vZ,Durdep)
  denshE <- densh[,1:2]
  denshS <- densh[,3:4]
  
  
  ## Generating likelihood fnuction to be minimized ##
  lik = (xbE * denshE[,2])^vCe * exp(- xbE * denshE[,1]) * (xbS * denshS[,2])^vCs * exp(- xbS * denshS[,1])
  logl <- log(lik)
  
  return(logl)
}  # Function: generate loglikelihood function

PHlikFn <- function(par) {            # Function: loglikelihood function to be minimized
  logl <- PHloglikFn(par)
  #print("PARAMETER");print(par)
  
  loglik <- -mean(logl)
}  # Function: loglikelihood function to be minimized

derivPHlikFn	<- function(par) {  	 # Function: estimate score matrix for Delta method
  
  scorePH <- matrix(0,obs,NROW(par))
  for (j in 1:NROW(par)) 
  { 
    d0 <- max(c(abs(0.0005*par[j]),0.0005))		# increment in dx of dloglik(x)/dx
    p <- par
    p[j] <- p[j] + d0
    z1 <- PHloglikFn(p)
    p <- par
    p[j] <- p[j] - d0
    z2 <- PHloglikFn(p)
    scorePH[,j] <- ((z1-z2)/(2*d0))
  }
  
  return(scorePH)  # returns obs. x nbr. parameters score matrix
}  # Function: estimate score matrix for Delta method

LikparamFn <- function(CovLik,Durdep) {   # Function: Estimate parameters of hazard model
  
  if (Durdep == 0) { 
    print("## Hazard model parameter estimation with piecewise constant duration dependence ################################")
    print("# par[1:NROW(d)] duration dependence for treatment hazard under Z=0")
    print("# par[(NROW(d)+1):(2*NROW(d))] duration dependence for treatment hazard under Z=1")
    print("# par[(2*NROW(d)+1):(3*NROW(d))] duration dependence for exit hazard under Z=0 and vdurS>vdurE (no treatment)")
    print("# par[(3*NROW(d)+1):(4*NROW(d))] duration dependence for exit hazard under Z=1 and vdurS>vdurE (no treatment)")
    print("# par[(4*NROW(d)+1):(5*NROW(d))] duration dependence for exit hazard under Z=0 and vdurS<=vdurE (treatment)")
    print("# par[(5*NROW(d)+1):(6*NROW(d))] duration dependence for exit hazard under Z=1 and vdurS<=vdurE (treatment)")
    print("# par[(6*NROW(d)+1):(6*NROW(d)+NCOL(mX))] covariate effects on treatment hazard")
    print("# par[(6*NROW(d)+NCOL(mX)+1):(6*NROW(d)+2*NCOL(mX))] covariate effects on exit hazard")
    print("#################################################################################################################")
    
    
    if (sum(mX)==0) {
      par <- matrix(0,6*NROW(d),1)
    } else if (ncol(mX1)==1)  {
      par <- matrix(0,6*NROW(d)+2,1)
    } else  {
      par <- matrix(0,6*NROW(d)+2*NCOL(mX),1)
    }
  }
  else {
    print("## Proportional Hazard model parameter estimation with proportional effect of each randomization on duration dependence ########")
    print("# par[1:NROW(d)] duration dependence for treatment hazard under Z=0")
    print("# par[(NROW(d)+1)] proportional effect of Z=1 on treatment duration dependence relative to Z=0")
    print("# par[(NROW(d)+2):(2*NROW(d)+1)] duration dependence for exit hazard under Z=0 and vdurS>vdurE (no treatment)")
    print("# par[(2*NROW(d)+2)] proportional effect of Z=1 and vdurS>vdurE on exit duration dependence (no treatment)")
    print("# par[(2*NROW(d)+3)] proportional effect of Z=0 and vdurS<=vdurE on exit duration dependence (treatment)")
    print("# par[(2*NROW(d)+4)] proportional effect of Z=1 and vdurS<=vdurE on exit duration dependence (treatment)")
    print("# par[(2*NROW(d)+5):(2*NROW(d)+4+NCOL(mX))] covariate effects on treatment hazard")
    print("# par[(2*NROW(d)+4+NCOL(mX)+1):(2*NROW(d)+4+2*NCOL(mX))] covariate effects on exit hazard")
    print("################################################################################################################################")
    
    
    if (sum(mX)==0) {
      par <- matrix(0,(2*NROW(d)+4),1)
    } else if (ncol(mX1)==1)  {
      par <- matrix(0,(2*NROW(d)+4+2),1)
    } else  {
      par <- matrix(0,(2*NROW(d)+4+2*NCOL(mX)),1)
    }
  }
  
  PHestim <- optim(par,PHlikFn,method = "BFGS", hessian = TRUE)
  par <- PHestim$par
  
  if (CovLik == 0) {        # Variance- Covariance Matrix
    scorePH <- derivPHlikFn(par)
    covPH <- solve(t(scorePH)%*%scorePH) }       # This version may not be possible if matrix to be inverted is singular
  else { 
    Hess <- PHestim$hessian
    covPH <- Hess  }
  sdev <- sqrt(diag(covPH))    # Standard Errors of parameters
  
  # Calculate p-values
  iNull <- 0   # H_0=0 is null hypothesis
  tTest <- (abs(par-iNull))/sdev   # t-test	conditional probability	 	 
  PvalT <- 2*(1-pt(tTest,obs-NROW(par)))
  
  
  print("Output of Log-likelihood Estimation")
  print(c("parameter","stand. dev.", "p-values"))
  print(cbind(par,sdev,PvalT))
  
  return( cbind(par,sdev,covPH) )  # Output is nbr. parameters x 3 matrix of parameter, standard deviation and P-values
}  # Function: Estimate parameters of hazard model

EffectprepFn <- function(par, Durdep, s, tau) { # Function: Generates counterfactual treatment times and unweighted estimates
  
  
  # Duration until exit, duration until training 
  xb <-  CovarEffFn(par,Durdep)
  xbS <- exp(xb[,1])              # Matrix of Explanatory variables affecting treatment
  xbE <- exp(xb[,2])	  # Matrix of Explanatory variables affecting exit 
  
  t <- matrix(tau,obs,1)      # exit time 
  s0 <- matrix(s,obs,1)       # treatment time 
  
  # B0 effects
  Z <- matrix(0,obs,1)  ## Obtain survivors at all t when Z=0
  SurEz0t <- exp(- xbE * PHlikbuildFn(par,t,t,matrix(0,obs,1),Z,Durdep)[,1])      # Z=0 non-treat counterfactual survivor function
  vB0 <- SurEz0t
  
  # BZ effects
  Z <- matrix(1,obs,1)  ## Obtain survivors at all t when Z=1
  SurEz1t <- exp(- xbE * PHlikbuildFn(par,t,t,matrix(0,obs,1),Z,Durdep)[,1]) 
  vBZ <- SurEz1t-SurEz0t
  
  
  # BS effects
  Z <- matrix(0,obs,1)  ## Obtain survivors at all t when Z=0
  SurEz0ts <- exp(- xbE * PHlikbuildFn(par,t,s0,matrix(1,obs,1),Z,Durdep)[,1]) 
  vBS <- SurEz0ts-SurEz0t
  
  
  # BZS effects
  Z <- matrix(1,obs,1)  ## Obtain survivors at all t when Z=0
  SurEz1ts <- exp(- xbE * PHlikbuildFn(par,t,s0,matrix(1,obs,1),Z,Durdep)[,1]) 
  vBZS <- SurEz1ts-SurEz1t - vBS
  
  
  return( cbind(vB0, vBZ, vBS, vBZS))  # Output is obs x 4 matrix of unweighted causal effects
} # Function: Generates counterfactual treatment times and unweighted estimates

MeaneffectFn <- function(par, Durdep, mins, dS, dT, dTmov) {  # Function: Estimate time varying and average effects over treatment time interval [mins:mins+dS]
  
  # Duration until exit, duration until training 
  xb <-  CovarEffFn(par,Durdep)
  xbS <- exp(xb[,1])              # Matrix of Explanatory variables affecting treatment
  xbE <- exp(xb[,2])	  # Matrix of Explanatory variables affecting exit 
  
  Wden <- matrix(0,obs,max(vdurE))
  WdenST <- matrix(0,obs,max(vdurE))
  mDensSh <- matrix(0,obs,2)
  mDensS <- matrix(0,obs,max(vdurE))
  
  for (tt in 1:(mins+dS)) 
  {
    ddS <- matrix(tt,obs,1)
    #mSurEz0[,tt] <- exp(- xbE * PHlikbuildFn(par,ddS,ddS,matrix(0,obs,1),matrix(0,obs,1),Durdep)[,1]) # survival probability for Z=0 under no treatment  
    mDensSh <- PHlikbuildFn(par,ddS,ddS,matrix(1,obs,1),matrix(1,obs,1),Durdep)[,3:4]       # probability (density) of treatment at S=s under Z=1
    mDensS[,tt] <- (xbS * mDensSh[,2]) * exp(- xbS * mDensSh[,1])    # generate probability of treatment at S=s under Z=1 (numerator of weight function)
    Wden[,tt] <- sum(mDensS[,tt])*matrix(1,obs,1)                    # generate denominator of wATThat
  }
  
  wEff <- mDensS/Wden        # weights for effects on potentially treated wATThat
  
  
  mDelta <- matrix(0,4,(dS+1))    # matrix of causal effects for each s for potential treated at S=s
  colnames(mDelta) <- paste('PotTreat at s=',mins:(mins+dS))
  
  
  DeltaAvg <- matrix(0,4,1)
  for (s in mins:(mins+dS)) 
  {
    if (dTmov==0)
    { tau <- dT }
    else
    { tau <- s+dT }
    
    SurEz0 <- exp(- xbE * PHlikbuildFn(par,matrix(s,obs,1),matrix(s,obs,1),matrix(0,obs,1),matrix(0,obs,1),Durdep)[,1])
    
    unweightEst <- EffectprepFn(par, Durdep, s, tau)   # Output is obs x 4 matrix of unweighted causal effects
    mDelta[,(s-mins+1)] <- t(colSums(wEff[,s] * unweightEst)) 
    
    DeltaAvg <- DeltaAvg + colSums(mDensS[,s]/sum(Wden[1,mins:(mins+dS)]) * unweightEst)
    
  }
  colnames(DeltaAvg) <- c("avg. PotTreat")
  
  
  # Generate Intention to Treat: note: this is note a very robust estimation strategy for the ITT effects.
  DeltaITT <- matrix(0,4,1)
  colnames(DeltaITT) <- c("ITT")
  if (mins == 1 )                  # Generate Intention to treat of Z when mins=1
  { 
    mtempZ <- cbind(vdurE,vCe,vdurS,vCs,vZ,xbE)
    mtempZ1 = mtempZ[(mtempZ[,5]==1),]
    mtempZ0 = mtempZ[(mtempZ[,5]==0),]
    
    mtempZ1 = mtempZ1[!(as.numeric(mtempZ1[,1]<dT)*(1-mtempZ1[,1])),]  # remove death censored observations for ITT calculation (bias effects since they censor treatment)
    mtempZ0 = mtempZ0[!(as.numeric(mtempZ0[,1]<dT)*(1-mtempZ0[,1])),]  # remove death censored observations for ITT calculation
    
    
    ddtt1 <- matrix(dT,length(mtempZ1),1)
    ddtt0 <- matrix(dT,length(mtempZ0),1)
    SurEz1 <- exp(- mtempZ1[,6:ncol(mtempZ1)] * PHlikbuildFn(par,ddtt1,mtempZ1[,3],mtempZ1[,4],mtempZ1[,5],Durdep)[,1])
    SurEz0 <- exp(- mtempZ0[,6:ncol(mtempZ0)] * PHlikbuildFn(par,ddtt0,mtempZ0[,3],mtempZ0[,4],mtempZ0[,5],Durdep)[,1])
    DeltaITT[1] <- (sum(SurEz1)/length(SurEz1)-sum(SurEz0)/length(SurEz0))
    
    #DeltaITT[1] <- (sum((vdurE <= dT)*vCe*vZ )/sum(vZ)-sum((vdurE <= dT)*vCe*(1-vZ) )/sum(1-vZ))
  } 
  
  DiffPrTreat <- matrix(0,4,1) 
  DiffPrTreatsum <- 0
  
  # Effect of regime on probability of treatment
  ddtt <- matrix((mins+dS),obs,1)
  ProbTreatz1 <- PHlikbuildFn(par,ddtt,ddtt,matrix(1,obs,1),matrix(1,obs,1),Durdep)[,3]  # generate treatment survival at S=s under Z=1
  ProbTreatz0 <- PHlikbuildFn(par,ddtt,ddtt,matrix(1,obs,1),matrix(0,obs,1),Durdep)[,3]  # generate treatment survival at S=s under Z=0
  DiffPrTreat <-sum(exp(- xbS * ProbTreatz1) - exp(- xbS * ProbTreatz0))/obs
  #print(DiffPrTreat)
  
  
  Effectout <- cbind(DiffPrTreat,DeltaITT,DeltaAvg,mDelta)
  
  return( Effectout )  # return 4 x ((dS+1)+3) matrix of: Regime effect on Treatment + ITT effects + average effects over  [mins:mins+dS] +time varyin effects over  [mins:mins+dS] 
}

EffectFn <- function(par, Durdep, mins, dS, dT, dTmov, varP, plGr)	{ # Function: Estimate standard errors and print results
  
  mEffects <- MeaneffectFn(par, Durdep, mins, dS, dT, dTmov) # return 4 x ((dS+1)+3): Regime effect on Treatment + matrix of ITT effects + average effects over  [mins:mins+dS] +time varyin effects over  [mins:mins+dS] 
  rownames(mEffects) <- c("vB0 (par)", "vBZ (par)",  "vBS (par)", "vBZS (par)")
  print(mEffects) 
  
  #print("Computing Standard Errors: ")
  scoreEff <- array(0,dim=c(NROW(mEffects),NCOL(mEffects),NROW(par)))
  
  
  time1 <- 0
  time2 <- 0
  ptm <- proc.time()  # Start the clock!
  for (j in 1:NROW(par)) 
  { 
    d0 <- max(c(abs(0.0005*par[j]),0.0005))		# increment in dx of dloglik(x)/dx
    p <- par
    p[j] <- p[j] + d0
    z1 <- MeaneffectFn(p, Durdep, mins, dS, dT, dTmov)
    p <- par
    p[j] <- p[j] - d0
    z2 <- MeaneffectFn(p, Durdep, mins, dS, dT, dTmov)
    scoreEff[,,j] <- (z1-z2)/(2*d0)
    
    # print(j)
    # print(scoreEff[,,j])
    
    time1 <- time1+1 ; timeN <-  (proc.time() - ptm);time2 <- (time2*(time1-1) + timeN[3])/time1    # Stop the clock
    ptm <- proc.time()  # Start the clock
    #print("Approximate minutes remaining =");print((NROW(par)-j)*(time2/60))
  }
  
  
  
  mEffse <- matrix(0,NROW(mEffects),NCOL(mEffects))
  mEffpval <- matrix(0,NROW(mEffects),NCOL(mEffects))
  for (k in 1:NCOL(mEffects)) 
  {
    
    
    scoreEff[,k,]%*%varP%*%t(scoreEff[,k,])
    
    varE <- scoreEff[,k,]%*%varP%*%t(scoreEff[,k,])
    mEffse[,k] <- sqrt(diag(varE))
    mEffpval[,k] <- 2*(1-pt(abs(mEffects[,k])/mEffse[,k],obs-NROW(par)))  # Calculate p-values with null hypothesis =0
    
  }
  
  
  rownames(mEffse) <- c("vB0 (se)", "vBZ (se)",  "vBS (se)", "vBZS (se)")
  
  colnames(mEffse) <- colnames(mEffects)
  rownames(mEffpval) <- c("vB0 (Pv)",  "vBZ (Pv)", "vBS (Pv)", "vBZS (Pv)")
  
  colnames(mEffpval) <- colnames(mEffects)
  
  # if (plGr==1 & dS > 0)
  # {
  #   graphEffectsFn(mins,dS, dT,mEffects,mEffse) 
  # }
  #print(mEffects)
  #print(mEffse)
  #print(mEffpval)
  
  mEffprint <- rbind(mEffects[1,],mEffse[1,],mEffpval[1,],mEffects[2,],mEffse[2,],mEffpval[2,],
                     mEffects[3,],mEffse[3,],mEffpval[3,],mEffects[4,],mEffse[4,],mEffpval[4,])
  rownames(mEffprint) <- c("vB0", "    (se)","  [P-val]",
                           "vBZ", "    (se)","  [P-val]", 
                           "vBS", "    (se)","  [P-val]",
                           "vBZS", "    (se)","  [P-val]")
  
  
  
  print("---------------------------------------------------------------------------------------------------------------------")
  print(c("mins=",mins, "mins+dS=", (mins+dS),"dT=",dT, "dTmov=",dTmov))
  print("Effects at each s = "); print( format(round(mEffprint[,4:(dS+4)], 3), nsmall = 3))
  print("Average Regime effect on Treatment Survival at mins+dS = ");print(format(round(cbind(mEffprint[1:3,1]), 3), nsmall = 3))
  print("ITT effect of policy regime Z (this is not rigorously estimated) = ");print(format(round(cbind(mEffprint[1:3,2]), 3), nsmall = 3))
  print("Avg. Effect over support of s = ");print(format(round(cbind(mEffprint[,3]), 3), nsmall = 3))
  
  
  
  
  print("---------------------------------------------------------------------------------------------------------------------")
  
  
  
  return( rbind(mEffects,mEffse,mEffpval) )
}

graphEffectsFn <- function(mins,dS, dT,mEffects,mEffse) 	{
  
  #cbind(DeltaITT,DeltaAvg,DeltaAvgST,mDelta,mDeltaST)
  save(mEffects,file="mEffects.Rda")
  save(mEffse,file="mEffse.Rda")
  
  load("mEffects.Rda") 
  load("mEffse.Rda") 
  
  
  # generate 95% conf. bands and plot effects
  mEf <- -mEffects[c(1,5,8,11:14),(NCOL(mEffects)-(dS)):NCOL(mEffects)]
  mEfse <- mEffse[c(1,5,8,11:14),(NCOL(mEffects)-(dS)):NCOL(mEffects)]
  m95up <- mEf+ 1.96*mEfse
  m95lo <- mEf- 1.96*mEfse
  
  
  
  # get the range for the x and y axis 
  
  vT <- seq(dS+1)+(mins-1)
  plotData0a <- as.data.frame(cbind(vT, mEf[1,1:(1+dS)],m95lo[1,1:(1+dS)],m95up[1,1:(1+dS)]))
  
  print(ggplot(data=plotData0a, aes(x=vT, y=plotData0a[,2], ymin=plotData0a[,3], ymax=plotData0a[,4])) + 
          geom_line() + 
          geom_ribbon(alpha=0.2) + 
          geom_hline(yintercept=0, linetype="dashed", color = "red", size=1) +
          theme_bw() +
          xlab("Time at treatment") + 
          ylab("B0 Effect"))
  
  
  vT <- seq(dS+1)+(mins-1)
  plotData1a <- as.data.frame(cbind(vT, mEf[2,1:(1+dS)],m95lo[2,1:(1+dS)],m95up[2,1:(1+dS)]))
  print(ggplot(data=plotData1a, aes(x=vT, y=plotData1a[,2], ymin=plotData1a[,3], ymax=plotData1a[,4])) + 
          geom_line() + 
          geom_ribbon(alpha=0.2) + 
          geom_hline(yintercept=0, linetype="dashed", color = "red", size=1) +
          theme_bw() +
          xlab("Time at treatment") + 
          ylab("BZ Effect"))
  
  plotData2a <- as.data.frame(cbind(vT, mEf[3,1:(1+dS)],m95lo[3,1:(1+dS)],m95up[3,1:(1+dS)]))
  print(ggplot(data=plotData2a, aes(x=vT, y=plotData2a[,2], ymin=plotData2a[,3], ymax=plotData2a[,4]))  + 
          geom_line() + 
          geom_ribbon(alpha=0.2) + 
          geom_hline(yintercept=0, linetype="dashed", color = "red", size=1) +
          theme_bw() +
          xlab("Time at treatment") + 
          ylab("BS Effect"))
  
  plotData3a <- as.data.frame(cbind(vT, mEf[4,1:(1+dS)],m95lo[4,1:(1+dS)],m95up[4,1:(1+dS)]))
  print(ggplot(data=plotData3a, aes(x=vT, y=plotData3a[,2], ymin=plotData3a[,3], ymax=plotData3a[,4])) + 
          geom_line() + 
          geom_ribbon(alpha=0.2) +
          geom_hline(yintercept=0, linetype="dashed", color = "red", size=1) +
          theme_bw() +
          xlab("Time at treatment") + 
          ylab("BZS Effect") +
          theme(legend.position="top"))
  
  
  
  plotData4a <- as.data.frame(cbind(vT, mEf[5,1:(1+dS)],m95lo[5,1:(1+dS)],m95up[5,1:(1+dS)]))
  print(ggplot(data=plotData4a, aes(x=vT, y=plotData4a[,2], ymin=plotData4a[,3], ymax=plotData4a[,4])) + 
          geom_line() + 
          geom_ribbon(alpha=0.2) +
          geom_hline(yintercept=0, linetype="dashed", color = "red", size=1) +
          theme_bw() +
          xlab("Time at treatment") + 
          ylab("Probability of being never survivor") +
          theme(legend.position="top"))
  
  plotData5a <- as.data.frame(cbind(vT, mEf[6,1:(1+dS)],m95lo[6,1:(1+dS)],m95up[6,1:(1+dS)]))
  print(ggplot(data=plotData5a, aes(x=vT, y=plotData5a[,2], ymin=plotData5a[,3], ymax=plotData5a[,4])) + 
          geom_line() + 
          geom_ribbon(alpha=0.2) +
          geom_hline(yintercept=0, linetype="dashed", color = "red", size=1) +
          theme_bw() +
          xlab("Time at treatment") + 
          ylab("Probability of being complier survivor") +
          theme(legend.position="top"))
  
  
  plotData6a <- as.data.frame(cbind(vT, mEf[4,1:(1+dS)],m95lo[4,1:(1+dS)],m95up[4,1:(1+dS)]))
  print(ggplot(data=plotData6a, aes(x=vT, y=plotData6a[,2], ymin=plotData6a[,3], ymax=plotData6a[,4])) + 
          geom_line() + 
          geom_ribbon(alpha=0.2) +
          theme_bw() +
          xlab("Time at treatment") + 
          ylab("Probability of being always survivor") +
          theme(legend.position="top"))
  
  
  
  
  return(1)
}




## Results Output #############################################
###############################################################

## Estimation Inputs ##
#
# CovLik  -> Covariance of parameters from likelihood estimation: 0 for calculation using outer product score, 1 using hessian.
# Durdep  -> Specification of duration dependence term: 0 piecewise constant for each randomization (policy regime
#            and treatments); 1 common piecewise constant duration dependence with constant 
#            proportional effects for each randomization  (policy regime and treatments)       
# mins    -> Initial period for multiple treatment estimation
# dS      -> Treatment interval over which Mean effect calculated (must be <= to dT-mins)
# dT      -> To define post treatment evaluation Length (along with dTmov)
# dTmov   -> Post treatment evaluation length: 1 if fixed at a constant dT; 0 if reducing with s, ie dT-s, for increasing s (end
#                                              evaluation period FIXED so must have mins+dS <= dT)
# plGr    -> Produce plots of effects: 0 no plot of effects, 1 plot of time varying effects (plots effects on survivingtreated)

# <<INPUT>> #
CovLik <- 1; Durdep <- 0;  

Likpar <- LikparamFn(CovLik,Durdep)  # Prints estimates of likelihood function: parameters, standard deviations, P-Values

# Output of LikparamFn is matrix of parameter, standard deviation and Variance-Covariance matrix

if (blood_types == 0 & cov_incl == 1 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 0){
  save(Likpar,file="LikeParam/Likpar_OvsABnocov.Rda") 
} else if (blood_types == 0 & cov_incl == 1 & post2015 == 0 & livingdon == 0 & calentry == 0  & race == 0 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 1 & p_score_m == 0){
  save(Likpar,file="LikeParam/Likpar_OvsABnocov_Eadj.Rda")
} else if (blood_types == 0 & cov_incl == 0 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 0){
  save(Likpar,file="LikeParam/Likpar_OvsABtreatcov.Rda")
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0  & race == 0 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 0){
  save(Likpar,file="LikeParam/Likpar_OvsAB.Rda")
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0  & race == 0 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 1 & p_score_m == 0){
  save(Likpar,file="LikeParam/Likpar_OvsAB_EadjEDUC.Rda")
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 1 & livingdon == 0 & calentry == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 0){
  save(Likpar,file="LikeParam/Likpar_OvsABpost2015.Rda")
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 1 & calentry == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 0){
  save(Likpar,file="LikeParam/Likpar_OvsABlivdon.Rda")
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 1 & race == 0 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 0){
  save(Likpar,file="LikeParam/Likpar_OvsABcalentry0208.Rda")
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 2 & race == 0 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 0){
  save(Likpar,file="LikeParam/Likpar_OvsABcalentry0814.Rda")
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 1 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 0){
  save(Likpar,file="LikeParam/Likpar_OvsABwhite.Rda")
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 1 & educ_adj == 0 & p_score_m == 0){
  save(Likpar,file="LikeParam/Likpar_OvsAB_HSmin.Rda")
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 4 & educ_adj == 0 & p_score_m == 0){
  save(Likpar,file="LikeParam/Likpar_OvsAB_scollpl.Rda")
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 1 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 1 & educ_adj == 0 & p_score_m == 0){
  save(Likpar,file="LikeParam/Likpar_OvsABwhite_HSmin.Rda")
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 1 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 4 & educ_adj == 0 & p_score_m == 0){
  save(Likpar,file="LikeParam/Likpar_OvsABwhite_scollpl.Rda")
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 2 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 0){
  save(Likpar,file="LikeParam/Likpar_OvsABnonwhite.Rda")
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 0 & biosex == 1 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 0){
  save(Likpar,file="LikeParam/Likpar_OvsABmale.Rda")
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 0 & biosex == 2 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 0){
  save(Likpar,file="LikeParam/Likpar_OvsABfemale.Rda")
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 0 & biosex == 0 & diab_t2 ==1 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 0){
  save(Likpar,file="LikeParam/Likpar_OvsABdabt2Yes.Rda")
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 0 & biosex == 0 & diab_t2 ==2 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 0){
  save(Likpar,file="LikeParam/Likpar_OvsABdiabt2No.Rda")
} else if (blood_types == 1 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 0){
  save(Likpar,file="LikeParam/Likpar_OvsB.Rda")
} else if (blood_types == 2 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 0){
  save(Likpar,file="LikeParam/Likpar_OvsA.Rda")
} else if (blood_types == 0 & cov_incl == 1 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 1){
  save(Likpar,file="LikeParam/Likpar_OvsABnocovPmatc.Rda") 
} else if (blood_types == 0 & cov_incl == 1 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 1 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 1){
  save(Likpar,file="LikeParam/Likpar_OvsABnocovPmatcW.Rda") 
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 1){
  save(Likpar,file="LikeParam/Likpar_OvsABcovPmatc.Rda") 
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 1 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 1){
  save(Likpar,file="LikeParam/Likpar_OvsABcovPmatcW.Rda") 
}


if (blood_types == 0 & cov_incl == 1 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 0){
  load("LikeParam/Likpar_OvsABnocov.Rda") 
} else if (blood_types == 0 & cov_incl == 1 & post2015 == 0 & livingdon == 0 & calentry == 0  & race == 0 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 1 & p_score_m == 0){
  load("LikeParam/Likpar_OvsABnocov_Eadj.Rda")
} else if (blood_types == 0 & cov_incl == 0 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 0){
  load("LikeParam/Likpar_OvsABtreatcov.Rda")
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0  & race == 0 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 0){
  load("LikeParam/Likpar_OvsAB.Rda")
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0  & race == 0 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 1 & p_score_m == 0){
  load("LikeParam/Likpar_OvsAB_EadjEDUC.Rda")
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 1 & livingdon == 0 & calentry == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 0){
  load("LikeParam/Likpar_OvsABpost2015.Rda")
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 1 & calentry == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 0){
  load("LikeParam/Likpar_OvsABlivdon.Rda")
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 1 & race == 0 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 0){
  load("LikeParam/Likpar_OvsABcalentry0208.Rda")
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 2 & race == 0 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 0){
  load("LikeParam/Likpar_OvsABcalentry0814.Rda")
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 1 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 0){
  load("LikeParam/Likpar_OvsABwhite.Rda")
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 1 & educ_adj == 0 & p_score_m == 0){
  load("LikeParam/Likpar_OvsAB_HSmin.Rda")
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 4 & educ_adj == 0 & p_score_m == 0){
  load("LikeParam/Likpar_OvsAB_scollpl.Rda")
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 1 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 1 & educ_adj == 0 & p_score_m == 0){
  load("LikeParam/Likpar_OvsABwhite_HSmin.Rda")
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 1 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 4 & educ_adj == 0 & p_score_m == 0){
  load("LikeParam/Likpar_OvsABwhite_scollpl.Rda")
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 2 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 0){
  load("LikeParam/Likpar_OvsABnonwhite.Rda")
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 0 & biosex == 1 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 0){
  load("LikeParam/Likpar_OvsABmale.Rda")
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 0 & biosex == 2 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 0){
  load("LikeParam/Likpar_OvsABfemale.Rda")
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 0 & biosex == 0 & diab_t2 ==1 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 0){
  load("LikeParam/Likpar_OvsABdabt2Yes.Rda")
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 0 & biosex == 0 & diab_t2 ==2 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 0){
  load("LikeParam/Likpar_OvsABdiabt2No.Rda")
} else if (blood_types == 1 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 0){
  load("LikeParam/Likpar_OvsB.Rda")
} else if (blood_types == 2 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 0){
  load("LikeParam/Likpar_OvsA.Rda")
} else if (blood_types == 0 & cov_incl == 1 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 1){
  load("LikeParam/Likpar_OvsABnocovPmatc.Rda")
} else if (blood_types == 0 & cov_incl == 1 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 1 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 1){
  load("LikeParam/Likpar_OvsABnocovPmatcW.Rda")
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 1){
  load("LikeParam/Likpar_OvsABcovPmatc.Rda")
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 1 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 1){
  load("LikeParam/Likpar_OvsABcovPmatcW.Rda")
}


par <- Likpar[,1:2] 
covPH <- Likpar[,3:NCOL(Likpar)]




###################
## Output Results
###################
outcome = c(12,24,36,48,60)/ANmonth
mOutput0 = matrix(0,12,1)
for (i in outcome){
  mins <- 1; dS <- 0; dT <- i; dTmov <- 0; plGr <- 1;
  mOutput <- EffectFn(par,Durdep, mins, dS, dT, dTmov, covPH, plGr)
  mOutput0 = cbind(mOutput0, mOutput[,3])
}
mOutput0 = mOutput0[,-1]


# Print Maximum Likelihood estimates and standard errors
#Likpar[,1:2]




# Descriptive stats
cat("Total observations =" , nrow(mX))
cat("O treated observations =" , sum(vZ*vCs))
cat("O non-treated observations =" , sum(vZ*(1-vCs)))
cat("not-O treated observations =" , sum((1-vZ)*vCs))
cat("not-O non-treated observations =" , sum((1-vZ)*(1-vCs)))


####################
### PLOT RESULTS
####################


# Create a data frame for plotting
df <- data.frame(
  time = c(12, 24, 36, 48, 60),
  point_estimate = -mOutput0["vBZ (par)", ],
  se = mOutput0["vBZ (se)", ]
)

# Calculate 95% confidence intervals
df$lower_ci <- df$point_estimate - 1.96 * df$se
df$upper_ci <- df$point_estimate + 1.96 * df$se

# Melt the data for ggplot

df_melted <- melt(df, id.vars = "time")



# Plot using ggplot2
p <- ggplot(df, aes(x = factor(time), y = point_estimate)) +
  geom_point(position = position_dodge(width = 0.3)) +
  geom_errorbar(
    aes(ymin = lower_ci, ymax = upper_ci),
    position = position_dodge(width = 0.3),
    width = 0.1,
    color = "black",
    linewidth = 0.7 # Adjust thickness here
  ) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "red") +
  labs(x = "Time on waitlist (months)", y = "Pre-Transplant Effect") +
  scale_x_discrete(labels = c("12", "24", "36", "48", "60")) +
  scale_y_continuous(limits = c(-0.025, 0.15)) +  # Set y-axis limits
  theme_minimal() +
  theme(panel.grid.major.x = element_blank(),
        panel.grid.minor.x = element_blank(),
        plot.background = element_rect(fill = "white")) # Set background to white

# Plot using ggplot2
p <- ggplot(df, aes(x = factor(time), y = point_estimate)) +
  geom_point(position = position_dodge(width = 0.3)) +
  geom_errorbar(
    aes(ymin = lower_ci, ymax = upper_ci),
    position = position_dodge(width = 0.3),
    width = 0.1,
    color = "black",
    linewidth = 0.7 # Adjust thickness here
  ) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "red") +
  labs(x = "Time on waitlist (months)", y = "Pre-Transplant Effect") +
  scale_x_discrete(labels = c("12", "24", "36", "48", "60")) +
  scale_y_continuous(limits = c(-0.15, 0.025)) +  # Set y-axis limits
  theme_minimal() +
  theme(panel.grid.major.x = element_blank(),
        panel.grid.minor.x = element_blank(),
        plot.background = element_rect(fill = "white")) # Set background to white
if (blood_types == 0 & cov_incl == 1 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 0){
  ggsave("Figures/Effect_OvsABnocov.png", plot = p, width = 6, height = 4)  
} else if (blood_types == 0 & cov_incl == 1 & post2015 == 0 & livingdon == 0 & calentry == 0  & race == 0 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 1 & p_score_m == 0){
  ggsave("Figures/Effect_OvsABnocov_Eadj.png", plot = p, width = 6, height = 4)
} else if (blood_types == 0 & cov_incl == 0 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 0){
  ggsave("Figures/Effect_OvsABtreatcov.png", plot = p, width = 6, height = 4) 
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0  & race == 0 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 0){
  ggsave("Figures/Effect_OvsAB.png", plot = p, width = 6, height = 4)
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0  & race == 0 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 1 & p_score_m == 0){
  ggsave("Figures/Effect_OvsAB_EadjEDUC.png", plot = p, width = 6, height = 4)
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 1 & livingdon == 0 & calentry == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 0){
  ggsave("Figures/Effect_OvsABpost2015.png", plot = p, width = 6, height = 4)
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 1 & calentry == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 0){
  ggsave("Figures/Effect_OvsABlivdon.png", plot = p, width = 6, height = 4)
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 1 & race == 0 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 0){
  ggsave("Figures/Effect_OvsABcalentry0208.png", plot = p, width = 6, height = 4)
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 2 & race == 0 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 0){
  ggsave("Figures/Effect_OvsABcalentry0814.png", plot = p, width = 6, height = 4)
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 1 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 0){
  ggsave("Figures/Effect_OvsABwhite.png", plot = p, width = 6, height = 4)
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 1 & educ_adj == 0 & p_score_m == 0){
  ggsave("Figures/Effect_OvsAB_HSmin.png", plot = p, width = 6, height = 4)
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 4 & educ_adj == 0 & p_score_m == 0){
  ggsave("Figures/Effect_OvsAB_scollpl.png", plot = p, width = 6, height = 4)
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 1 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 1 & educ_adj == 0 & p_score_m == 0){
  ggsave("Figures/Effect_OvsABwhite_HSmin.png", plot = p, width = 6, height = 4)
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 1 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 4 & educ_adj == 0 & p_score_m == 0){
  ggsave("Figures/Effect_OvsABwhite_scollpl.png", plot = p, width = 6, height = 4)
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 2 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 0){
  ggsave("Figures/Effect_OvsABnonwhite.png", plot = p, width = 6, height = 4)
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 0 & biosex == 1 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 0){
  ggsave("Figures/Effect_OvsABmale.png", plot = p, width = 6, height = 4)
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 0 & biosex == 2 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 0){
  ggsave("Figures/Effect_OvsABfemale.png", plot = p, width = 6, height = 4)
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 0 & biosex == 0 & diab_t2 ==1 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 0){
  ggsave("Figures/Effect_OvsABdabt2Yes.png", plot = p, width = 6, height = 4)
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 0 & biosex == 0 & diab_t2 ==2 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 0){
  ggsave("Figures/Effect_OvsABdiabt2No.png", plot = p, width = 6, height = 4)
} else if (blood_types == 1 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 1 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 0){
  ggsave("Figures/Effect_OvsBwhite.png", plot = p, width = 6, height = 4)
} else if (blood_types == 2 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 1 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 0){
  ggsave("Figures/Effect_OvsAwhite.png", plot = p, width = 6, height = 4)
} else if (blood_types == 0 & cov_incl == 1 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 1){
  ggsave("Figures/Effect_OvsABnocovPmatc.png", plot = p, width = 6, height = 4)  
} else if (blood_types == 0 & cov_incl == 1 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 1 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 1){
  ggsave("Figures/Effect_OvsABnocovPmatcW.png", plot = p, width = 6, height = 4)  
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 1){
  ggsave("Figures/Effect_OvsABcovPmatc.png", plot = p, width = 6, height = 4)  
} else if (blood_types == 0 & cov_incl == 3 & post2015 == 0 & livingdon == 0 & calentry == 0 & race == 1 & biosex == 0 & diab_t2 ==0 & hcv_pos_don == 0 & cpra == 0 & educD == 0 & educ_adj == 0 & p_score_m == 1){
  ggsave("Figures/Effect_OvsABcovPmatcW.png", plot = p, width = 6, height = 4)  
}



cat("Total observations =" , nrow(mX))
cat("O treated observations =" , sum(vZ*vCs))
cat("O non-treated observations =" , sum(vZ*(1-vCs)))
cat("not-O treated observations =" , sum((1-vZ)*vCs))
cat("not-O non-treated observations =" , sum((1-vZ)*(1-vCs)))





