########################################################################
##  Paper Title: Causally Evaluating Selection: Biological, 
##               Behavioral and Institutional Effects on
##               the Kidney Transplant Waitlist
#####
##                                                                    
##  Purpose: Estimating Pre-transplant Effects with doubly robust
##          and other Machine Learning approaches
##
##  Reproducibility Information: see end of code for environment info 
##                                                                    
##  Author: Stephen Kastoryano                                        
##  Date  : 30 March 2025                                                 
##                                                      
##           
##  input:  "DF_pre.RData", "DF_post.RData", "DF_all.RData" from KidneyExp_clean
##          
##
##  output: Figure XX and Table YY in Appendix ZZ
##           
##
##  Instructions: Run as is  
##
##                                                                    
######################################################################################  


library("foreign")
library("dplyr")
library("tidyr")
library("ggplot2")    
library("lmtest")
library("sandwich")
library("clubSandwich")
library(survival)
library(randomForestSRC)
library(survivalmodels)
library(keras)
library(tensorflow)
library(glmnet)
library(DoubleML)
library(mlr3)
library(mlr3learners)
library(fastDummies)
library(nnet)


library(reticulate)


# Set Python to the newly installed version
#use_python("C:/Users/skast/AppData/Local/Programs/Python/Python311", required = TRUE) 
use_python("C:/Users/skast/AppData/Local/Programs/Python/Python311/python.exe", required = TRUE)



py_config()

#system("pip install numpy torch scikit-learn h5py")
#system("pip install numpy==1.23.5")

py_config()


system("python -m venv myenv")
system("myenv\\Scripts\\activate")  # On Windows
# Then install pycox inside the virtual environment
system("pip install pycox numpy torch scikit-learn h5py tensorflow")


library(reticulate)
py_config()



setwd("C:/Users/skast/Dropbox/ContDurMA/CompCode 2023")

set.seed(5327456)




####################
### LOAD DATA, DEFINE SAMPLE
####################



post2015 = 0   # Equal to 0 for pre-2015 reform analysis, 1 for post-2015 reform analysis, 2 for pre- and post-2015 figures
blood_types = 0   # Equal to 0 for AB vs O type, 1 for B vs O type, 2 for A vs O type, 3 for all
livingdon = 0     # 0 for baseline without living donor transplant candidates,Equal to 1 if we want to keep living donor transplants in data
calentry = 0      # 0 for baseline 2002-6-01 -- 2014-12-01, 1 for 2002-6-01 -- 2008-9-01, 2 for 2008-9-01 -- 2014-12-01. Ensures 6 years and 3 months of calendar entries for each 
covadj = 0        # 0 for baseline, 1 for specification with additional adjustments on covariates to check small differences in balance are not driving selection on observables  
race = 0          # 0 for baseline all, 1 for white, 2 for non-white
biosex = 0        # 0 for baseline all, 1 for male, 2 for female
diab_ent = 0       # 0 for baseline all, 1 for diabetes at entry, 2 no diabetes at entry
diab_t2 = 0       # 0 for baseline all, 1 for Type 2 diabetes as main reason for transplant, 2 for not Type 2 diabetes as main reason for transplant
hcv_pos_don = 0   # 0 is baseline not removing candidates who would accept HCV positive donor kidney (very unhealthy kidney), 1 if removing
cpra = 0          # 0 is baseline removing candidates who have CPRA above 0, 1 if all CPRA included
dial <- 0     # 0 for baseline controlling for dialysis status and time on dialysis at entry and imputing 'no dialysis' for NAs, 1 not controlling for dialysis status and  and time on dialysis at entry
educ <- 0     # 0 for baseline not controlling for education, 1 includes education variables but drops over 10% of sample as well
educD <- 0         # 0 is baseline including everyone, 1 includes HS degree or less, 2 includes 'some college', 3 includes at least a college degree   


##  Load files 
if (post2015 == 0){
  if (calentry == 0) {
    load("DF_pre.RData")
  } else if (calentry == 1) {
    load("DF_pre0208.RData")  
  } else {
    load("DF_pre0814.RData") 
  }
} else if (post2015 == 1){
  load("DF_post.RData")
} else {
  load("DF_all.RData") 
}



# Define for Type 2 diabetes as main reason for transplant
DF$diab_type2 = as.numeric(DF$CAN_DGN == 3070 ) # 1 if if Type 2 diabetes is main reason for transplant

table(DF$CAN_DGN)

table(DF$DIAL_ENTRY_time)


table(DF$DIAL_ENTRY)  # On Dialysis when entering the waitlist
sum(is.na(DF$DIAL_ENTRY)) 


## EPTS score AT ENTRY! for new kidney allocation analysis at t=1
if (post2015 >= 1){
  if (dial == 0){
    DF$DIAL_ENTRY_time_yr = round(DF$DIAL_ENTRY_time/ 365.25)
    DF$DIAL_ENTRY_time_yr[is.na(DF$DIAL_ENTRY_time_yr)] <- 0
    DF$DIAL_ENTRY[is.na(DF$DIAL_ENTRY)] <- 0
    DF$EPTSscore = 0.047 * max(DF$CAN_AGE_AT_LISTING - 25, 0) - 0.015 * DF$DIAB_ENTRY * max(DF$CAN_AGE_AT_LISTING - 25, 0) +
      0.398 * DF$CAN_PREV_TX - 0.237 * DF$DIAB_ENTRY * DF$CAN_PREV_TX +
      0.315 * log(DF$DIAL_ENTRY_time_yr + 1) - 0.099 * DF$DIAB_ENTRY * log(DF$DIAL_ENTRY_time_yr + 1) +
      0.130 * (1-DF$DIAL_ENTRY) - 0.348 * DF$DIAB_ENTRY * (1-DF$DIAL_ENTRY) + 1.262 * DF$DIAB_ENTRY
  }else{
    DF$EPTSscore = 0.047 * max(DF$CAN_AGE_AT_LISTING - 25, 0) - 0.015 * DF$DIAB_ENTRY * max(DF$CAN_AGE_AT_LISTING - 25, 0) +
      0.398 * DF$CAN_PREV_TX - 0.237 * DF$DIAB_ENTRY * DF$CAN_PREV_TX 
  }
  
  
  threshold <- quantile(DF$EPTSscore, 0.2)
  # Create a new variable DF$EPTSlow20 which represents prioritised candidates
  DF$EPTSlow20 <- ifelse(DF$EPTSscore <= threshold, 1, 0)
  
}


####################
### DATA SELECTION
####################


## Select blood types for comparison

if (blood_types == 0) {  # AB vs O
  # These lines must be include for AB vs. O analysis
  DF = DF[(DF$CAN_ABO != "A"),]   # Drop type A blood types 
  DF = DF[(DF$CAN_ABO != "B"),]   # Drop type B blood types 
  print(table(DF$CAN_ABO))
} else if (blood_types == 1) {  # B vs O
  DF = DF[(DF$CAN_ABO != "A"),]   # Drop type A blood types 
  DF = DF[(DF$CAN_ABO != "AB"),]   # Drop type AB blood types 
  print(table(DF$CAN_ABO))
} else if (blood_types == 2) {  # A vs O
  DF = DF[(DF$CAN_ABO != "B"),]   # Drop type B blood types 
  DF = DF[(DF$CAN_ABO != "AB"),]   # Drop type AB blood types 
  print(table(DF$CAN_ABO))
}


## Include living donors or not
if (livingdon == 0){
  DF =DF[(DF$DON_TY !="L"),]   # remove anyone who received kidney from living donor
}
nrow(DF)



if (covadj == 1){
  ### This code ensures that the distribution of health related variables are balanced in their mean
  ## It is ad hoc, in the sense that this code should not be replicated for other subsamples than the baseline one (all intial variables set to 0 besides 'covadj = 1')
  set.seed(3263)
  
  # Adjust for potential differences in age
  
  # Set the parameter to control the share of rows to drop
  param <- 0.152  # Adjust this value based on your preference
  # Calculate the probability of dropping each row based on CAN_AGE_AT_LISTING
  prob_drop <- 1-pnorm(DF$CAN_AGE_AT_LISTING, mean = mean(DF$CAN_AGE_AT_LISTING), sd = sd(DF$CAN_AGE_AT_LISTING))
  # Adjust the probability based on the parameter
  prob_drop <- prob_drop * param
  # Create a logical vector indicating whether each row of "not AB" should be dropped
  rows_to_drop <- DF$CAN_ABO != "AB" & runif(nrow(DF)) < prob_drop
  # Create the modified data frame by dropping the selected rows
  df_modified <- DF[!rows_to_drop, ]
  
  # Adjust for potential differences in diabetes 
  
  # Set the parameter to control the share of rows to drop
  param <- 0.045  # Adjust this value based on your preference
  # Calculate the probability of dropping each row based on CAN_AGE_AT_LISTING
  prob_drop <- 1-pnorm(df_modified$DIAB_ENTRY, mean = mean(df_modified$DIAB_ENTRY), sd = sd(df_modified$DIAB_ENTRY))
  # Adjust the probability based on the parameter
  prob_drop <- prob_drop * param
  # Create a logical vector indicating whether each row of "not AB" should be dropped
  rows_to_drop <- df_modified$CAN_ABO != "AB" & runif(nrow(df_modified)) < prob_drop
  # Create the modified data frame by dropping the selected rows
  df_modified <- df_modified[!rows_to_drop, ]
  
  
  # Adjust for potential differences in whether person received previous transplant 
  
  # Set the parameter to control the share of rows to drop
  param <- 0.29  # Adjust this value based on your preference
  # Calculate the probability of dropping each row based on CAN_AGE_AT_LISTING
  prob_drop <- 1-pnorm(df_modified$CAN_PREV_TX, mean = mean(df_modified$CAN_PREV_TX), sd = sd(df_modified$CAN_PREV_TX))
  # Adjust the probability based on the parameter
  prob_drop <- prob_drop * param
  # Create a logical vector indicating whether each row of "not AB" should be dropped
  rows_to_drop <- df_modified$CAN_ABO != "AB" & runif(nrow(df_modified)) < prob_drop
  # Create the modified data frame by dropping the selected rows
  df_modified <- df_modified[!rows_to_drop, ]
  
  # Check balance
  mean(df_modified$CAN_AGE_AT_LISTING[(df_modified$CAN_ABO == 'AB')], na.rm = TRUE)
  mean(df_modified$CAN_AGE_AT_LISTING[(df_modified$CAN_ABO != 'AB')], na.rm = TRUE)
  
  mean(df_modified$DIAB_ENTRY[(df_modified$CAN_ABO == 'AB')], na.rm = TRUE)
  mean(df_modified$DIAB_ENTRY[(df_modified$CAN_ABO != 'AB')], na.rm = TRUE)
  
  mean(df_modified$CAN_MALIG[(df_modified$CAN_ABO == 'AB')], na.rm = TRUE)
  mean(df_modified$CAN_MALIG[(df_modified$CAN_ABO != 'AB')], na.rm = TRUE)
  
  mean(df_modified$CAN_PREV_TX[(df_modified$CAN_ABO == 'AB')], na.rm = TRUE)
  mean(df_modified$CAN_PREV_TX[(df_modified$CAN_ABO != 'AB')], na.rm = TRUE)
  
  
  sum(DF$CAN_ABO == 'AB')
  sum(df_modified$CAN_ABO == 'AB')
  sum(DF$CAN_ABO != 'AB')
  sum(df_modified$CAN_ABO != 'AB')
  
  DF = df_modified
  
}
nrow(DF)

mean(DF$CAN_AGE_AT_LISTING[(DF$CAN_ABO == 'AB')], na.rm = TRUE)
mean(DF$CAN_AGE_AT_LISTING[(DF$CAN_ABO != 'AB')], na.rm = TRUE)


if (race == 1){
  DF = DF[(DF$CAN_RACE_SRTR == "WHITE"),]
} else if (race == 2){
  DF = DF[(DF$CAN_RACE_SRTR != "WHITE"),]
}
nrow(DF)


if (biosex == 1){
  DF = DF[(DF$FEMALE == 0),]
} else if (biosex == 2){
  DF = DF[(DF$FEMALE == 1),]
}

if (diab_ent == 1){
  DF = DF[(DF$DIAB_ENTRY == 1 ),]
} else if (diab_ent == 2){
  DF = DF[(DF$DIAB_ENTRY == 0 ),]
}

if (diab_t2 == 1){
  DF = DF[(DF$CAN_DGN == 3070 ),]
} else if (diab_t2 == 2){
  DF = DF[(DF$CAN_DGN != 3070 ),]
}


if (educD == 1) {  # includes HS degree or less
  DF = DF[!is.na(DF$CAN_EDUCATION_HS),]
  DF = DF[(DF$CAN_EDUCATION_HS == 1),]
} else if (educD == 2) {  # includes 'some college'
  DF = DF[!is.na(DF$CAN_EDUCATION_COL),]
  DF = DF[(DF$CAN_EDUCATION_COL == 1),] 
} else if (educD == 3) {  # includes at least a college degree
  DF = DF[!is.na(DF$CAN_EDUCATION_COLDEG),]
  DF = DF[(DF$CAN_EDUCATION_COLDEG == 1),]
}



if (cpra == 0) {
  DF <- DF[DF$CANHX_CPRA == 0, ]   # only keep CPRA == 0 people. So excluding all individuals with antibodies
}




table(DF$DIAB_ENTRY)
sum(is.na(DF$DIAB_ENTRY))

table(DF$diab_type2)
sum(is.na(DF$diab_type2))


table(DF$CAN_DGN)
table(DF$CAN_DIAB_TY)


DF$vdurE <- round(DF$durDE/30.437)   # Make analysis on monthly level
DF$vdurE <- DF$vdurE*(DF$vdurE > 0) +  (DF$vdurE == 0)
DF$vCe <- DF$durDEC
DF$vdurS <- round(DF$durTX/30.437)   # Make analysis on monthly level
DF$vdurS <- DF$vdurS*(DF$vdurS > 0) +  (DF$vdurS == 0)
DF$vCs <- DF$durTXC 

DF$vCs <- as.numeric(DF$vdurS <= DF$vdurE )* DF$vCs          # adjust treatment indicator if time to treatment censored before exit occurs
DF$vdurS <- DF$vdurS * as.numeric(DF$vdurS <= DF$vdurE ) + DF$vdurE * as.numeric(DF$vdurS > DF$vdurE ) 



# The following is to avoid leverage of right tail observations
Rcens = 120 # This number is just to make the pre- and post- 2015 analysis completely comparable

DF$vCe <- DF$vCe * as.numeric(DF$vdurE <= Rcens  ) 
DF$vdurE <- DF$vdurE * as.numeric(DF$vdurE <= Rcens  ) + Rcens * as.numeric(DF$vdurE > Rcens  )
DF$vCs <- DF$vCs * as.numeric(DF$vdurS <= Rcens  ) 
DF$vdurS <- DF$vdurS * as.numeric(DF$vdurS <= Rcens  ) + Rcens * as.numeric(DF$vdurS > Rcens  )
DF$vCe <- DF$vCe * (1- DF$vCe * as.numeric(DF$vdurS < DF$vdurE ) * as.numeric(DF$vCs == 0 ))
DF$vdurE <- DF$vdurE - (DF$vdurE - DF$vdurS) * as.numeric(DF$vdurS < DF$vdurE ) * as.numeric(DF$vCs == 0 ) 



sum(DF$vCe)





#######################################
## Effect of Blood type on pre-transplant survival
## censoring survival at moment of transplant for transplanted
## Comparing OLS no covariates, with baseline covariates, with extensive covariates, with doubly robust estimation
#######################################



# DF2 = DF[((DF$vCs == 1) == 1),]  # Select treated at t=1


DF2 = DF
DF2$Z <- as.numeric(DF2$CAN_ABO == "O")   # define regime


table(DF2$CAN_ABO)


# Candidate:  
#   main: c("DIAL_ENTRY_time", "CAN_BMI","CAN_DGN_POLY","CAN_DGN_HYPE","CAN_DGN_GLOM") 
#   potential bad control c("CAN_FUNCTN_STATn") # Note this is not used in Wolfe study. education variable should be added to this 
#   extra with high share missing: c("CAN_TOT_ALBUMIN", "CAN_TOT_ALBUMIN_miss")

# Donor characteristics:
#   main: c("DON_AGE","DON_WGT_KG","DON_CAD_DON_COD_ANOX","DON_CAD_DON_COD_CERE","DON_CAD_DON_COD_HEAD","DON_CAD_DON_COD_TUMO","DON_CAD_DON_COD_OTHE") 


# Candidate-donor match:
#   main: c("REC_A_MM_EQUIV_TX0", "REC_A_MM_EQUIV_TX1", "REC_A_MM_EQUIV_TX2", "REC_B_MM_EQUIV_TX0","REC_B_MM_EQUIV_TX1","REC_B_MM_EQUIV_TX2","REC_DR_MM_EQUIV_TX0","REC_DR_MM_EQUIV_TX1","REC_DR_MM_EQUIV_TX2","DON_ORG_SHARED") 



DF2 = DF2[,c("vdurE","vCe","vdurS","vCs","Z","CAN_AGE_AT_LISTING_35up","CAN_AGE_AT_LISTING_51",
             "CAN_AGE_AT_LISTING_58", "CAN_AGE_AT_LISTING_65", "CAN_BMI_1925", "CAN_BMI_2630", "CAN_BMI_over30",
             "FEMALE","CAN_PREV_TX", "DIAB_ENTRY","DIAL_ENTRY","DIAL_ENTRY_time", "DIAL_time_1YRplus","ASIAN", "BLACK", "OTHER_NONWHITE", "CAN_MALIG", 
             "CAN_ACPT_HBC_POS1", "CAN_ACPT_HCV_POS1", "CAN_BMI","CAN_DGN_POLY","CAN_DGN_HYPE","CAN_DGN_GLOM",
             'WHITE','CAN_EDUCATION_HS','CAN_EDUCATION_COL','CAN_EDUCATION_COLDEG',"CAN_LISTING_CTR_ID")]
#DF2 =  dummy_cols(DF2, select_columns = "CAN_LISTING_CTR_ID", remove_first_dummy = FALSE)


# Step 3: Collapse centers with <400 obs
center_counts <- table(DF2$CAN_LISTING_CTR_ID)
large_centers <- names(center_counts[center_counts >= 400])

# Step 3a: Create grouping variable
DF2$CTR_GROUPED <- ifelse(DF2$CAN_LISTING_CTR_ID %in% large_centers,
                         NA, "OTHER")  # NA for large centers, "OTHER" for small
DF2$CTR_GROUPED <- factor(DF2$CTR_GROUPED, exclude = NULL)  # keep NAs

# Step 3b: Dummy code ONLY large centers
DF2_large_only <- DF2[DF2$CAN_LISTING_CTR_ID %in% large_centers, , drop = FALSE]
DF2_dummies <- dummy_cols(DF2, select_columns = "CAN_LISTING_CTR_ID", remove_first_dummy = FALSE)
keep_dummy_names <- paste0("CAN_LISTING_CTR_ID_", large_centers)
dummy_cols_to_keep <- keep_dummy_names[keep_dummy_names %in% names(DF2_dummies)]
DF2 <- cbind(DF2, DF2_dummies[, dummy_cols_to_keep, drop = FALSE])

# Step 3c: Remove all other `CAN_LISTING_CTR_ID_` columns if any were auto-added
DF2 <- DF2[, !grepl("^CAN_LISTING_CTR_ID_", names(DF2)) | names(DF2) %in% dummy_cols_to_keep]

# Step 4: Drop original center ID
DF2$CAN_LISTING_CTR_ID <- NULL

DF2$CTR_GROUPED <- ifelse(DF2$CTR_GROUPED == "OTHER", 1, 0)



if (post2015 >= 1) {
  DF2 <- cbind(DF2,EPTSlow20 = DF$EPTSlow20)
}

cat("Total observations =" , nrow(DF2))

### Imputing missing values on the X (this matters as dropping them shifts results)
## It doesn't make much of a difference in the results which I use (it matters more that I just don't drop the variables), but might in your application
## 1. imputing mode (fast)
impute_mode <- function(df) {
  for (col in names(df)) {
    if (any(is.na(df[[col]]))) {  # Check if column has missing values
      mode_val <- names(sort(table(df[[col]]), decreasing = TRUE))[1]  # Get mode
      df[[col]][is.na(df[[col]])] <- mode_val  # Impute mode
    }
  }
  return(df)
}

DF2 <- impute_mode(DF2)  # Apply function to your dataframe
DF2[] <- lapply(DF2, function(x) {
  if (is.character(x)) as.numeric(x) else x
})

## 2. Tree based approach (takes time)
# DF2 <- mice(DF2, method = "cart", m = 5)  # Uses Classification and Regression Trees (CART)

nrow(DF2)
DF4 <- DF2[complete.cases(DF2), ]  # drop missing rows
nrow(DF4)


cat("Total observations =" , nrow(DF4))
cat("O observations =" , sum(DF4$Z))
cat("AB observations =" , sum(1-DF4$Z))
cat("O treated observations =" , sum(DF4$Z * DF4$vCs))
cat("O non-treated observations =" , sum(DF4$Z * (1- DF4$vCs)))
cat("not-O treated observations =" , sum((1-DF4$Z) * DF4$vCs))
cat("not-O non-treated observations =" , sum((1-DF4$Z)*(1- DF4$vCs)))




#######################################
## Effect of Blood type on pre-transplant survival
## censoring survival at moment of transplant for transplanted
## Comparing OLS no covariates, with baseline covariates, with extensive covariates, with doubly robust estimation
#######################################

# Initialize an empty data frame to store results
survival_results_df <- data.frame()
year_incr = 12
Rcens1 <- seq(year_incr, 60, by = year_incr)
for (rr in Rcens1) {
  DF3 <- DF4
  
  
  # Need following adjustment to impose censoring at moment of transplant
  DF3$vCe = DF3$vCe* as.numeric(DF3$vCs == 0) 
  DF3$vdurE = DF3$vdurE* as.numeric(DF3$vCs == 0) + DF3$vdurS* as.numeric(DF3$vCs == 1)
  
  DF3 <- DF3[!(as.numeric(DF3$vdurE < rr) + as.numeric(DF3$vCe == 0) == 2), ]  # remove competing risk censored outcomes
  DF3$Y <- as.numeric(DF3$vdurE >= rr) 
  
  ### with no covariates  
  sTreat <- "Z"
  streatX <- c(sTreat)

  
  B_ols_fn <- lm(as.formula(paste("Y ~ ", paste(streatX, collapse = "+"))),  data = DF3)
  print("B_ols_fn")
  # Store the results in the data frame
  result <- data.frame(
    Time = rr,
    Estimate = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[2, "Estimate"],
    Std_Error = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[2, "Std. Error"],
    specif = "without cov"
  )
  
  
  ### with base covariates
  survival_results_df <- rbind(survival_results_df, result)
  if (post2015 == 0){
    sX <- c("CAN_AGE_AT_LISTING_35up")
  }else{
    
    sX <- c("EPTSlow20")
  }
  
  sTreat <- "Z"
  streatX <- c(sTreat, sX)
  B_ols_fn <- lm(as.formula(paste("Y ~ ", paste(streatX, collapse = "+"))),   data = DF3)
  print(nrow(DF3))
  print(sum(complete.cases(DF3[,sX])))
  
  
  # Store the results in the data frame
  result <- data.frame(
    Time = rr,
    Estimate = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[2, "Estimate"],
    Std_Error = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[2, "Std. Error"],
    specif = "with base cov."
  )
  
  survival_results_df <- rbind(survival_results_df, result)
  

  
  
  ### double ML
  DF3 <- DF4[complete.cases(DF4), ]  # drop missing rows
  DF3$vCe = DF3$vCe* as.numeric(DF3$vCs == 0)
  DF3$vdurE = DF3$vdurE* as.numeric(DF3$vCs == 0) + DF3$vdurS* as.numeric(DF3$vCs == 1)
  
  DF3 <- DF3[!(as.numeric(DF3$vdurE < rr) + as.numeric(DF3$vCe == 0) == 2), ]  # remove competing risk censored outcomes
  DF3$Y <- as.numeric(DF3$vdurE >= rr)
  
  
  sX <- colnames(DF3[,6:(ncol(DF3)-1 - 2*(length(Rcens1)+2))])
  sX <- c("CAN_AGE_AT_LISTING_35up","CAN_AGE_AT_LISTING_51",
          "CAN_AGE_AT_LISTING_58", "CAN_AGE_AT_LISTING_65", "CAN_BMI_1925", "CAN_BMI_2630", "CAN_BMI_over30",
          "FEMALE","CAN_PREV_TX", "DIAB_ENTRY","DIAL_ENTRY","DIAL_ENTRY_time", "DIAL_time_1YRplus","ASIAN", "BLACK", "OTHER_NONWHITE", "CAN_MALIG",
          "CAN_ACPT_HBC_POS1",  "CAN_BMI","CAN_DGN_POLY","CAN_DGN_HYPE","CAN_DGN_GLOM",
          'CAN_EDUCATION_HS','CAN_EDUCATION_COL','CAN_EDUCATION_COLDEG')
  
  # Step 1: Find all large center dummy variable names in DF3
  large_center_vars <- grep("^CAN_LISTING_CTR_ID_", names(DF3), value = TRUE)
  
  # Step 2: Add small center indicator variable name
  small_center_var <- "CTR_GROUPED"
  
  # Step 3: Append to your existing match_vars

  sX <- c(sX, large_center_vars, small_center_var)
  sX

  
  DF3 = DF3 
  
  # Define the data backend
  dml_data <- DoubleMLData$new(data = DF3, y_col = "Y", d_cols = "Z", x_cols = sX)
  
  # Define ML learners
  learner_lasso <- lrn("regr.cv_glmnet")  # LASSO for Y
  learner_ridge <- lrn("regr.cv_glmnet")  # Ridge for D (can use LASSO too)
  
  
  # Define DML model
  dml_plr <- DoubleMLPLR$new(dml_data, ml_l = learner_lasso, ml_m = learner_ridge,
                             dml_procedure = "dml2",
                             score = "partialling out" )
  
  # Estimate the model
  dml_plr$fit()
  
  # Extract treatment effect and heteroskedasticity-robust standard error
  coef_estimate <- dml_plr$coef
  se_robust <- dml_plr$se
  
  result <- data.frame(
    Time = rr,
    Estimate =dml_plr$coef,
    Std_Error = dml_plr$se,
    specif = "double ML"
  )
  
  survival_results_df <- rbind(survival_results_df, result)
  
  print(survival_results_df)
}

# Print the resulting data frame
print(survival_results_df)


# Assuming you have a data frame named 'survival_results_df' containing your survival analysis results
# Make sure 'size', 'effect', 'effect_se', and 'specification' columns exist in the data frame

pd <- 3
print(ggplot(survival_results_df,
             aes(x     = Time,
                 y     = -Estimate,
                 color = specif)) +
        geom_point(shape = 15,
                   size  = 4,
                   position = position_dodge(pd)) +  # Use position_dodge with the desired offset
        geom_errorbar(aes(ymin  = -Estimate - 1.96*Std_Error,
                          ymax  = -Estimate + 1.96*Std_Error),
                      width = 2,
                      size  = 1,
                      position = position_dodge(pd)) +  # Use the same offset for error bars
        theme_bw() +
        theme(text = element_text(size = 20),
              panel.grid = element_blank()) +  # Remove the background grid
        theme(legend.title = element_blank()) +
        theme(legend.position = c(0.15, 0.86)) +
        theme(legend.background = element_rect(fill = "white",
                                               size = 0.5, linetype = "solid", 
                                               colour = "black")) +
        scale_color_grey() +
        scale_y_continuous(breaks = seq(-0.24, 0.18, by = 0.04)) +
        coord_cartesian(ylim = c(-0.24, 0.18)) +
        geom_hline(yintercept = 0, linetype = "dotted") +
        ylab("Difference in survival probability") +
        xlab("Time in months"))
if (post2015 == 0 & blood_types == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & educD ==0){
  ggsave("Figures\\Pre_tx_eff_OvsAB_ddml.png", width = 8, height = 5)
}





# set.seed(3390760)
# DF41 = DF4[(DF4$Z ==1),]
# DF40 = DF4[(DF4$Z ==0),]
# DF41 <- DF41[sample(nrow(DF41), size = nrow(DF40), replace = FALSE), ]
# DF4 = rbind(DF41,DF40)


# year_incr = 6
# Rcens1 <- seq(year_incr, 72, by = year_incr)
# if (post2015 == 1) {
#   Rcens1 <- seq(year_incr, 72, by = year_incr)
# }
# 
# # To adjust for competing risk right censoring using linear weight
# DF4$pscore_cum = 1
# for (rr in Rcens1) {
# 
#   DF41 = DF4[(DF4$Z ==1),]
#   DF40 = DF4[(DF4$Z ==0),]
#   DF3 <- DF4
#   print("rr")
#   print(rr)
# 
#   sX <- c("CAN_AGE_AT_LISTING_35up","CAN_AGE_AT_LISTING_51",
#           "CAN_AGE_AT_LISTING_58", "CAN_AGE_AT_LISTING_65", "CAN_BMI_1925", "CAN_BMI_2630", "CAN_BMI_over30",
#           "FEMALE","CAN_PREV_TX", "DIAB_ENTRY","DIAL_ENTRY","DIAL_ENTRY_time", "DIAL_time_1YRplus","ASIAN", "BLACK", "OTHER_NONWHITE", "CAN_MALIG", 
#           "CAN_ACPT_HBC_POS1",  "CAN_BMI","CAN_DGN_POLY","CAN_DGN_HYPE","CAN_DGN_GLOM",
#           'CAN_EDUCATION_HS','CAN_EDUCATION_COL','CAN_EDUCATION_COLDEG')
#  
#   DF3 <- DF3[!(as.numeric(DF3$vdurE < rr) + as.numeric(DF3$vCe == 0) == 2), ]  # remove randomly censored outcomes
#   
#   DF3 = DF3[(DF3$vdurE >= (rr-12)),]
#   DF3 = DF3[(DF3$vdurS >= (rr-12)),]
# 
#   DF3$Crisk = as.numeric(DF3$vdurS >= (rr-12)) * as.numeric(DF3$vdurS < rr) * as.numeric(DF3$vCs == 1)
#   #DF3$Crisk =  as.numeric(DF3$vdurS < rr) * as.numeric(DF3$vCs == 1)
#   
#   print(sum(DF3$Crisk)/nrow(DF3))
#   
#   ps_model <- glm(as.formula(paste("Crisk ~ ", paste(sX, collapse = "+"))), 
#                   family = binomial(), data = DF3[(DF3$Z ==0),])
#   DF40$pscore <- predict(ps_model, newdata = DF40, type = "response")  # probability of treatment at rr
#   print(mean(DF40$pscore))
#   
#   ps_model <- glm(as.formula(paste("Crisk ~ ", paste(sX, collapse = "+"))), 
#                   family = binomial(), data = DF3[(DF3$Z ==1),])
#   DF41$pscore <- predict(ps_model, newdata = DF41, type = "response")  # probability of treatment at rr
#   print(mean(DF41$pscore))
#   
#   DF4 = rbind(DF41,DF40)
# 
#   DF4$pscore_cum =  DF4$pscore_cum * (1-DF4$pscore) # probability of non-treatment by end of rr
#   
#   #DF4$pscore_cum =  (1-DF4$pscore) # probability of non-treatment by end of rr
#   
# 
#   # print("mean(DF4$pscore_cum[(DF4$Z ==0)] )")
#   # print(mean(DF4$pscore_cum[(DF4$Z ==0)] ))
#   # print("mean(DF4$pscore_cum[(DF4$Z ==1)] )")
#   # print(mean(DF4$pscore_cum[(DF4$Z ==1)] ))
#   # print(mean(DF4$pscore_cum))
#   DF4[[paste0("weight_Crisk_", rr)]]  <- 1/ (DF4$pscore_cum)
#   #DF4[[paste0("weight_", rr)]]  <- 1/ DF4$pscore
#   
# 
#   
# }
# 


# THis is the one you should use, if any
# year_incr = 6
# Rcens1 <- seq(year_incr, 120, by = year_incr)
# if (post2015 == 1) {
#   Rcens1 <- seq(year_incr, 72, by = year_incr)
# }
# 
# # To adjust for competing risk right censoring using linear weight
# DF4$pscore_cum = 1
# for (rr in Rcens1) {
#   
#   DF3 <- DF4
#   print("rr")
#   print(rr)
#   
#   sX <- c("Z","CAN_AGE_AT_LISTING_35up","CAN_AGE_AT_LISTING_51",
#           "CAN_AGE_AT_LISTING_58", "CAN_AGE_AT_LISTING_65", "CAN_BMI_1925", "CAN_BMI_2630", "CAN_BMI_over30",
#           "FEMALE","CAN_PREV_TX", "DIAB_ENTRY","DIAL_ENTRY","DIAL_ENTRY_time", "DIAL_time_1YRplus","ASIAN", "BLACK", "OTHER_NONWHITE", "CAN_MALIG", 
#           "CAN_ACPT_HBC_POS1",  "CAN_BMI","CAN_DGN_POLY","CAN_DGN_HYPE","CAN_DGN_GLOM",
#           'CAN_EDUCATION_HS','CAN_EDUCATION_COL','CAN_EDUCATION_COLDEG')
#   
#   DF3 <- DF3[!(as.numeric(DF3$vdurE < rr) + as.numeric(DF3$vCe == 0) == 2), ]  # remove randomly censored outcomes
#   
#   DF3 = DF3[(DF3$vdurE >= (rr-12)),]
#   DF3 = DF3[(DF3$vdurS >= (rr-12)),]
#   
#   DF3$Crisk = as.numeric(DF3$vdurS >= (rr-12)) * as.numeric(DF3$vdurS < rr) * as.numeric(DF3$vCs == 1)
#   #DF3$Crisk =  as.numeric(DF3$vdurS < rr) * as.numeric(DF3$vCs == 1)
#   
#   print(sum(DF3$Crisk)/nrow(DF3))
#   
#   ps_model <- glm(as.formula(paste("Crisk ~ ", paste(sX, collapse = "+"))), 
#                   family = binomial(), data = DF3)
#   DF4$pscore <- predict(ps_model, newdata = DF4, type = "response")  # probability of treatment at rr
#   print(mean(DF4$pscore))
#   
#   
#   DF4$pscore_cum =  DF4$pscore_cum * (1-DF4$pscore) # probability of non-treatment by end of rr
#   
#   #DF4$pscore_cum =  (1-DF4$pscore) # probability of non-treatment by end of rr
#   
#   
#   # print("mean(DF4$pscore_cum[(DF4$Z ==0)] )")
#   # print(mean(DF4$pscore_cum[(DF4$Z ==0)] ))
#   # print("mean(DF4$pscore_cum[(DF4$Z ==1)] )")
#   # print(mean(DF4$pscore_cum[(DF4$Z ==1)] ))
#   # print(mean(DF4$pscore_cum))
#   DF4[[paste0("weight_Crisk_", rr)]]  <- 1/ (DF4$pscore_cum)
#   #DF4[[paste0("weight_", rr)]]  <- 1/ DF4$pscore
#   
#   
#   
# }






# 
# 
# 
# 
# 
# 
# 
# # To adjust for competing risk right censoring using keras deep learning
# DF4$pscore_cum = 1
# for (rr in Rcens1) {
#   rr =12
#   DF3 <- DF4
#   
# 
#   sX <- c("Z", "CAN_AGE_AT_LISTING_35up","CAN_AGE_AT_LISTING_51",
#           "CAN_AGE_AT_LISTING_58", "CAN_AGE_AT_LISTING_65", "CAN_BMI_1925", "CAN_BMI_2630", "CAN_BMI_over30",
#           "FEMALE","CAN_PREV_TX", "DIAB_ENTRY","DIAL_ENTRY","DIAL_ENTRY_time", "DIAL_time_1YRplus","ASIAN", "BLACK", "OTHER_NONWHITE", "CAN_MALIG", "CAN_FUNCTN_STATn",
#           "CAN_ACPT_HBC_POS1",  "CAN_BMI","CAN_DGN_POLY","CAN_DGN_HYPE","CAN_DGN_GLOM",
#           'CAN_EDUCATION_HS','CAN_EDUCATION_COL','CAN_EDUCATION_COLDEG')
#   
#   DF3 <- DF3[!(as.numeric(DF3$vdurE < rr) + as.numeric(DF3$vCe == 0) == 2), ]  # remove randomly censored outcomes
#   
# 
#   DF3$Crisk = as.numeric(DF3$vdurS < rr) * as.numeric(DF3$vCs == 1)
#   DF3$Crisk <- factor(DF3$Crisk) 
#   sY = "Crisk"
#   
#   X_train <- as.matrix(DF3[, sX])  # Convert predictors to matrix
#   y_train <- as.numeric(DF3$Crisk) # Convert target to numeric
#   X_test <- as.matrix(DF4[, sX])  # Convert predictors to matrix
#   
# 
#   # Define the model with an explicit input layer
#   model <- keras_model_sequential() %>%
#     layer_dense(units = 64, activation = 'relu', input_shape = list(ncol(X_train))) %>%  # Use list() instead of c()
#     layer_dense(units = 1, activation = 'sigmoid')
#   
#   # Compile the model
#   model %>% compile(
#     loss = 'binary_crossentropy',
#     optimizer = optimizer_adam(),
#     metrics = c('accuracy')
#   )
#   
#   # Train the model
#   model %>% fit(X_train, y_train, epochs = 10, batch_size = 32, validation_split = 0.2)
#   
#   # Predict probabilities
#   pscore <- model %>% predict(X_test)
# 
#   
#   # Make predictions
#   DF4$pscore <- model %>% predict(X_test)
#   # Predict
#   DF4$pscore = DF4$pscore / sum(DF4$pscore)
#   DF4$pscore_cum =  DF4$pscore_cum * (1-DF4$pscore) # probability of non-treatment by end of rr
#   
#   # print(mean(DF4$pscore_cum))
#   DF4[[paste0("weight_Crisk_", rr)]]  <- 1/ (DF4$pscore_cum)
#   
#   
#   
# }

# 
# 
# 
# year_incr = 4
# Rcens1 <- seq(year_incr, 120, by = year_incr)
# if (post2015 == 1) {
#   Rcens1 <- seq(year_incr, 72, by = year_incr)
# }
# 
# # To adjust for random right censoring
# DF4$pscore_cum = 1
# for (rr in Rcens1) {
#   DF3 <- DF4
#   
#   
#   sX <- c("Z","CAN_AGE_AT_LISTING_35up","CAN_AGE_AT_LISTING_51",
#           "CAN_AGE_AT_LISTING_58", "CAN_AGE_AT_LISTING_65", "CAN_BMI_1925", "CAN_BMI_2630", "CAN_BMI_over30",
#           "FEMALE","CAN_PREV_TX", "DIAB_ENTRY","DIAL_ENTRY","DIAL_ENTRY_time", "DIAL_time_1YRplus","ASIAN", "BLACK", "OTHER_NONWHITE", "CAN_MALIG", 
#           "CAN_ACPT_HBC_POS1",  "CAN_BMI","CAN_DGN_POLY","CAN_DGN_HYPE","CAN_DGN_GLOM",
#           'CAN_EDUCATION_HS','CAN_EDUCATION_COL','CAN_EDUCATION_COLDEG')
#   
#   
#   
# 
#   DF3 = DF3[(DF3$vdurE >= (rr-12)),]
#   DF3 = DF3[(DF3$vdurS >= (rr-12)),]
#   DF3$ranC = as.numeric(DF3$vdurE >= (rr-12)) * as.numeric(DF3$vdurE < rr) * as.numeric(DF3$vCe == 0)
#   
#   ps_model <- glm(as.formula(paste("ranC ~ ", paste(sX, collapse = "+"))), 
#                   family = binomial(), data = DF3)
#   DF4$pscore <- predict(ps_model, newdata = DF4, type = "response")  # probability of treatment at rr
# 
#   DF4$pscore_cum =  DF4$pscore_cum * (1-DF4$pscore) # probability of non-treatment by end of rr
#   # print(mean(DF4$pscore_cum))
#   DF4[[paste0("weight_ranC_", rr)]]  <- 1/ DF4$pscore_cum 
# 
#   
#   
# }





#######################################
## Effect of Blood type on pre-transplant survival
## censoring survival at moment of transplant for transplanted
## Comparing double ML for different IPCW choices
#######################################


year_incr = 3
Rcens1 <- seq(year_incr, 96, by = year_incr)
if (post2015 == 1) {
  Rcens1 <- seq(year_incr, 72, by = year_incr)
}

# To adjust for competing risk right censoring using neural net (basic) weight
DF4$pscore_cum = 1
for (rr in Rcens1) {
  DF3 <- DF4
  print("rr")
  print(rr)
  
  sX <- c("Z", "CAN_AGE_AT_LISTING_35up","CAN_AGE_AT_LISTING_51",
          "CAN_AGE_AT_LISTING_58", "CAN_AGE_AT_LISTING_65", "CAN_BMI_1925", "CAN_BMI_2630", "CAN_BMI_over30",
          "FEMALE","CAN_PREV_TX", "DIAB_ENTRY","DIAL_ENTRY","DIAL_ENTRY_time", "DIAL_time_1YRplus","ASIAN", "BLACK", "OTHER_NONWHITE", "CAN_MALIG",
          "CAN_ACPT_HBC_POS1",  "CAN_BMI","CAN_DGN_POLY","CAN_DGN_HYPE","CAN_DGN_GLOM",
          'CAN_EDUCATION_HS','CAN_EDUCATION_COL','CAN_EDUCATION_COLDEG')
  
  # Step 1: Find all large center dummy variable names in DF3
  large_center_vars <- grep("^CAN_LISTING_CTR_ID_", names(DF3), value = TRUE)
  
  # Step 2: Add small center indicator variable name
  small_center_var <- "CTR_GROUPED"
  
  # Step 3: Append to your existing match_vars
  
  sX <- c(sX, large_center_vars, small_center_var)
  sX

  
  DF3 <- DF3[!(as.numeric(DF3$vdurE < rr) + as.numeric(DF3$vCe == 0) == 2), ]  # remove randomly censored outcomes
  
  DF3 = DF3[(DF3$vdurE >= (rr-12)),]
  DF3 = DF3[(DF3$vdurS >= (rr-12)),]
  
  
  DF3$Crisk = as.numeric(DF3$vdurS < rr) * as.numeric(DF3$vCs == 1)
  DF3$Crisk <- factor(DF3$Crisk)
  sY = "Crisk"
  
  
  # Fit a neural network model
  model <- nnet(DF3$Crisk ~ ., data = DF3[,c(sY,sX)], size = 5, linout = FALSE, trace = FALSE)
  
  # Predict
  DF4$pscore <- predict(model, DF4[,sX], type = "raw")
  DF4$pscore_cum =  DF4$pscore_cum * (1-DF4$pscore) # probability of non-treatment by end of rr
  print(mean(DF4$pscore_cum[(DF4$Z ==0)] ))
  print(mean(DF4$pscore_cum[(DF4$Z ==1)] ))
  # print(mean(DF4$pscore_cum))
  DF4[[paste0("weight_Crisk_", rr)]]  <- 1/ (DF4$pscore_cum)
}  
  
  
Rcens1 <- seq(year_incr, 96, by = year_incr)
if (post2015 == 1) {
  Rcens1 <- seq(year_incr, 72, by = year_incr)
}

# To adjust for competing risk right censoring using neural net (basic) weight
DF4$pscore_cum = 1
for (rr in Rcens1) {
  print("rr")
  print(rr)
  DF3 <- DF4
  
  
  sX <- c("Z", "CAN_AGE_AT_LISTING_35up","CAN_AGE_AT_LISTING_51",
          "CAN_AGE_AT_LISTING_58", "CAN_AGE_AT_LISTING_65", "CAN_BMI_1925", "CAN_BMI_2630", "CAN_BMI_over30",
          "FEMALE","CAN_PREV_TX", "DIAB_ENTRY","DIAL_ENTRY","DIAL_ENTRY_time", "DIAL_time_1YRplus","ASIAN", "BLACK", "OTHER_NONWHITE", "CAN_MALIG",
          "CAN_ACPT_HBC_POS1",  "CAN_BMI","CAN_DGN_POLY","CAN_DGN_HYPE","CAN_DGN_GLOM",
          'CAN_EDUCATION_HS','CAN_EDUCATION_COL','CAN_EDUCATION_COLDEG')
  
  # Step 1: Find all large center dummy variable names in DF3
  large_center_vars <- grep("^CAN_LISTING_CTR_ID_", names(DF3), value = TRUE)
  
  # Step 2: Add small center indicator variable name
  small_center_var <- "CTR_GROUPED"
  
  # Step 3: Append to your existing match_vars
  
  sX <- c(sX, large_center_vars, small_center_var)
  sX


  DF3 = DF3[(DF3$vdurE >= (rr-12)),]
  DF3 = DF3[(DF3$vdurS >= (rr-12)),]
  
  
  DF3$ranC = as.numeric(DF3$vdurE >= (rr-12)) * as.numeric(DF3$vdurE < rr) * as.numeric(DF3$vCe == 0)
  DF3$ranC <- factor(DF3$ranC)
  sY = "ranC"
  
  
  # Fit a neural network model
  model <- nnet(DF3$ranC ~ ., data = DF3[,c(sY,sX)], size = 5, linout = FALSE, trace = FALSE)
  
  # Predict
  DF4$pscore <- predict(model, DF4[,sX], type = "raw")

  DF4$pscore_cum =  DF4$pscore_cum * (1-DF4$pscore) # probability of non-treatment by end of rr
  print(mean(DF4$pscore_cum[(DF4$Z ==0)] ))
  print(mean(DF4$pscore_cum[(DF4$Z ==1)] ))
  # print(mean(DF4$pscore_cum))
  DF4[[paste0("weight_ranC_", rr)]]  <- 1/ (DF4$pscore_cum)
  
  
  
}


# Initialize an empty data frame to store results
survival_results_df <- data.frame()
year_incr = 12
Rcens1 <- seq(year_incr, 60, by = year_incr)
for (rr in Rcens1) {

  ### double ML
  DF3 <- DF4[complete.cases(DF4), ]  # drop missing rows
  DF3$vCe = DF3$vCe* as.numeric(DF3$vCs == 0)
  DF3$vdurE = DF3$vdurE* as.numeric(DF3$vCs == 0) + DF3$vdurS* as.numeric(DF3$vCs == 1)

  DF3 <- DF3[!(as.numeric(DF3$vdurE < rr) + as.numeric(DF3$vCe == 0) == 2), ]  # remove competing risk censored outcomes
  DF3$Y <- as.numeric(DF3$vdurE >= rr)


  sX <- colnames(DF3[,6:(ncol(DF3)-1 - 2*(length(Rcens1)+2))])
  sX <- c("CAN_AGE_AT_LISTING_35up","CAN_AGE_AT_LISTING_51",
          "CAN_AGE_AT_LISTING_58", "CAN_AGE_AT_LISTING_65", "CAN_BMI_1925", "CAN_BMI_2630", "CAN_BMI_over30",
          "FEMALE","CAN_PREV_TX", "DIAB_ENTRY","DIAL_ENTRY","DIAL_ENTRY_time", "DIAL_time_1YRplus","ASIAN", "BLACK", "OTHER_NONWHITE", "CAN_MALIG",
          "CAN_ACPT_HBC_POS1",  "CAN_BMI","CAN_DGN_POLY","CAN_DGN_HYPE","CAN_DGN_GLOM",
          'CAN_EDUCATION_HS','CAN_EDUCATION_COL','CAN_EDUCATION_COLDEG')
  
  # Step 1: Find all large center dummy variable names in DF3
  large_center_vars <- grep("^CAN_LISTING_CTR_ID_", names(DF3), value = TRUE)
  
  # Step 2: Add small center indicator variable name
  small_center_var <- "CTR_GROUPED"
  
  # Step 3: Append to your existing match_vars
  
  sX <- c(sX, large_center_vars, small_center_var)
  sX
   
  
  DF3$weight = DF3[[paste0("weight_ranC_", rr)]]   * DF3[[paste0("weight_Crisk_", rr)]] # weights adjust for competing risks and random right censoring
  
  DF3 = DF3 *  DF3$weight
  
  
  DF3 <- DF3 %>% drop_na(Y, Z, CAN_AGE_AT_LISTING_35up, CAN_AGE_AT_LISTING_51, CAN_AGE_AT_LISTING_58, 
                         CAN_AGE_AT_LISTING_65, CAN_BMI_1925, CAN_BMI_2630, CAN_BMI_over30, FEMALE, CAN_PREV_TX, 
                         DIAB_ENTRY, DIAL_ENTRY, DIAL_ENTRY_time, DIAL_time_1YRplus, ASIAN, BLACK, OTHER_NONWHITE, 
                         CAN_MALIG, CAN_ACPT_HBC_POS1, CAN_BMI, CAN_DGN_POLY, CAN_DGN_HYPE, CAN_DGN_GLOM, 
                         CAN_EDUCATION_HS, CAN_EDUCATION_COL, CAN_EDUCATION_COLDEG)





  # Define the data backend
  dml_data <- DoubleMLData$new(data = DF3, y_col = "Y", d_cols = "Z", x_cols = sX)

  # Define ML learners
  learner_lasso <- lrn("regr.cv_glmnet")  # LASSO for Y
  learner_ridge <- lrn("regr.cv_glmnet")  # Ridge for D (can use LASSO too)


  # Define DML model
  dml_plr <- DoubleMLPLR$new(dml_data, ml_l = learner_lasso, ml_m = learner_ridge,
                             dml_procedure = "dml2",
                             score = "partialling out" )

  # Estimate the model
  dml_plr$fit()

  # Extract treatment effect and heteroskedasticity-robust standard error
  coef_estimate <- dml_plr$coef
  se_robust <- dml_plr$se

  result <- data.frame(
    Time = rr,
    Estimate =dml_plr$coef,
    Std_Error = dml_plr$se,
    specif = "DDML 3-mths"
  )

  survival_results_df <- rbind(survival_results_df, result)

  print(survival_results_df)
}

# Print the resulting data frame
print(survival_results_df)









year_incr = 6
Rcens1 <- seq(year_incr, 96, by = year_incr)
if (post2015 == 1) {
  Rcens1 <- seq(year_incr, 72, by = year_incr)
}

# To adjust for competing risk right censoring using neural net (basic) weight
DF4$pscore_cum = 1
for (rr in Rcens1) {
  DF3 <- DF4
  print("rr")
  print(rr)
  
  sX <- c("Z", "CAN_AGE_AT_LISTING_35up","CAN_AGE_AT_LISTING_51",
          "CAN_AGE_AT_LISTING_58", "CAN_AGE_AT_LISTING_65", "CAN_BMI_1925", "CAN_BMI_2630", "CAN_BMI_over30",
          "FEMALE","CAN_PREV_TX", "DIAB_ENTRY","DIAL_ENTRY","DIAL_ENTRY_time", "DIAL_time_1YRplus","ASIAN", "BLACK", "OTHER_NONWHITE", "CAN_MALIG",
          "CAN_ACPT_HBC_POS1",  "CAN_BMI","CAN_DGN_POLY","CAN_DGN_HYPE","CAN_DGN_GLOM",
          'CAN_EDUCATION_HS','CAN_EDUCATION_COL','CAN_EDUCATION_COLDEG')
  
  # Step 1: Find all large center dummy variable names in DF3
  large_center_vars <- grep("^CAN_LISTING_CTR_ID_", names(DF3), value = TRUE)
  
  # Step 2: Add small center indicator variable name
  small_center_var <- "CTR_GROUPED"
  
  # Step 3: Append to your existing match_vars
  
  sX <- c(sX, large_center_vars, small_center_var)
  sX
   
  
  DF3 <- DF3[!(as.numeric(DF3$vdurE < rr) + as.numeric(DF3$vCe == 0) == 2), ]  # remove randomly censored outcomes
  
  DF3 = DF3[(DF3$vdurE >= (rr-12)),]
  DF3 = DF3[(DF3$vdurS >= (rr-12)),]
  
  
  DF3$Crisk = as.numeric(DF3$vdurS < rr) * as.numeric(DF3$vCs == 1)
  DF3$Crisk <- factor(DF3$Crisk)
  sY = "Crisk"
  
  
  # Fit a neural network model
  model <- nnet(DF3$Crisk ~ ., data = DF3[,c(sY,sX)], size = 5, linout = FALSE, trace = FALSE)
  
  # Predict
  DF4$pscore <- predict(model, DF4[,sX], type = "raw")
  DF4$pscore_cum =  DF4$pscore_cum * (1-DF4$pscore) # probability of non-treatment by end of rr
  print(mean(DF4$pscore_cum[(DF4$Z ==0)] ))
  print(mean(DF4$pscore_cum[(DF4$Z ==1)] ))
  # print(mean(DF4$pscore_cum))
  DF4[[paste0("weight_Crisk_", rr)]]  <- 1/ (DF4$pscore_cum)
}  


Rcens1 <- seq(year_incr, 96, by = year_incr)
if (post2015 == 1) {
  Rcens1 <- seq(year_incr, 72, by = year_incr)
}

# To adjust for competing risk right censoring using neural net (basic) weight
DF4$pscore_cum = 1
for (rr in Rcens1) {
  print("rr")
  print(rr)
  DF3 <- DF4
  
  
  sX <- c("Z", "CAN_AGE_AT_LISTING_35up","CAN_AGE_AT_LISTING_51",
          "CAN_AGE_AT_LISTING_58", "CAN_AGE_AT_LISTING_65", "CAN_BMI_1925", "CAN_BMI_2630", "CAN_BMI_over30",
          "FEMALE","CAN_PREV_TX", "DIAB_ENTRY","DIAL_ENTRY","DIAL_ENTRY_time", "DIAL_time_1YRplus","ASIAN", "BLACK", "OTHER_NONWHITE", "CAN_MALIG",
          "CAN_ACPT_HBC_POS1",  "CAN_BMI","CAN_DGN_POLY","CAN_DGN_HYPE","CAN_DGN_GLOM",
          'CAN_EDUCATION_HS','CAN_EDUCATION_COL','CAN_EDUCATION_COLDEG')
  
  # Step 1: Find all large center dummy variable names in DF3
  large_center_vars <- grep("^CAN_LISTING_CTR_ID_", names(DF3), value = TRUE)
  
  # Step 2: Add small center indicator variable name
  small_center_var <- "CTR_GROUPED"
  
  # Step 3: Append to your existing match_vars
  
  sX <- c(sX, large_center_vars, small_center_var)
  sX
   
  
  
  DF3 = DF3[(DF3$vdurE >= (rr-12)),]
  DF3 = DF3[(DF3$vdurS >= (rr-12)),]
  
  
  DF3$ranC = as.numeric(DF3$vdurE >= (rr-12)) * as.numeric(DF3$vdurE < rr) * as.numeric(DF3$vCe == 0)
  DF3$ranC <- factor(DF3$ranC)
  sY = "ranC"
  
  
  # Fit a neural network model
  model <- nnet(DF3$ranC ~ ., data = DF3[,c(sY,sX)], size = 5, linout = FALSE, trace = FALSE)
  
  # Predict
  DF4$pscore <- predict(model, DF4[,sX], type = "raw")
  
  DF4$pscore_cum =  DF4$pscore_cum * (1-DF4$pscore) # probability of non-treatment by end of rr
  print(mean(DF4$pscore_cum[(DF4$Z ==0)] ))
  print(mean(DF4$pscore_cum[(DF4$Z ==1)] ))
  # print(mean(DF4$pscore_cum))
  DF4[[paste0("weight_ranC_", rr)]]  <- 1/ (DF4$pscore_cum)
  
  
  
}








year_incr = 12
Rcens1 <- seq(year_incr, 60, by = year_incr)
for (rr in Rcens1) {

  ### double ML
  DF3 <- DF4[complete.cases(DF4), ]  # drop missing rows
  DF3$vCe = DF3$vCe* as.numeric(DF3$vCs == 0)
  DF3$vdurE = DF3$vdurE* as.numeric(DF3$vCs == 0) + DF3$vdurS* as.numeric(DF3$vCs == 1)

  DF3 <- DF3[!(as.numeric(DF3$vdurE < rr) + as.numeric(DF3$vCe == 0) == 2), ]  # remove competing risk censored outcomes
  DF3$Y <- as.numeric(DF3$vdurE >= rr)


  sX <- colnames(DF3[,6:(ncol(DF3)-1 - 2*(length(Rcens1)+2))])
  sX <- c("CAN_AGE_AT_LISTING_35up","CAN_AGE_AT_LISTING_51",
          "CAN_AGE_AT_LISTING_58", "CAN_AGE_AT_LISTING_65", "CAN_BMI_1925", "CAN_BMI_2630", "CAN_BMI_over30",
          "FEMALE","CAN_PREV_TX", "DIAB_ENTRY","DIAL_ENTRY","DIAL_ENTRY_time", "DIAL_time_1YRplus","ASIAN", "BLACK", "OTHER_NONWHITE", "CAN_MALIG",
          "CAN_ACPT_HBC_POS1",  "CAN_BMI","CAN_DGN_POLY","CAN_DGN_HYPE","CAN_DGN_GLOM",
          'CAN_EDUCATION_HS','CAN_EDUCATION_COL','CAN_EDUCATION_COLDEG')
  
  # Step 1: Find all large center dummy variable names in DF3
  large_center_vars <- grep("^CAN_LISTING_CTR_ID_", names(DF3), value = TRUE)
  
  # Step 2: Add small center indicator variable name
  small_center_var <- "CTR_GROUPED"
  
  # Step 3: Append to your existing match_vars
  
  sX <- c(sX, large_center_vars, small_center_var)
  sX
   

  DF3$weight = DF3[[paste0("weight_ranC_", rr)]]   * DF3[[paste0("weight_Crisk_", rr)]] # weights adjust for competing risks and random right censoring
  



  DF3 = DF3 *  DF3$weight
  
  DF3 <- DF3 %>% drop_na(Y, Z, CAN_AGE_AT_LISTING_35up, CAN_AGE_AT_LISTING_51, CAN_AGE_AT_LISTING_58, 
                         CAN_AGE_AT_LISTING_65, CAN_BMI_1925, CAN_BMI_2630, CAN_BMI_over30, FEMALE, CAN_PREV_TX, 
                         DIAB_ENTRY, DIAL_ENTRY, DIAL_ENTRY_time, DIAL_time_1YRplus, ASIAN, BLACK, OTHER_NONWHITE, 
                         CAN_MALIG, CAN_ACPT_HBC_POS1, CAN_BMI, CAN_DGN_POLY, CAN_DGN_HYPE, CAN_DGN_GLOM, 
                         CAN_EDUCATION_HS, CAN_EDUCATION_COL, CAN_EDUCATION_COLDEG)
  



  # Define the data backend
  dml_data <- DoubleMLData$new(data = DF3, y_col = "Y", d_cols = "Z", x_cols = sX)

  # Define ML learners
  learner_lasso <- lrn("regr.cv_glmnet")  # LASSO for Y
  learner_ridge <- lrn("regr.cv_glmnet")  # Ridge for D (can use LASSO too)


  # Define DML model
  dml_plr <- DoubleMLPLR$new(dml_data, ml_l = learner_lasso, ml_m = learner_ridge,
                             dml_procedure = "dml2",
                             score = "partialling out" )

  # Estimate the model
  dml_plr$fit()

  # Extract treatment effect and heteroskedasticity-robust standard error
  coef_estimate <- dml_plr$coef
  se_robust <- dml_plr$se

  result <- data.frame(
    Time = rr,
    Estimate =dml_plr$coef,
    Std_Error = dml_plr$se,
    specif = "DDML 6-mths"
  )

  survival_results_df <- rbind(survival_results_df, result)

  print(survival_results_df)
}

# Print the resulting data frame
print(survival_results_df)





year_incr = 12
Rcens1 <- seq(year_incr, 96, by = year_incr)
if (post2015 == 1) {
  Rcens1 <- seq(year_incr, 72, by = year_incr)
}

# To adjust for competing risk right censoring using neural net (basic) weight
DF4$pscore_cum = 1
for (rr in Rcens1) {
  DF3 <- DF4
  print("rr")
  print(rr)
  
  sX <- c("Z", "CAN_AGE_AT_LISTING_35up","CAN_AGE_AT_LISTING_51",
          "CAN_AGE_AT_LISTING_58", "CAN_AGE_AT_LISTING_65", "CAN_BMI_1925", "CAN_BMI_2630", "CAN_BMI_over30",
          "FEMALE","CAN_PREV_TX", "DIAB_ENTRY","DIAL_ENTRY","DIAL_ENTRY_time", "DIAL_time_1YRplus","ASIAN", "BLACK", "OTHER_NONWHITE", "CAN_MALIG",
          "CAN_ACPT_HBC_POS1",  "CAN_BMI","CAN_DGN_POLY","CAN_DGN_HYPE","CAN_DGN_GLOM",
          'CAN_EDUCATION_HS','CAN_EDUCATION_COL','CAN_EDUCATION_COLDEG')
  
  # Step 1: Find all large center dummy variable names in DF3
  large_center_vars <- grep("^CAN_LISTING_CTR_ID_", names(DF3), value = TRUE)
  
  # Step 2: Add small center indicator variable name
  small_center_var <- "CTR_GROUPED"
  
  # Step 3: Append to your existing match_vars
  
  sX <- c(sX, large_center_vars, small_center_var)
  sX
   
  
  DF3 <- DF3[!(as.numeric(DF3$vdurE < rr) + as.numeric(DF3$vCe == 0) == 2), ]  # remove randomly censored outcomes
  
  DF3 = DF3[(DF3$vdurE >= (rr-12)),]
  DF3 = DF3[(DF3$vdurS >= (rr-12)),]
  
  
  DF3$Crisk = as.numeric(DF3$vdurS < rr) * as.numeric(DF3$vCs == 1)
  DF3$Crisk <- factor(DF3$Crisk)
  sY = "Crisk"
  
  
  # Fit a neural network model
  model <- nnet(DF3$Crisk ~ ., data = DF3[,c(sY,sX)], size = 5, linout = FALSE, trace = FALSE)
  
  # Predict
  DF4$pscore <- predict(model, DF4[,sX], type = "raw")
  DF4$pscore_cum =  DF4$pscore_cum * (1-DF4$pscore) # probability of non-treatment by end of rr
  print(mean(DF4$pscore_cum[(DF4$Z ==0)] ))
  print(mean(DF4$pscore_cum[(DF4$Z ==1)] ))
  # print(mean(DF4$pscore_cum))
  DF4[[paste0("weight_Crisk_", rr)]]  <- 1/ (DF4$pscore_cum)
}  


Rcens1 <- seq(year_incr, 96, by = year_incr)
if (post2015 == 1) {
  Rcens1 <- seq(year_incr, 72, by = year_incr)
}

# To adjust for competing risk right censoring using neural net (basic) weight
DF4$pscore_cum = 1
for (rr in Rcens1) {
  print("rr")
  print(rr)
  DF3 <- DF4
  
  
  sX <- c("Z", "CAN_AGE_AT_LISTING_35up","CAN_AGE_AT_LISTING_51",
          "CAN_AGE_AT_LISTING_58", "CAN_AGE_AT_LISTING_65", "CAN_BMI_1925", "CAN_BMI_2630", "CAN_BMI_over30",
          "FEMALE","CAN_PREV_TX", "DIAB_ENTRY","DIAL_ENTRY","DIAL_ENTRY_time", "DIAL_time_1YRplus","ASIAN", "BLACK", "OTHER_NONWHITE", "CAN_MALIG",
          "CAN_ACPT_HBC_POS1",  "CAN_BMI","CAN_DGN_POLY","CAN_DGN_HYPE","CAN_DGN_GLOM",
          'CAN_EDUCATION_HS','CAN_EDUCATION_COL','CAN_EDUCATION_COLDEG')
  
  # Step 1: Find all large center dummy variable names in DF3
  large_center_vars <- grep("^CAN_LISTING_CTR_ID_", names(DF3), value = TRUE)
  
  # Step 2: Add small center indicator variable name
  small_center_var <- "CTR_GROUPED"
  
  # Step 3: Append to your existing match_vars
  
  sX <- c(sX, large_center_vars, small_center_var)
  sX
   
  
  
  DF3 = DF3[(DF3$vdurE >= (rr-12)),]
  DF3 = DF3[(DF3$vdurS >= (rr-12)),]
  
  
  DF3$ranC = as.numeric(DF3$vdurE >= (rr-12)) * as.numeric(DF3$vdurE < rr) * as.numeric(DF3$vCe == 0)
  DF3$ranC <- factor(DF3$ranC)
  sY = "ranC"
  
  
  # Fit a neural network model
  model <- nnet(DF3$ranC ~ ., data = DF3[,c(sY,sX)], size = 5, linout = FALSE, trace = FALSE)
  
  # Predict
  DF4$pscore <- predict(model, DF4[,sX], type = "raw")
  
  DF4$pscore_cum =  DF4$pscore_cum * (1-DF4$pscore) # probability of non-treatment by end of rr
  print(mean(DF4$pscore_cum[(DF4$Z ==0)] ))
  print(mean(DF4$pscore_cum[(DF4$Z ==1)] ))
  # print(mean(DF4$pscore_cum))
  DF4[[paste0("weight_ranC_", rr)]]  <- 1/ (DF4$pscore_cum)
  
  
  
}





year_incr = 12
Rcens1 <- seq(year_incr, 60, by = year_incr)
for (rr in Rcens1) {
  
  ### double ML
  DF3 <- DF4[complete.cases(DF4), ]  # drop missing rows
  DF3$vCe = DF3$vCe* as.numeric(DF3$vCs == 0)
  DF3$vdurE = DF3$vdurE* as.numeric(DF3$vCs == 0) + DF3$vdurS* as.numeric(DF3$vCs == 1)
  
  DF3 <- DF3[!(as.numeric(DF3$vdurE < rr) + as.numeric(DF3$vCe == 0) == 2), ]  # remove competing risk censored outcomes
  DF3$Y <- as.numeric(DF3$vdurE >= rr)
  
  
  sX <- colnames(DF3[,6:(ncol(DF3)-1 - 2*(length(Rcens1)+2))])
  sX <- c("CAN_AGE_AT_LISTING_35up","CAN_AGE_AT_LISTING_51",
          "CAN_AGE_AT_LISTING_58", "CAN_AGE_AT_LISTING_65", "CAN_BMI_1925", "CAN_BMI_2630", "CAN_BMI_over30",
          "FEMALE","CAN_PREV_TX", "DIAB_ENTRY","DIAL_ENTRY","DIAL_ENTRY_time", "DIAL_time_1YRplus","ASIAN", "BLACK", "OTHER_NONWHITE", "CAN_MALIG",
          "CAN_ACPT_HBC_POS1",  "CAN_BMI","CAN_DGN_POLY","CAN_DGN_HYPE","CAN_DGN_GLOM",
          'CAN_EDUCATION_HS','CAN_EDUCATION_COL','CAN_EDUCATION_COLDEG')
  
  # Step 1: Find all large center dummy variable names in DF3
  large_center_vars <- grep("^CAN_LISTING_CTR_ID_", names(DF3), value = TRUE)
  
  # Step 2: Add small center indicator variable name
  small_center_var <- "CTR_GROUPED"
  
  # Step 3: Append to your existing match_vars
  
  sX <- c(sX, large_center_vars, small_center_var)
  sX
   
  
  DF3$weight = DF3[[paste0("weight_ranC_", rr)]]   * DF3[[paste0("weight_Crisk_", rr)]] # weights adjust for competing risks and random right censoring
  
  DF3 = DF3 *  DF3$weight
  
  DF3 <- DF3 %>% drop_na(Y, Z, CAN_AGE_AT_LISTING_35up, CAN_AGE_AT_LISTING_51, CAN_AGE_AT_LISTING_58, 
                         CAN_AGE_AT_LISTING_65, CAN_BMI_1925, CAN_BMI_2630, CAN_BMI_over30, FEMALE, CAN_PREV_TX, 
                         DIAB_ENTRY, DIAL_ENTRY, DIAL_ENTRY_time, DIAL_time_1YRplus, ASIAN, BLACK, OTHER_NONWHITE, 
                         CAN_MALIG, CAN_ACPT_HBC_POS1, CAN_BMI, CAN_DGN_POLY, CAN_DGN_HYPE, CAN_DGN_GLOM, 
                         CAN_EDUCATION_HS, CAN_EDUCATION_COL, CAN_EDUCATION_COLDEG)
  
  

  
  # Define the data backend
  dml_data <- DoubleMLData$new(data = DF3, y_col = "Y", d_cols = "Z", x_cols = sX)
  
  # Define ML learners
  learner_lasso <- lrn("regr.cv_glmnet")  # LASSO for Y
  learner_ridge <- lrn("regr.cv_glmnet")  # Ridge for D (can use LASSO too)
  
  
  # Define DML model
  dml_plr <- DoubleMLPLR$new(dml_data, ml_l = learner_lasso, ml_m = learner_ridge,
                             dml_procedure = "dml2",
                             score = "partialling out" )
  
  # Estimate the model
  dml_plr$fit()
  
  # Extract treatment effect and heteroskedasticity-robust standard error
  coef_estimate <- dml_plr$coef
  se_robust <- dml_plr$se
  
  result <- data.frame(
    Time = rr,
    Estimate =dml_plr$coef,
    Std_Error = dml_plr$se,
    specif = "DDML 12-mths"
  )
  
  survival_results_df <- rbind(survival_results_df, result)
  
  print(survival_results_df)
}

# Print the resulting data frame
print(survival_results_df)


# Assuming you have a data frame named 'survival_results_df' containing your survival analysis results
# Make sure 'size', 'effect', 'effect_se', and 'specification' columns exist in the data frame

pd <- 3
print(ggplot(survival_results_df,
             aes(x     = Time,
                 y     = -Estimate,
                 color = specif)) +
        geom_point(shape = 15,
                   size  = 4,
                   position = position_dodge(pd)) +  # Use position_dodge with the desired offset
        geom_errorbar(aes(ymin  = -Estimate - 1.96*Std_Error,
                          ymax  = -Estimate + 1.96*Std_Error),
                      width = 2,
                      size  = 1,
                      position = position_dodge(pd)) +  # Use the same offset for error bars
        theme_bw() +
        theme(text = element_text(size = 20),
              panel.grid = element_blank()) +  # Remove the background grid
        theme(legend.title = element_blank()) +
        theme(legend.position = c(0.15, 0.86)) +
        theme(legend.background = element_rect(fill = "white",
                                               size = 0.5, linetype = "solid", 
                                               colour = "black")) +
        scale_color_grey() +
        scale_y_continuous(breaks = seq(-0.40, 0.18, by = 0.04)) +
        coord_cartesian(ylim = c(-0.40, 0.18)) +
        geom_hline(yintercept = 0, linetype = "dotted") +
        ylab("Difference in survival probability") +
        xlab("Time in months"))
if (post2015 == 0 & blood_types == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & educD ==0){
  ggsave("Figures\\Pre_tx_eff_OvsAB_ddmlW.png", width = 8, height = 5)
}



print(ggplot(survival_results_df[(survival_results_df$specif != "DDML 3-mths"),],
             aes(x     = Time,
                 y     = -Estimate,
                 color = specif)) +
        geom_point(shape = 15,
                   size  = 4,
                   position = position_dodge(pd)) +  # Use position_dodge with the desired offset
        geom_errorbar(aes(ymin  = -Estimate - 1.96*Std_Error,
                          ymax  = -Estimate + 1.96*Std_Error),
                      width = 2,
                      size  = 1,
                      position = position_dodge(pd)) +  # Use the same offset for error bars
        theme_bw() +
        theme(text = element_text(size = 20),
              panel.grid = element_blank()) +  # Remove the background grid
        theme(legend.title = element_blank()) +
        theme(legend.position = c(0.15, 0.86)) +
        theme(legend.background = element_rect(fill = "white",
                                               size = 0.5, linetype = "solid", 
                                               colour = "black")) +
        scale_color_grey() +
        scale_y_continuous(breaks = seq(-0.40, 0.18, by = 0.04)) +
        coord_cartesian(ylim = c(-0.40, 0.18)) +
        geom_hline(yintercept = 0, linetype = "dotted") +
        ylab("Difference in survival probability") +
        xlab("Time in months"))
if (post2015 == 0 & blood_types == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & educD ==0){
  ggsave("Figures\\Pre_tx_eff_OvsAB_ddmlW.png", width = 8, height = 5)
}












#######################################
## Effect of Blood type on pre-transplant survival
## censoring survival at moment of transplant for transplanted
## Comparing OLS no covariates, with baseline covariates, Cox-lasso, deep survival learning, random survival forest
#######################################


# Initialize an empty data frame to store results
survival_results_df <- data.frame()

# DF2 = DF[((DF$vCs == 1) == 1),]  # Select treated at t=1


DF2 = DF
DF2$Z <- as.numeric(DF2$CAN_ABO == "O")   # define regime
DF2$vCe = DF2$vCe* as.numeric(DF2$vCs == 0) 
DF2$vdurE = DF2$vdurE* as.numeric(DF2$vCs == 0) + DF2$vdurS* as.numeric(DF2$vCs == 1)

table(DF2$CAN_ABO)



# Candidate:  
#   main: c("DIAL_ENTRY_time", "CAN_BMI","CAN_DGN_POLY","CAN_DGN_HYPE","CAN_DGN_GLOM") 
#   potential bad control c("CAN_FUNCTN_STATn") # Note this is not used in Wolfe study. education variable should be added to this 
#   extra with high share missing: c("CAN_TOT_ALBUMIN", "CAN_TOT_ALBUMIN_miss")

# Donor characteristics:
#   main: c("DON_AGE","DON_WGT_KG","DON_CAD_DON_COD_ANOX","DON_CAD_DON_COD_CERE","DON_CAD_DON_COD_HEAD","DON_CAD_DON_COD_TUMO","DON_CAD_DON_COD_OTHE") 


# Candidate-donor match:
#   main: c("REC_A_MM_EQUIV_TX0", "REC_A_MM_EQUIV_TX1", "REC_A_MM_EQUIV_TX2", "REC_B_MM_EQUIV_TX0","REC_B_MM_EQUIV_TX1","REC_B_MM_EQUIV_TX2","REC_DR_MM_EQUIV_TX0","REC_DR_MM_EQUIV_TX1","REC_DR_MM_EQUIV_TX2","DON_ORG_SHARED") 



DF2 = DF2[,c("vdurE","vCe","vdurS","vCs","Z","CAN_AGE_AT_LISTING_35up","CAN_AGE_AT_LISTING_51",
            "CAN_AGE_AT_LISTING_58", "CAN_AGE_AT_LISTING_65", "CAN_BMI_1925", "CAN_BMI_2630", "CAN_BMI_over30",
            "FEMALE","CAN_PREV_TX", "DIAB_ENTRY","DIAL_ENTRY","DIAL_ENTRY_time", "DIAL_time_1YRplus", "ASIAN", "BLACK", "OTHER_NONWHITE", "CAN_MALIG", "CAN_FUNCTN_STATn",
            "CAN_ACPT_HBC_POS1", "CAN_ACPT_HCV_POS1", "CAN_BMI","CAN_DGN_POLY","CAN_DGN_HYPE","CAN_DGN_GLOM",
            'WHITE','CAN_EDUCATION_HS','CAN_EDUCATION_COL','CAN_EDUCATION_COLDEG',"CAN_LISTING_CTR_ID")]
DF2 =  dummy_cols(DF2, select_columns = "CAN_LISTING_CTR_ID", remove_first_dummy = FALSE)
DF2 =  dummy_cols(DF2, select_columns = "CAN_FUNCTN_STATn", remove_first_dummy = FALSE)

cat("Total observations =" , nrow(DF2))

### Imputing missing values on the X (this matters as dropping them shifts results)
## It doesn't make much of a difference in the results which I use (it matters more that I just don't drop the variables), but might in your application
## 1. imputing mode (fast)
impute_mode <- function(df) {
  for (col in names(df)) {
    if (any(is.na(df[[col]]))) {  # Check if column has missing values
      mode_val <- names(sort(table(df[[col]]), decreasing = TRUE))[1]  # Get mode
      df[[col]][is.na(df[[col]])] <- mode_val  # Impute mode
    }
  }
  return(df)
}

DF2 <- impute_mode(DF2)  # Apply function to your dataframe
DF2[] <- lapply(DF2, function(x) {
  if (is.character(x)) as.numeric(x) else x
})

## 2. Tree based approach (takes time)
# DF2 <- mice(DF2, method = "cart", m = 5)  # Uses Classification and Regression Trees (CART)

nrow(DF2)
DF4 <- DF2[complete.cases(DF2), ]  # drop missing rows
nrow(DF4)


cat("Total observations =" , nrow(DF4))
cat("O observations =" , sum(DF4$Z))
cat("AB observations =" , sum(1-DF4$Z))
cat("O treated observations =" , sum(DF4$Z * DF4$vCs))
cat("O non-treated observations =" , sum(DF4$Z * (1- DF4$vCs)))
cat("not-O treated observations =" , sum((1-DF4$Z) * DF4$vCs))
cat("not-O non-treated observations =" , sum((1-DF4$Z)*(1- DF4$vCs)))

Rcens1 <- c(12,24,36,48,60,72,84,96,108,120)
for (rr in Rcens1) {
  DF3 <- DF4
  
  # Data selection. none of these are strictly necessary for results but they are used in the main analysis so need to be consistent
  
  
  ### with no covariates
  DF3$Y <- as.numeric(DF3$vdurE >= rr)
  DF3 <- DF3[!(as.numeric(DF3$vdurE < rr) + as.numeric(DF3$vCe == 0) == 2), ]  # remove randomly censored outcomes
  
  sTreat <- "Z"
  streatX <- c(sTreat)
  B_ols_fn <- lm(as.formula(paste("Y ~ ", paste(streatX, collapse = "+"))), data = DF3)
  print("B_ols_fn")
  # Store the results in the data frame
  result <- data.frame(
    Time = rr,
    Estimate = -coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[2, "Estimate"],
    Std_Error = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[2, "Std. Error"],
    specif = "without cov"
  )
  
  
  ### with base covariates
  survival_results_df <- rbind(survival_results_df, result)
  if (post2015 == 0){
    sX <- c("CAN_AGE_AT_LISTING_35up")
  }else{
    
    sX <- c("EPTSlow20")
  }
  
  sTreat <- "Z"
  streatX <- c(sTreat, sX)
  B_ols_fn <- lm(as.formula(paste("Y ~ ", paste(streatX, collapse = "+"))), data = DF3)
  print(nrow(DF3))
  print(sum(complete.cases(DF3[,sX])))
  
  
  # Store the results in the data frame
  result <- data.frame(
    Time = rr,
    Estimate = -coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[2, "Estimate"],
    Std_Error = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[2, "Std. Error"],
    specif = "with base cov."
  )
  
  survival_results_df <- rbind(survival_results_df, result)

  

  # Cox-Lasso Model
  # Define the set of covariates
  DF3 <- DF4[complete.cases(DF4), ]  # drop missing rows
  DF3$Y <- as.numeric(DF3$vdurE >= rr)
  DF3 <- DF3[!(as.numeric(DF3$vdurE < rr) + as.numeric(DF3$vCe == 0) == 2), ]  # remove randomly censored outcomes
  
  sX <- colnames(DF3[,6:(ncol(DF3)-1)])

  # Define the treatment variable (Z)
  sTreat <- "Z"
  streatX <- c(sTreat, sX)

  # Create the survival object (assuming vdurE and vCe are your survival time and event indicator)
  DF3$SurvObj <- with(DF3, Surv(vdurE, vCe))

  # Prepare the matrix for the Cox-Lasso model (X includes Z and all covariates in sX)
  X <- as.matrix(DF3[, streatX])

  # Fit the Cox-Lasso model using cv.glmnet with the survival object
  cox_lasso_model <- cv.glmnet(X, DF3$SurvObj, family = "cox", alpha = 1)

  # Extract the coefficients at the best lambda (lambda.min)
  coefficients <- coef(cox_lasso_model, s = "lambda.min")

  # Get the coefficient for Z
  coef_Z <- coefficients["Z", ]

  # Calculate the hazard ratio for Z
  hazard_ratio_Z <- exp(coef_Z)

  # Standard error calculation: You may calculate this from the cross-validation error or use the covariance matrix from the glmnet fit.
  # Use the glmnet fit's coefficients to extract the standard error
  se_Z <- sqrt(diag(cox_lasso_model$cvm))[1]  # Get standard error from cross-validation (adjust indexing if needed)

    # Store the results
  result <- data.frame(
    Time = rr,  # You should replace 'rr' with your actual time variable or specific time points if relevant
    Estimate = -hazard_ratio_Z,  # This is the hazard ratio for Z
    Std_Error = se_Z,  # Standard error of the hazard ratio for Z
    specif = "Cox-Lasso with ext. cov."
  )

  survival_results_df <- rbind(survival_results_df, result)

  print(survival_results_df)

  # Define survival object
  DF3$SurvObj <- with(DF3, Surv(vdurE, vCe))


  # DeepSurv Model

  deep_model <- deepsurv(SurvObj ~ Z, data = DF3)
  deep_preds <- predict(deep_model, DF3)
  deep_est <- mean(deep_preds)
  deep_se <- sd(deep_preds) / sqrt(nrow(DF3))


  result <- data.frame(
    Time = rr,
    Estimate = -deep_est,
    Std_Error = deep_se,
    specif = "Deep survival"
  )

  survival_results_df <- rbind(survival_results_df, result)

  # Random Survival Forest Model
  rsf_model <- rfsrc(SurvObj ~ Z, data = DF3, ntree = 500)
  rsf_preds <- predict(rsf_model, newdata = DF3)$predicted
  rsf_est <- mean(rsf_preds)
  rsf_se <- sd(rsf_preds) / sqrt(nrow(DF3))

  result <- data.frame(
    Time = rr,
    Estimate = -rsf_est,
    Std_Error = rsf_se,
    specif = "Rand. forest surv."
  )

  survival_results_df <- rbind(survival_results_df, result)
  
  print(survival_results_df)
}

# Print the resulting data frame
print(survival_results_df)











# To be ignored (but still uperhaps useful to see what else I tried to look at)
# 
# #######################################
# ## Effect of Blood type on pre-transplant survival
# ## censoring survival at moment of transplant for transplanted
# ## Comparing OLS no covariates, with baseline covariates, with extensive covariates, with doubly debiased estimation
# #######################################
# 
# 
# # Initialize an empty data frame to store results
# survival_results_df <- data.frame()
# 
# # DF2 = DF[((DF$vCs == 1) == 1),]  # Select treated at t=1
# 
# 
# DF2 = DF
# DF2$Z <- as.numeric(DF2$CAN_ABO == "O")   # define regime
# 
# table(DF2$CAN_ABO)
# 
# 
# # Candidate:  
# #   main: c("DIAL_ENTRY_time", "CAN_BMI","CAN_DGN_POLY","CAN_DGN_HYPE","CAN_DGN_GLOM") 
# #   potential bad control c("CAN_FUNCTN_STATn") # Note this is not used in Wolfe study. education variable should be added to this 
# #   extra with high share missing: c("CAN_TOT_ALBUMIN", "CAN_TOT_ALBUMIN_miss")
# 
# # Donor characteristics:
# #   main: c("DON_AGE","DON_WGT_KG","DON_CAD_DON_COD_ANOX","DON_CAD_DON_COD_CERE","DON_CAD_DON_COD_HEAD","DON_CAD_DON_COD_TUMO","DON_CAD_DON_COD_OTHE") 
# 
# 
# # Candidate-donor match:
# #   main: c("REC_A_MM_EQUIV_TX0", "REC_A_MM_EQUIV_TX1", "REC_A_MM_EQUIV_TX2", "REC_B_MM_EQUIV_TX0","REC_B_MM_EQUIV_TX1","REC_B_MM_EQUIV_TX2","REC_DR_MM_EQUIV_TX0","REC_DR_MM_EQUIV_TX1","REC_DR_MM_EQUIV_TX2","DON_ORG_SHARED") 
# 
# 
# 
# DF2 = DF2[,c("vdurE","vCe","vdurS","vCs","Z","CAN_AGE_AT_LISTING_35up","CAN_AGE_AT_LISTING_51",
#             "CAN_AGE_AT_LISTING_58", "CAN_AGE_AT_LISTING_65", "CAN_BMI_1925", "CAN_BMI_2630", "CAN_BMI_over30",
#             "FEMALE","CAN_PREV_TX", "DIAB_ENTRY","DIAL_ENTRY","DIAL_ENTRY_time", "DIAL_time_1YRplus","ASIAN", "BLACK", "OTHER_NONWHITE", "CAN_MALIG", "CAN_FUNCTN_STATn",
#             "CAN_ACPT_HBC_POS1", "CAN_ACPT_HCV_POS1", "CAN_BMI","CAN_DGN_POLY","CAN_DGN_HYPE","CAN_DGN_GLOM",
#             'WHITE','CAN_EDUCATION_HS','CAN_EDUCATION_COL','CAN_EDUCATION_COLDEG',"CAN_LISTING_CTR_ID")]
# DF2 =  dummy_cols(DF2, select_columns = "CAN_LISTING_CTR_ID", remove_first_dummy = FALSE)
# DF2 =  dummy_cols(DF2, select_columns = "CAN_FUNCTN_STATn", remove_first_dummy = FALSE)
# 
# cat("Total observations =" , nrow(DF2))
# 
# ### Imputing missing values on the X (this matters as dropping them shifts results)
# ## It doesn't make much of a difference in the results which I use (it matters more that I just don't drop the variables), but might in your application
# ## 1. imputing mode (fast)
# impute_mode <- function(df) {
#   for (col in names(df)) {
#     if (any(is.na(df[[col]]))) {  # Check if column has missing values
#       mode_val <- names(sort(table(df[[col]]), decreasing = TRUE))[1]  # Get mode
#       df[[col]][is.na(df[[col]])] <- mode_val  # Impute mode
#     }
#   }
#   return(df)
# }
# 
# DF2 <- impute_mode(DF2)  # Apply function to your dataframe
# DF2[] <- lapply(DF2, function(x) {
#   if (is.character(x)) as.numeric(x) else x
# })
# 
# ## 2. Tree based approach (takes time)
# # DF2 <- mice(DF2, method = "cart", m = 5)  # Uses Classification and Regression Trees (CART)
# 
# nrow(DF2)
# DF4 <- DF2[complete.cases(DF2), ]  # drop missing rows
# nrow(DF4)
# 
# 
# cat("Total observations =" , nrow(DF4))
# cat("O observations =" , sum(DF4$Z))
# cat("AB observations =" , sum(1-DF4$Z))
# cat("O treated observations =" , sum(DF4$Z * DF4$vCs))
# cat("O non-treated observations =" , sum(DF4$Z * (1- DF4$vCs)))
# cat("not-O treated observations =" , sum((1-DF4$Z) * DF4$vCs))
# cat("not-O non-treated observations =" , sum((1-DF4$Z)*(1- DF4$vCs)))
# 
# 
# 
# Rcens1 <- c(12,24,36,48,60,72,84,96,108,120)
# for (rr in Rcens1) {
#   DF3 <- DF4
#   
#   # Need following adjustment to impose censoring at moment of transplant
#   DF3$vCe = DF3$vCe* as.numeric(DF3$vCs == 0) 
#   DF3$vdurE = DF3$vdurE* as.numeric(DF3$vCs == 0) + DF3$vdurS* as.numeric(DF3$vCs == 1)
#   
#   DF3 <- DF3[!(as.numeric(DF3$vdurE < rr) + as.numeric(DF3$vCe == 0) == 2), ]  # remove randomly censored outcomes and competing risk censored ones
#   DF3$Y <- as.numeric(DF3$vdurE >= rr) 
#   
#   
#   sTreat <- "Z"
#   streatX <- c(sTreat)
#   B_ols_fn <- lm(as.formula(paste("Y ~ ", paste(streatX, collapse = "+"))), data = DF3)
#   print("B_ols_fn")
#   # Store the results in the data frame
#   result <- data.frame(
#     Time = rr,
#     Estimate = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[2, "Estimate"],
#     Std_Error = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[2, "Std. Error"],
#     specif = "without cov"
#   )
#   
#   
#   ### with base covariates
#   survival_results_df <- rbind(survival_results_df, result)
#   if (post2015 == 0){
#     sX <- c("CAN_AGE_AT_LISTING_35up")
#   }else{
#     
#     sX <- c("EPTSlow20")
#   }
#   
#   sTreat <- "Z"
#   streatX <- c(sTreat, sX)
#   B_ols_fn <- lm(as.formula(paste("Y ~ ", paste(streatX, collapse = "+"))), data = DF3)
#   print(nrow(DF3))
#   print(sum(complete.cases(DF3[,sX])))
#   
#   
#   # Store the results in the data frame
#   result <- data.frame(
#     Time = rr,
#     Estimate = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[2, "Estimate"],
#     Std_Error = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[2, "Std. Error"],
#     specif = "with base cov."
#   )
#   
#   survival_results_df <- rbind(survival_results_df, result)
#   
#   ### with extensive covariates
#   if (post2015 == 0){
#     if (educ == 0) {
#       sX <- c("CAN_AGE_AT_LISTING_51", "CAN_AGE_AT_LISTING_58", "CAN_AGE_AT_LISTING_65", "CAN_BMI_1925", "CAN_BMI_2630", "CAN_BMI_over30", 
#               "FEMALE","CAN_PREV_TX", "DIAB_ENTRY","DIAL_ENTRY","DIAL_time_1YRplus", "ASIAN", "BLACK", "OTHER_NONWHITE", "CAN_MALIG", "CAN_ACPT_HBC_POS1", 
#               "CAN_ACPT_HCV_POS1","CAN_BMI","CAN_DGN_POLY","CAN_DGN_HYPE","CAN_DGN_GLOM")
#     }else{
#       sX <- c("CAN_AGE_AT_LISTING_51", "CAN_AGE_AT_LISTING_58", "CAN_AGE_AT_LISTING_65", "CAN_BMI_1925", "CAN_BMI_2630", "CAN_BMI_over30", 
#               "FEMALE","CAN_PREV_TX", "DIAB_ENTRY","DIAL_ENTRY","DIAL_time_1YRplus", "ASIAN", "BLACK", "OTHER_NONWHITE", "CAN_MALIG", "CAN_ACPT_HBC_POS1", 
#               "CAN_ACPT_HCV_POS1","CAN_BMI","CAN_DGN_POLY","CAN_DGN_HYPE","CAN_DGN_GLOM","CAN_EDUCATION_HS","CAN_EDUCATION_COL","CAN_EDUCATION_COLDEG")
#     }
#   }else{
#     if (educ == 0) {
#       sX <- c("EPTSlow20","CAN_AGE_AT_LISTING_51", "CAN_AGE_AT_LISTING_58", "CAN_AGE_AT_LISTING_65", "CAN_BMI_1925", "CAN_BMI_2630", "CAN_BMI_over30", 
#               "FEMALE","CAN_PREV_TX", "DIAB_ENTRY","DIAL_ENTRY","DIAL_time_1YRplus", "ASIAN", "BLACK", "OTHER_NONWHITE", "CAN_MALIG", "CAN_ACPT_HBC_POS1", 
#               "CAN_ACPT_HCV_POS1","CAN_BMI","CAN_DGN_POLY","CAN_DGN_HYPE","CAN_DGN_GLOM")
#     }else{
#       sX <- c("EPTSlow20","CAN_AGE_AT_LISTING_51", "CAN_AGE_AT_LISTING_58", "CAN_AGE_AT_LISTING_65", "CAN_BMI_1925", "CAN_BMI_2630", "CAN_BMI_over30", 
#               "FEMALE","CAN_PREV_TX", "DIAB_ENTRY","DIAL_ENTRY","DIAL_time_1YRplus", "ASIAN", "BLACK", "OTHER_NONWHITE", "CAN_MALIG", "CAN_ACPT_HBC_POS1", 
#               "CAN_ACPT_HCV_POS1","CAN_BMI","CAN_DGN_POLY","CAN_DGN_HYPE","CAN_DGN_GLOM","CAN_EDUCATION_HS","CAN_EDUCATION_COL","CAN_EDUCATION_COLDEG")
#     }
#   }
#   sTreat <- "Z"
#   streatX <- c(sTreat, sX)
#   B_ols_fn <- lm(as.formula(paste("Y ~ ", paste(streatX, collapse = "+"))), data = DF3)
#   
#   print("check1")
#   #nrow(DF3)
#   print(sum(DF3$Z))
#   print(sum((1-DF3$Z)))
#   print("check2")
#   
#   
#   # Store the results in the data frame
#   result <- data.frame(
#     Time = rr,
#     Estimate = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[2, "Estimate"],
#     Std_Error = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[2, "Std. Error"],
#     specif = "with ext. cov."
#   )
#   
#   survival_results_df <- rbind(survival_results_df, result)
#   
# 
#   ### double ML
#   DF3 <- DF4[complete.cases(DF4), ]  # drop missing rows
#   DF3$vCe = DF3$vCe* as.numeric(DF3$vCs == 0) 
#   DF3$vdurE = DF3$vdurE* as.numeric(DF3$vCs == 0) + DF3$vdurS* as.numeric(DF3$vCs == 1)
#   
#   DF3$Y <- as.numeric(DF3$vdurE >= rr)
#   DF3 <- DF3[!(as.numeric(DF3$vdurE < rr) + as.numeric(DF3$vCe == 0) == 2), ]  # remove randomly censored outcomes
#   
#   sX <- colnames(DF3[,6:(ncol(DF3)-1)])
#   print(sX)
# 
# 
#   # Define the data backend
#   dml_data <- DoubleMLData$new(data = DF3, y_col = "Y", d_cols = "Z", x_cols = sX)
# 
#   # Define ML learners
#   learner_lasso <- lrn("regr.cv_glmnet")  # LASSO for Y
#   learner_ridge <- lrn("regr.cv_glmnet")  # Ridge for D (can use LASSO too)
# 
#   # Define DML model
#   dml_plr <- DoubleMLPLR$new(dml_data, ml_l = learner_lasso, ml_m = learner_ridge,
#                              dml_procedure = "dml2", 
#                              score = "partialling out" )
# 
#   # Estimate the model
#   dml_plr$fit()
# 
#   # Extract treatment effect and heteroskedasticity-robust standard error
#   coef_estimate <- dml_plr$coef
#   se_robust <- dml_plr$se
# 
#   result <- data.frame(
#     Time = rr,
#     Estimate =dml_plr$coef,
#     Std_Error = dml_plr$se,
#     specif = "double ML"
#   )
# 
#   survival_results_df <- rbind(survival_results_df, result)
# 
#   print(survival_results_df)
#   }
# 
# # Print the resulting data frame
# print(survival_results_df)
# 
# 
# # Assuming you have a data frame named 'survival_results_df' containing your survival analysis results
# # Make sure 'size', 'effect', 'effect_se', and 'specification' columns exist in the data frame
# 
# pd <- 3
# print(ggplot(survival_results_df,
#              aes(x     = Time,
#                  y     = -Estimate,
#                  color = specif)) +
#         geom_point(shape = 15,
#                    size  = 4,
#                    position = position_dodge(pd)) +
#         geom_errorbar(aes(ymin  = -Estimate - 1.96*Std_Error,
#                           ymax  = -Estimate + 1.96*Std_Error),
#                       width = 2,
#                       size  = 1,
#                       position = position_dodge(pd)) +
#         theme_bw() +
#         theme(text = element_text(size = 20),
#               panel.grid = element_blank(),
#               legend.title = element_blank(),
#               legend.position = c(0.15, 0.86),
#               legend.background = element_rect(fill = "white",
#                                                size = 0.5, linetype = "solid", 
#                                                colour = "black")) +
#         scale_color_grey() +
#         scale_x_continuous(breaks = seq(0, 60, by = 12), limits = c(0, 62)) +
#         scale_y_continuous(breaks = seq(-0.16, 0.18, by = 0.04)) +
#         coord_cartesian(ylim = c(-0.16, 0.18)) +
#         geom_hline(yintercept = 0, linetype = "dotted") +
#         ylab("Difference in survival probability") +
#         xlab("Time in months"))
# if (post2015 == 0 & blood_types == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & educD ==0){
#   ggsave("Figures\\Pre_tx_eff_OvsAB_drob.png", width = 8, height = 5)
# }
# 
# 
# 
# 
# 
# 
# 
# 
# 



