########################################################################
##  Paper Title: Causally Evaluating Selection: Biological, 
##               Behavioral and Institutional Effects on
##               the Kidney Transplant Waitlist
#####
##
##  Purpose: Clean and prepare SRTR kidney data for analysis by blood type 
##
##  Reproducibility Information: see end of code for environment info 
##                                                                    
##  Author: Stephen Kastoryano                                        
##  Date  : 30 June 2024                                                 
##                                                                    
##           
##           
##  input:  "cand_kipa.sas7bdat" - SRTR kidney data. 
##           Contact SRTR to request data at https://www.srtr.org/requesting-srtr-data/data-requests/
##          
##
##  output: "DF_pre.RData", "DF_post.RData" - for KidneyExp_KM.R, KidneyExp_descstats.R, KidneyExp_Estim1.R, KidneyExp_EstimDTE.R
##           
##
##  Instructions: Run twice, once setting post2015 = 0 on line 47
##               and once setting post2015 = 1 on line 47        
##
##                                                                    
######################################################################################

library("haven")     
library("foreign")
library("dplyr")
library("tidyr")
library("ggplot2")    
library("survival") 
library("survminer") 

setwd("C:/Users/skast/Dropbox/ContDurMA/CompCode 2023")

# Main dataset of candidates on the waitlist
df_can1 <- read_sas("C:\\Users\\skast\\Transplant data\\cand_kipa.sas7bdat")
head(df_can1)

sum(is.na(df_can1$CAN_PHYSC_CAPACITY)) /nrow(df_can1)
table(df_can1$CAN_PHYSC_CAPACITY)
sum(is.na(df_can1$CAN_FUNCTN_STAT)) /nrow(df_can1)
table(df_can1$CAN_FUNCTN_STAT)



post2015 = 2   # Equal to 0 for pre-2015 reform analysis, 1 for post-2015 reform analysis, 2 for pre- and post-2015 figures
calentry = 0   # 0 for baseline analysis. 1 for 2002-6-01 -- 2008-9-01, 2 for 2008-9-01 -- 2014-12-01. Ensures 6 years and 3 months of calendar entries for each 

####################
### DATA SELECTION
####################

df_can=df_can1
nrow(df_can)

df_can =df_can[!(is.na(df_can$CAN_ACTIVATE_DT)),]  # remove people who don't have an activation date
nrow(df_can)

df_can= df_can[(df_can$WL_ORG =="KI"),]  # select only people set to receive kidney transplant
nrow(df_can)

# Only keep first spell on the waitlist
length(df_can$PERS_ID)
length(unique(df_can$PERS_ID))
df_can <- df_can[order(df_can$PERS_ID,df_can$CAN_ACTIVATE_DT),] # sort variables
df_can = df_can[!(duplicated(df_can[,c("PERS_ID")])),]
nrow(df_can)

# Make sure none of these people received a previous kidney transplant
sum(is.na(df_can$CAN_PREV_KI))
df_can = df_can[(df_can$CAN_PREV_KI == 0),]




df_can= df_can[(df_can$CAN_ACTIVATE_DT >="2002-6-01"),]  # Select candidates who entered waitlist after this date  
nrow(df_can)


if (post2015 == 0) {
  df_can= df_can[(df_can$CAN_ACTIVATE_DT <="2014-12-01"),]   # "2014-12-01" because allocation system was rehauled in december 2014
  
  if (calentry == 1) {
    df_can= df_can[(df_can$CAN_ACTIVATE_DT <="2008-9-01"),]   
    
  } else if (calentry == 2) {
    df_can= df_can[(df_can$CAN_ACTIVATE_DT >"2008-9-01"),]   
  }
  
} else if (post2015 == 1) {
  df_can= df_can[(df_can$CAN_ACTIVATE_DT >"2014-12-01"),]   # "2014-12-01" because allocation system was rehauled in december 2014
} else {}




nrow(df_can)



nrow(df_can)

## Preparing outcome variables ##

# some death dates are not the same, make sure death is the first registered death across systems
df_can$CAN_DEATH_DT[is.na(df_can$CAN_DEATH_DT)] <- as.Date("2023-12-01")
df_can$PERS_OPTN_DEATH_DT[is.na(df_can$PERS_OPTN_DEATH_DT)] <- as.Date("2023-12-01")
df_can$PERS_SSA_DEATH_DT[is.na(df_can$PERS_SSA_DEATH_DT)] <- as.Date("2023-12-01")

df_can$CAN_DEATH_DT = pmin(df_can$CAN_DEATH_DT,df_can$PERS_OPTN_DEATH_DT,df_can$PERS_SSA_DEATH_DT)

df_can$CAN_DEATH_DT[(df_can$CAN_DEATH_DT == "2023-12-01")] <- NA




if (post2015 == 0) {
  if (calentry == 1) {
    df_can$CAN_DEATH_DT[(df_can$CAN_DEATH_DT> as.Date("2008-9-01"))] <- as.Date("2008-9-01")   # replace death dates larger than  "2008-9-01"
    df_can$CAN_DEATH_DT = df_can$CAN_DEATH_DT %>% replace_na(as.Date("2008-9-01"))  # replace for death date NA values with last date in dataset
    df_can$CAN_DEATH_DT <- ifelse(is.na(df_can$CAN_DEATH_DT), as.Date("2008-9-01"), df_can$CAN_DEATH_DT)
    
    sum((df_can$CAN_DEATH_DT == as.Date("2008-9-01")))
    sum(!(df_can$CAN_DEATH_DT == as.Date("2008-9-01")))
    
    df_can$PERS_NEXTTX[(df_can$PERS_NEXTTX> as.Date("2008-9-01"))] <- as.Date("2008-9-01")   # replace transplant dates larger than  "2008-9-01" 
    df_can$PERS_NEXTTX = df_can$PERS_NEXTTX %>% replace_na(as.Date("2008-9-01"))   # replace for transplant date NA values with last date in dataset
    df_can$PERS_NEXTTX <- ifelse(is.na(df_can$PERS_NEXTTX), as.Date("2008-9-01"), df_can$PERS_NEXTTX)
    sum((df_can$PERS_NEXTTX == as.Date("2008-9-01"))) 
    sum(!(df_can$PERS_NEXTTX == as.Date("2008-9-01")))
    
    
    # Define duration to outcome and duration to treatment variables
    df_can$durDE = as.numeric(df_can$CAN_DEATH_DT) - as.numeric(df_can$CAN_ACTIVATE_DT)          # duration to death
    df_can$durDEC = as.numeric(df_can$CAN_DEATH_DT != as.Date("2008-9-01"))     # dummy =1 if death occured, 0 otherwise
    
    df_can$durTX = as.numeric(df_can$PERS_NEXTTX != as.Date("2008-9-01")) *(df_can$PERS_NEXTTX -as.numeric(df_can$CAN_ACTIVATE_DT)) + as.numeric(df_can$PERS_NEXTTX == as.Date("2008-9-01")) * df_can$durDE          # duration to transplant
    df_can$durTXC = as.numeric(df_can$durDE != df_can$durTX)       # dummy =1 if transplant occured, 0 otherwise
  } else {
    df_can$CAN_DEATH_DT[(df_can$CAN_DEATH_DT> as.Date("2014-12-01"))] <- as.Date("2014-12-01")   # replace death dates larger than  "2014-12-01" 
    df_can$CAN_DEATH_DT = df_can$CAN_DEATH_DT %>% replace_na(as.Date("2014-12-01"))  # replace for death date NA values with last date in dataset
    df_can$CAN_DEATH_DT <- ifelse(is.na(df_can$CAN_DEATH_DT), as.Date("2014-12-01"), df_can$CAN_DEATH_DT)
    
    sum((df_can$CAN_DEATH_DT == as.Date("2014-12-01")))
    sum(!(df_can$CAN_DEATH_DT == as.Date("2014-12-01")))
    
    df_can$PERS_NEXTTX[(df_can$PERS_NEXTTX> as.Date("2014-12-01"))] <- as.Date("2014-12-01")   # replace transplant dates larger than  "2014-12-01" 
    df_can$PERS_NEXTTX = df_can$PERS_NEXTTX %>% replace_na(as.Date("2014-12-01"))   # replace for transplant date NA values with last date in dataset
    df_can$PERS_NEXTTX <- ifelse(is.na(df_can$PERS_NEXTTX), as.Date("2014-12-01"), df_can$PERS_NEXTTX)
    sum((df_can$PERS_NEXTTX == as.Date("2014-12-01"))) 
    sum(!(df_can$PERS_NEXTTX == as.Date("2014-12-01")))
    
    
    # Define duration to outcome and duration to treatment variables
    df_can$durDE = as.numeric(df_can$CAN_DEATH_DT) - as.numeric(df_can$CAN_ACTIVATE_DT)          # duration to death
    df_can$durDEC = as.numeric(df_can$CAN_DEATH_DT != as.Date("2014-12-01"))     # dummy =1 if death occured, 0 otherwise
    
    df_can$durTX = as.numeric(df_can$PERS_NEXTTX != as.Date("2014-12-01")) *(df_can$PERS_NEXTTX -as.numeric(df_can$CAN_ACTIVATE_DT)) + as.numeric(df_can$PERS_NEXTTX == as.Date("2014-12-01")) * df_can$durDE          # duration to transplant
    df_can$durTXC = as.numeric(df_can$durDE != df_can$durTX)       # dummy =1 if transplant occured, 0 otherwise
  }
  
} else {
  df_can$CAN_DEATH_DT = df_can$CAN_DEATH_DT %>% replace_na(as.Date("2023-12-01"))  # replace for death date NA values with last date in dataset
  sum((df_can$CAN_DEATH_DT == as.Date("2023-12-01"))) 
  sum(!(df_can$CAN_DEATH_DT == as.Date("2023-12-01")))
  
  df_can$PERS_NEXTTX = df_can$PERS_NEXTTX %>% replace_na(as.Date("2023-12-01"))   # replace for transplant date NA values with last date in dataset
  sum((df_can$PERS_NEXTTX == as.Date("2023-12-01")))
  sum(!(df_can$PERS_NEXTTX == as.Date("2023-12-01")))
  
  
  # Define duration to outcome and duration to treamtent variables
  df_can$durDE = as.numeric(df_can$CAN_DEATH_DT) - as.numeric(df_can$CAN_ACTIVATE_DT)          # duration to death
  df_can$durDEC = as.numeric(df_can$CAN_DEATH_DT != as.Date("2023-12-01"))     # dummy =1 if death occured, 0 otherwise
  
  df_can$durTX = as.numeric(df_can$PERS_NEXTTX != as.Date("2023-12-01")) * (as.numeric(df_can$PERS_NEXTTX) -as.numeric(df_can$CAN_ACTIVATE_DT)) + as.numeric(df_can$PERS_NEXTTX == as.Date("2023-12-01"))* df_can$durDE          # duration to transplant
  df_can$durTXC = as.numeric(df_can$durDE != df_can$durTX)       # dummy =1 if transplant occured, 0 otherwise
}



## Remove a small number of strange observations, assumed to be random typos, non-systematic ##
nrow(df_can)
df_can =df_can[!(df_can$durDE<1),]  # remove people who have non-positive duration to death
nrow(df_can)
df_can =df_can[!(df_can$durTX<1),]  # remove people who have non-positive duration to transplant
nrow(df_can)
df_can =df_can[!(df_can$durDE <df_can$durTX ),]  # remove people who have duration to transplant larger than duration to death (1 observation)
nrow(df_can)



df_can= df_can[(df_can$CAN_AGE_AT_LISTING >=18),]  # drop under 18s who have different priority
nrow(df_can)




sum(df_can$durTXC)  # number of people who received transplant
sum(df_can$durDEC)  # number of people who died

x = nrow(df_can)
df_can =df_can[!(df_can$CAN_ABO == "A1"),]  # remove few indivudals with non-standard blood types
df_can =df_can[!(df_can$CAN_ABO == "A2"),]  # remove few indivudals with non-standard blood types
df_can =df_can[!(df_can$CAN_ABO == "A1B"),]  # remove few indivudals with non-standard blood types
df_can =df_can[!(df_can$CAN_ABO == "A2B"),]  # remove few indivudals with non-standard blood types
df_can= df_can[!is.na(df_can$CAN_ABO),]  # Drop observations with no blood type data (only 1 observation dropped)
nrow(df_can)

1-nrow(df_can)/x  # share dropped of rare blood types

# Define duration to death when censoring all death durations at the moment a person enters treatment 
df_can$durDEn = df_can$durDE*as.numeric(df_can$durDE<= df_can$durTX ) + df_can$durTX*as.numeric(df_can$durDE> df_can$durTX )
df_can$durDEnC =  as.numeric(df_can$durDE == df_can$durDEn)* as.numeric(df_can$CAN_DEATH_DT != "2023-12-01")*df_can$durDEC


DF = df_can

nrow(DF)

table(DF$CAN_ABO)





################################
### Select and clean covariates
################################


## Living donor
DF$live_don =  as.numeric(DF$DON_TY =="L")  # 1 if kidney from living donor

## Dialysis
# I don't love this dialysis variable. It is inconsistent across CAN_DIAL_DT and CAN_DIAL
# Also, almost everyone is on dialysis by entry into waitlist and most others go on dialysis shortly after entry
DF$DIAL_ENTRY = as.numeric(DF$CAN_DIAL_DT <= DF$CAN_ACTIVATE_DT)  # create binary variable=1 if on dialysis when entering the waitlist
DF$DIAL_ENTRY[is.na(DF$DIAL_ENTRY)] <- 0
DF$DIAL_ENTRY_time = as.numeric(DF$CAN_ACTIVATE_DT - DF$CAN_DIAL_DT)  # create binary variable=1 if on dialysis when entering the waitlist
DF$DIAL_ENTRY_time[(DF$DIAL_ENTRY_time <0)] <- 0
DF$DIAL_ENTRY_time[is.na(DF$DIAL_ENTRY_time)] <- 0
table(DF$DIAL_ENTRY)  # On Dialysis when entering the waitlist
sum(is.na(DF$DIAL_ENTRY)) 
# You probably want to do an analysis with an without these observations as robustness check
table(DF$DIAL_ENTRY_time)

# Generate varible for on dialysis for over a year
DF$DIAL_time_1YRplus = as.numeric(DF$DIAL_ENTRY_time > 365)

# # Selection on Dialysis variable
# df_can_final$DIAL_ENTRY[is.na(df_can_final$DIAL_ENTRY)] <- 999
# nrow(df_can_final)
# df_can_final =df_can_final[(df_can_final$DIAL_ENTRY != 0),]   # only keep people observed to be on dialysis.
# nrow(df_can_final)
# df_can_final$DIAL_ENTRY[(df_can_final$DIAL_ENTRY == 999)] <- NA
# # This variable is problematic. You probably want to do an analysis with an without these observation and then conduct robustness check


## Calculated Candidate Age at Listing
nrow(DF)
table(DF$CAN_AGE_AT_LISTING)  

# Generate a set of age variables
DF$CAN_AGE_AT_LISTING_35up = as.numeric(DF$CAN_AGE_AT_LISTING >= 35)
DF$CAN_AGE_AT_LISTING_41 = as.numeric(DF$CAN_AGE_AT_LISTING <= 41)
DF$CAN_AGE_AT_LISTING_51 = as.numeric(DF$CAN_AGE_AT_LISTING > 41)*as.numeric(DF$CAN_AGE_AT_LISTING <= 51)
DF$CAN_AGE_AT_LISTING_58 = as.numeric(DF$CAN_AGE_AT_LISTING > 51)*as.numeric(DF$CAN_AGE_AT_LISTING <= 58)
DF$CAN_AGE_AT_LISTING_65 = as.numeric(DF$CAN_AGE_AT_LISTING > 58)*as.numeric(DF$CAN_AGE_AT_LISTING <= 65)
DF$CAN_AGE_AT_LISTING_65up = as.numeric(DF$CAN_AGE_AT_LISTING > 65)
DF$CAN_AGE_AT_LISTING_SQ = DF$CAN_AGE_AT_LISTING^2
DF$CAN_AGE_AT_LISTING_CB = DF$CAN_AGE_AT_LISTING^3



## Education level
table(DF$CAN_EDUCATION)  
sum(is.na(DF$CAN_EDUCATION))
DF$CAN_EDUCATION[(DF$CAN_EDUCATION > 6)] <- NA
DF$CAN_EDUCATION_HS = as.numeric(DF$CAN_EDUCATION < 4)
DF$CAN_EDUCATION_COL = as.numeric(DF$CAN_EDUCATION == 4)  # Any college
DF$CAN_EDUCATION_COLDEG = as.numeric(DF$CAN_EDUCATION > 4)
sum(is.na(DF$CAN_EDUCATION))

## Patient/s Employment Status
table(DF$CAN_EMPL_STAT) 
sum(is.na(DF$CAN_EMPL_STAT))  ## ->>> Unusable, too many NA


## Candidate BMI
table(DF$CAN_BMI)  # Candidate BMI
sum(is.na(DF$CAN_BMI))  
DF$CAN_BMI[(DF$CAN_BMI > 70)] <- NA
DF$CAN_BMI_under19 = as.numeric(DF$CAN_BMI <=19)
DF$CAN_BMI_1925= as.numeric(DF$CAN_BMI > 19)*as.numeric(DF$CAN_BMI <= 25)
DF$CAN_BMI_2630= as.numeric(DF$CAN_BMI > 25)*as.numeric(DF$CAN_BMI <= 30)
DF$CAN_BMI_over30 = as.numeric(DF$CAN_BMI > 30)


# Patient hypertension 
table(DF$CAN_DRUG_TREAT_HYPERTEN)  # There are too many unobserved variables to add as covariate
sum(is.na(DF$CAN_DRUG_TREAT_HYPERTEN))


## Creatinine measures of candidate are not very well registered
# CAN_MOST_RECENT_CREAT has about 33% missing values
# CAN_CREAT_CLEAR has about has 96% missing values
table(DF$CAN_CREAT_CLEAR) # Candidate creatinine measure. There are too many unobserved variables to add as covariate
sum(is.na(DF$CAN_CREAT_CLEAR))


## 	Any previous Malignancy
table(DF$CAN_MALIG) 
sum(is.na(DF$CAN_MALIG)) 
DF$CAN_MALIG[as.logical(1-as.numeric((DF$CAN_MALIG == "Y"))-as.numeric((DF$CAN_MALIG == "N")))] <- NA
DF$CAN_MALIG[(DF$CAN_MALIG == "Y")] <- 1
DF$CAN_MALIG[(DF$CAN_MALIG == "N")] <- 0
DF$CAN_MALIG =  as.numeric(DF$CAN_MALIG)
sum(is.na(DF$CAN_MALIG)) 

## SRTR Patient Race
table(DF$CAN_RACE_SRTR)  
sum(is.na(DF$CAN_RACE_SRTR)) 
DF$ASIAN = as.numeric(DF$CAN_RACE_SRTR == "ASIAN")
DF$BLACK = as.numeric(DF$CAN_RACE_SRTR == "BLACK")
DF$OTHER_NONWHITE = as.numeric(DF$CAN_RACE_SRTR == "MULTI") + as.numeric(DF$CAN_RACE_SRTR == "NATIVE") + as.numeric(DF$CAN_RACE_SRTR == "PACIFIC")
DF$WHITE = as.numeric(DF$CAN_RACE_SRTR == "WHITE")


## Previous Transplants
table(DF$CAN_PREV_TX)  
sum(is.na(DF$CAN_PREV_TX)) 


## Biological sex
DF$FEMALE = as.numeric(DF$CAN_GENDER == "F")


## Age at Diabetes Onset
table(DF$CAN_AGE_DIAB)  
sum(is.na(DF$CAN_AGE_DIAB))  

DF$DIAB_ENTRY = as.numeric(DF$CAN_AGE_DIAB <= DF$CAN_AGE_AT_LISTING )   # create binary variable=1 if diabetic when entering the waitlist
DF$DIAB_ENTRY[is.na(DF$DIAB_ENTRY)] <-0
table(DF$DIAB_ENTRY)  # Diabetic when entering the waitlist
sum(is.na(DF$DIAB_ENTRY)) 


## Main reason why candidate needs transplant is Type-II diabetes
DF$diab_type2 = as.numeric(DF$CAN_DGN == 3070 )



## Patient functional status. This may be a bad control as it is not necessarily measured at entry
DF$CAN_FUNCTN_STATn = as.numeric(DF$CAN_FUNCTN_STAT>2000)*as.numeric(DF$CAN_FUNCTN_STAT<2031) + 3*as.numeric(DF$CAN_FUNCTN_STAT ==3) + ## Poor health
  2*as.numeric(DF$CAN_FUNCTN_STAT>2039)*as.numeric(DF$CAN_FUNCTN_STAT<2061) + 2*as.numeric(DF$CAN_FUNCTN_STAT ==2) + ## Medium health
  3*as.numeric(DF$CAN_FUNCTN_STAT == 1) + 3*as.numeric(DF$CAN_FUNCTN_STAT > 2069)  ## Good health
DF$CAN_FUNCTN_STATn[(DF$CAN_FUNCTN_STAT == 998)] <- NA
DF$CAN_FUNCTN_STATn[(DF$CAN_FUNCTN_STAT == 996)] <- NA
##### Which Kidney characteristics will not be accepted
table(DF$CAN_FUNCTN_STATn)

## Accept an Hepatitis B Core Antibody Positive Donor?
table(DF$CAN_ACPT_HBC_POS)  
sum(is.na(DF$CAN_ACPT_HBC_POS))
DF$CAN_ACPT_HBC_POS1 = as.numeric(DF$CAN_ACPT_HBC_POS == "Y")  # 1 if Accept an Hepatitis B Core Antibody Positive Donor


## Accept an HCV Positive donor?
table(DF$CAN_ACPT_HCV_POS)   
sum(is.na(DF$CAN_ACPT_HCV_POS))
DF$CAN_ACPT_HCV_POS1 = as.numeric(DF$CAN_ACPT_HCV_POS == "Y") # 1 if Accept an HCV Positive donor?


## Accepted Creatinine level of Donor?
table(DF$CAN_MIN_PEAK_CREAT) 
sum(is.na(DF$CAN_MIN_PEAK_CREAT))

nrow(DF)
DF$CAN_MIN_PEAK_CREAT[(DF$CAN_MIN_PEAK_CREAT > 20)] <- NA  # Values above 20 are missing values

sum(is.na(DF$CAN_MIN_PEAK_CREAT))
sum(as.numeric(DF$CAN_MIN_PEAK_CREAT > 5), na.rm=T)

DF$CAN_MIN_PEAK_CREAT_5up = as.numeric(DF$CAN_MIN_PEAK_CREAT > 5) # 1 if Creatinine level above 5

## Note: Other kidney acceptance variables have excessively large amounts of NA



nrow(DF)
## Cleaning and including PRA  ##

df_canPRA <- read_sas("C:\\Users\\skast\\Transplant data\\pra_hist.sas7bdat")
head(df_canPRA)
df_canPRA =df_canPRA[(df_canPRA$WL_ORG == "KI"),]  # remove people who are not registered for kidney transplant
nrow(df_canPRA)

#order
df_canPRA <- df_canPRA %>%
  arrange(PX_ID, CANHX_BEGIN_DT)

df_canPRA = df_canPRA[!(duplicated(df_canPRA[,c("PX_ID")])),] # drop duplicates and only keep first CPRA measure
df_canPRA_merge = df_canPRA[,c("PX_ID", "CANHX_CPRA")]

DF <- merge(DF, df_canPRA_merge, df_canPRA_merge="PX_ID") # merge to main DF
nrow(DF)

# Generate CPRA dummies
DF$CANHX_CPRA_0 = as.numeric(DF$CANHX_CPRA == 0)
DF$CANHX_CPRA_60 = as.numeric(DF$CANHX_CPRA <= 0.6)
DF$CANHX_CPRA_100 =  as.numeric(DF$CANHX_CPRA > 0.6)








### Cleaning additional candidate, donor and candidate-donor interaction variables ##
### The distinction is that these variables evolve over time on the waitlist and
## we only observe their value from the last checkup or from right before they
## receive a transplant. What is more, these are also choice variables in that 
## physicians and transplant centers, ad candidates may be choosing whether to 
## have a transplant depending on these evolving characteristics. Because of this
## we will consider them as a separate category of covariates in the analysis.


# Wolfe et. al. variables

# Candidate:  
#   main: c("DIAL_ENTRY_time", "CAN_BMI","CAN_DGN_POLY","CAN_DGN_HYPE","CAN_DGN_GLOM", "CAN_LISTING_CTR_ID") 
#   potential bad control c("CAN_FUNCTN_STATn") # Note this is not used in Wolfe study. education variable should be added to this 
#   extra with high share missing: c("CAN_TOT_ALBUMIN", "CAN_TOT_ALBUMIN_miss")

# Candidate total albumin (g/dL)
sum(is.na(DF$CAN_TOT_ALBUMIN)) /nrow(DF) # This one has a good amount of missing values, not sure
table(DF$CAN_TOT_ALBUMIN)
DF$CAN_TOT_ALBUMIN_miss = as.numeric(is.na(DF$CAN_TOT_ALBUMIN))

sum(is.na(DF$DIAL_ENTRY_time))/nrow(DF)


# Candidate diagnosis
DF$CAN_DGN_POLY = as.numeric(DF$CAN_DGN == 3008) 
DF$CAN_DGN_HYPE = as.numeric(DF$CAN_DGN == 3040) 
DF$CAN_DGN_GLOM = as.numeric(DF$CAN_DGN >= 3000) * as.numeric(DF$CAN_DGN <= 3006) 
DF$CAN_DGN_OTHE = 1 - DF$CAN_DGN_POLY - DF$CAN_DGN_HYPE - DF$CAN_DGN_GLOM

sum(is.na(DF$CAN_LISTING_CTR_ID)) /nrow(DF) # This one has a good amount of missing values, not sure
table(DF$CAN_LISTING_CTR_ID)




# This is info at moment of transplant
df_can_tx1 <- read_sas("C:\\Users\\skast\\Transplant data\\tx_ki.sas7bdat")
df_can_tx = df_can_tx1
head(df_can_tx)



# Candidate-donor match:
#   main: c("REC_A_MM_EQUIV_TX0", "REC_A_MM_EQUIV_TX1", "REC_A_MM_EQUIV_TX2", "REC_B_MM_EQUIV_TX0","REC_B_MM_EQUIV_TX1","REC_B_MM_EQUIV_TX2","REC_DR_MM_EQUIV_TX0","REC_DR_MM_EQUIV_TX1","REC_DR_MM_EQUIV_TX2","DON_ORG_SHARED") 

df_can_tx$REC_A_MM_EQUIV_TX0 = as.numeric(df_can_tx$REC_A_MM_EQUIV_TX == 0) 
df_can_tx$REC_A_MM_EQUIV_TX1 = as.numeric(df_can_tx$REC_A_MM_EQUIV_TX == 1)
df_can_tx$REC_A_MM_EQUIV_TX2 = as.numeric(df_can_tx$REC_A_MM_EQUIV_TX == 2)

df_can_tx$REC_B_MM_EQUIV_TX0 = as.numeric(df_can_tx$REC_B_MM_EQUIV_TX == 0) 
df_can_tx$REC_B_MM_EQUIV_TX1 = as.numeric(df_can_tx$REC_B_MM_EQUIV_TX == 1)
df_can_tx$REC_B_MM_EQUIV_TX2 = as.numeric(df_can_tx$REC_B_MM_EQUIV_TX == 2)

df_can_tx$REC_DR_MM_EQUIV_TX0 = as.numeric(df_can_tx$REC_DR_MM_EQUIV_TX == 0) 
df_can_tx$REC_DR_MM_EQUIV_TX1 = as.numeric(df_can_tx$REC_DR_MM_EQUIV_TX == 1)
df_can_tx$REC_DR_MM_EQUIV_TX2 = as.numeric(df_can_tx$REC_DR_MM_EQUIV_TX == 2)


df_can_tx$GRAFT_FAIL = !is.na(df_can_tx$REC_FAIL_DT)


# Donor characteristics:
#   main: c("DON_AGE","DON_WGT_KG","DON_CAD_DON_COD_ANOX","DON_CAD_DON_COD_CERE","DON_CAD_DON_COD_HEAD","DON_CAD_DON_COD_TUMO","DON_CAD_DON_COD_OTHE") 

# Donation after cardiac death - Could not find corresponding variable
# Donor cytomegalovirus negative - Could not find corresponding variable
# Donor hypertension - too many missing ~ 25%

sum(is.na(df_can_tx$DON_CAD_DON_COD)) /nrow(df_can_tx)
table(df_can_tx$DON_CAD_DON_COD)


df_can_tx$DON_CAD_DON_COD_ANOX = as.numeric(df_can_tx$DON_CAD_DON_COD == 1) 
df_can_tx$DON_CAD_DON_COD_CERE = as.numeric(df_can_tx$DON_CAD_DON_COD == 2)
df_can_tx$DON_CAD_DON_COD_HEAD = as.numeric(df_can_tx$DON_CAD_DON_COD == 3)
df_can_tx$DON_CAD_DON_COD_TUMO = as.numeric(df_can_tx$DON_CAD_DON_COD == 4)
df_can_tx$DON_CAD_DON_COD_OTHE = as.numeric(df_can_tx$DON_CAD_DON_COD == 999)


df_can_tx_sub <- df_can_tx[,c("PX_ID", "GRAFT_FAIL", "REC_A_MM_EQUIV_TX","REC_B_MM_EQUIV_TX","REC_DR_MM_EQUIV_TX","REC_MM_EQUIV_TX", "REC_A_MM_EQUIV_TX0", "REC_A_MM_EQUIV_TX1", "REC_A_MM_EQUIV_TX2", "REC_B_MM_EQUIV_TX0","REC_B_MM_EQUIV_TX1","REC_B_MM_EQUIV_TX2","REC_DR_MM_EQUIV_TX0","REC_DR_MM_EQUIV_TX1","REC_DR_MM_EQUIV_TX2","DON_ORG_SHARED","DON_AGE","DON_WGT_KG","DON_CAD_DON_COD_ANOX","DON_CAD_DON_COD_CERE","DON_CAD_DON_COD_HEAD","DON_CAD_DON_COD_TUMO","DON_CAD_DON_COD_OTHE")]

nrow(DF)

DF <- DF %>%
  left_join(df_can_tx_sub, by = "PX_ID")
nrow(DF)


##  save files 
if (post2015 == 0){
  if (calentry == 0) {
    save(DF, file="DF_pre.RData") 
  } else if (calentry == 1) {
    save(DF, file="DF_pre0208.RData") 
  } else {
    save(DF, file="DF_pre0814.RData")
  }
} else if (post2015 == 1){
  save(DF, file="DF_post.RData")
} else {
  save(DF, file="DF_all.RData") 
}


# Candidate:  
#   main: c("DIAL_ENTRY_time", "CAN_BMI","CAN_DGN_POLY","CAN_DGN_HYPE","CAN_DGN_GLOM", "CAN_LISTING_CTR_ID") 
#   potential bad control c("CAN_FUNCTN_STATn") # Note this is not used in Wolfe study. education variable should be added to this 
#   extra with high share missing: c("CAN_TOT_ALBUMIN", "CAN_TOT_ALBUMIN_miss")

# Donor characteristics:
#   main: c("DON_AGE","DON_WGT_KG","DON_CAD_DON_COD_ANOX","DON_CAD_DON_COD_CERE","DON_CAD_DON_COD_HEAD","DON_CAD_DON_COD_TUMO","DON_CAD_DON_COD_OTHE") 


# Candidate-donor match:
#   main: c("REC_A_MM_EQUIV_TX0", "REC_A_MM_EQUIV_TX1", "REC_A_MM_EQUIV_TX2", "REC_B_MM_EQUIV_TX0","REC_B_MM_EQUIV_TX1","REC_B_MM_EQUIV_TX2","REC_DR_MM_EQUIV_TX0","REC_DR_MM_EQUIV_TX1","REC_DR_MM_EQUIV_TX2","DON_ORG_SHARED") 



# # This is transplant follow-up data. THe problem is that all of these outcomes will be jointly detemined with survival
# # So they will make little sense analysed on their own
# df_can_fol <- read_sas("C:\\Users\\skast\\Transplant data\\txf_ki.sas7bdat")
# head(df_can_fol)
# # Candidate cause of death - almost all many missing 
# sum(is.na(df_can_fol$TFL_COD)) /nrow(df_can_fol)
# table(df_can_fol$TFL_COD)
# # Candidate physical capacity - too many missing 
# sum(is.na(df_can_fol$TFL_PHYSC_CAPACITY)) /nrow(df_can_fol)
# table(df_can_fol$TFL_PHYSC_CAPACITY)
# # Candidate functional status - this is good. use it
# sum(is.na(df_can_fol$TFL_FUNCTN_STAT)) /nrow(df_can_fol)
# table(df_can_fol$TFL_FUNCTN_STAT)
# # Date of kidney graft failure - I also like this as a measure
# sum(is.na(df_can_fol$TFL_FAIL_DT)) /nrow(df_can_fol)
# table(df_can_fol$TFL_FAIL_DT)
























# All relevant information from this is in TX_KI dataset (donor info, )
# df_can6 <- read_sas("C:\\Users\\skast\\Transplant data\\rec_histo.sas7bdat")
# head(df_can6)


# For now not necessary, but might be used for a robustness check down the line
# df_can4 <- read_sas("C:\\Users\\skast\\Transplant data\\stathist_kipa.sas7bdat")
# head(df_can4)

# Don't think you'll need this for current project. Maybe for future ones. All the relevant comparative info is in candidate dataset
# df_can7 <- read_sas("C:\\Users\\skast\\Transplant data\\institution.sas7bdat")
# head(df_can7)

# Don't think you'll need this for current project. Maybe for future ones. All the relevant comparative info is in candidate dataset
# df_can10 <- read_sas("C:\\Users\\skast\\Transplant data\\hist_opo_txc.sas7bdat")
# head(df_can10)


# The donor disposition data just ahs way too many missing values. I don't think 
# anything reliable can be done with it
# df_can13 <- read_sas("C:\\Users\\skast\\Transplant data\\donor_disposition.sas7bdat")
# head(df_can13)
# 
# nrow(df_can13)
# table(df_can13$DON_SHARE_TY) # This variable has a code for zero-antigen mismatch, but the variable is way to incomplete
# sum(is.na(df_can13$DON_SHARE_TY)) /nrow(df_can13)
# sum(is.na(df_can13$DON_DISPOSITION)) /nrow(df_can13)
# table(df_can13$DON_DISPOSITION)

# I can't see anyting here you can readily use, you mostly need the compatibility data
# df_can14 <- read_sas("C:\\Users\\skast\\Transplant data\\donor_deceased.sas7bdat")
# head(df_can14)





# 
# #### Checking cause of death of donated kidney's donor
# ##################################
# 
# df_can2 <- read_sas("C:\\Users\\skast\\Transplant data\\donor_deceased.sas7bdat")
# 
# post2015 = 0      # Equal to 0 for pre-2015 reform analysis baseline, 1 for post-2015 reform analysis
# ##  Load files 
# if (post2015 == 0){
#   load("DF_pre.RData")
# }else{
#   load("DF_post.RData")
# }
# 
# table(df_can2$DON_DEATH_CIRCUM)
# 
# df_can2_unique <- df_can2 %>%
#   group_by(DONOR_ID) %>%
#   sample_n(1) %>%
#   select(DONOR_ID, DON_DEATH_CIRCUM, DON_DEATH_MECH)
# 
# # Step 2: Merge the selected rows with the main data frame DF
# merged_df <- DF %>%
#   left_join(df_can2_unique, by = "DONOR_ID")
# 
# table(merged_df$DON_DEATH_CIRCUM)
# table(merged_df$DON_DEATH_CIRCUM > 0)
# table(!is.na(merged_df$DON_DEATH_CIRCUM))
# 
# 
# table(merged_df$DON_DEATH_MECH)
# table(merged_df$DON_DEATH_MECH > 0)
# table(!is.na(merged_df$DON_DEATH_MECH))
# 




# > sessionInfo()
# R version 4.3.1 (2023-06-16 ucrt)
# Platform: x86_64-w64-mingw32/x64 (64-bit)
# Running under: Windows 11 x64 (build 22631)
# 
# Matrix products: default
# 
# 
# locale:
#   [1] LC_COLLATE=English_United Kingdom.utf8  LC_CTYPE=English_United Kingdom.utf8   
# [3] LC_MONETARY=English_United Kingdom.utf8 LC_NUMERIC=C                           
# [5] LC_TIME=English_United Kingdom.utf8    
# 
# time zone: Europe/London
# tzcode source: internal
# 
# attached base packages:
#   [1] stats     graphics  grDevices utils     datasets  methods   base     
# 
# other attached packages:
#   [1] survminer_0.4.9 ggpubr_0.6.0    survival_3.5-5  ggplot2_3.4.2   tidyr_1.3.0     foreign_0.8-84  haven_2.5.3    
# [8] dplyr_1.1.2   




