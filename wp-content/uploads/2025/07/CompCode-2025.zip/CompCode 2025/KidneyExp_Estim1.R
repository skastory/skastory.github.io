########################################################################
##  Paper Title: Causally Evaluating Selection: Biological, 
##               Behavioral and Institutional Effects on
##               the Kidney Transplant Waitlist
#####
##                                                                    
##  Purpose: Estimate of period t=1 effects and heterogenous effects on treatment and survival  
##
##  Reproducibility Information: see end of code for environment info 
##                                                                    
##  Author: Stephen Kastoryano                                        
##  Date  : 30 June 2024                                                 
##                                                      
##           
##  input:  "DF_pre.RData", "DF_post.RData", "DF_all.RData" from KidneyExp_clean
##          
##
##  output: Figure 5 in Text and All Figures in Appendix:'Heterogeneous effects using Type-II diabetes as a proxy for poor health' (except Km by diabetes status figure)
##           
##
##  Instructions: Run twice, once setting post2015 = 0 on line 51
##               and once setting post2015 = 1 on line 51 (only for 'New Kidney Allocation' Figure in Appendix: Testing differential probability of transplant at t = 1)  
##
##                                                                    
######################################################################################


library("foreign")
library("dplyr")
library("tidyr")
library("ggplot2")    
library("lmtest")
library("sandwich")
library("clubSandwich")
library("mice")
library("VIM")
library("fastDummies")
library("DoubleML")
library(mlr3)
library(mlr3learners)

setwd("C:/Users/skast/Dropbox/ContDurMA/CompCode 2023")

set.seed(5327456)




####################
### LOAD DATA, DEFINE SAMPLE
####################



post2015 = 0  # Equal to 0 for pre-2015 reform analysis, 1 for post-2015 reform analysis, 2 for pre- and post-2015 figures
blood_types = 0   # Equal to 0 for AB vs O type, 1 for B vs O type, 2 for A vs O type, 3 for all
livingdon = 0     # 0 for baseline without living donor transplant candidates,Equal to 1 if we want to keep living donor transplants in data
calentry = 0      # 0 for baseline 2002-6-01 -- 2014-12-01, 1 for 2002-6-01 -- 2008-9-01, 2 for 2008-9-01 -- 2014-12-01. Ensures 6 years and 3 months of calendar entries for each 
covadj = 0        # 0 for baseline, 1 for specification with additional adjustments on covariates to check small differences in balance are not driving selection on observables  
race = 1          # 0 for baseline all, 1 for white, 2 for non-white
biosex = 0        # 0 for baseline all, 1 for male, 2 for female
diab_ent = 0       # 0 for baseline all, 1 for diabetes at entry, 2 no diabetes at entry
diab_t2 = 0       # 0 for baseline all, 1 for Type 2 diabetes as main reason for transplant, 2 for not Type 2 diabetes as main reason for transplant
hcv_pos_don = 0   # 0 is baseline not removing candidates who would accept HCV positive donor kidney (very unhealthy kidney), 1 if removing
cpra = 0          # 0 is baseline removing candidates who have CPRA above 0, 1 if all CPRA included
Dtau <- 3  # Choose treatment window for t=1 Should show for Dtau = 3 in main and Dtau = 1 
dtau1 <- c(3) # Different choices of treatment window for t=1
dial <- 0     # 0 for baseline controlling for dialysis status and time on dialysis at entry and imputing 'no dialysis' for NAs, 1 not controlling for dialysis status and  and time on dialysis at entry
educ <- 0     # 0 for baseline not controlling for education, 1 includes education variables but drops over 10% of sample as well
educD <- 0         # 0 is baseline including everyone, 1 includes HS degree or less, 2 includes 'some college', 3 includes at least a college degree   
Rcens = 240          # tau is duration since entering waitlist, 116 is baseline to make pre- and post- comparable
fun_abil = 0      # 0 all functional ability, 1 only high functional ability
if (post2015 == 1) {
  Rcens = 96
}
Rcens



##  Load files 
if (post2015 == 0){
  if (calentry == 0) {
    load("DF_pre.RData")
  } else if (calentry == 1) {
    load("DF_pre0208.RData")  
  } else {
    load("DF_pre0814.RData") 
  }
} else if (post2015 == 1){
  load("DF_post.RData")
} else {
  load("DF_all.RData") 
}



# Define for Type 2 diabetes as main reason for transplant
DF$diab_type2 = as.numeric(DF$CAN_DGN == 3070 ) # 1 if if Type 2 diabetes is main reason for transplant

table(DF$CAN_DGN)

table(DF$DIAL_ENTRY_time)


table(DF$DIAL_ENTRY)  # On Dialysis when entering the waitlist
sum(is.na(DF$DIAL_ENTRY)) 


## EPTS score AT ENTRY! for new kidney allocation analysis at t=1
if (post2015 >= 1){
  if (dial == 0){
    DF$DIAL_ENTRY_time_yr = round(DF$DIAL_ENTRY_time/ 365.25)
    DF$DIAL_ENTRY_time_yr[is.na(DF$DIAL_ENTRY_time_yr)] <- 0
    DF$DIAL_ENTRY[is.na(DF$DIAL_ENTRY)] <- 0
    DF$EPTSscore = 0.047 * max(DF$CAN_AGE_AT_LISTING - 25, 0) - 0.015 * DF$DIAB_ENTRY * max(DF$CAN_AGE_AT_LISTING - 25, 0) +
      0.398 * DF$CAN_PREV_TX - 0.237 * DF$DIAB_ENTRY * DF$CAN_PREV_TX +
      0.315 * log(DF$DIAL_ENTRY_time_yr + 1) - 0.099 * DF$DIAB_ENTRY * log(DF$DIAL_ENTRY_time_yr + 1) +
      0.130 * (1-DF$DIAL_ENTRY) - 0.348 * DF$DIAB_ENTRY * (1-DF$DIAL_ENTRY) + 1.262 * DF$DIAB_ENTRY
  }else{
    DF$EPTSscore = 0.047 * max(DF$CAN_AGE_AT_LISTING - 25, 0) - 0.015 * DF$DIAB_ENTRY * max(DF$CAN_AGE_AT_LISTING - 25, 0) +
      0.398 * DF$CAN_PREV_TX - 0.237 * DF$DIAB_ENTRY * DF$CAN_PREV_TX 
  }
  
  
  threshold <- quantile(DF$EPTSscore, 0.2)
  # Create a new variable DF$EPTSlow20 which represents prioritised candidates
  DF$EPTSlow20 <- ifelse(DF$EPTSscore <= threshold, 1, 0)
  
}


####################
### DATA SELECTION
####################


## Select blood types for comparison

if (blood_types == 0) {  # AB vs O
  # These lines must be include for AB vs. O analysis
  DF = DF[(DF$CAN_ABO != "A"),]   # Drop type A blood types 
  DF = DF[(DF$CAN_ABO != "B"),]   # Drop type B blood types 
  print(table(DF$CAN_ABO))
} else if (blood_types == 1) {  # B vs O
  DF = DF[(DF$CAN_ABO != "A"),]   # Drop type A blood types 
  DF = DF[(DF$CAN_ABO != "AB"),]   # Drop type AB blood types 
  print(table(DF$CAN_ABO))
} else if (blood_types == 2) {  # A vs O
  DF = DF[(DF$CAN_ABO != "B"),]   # Drop type B blood types 
  DF = DF[(DF$CAN_ABO != "AB"),]   # Drop type AB blood types 
  print(table(DF$CAN_ABO))
}


## Include living donors or not
if (livingdon == 0){
  DF =DF[(DF$DON_TY !="L"),]   # remove anyone who received kidney from living donor
}
nrow(DF)



if (covadj == 1){
  ### This code ensures that the distribution of health related variables are balanced in their mean
  ## It is ad hoc, in the sense that this code should not be replicated for other subsamples than the baseline one (all intial variables set to 0 besides 'covadj = 1')
  set.seed(3263)
  
  # Adjust for potential differences in age
  
  # Set the parameter to control the share of rows to drop
  param <- 0.152  # Adjust this value based on your preference
  # Calculate the probability of dropping each row based on CAN_AGE_AT_LISTING
  prob_drop <- 1-pnorm(DF$CAN_AGE_AT_LISTING, mean = mean(DF$CAN_AGE_AT_LISTING), sd = sd(DF$CAN_AGE_AT_LISTING))
  # Adjust the probability based on the parameter
  prob_drop <- prob_drop * param
  # Create a logical vector indicating whether each row of "not AB" should be dropped
  rows_to_drop <- DF$CAN_ABO != "AB" & runif(nrow(DF)) < prob_drop
  # Create the modified data frame by dropping the selected rows
  df_modified <- DF[!rows_to_drop, ]
  
  # Adjust for potential differences in diabetes 
  
  # Set the parameter to control the share of rows to drop
  param <- 0.045  # Adjust this value based on your preference
  # Calculate the probability of dropping each row based on CAN_AGE_AT_LISTING
  prob_drop <- 1-pnorm(df_modified$DIAB_ENTRY, mean = mean(df_modified$DIAB_ENTRY), sd = sd(df_modified$DIAB_ENTRY))
  # Adjust the probability based on the parameter
  prob_drop <- prob_drop * param
  # Create a logical vector indicating whether each row of "not AB" should be dropped
  rows_to_drop <- df_modified$CAN_ABO != "AB" & runif(nrow(df_modified)) < prob_drop
  # Create the modified data frame by dropping the selected rows
  df_modified <- df_modified[!rows_to_drop, ]
  
  
  # Adjust for potential differences in whether person received previous transplant 
  
  # Set the parameter to control the share of rows to drop
  param <- 0.29  # Adjust this value based on your preference
  # Calculate the probability of dropping each row based on CAN_AGE_AT_LISTING
  prob_drop <- 1-pnorm(df_modified$CAN_PREV_TX, mean = mean(df_modified$CAN_PREV_TX), sd = sd(df_modified$CAN_PREV_TX))
  # Adjust the probability based on the parameter
  prob_drop <- prob_drop * param
  # Create a logical vector indicating whether each row of "not AB" should be dropped
  rows_to_drop <- df_modified$CAN_ABO != "AB" & runif(nrow(df_modified)) < prob_drop
  # Create the modified data frame by dropping the selected rows
  df_modified <- df_modified[!rows_to_drop, ]
  
  # Check balance
  mean(df_modified$CAN_AGE_AT_LISTING[(df_modified$CAN_ABO == 'AB')], na.rm = TRUE)
  mean(df_modified$CAN_AGE_AT_LISTING[(df_modified$CAN_ABO != 'AB')], na.rm = TRUE)
  
  mean(df_modified$DIAB_ENTRY[(df_modified$CAN_ABO == 'AB')], na.rm = TRUE)
  mean(df_modified$DIAB_ENTRY[(df_modified$CAN_ABO != 'AB')], na.rm = TRUE)
  
  mean(df_modified$CAN_MALIG[(df_modified$CAN_ABO == 'AB')], na.rm = TRUE)
  mean(df_modified$CAN_MALIG[(df_modified$CAN_ABO != 'AB')], na.rm = TRUE)
  
  mean(df_modified$CAN_PREV_TX[(df_modified$CAN_ABO == 'AB')], na.rm = TRUE)
  mean(df_modified$CAN_PREV_TX[(df_modified$CAN_ABO != 'AB')], na.rm = TRUE)
  
  
  sum(DF$CAN_ABO == 'AB')
  sum(df_modified$CAN_ABO == 'AB')
  sum(DF$CAN_ABO != 'AB')
  sum(df_modified$CAN_ABO != 'AB')
  
  DF = df_modified
  
}
nrow(DF)

mean(DF$CAN_AGE_AT_LISTING[(DF$CAN_ABO == 'AB')], na.rm = TRUE)
mean(DF$CAN_AGE_AT_LISTING[(DF$CAN_ABO != 'AB')], na.rm = TRUE)


if (race == 1){
  DF = DF[(DF$CAN_RACE_SRTR == "WHITE"),]
} else if (race == 2){
  DF = DF[(DF$CAN_RACE_SRTR != "WHITE"),]
}
nrow(DF)


if (biosex == 1){
  DF = DF[(DF$FEMALE == 0),]
} else if (biosex == 2){
  DF = DF[(DF$FEMALE == 1),]
}

if (diab_ent == 1){
  DF = DF[(DF$DIAB_ENTRY == 1 ),]
} else if (diab_ent == 2){
  DF = DF[(DF$DIAB_ENTRY == 0 ),]
}

if (diab_t2 == 1){
  DF = DF[(DF$CAN_DGN == 3070 ),]
} else if (diab_t2 == 2){
  DF = DF[(DF$CAN_DGN != 3070 ),]
}


if (educD == 1) {  # includes HS degree or less
  DF = DF[!is.na(DF$CAN_EDUCATION_HS),]
  DF = DF[(DF$CAN_EDUCATION_HS == 1),]
} else if (educD == 2) {  # includes 'some college'
  DF = DF[!is.na(DF$CAN_EDUCATION_COL),]
  DF = DF[(DF$CAN_EDUCATION_COL == 1),] 
} else if (educD == 3) {  # includes at least a college degree
  DF = DF[!is.na(DF$CAN_EDUCATION_COLDEG),]
  DF = DF[(DF$CAN_EDUCATION_COLDEG == 1),]
}

if (cpra == 0) {
  DF <- DF[DF$CANHX_CPRA == 0, ]   # only keep CPRA == 0 people. So excluding all individuals with antibodies
}


if (fun_abil == 1) {
  DF <- DF[DF$CAN_FUNCTN_STATn == 3, ]   # only keep CPRA == 0 people. So excluding all individuals with antibodies
}


DF2 = DF
DF2$Z <- as.numeric(DF2$CAN_ABO == "AB")   # define regime
#DF2 = DF2[(DF2$vdurE > Dtau),]





table(DF$DIAB_ENTRY)
sum(is.na(DF$DIAB_ENTRY))

table(DF$diab_type2)
sum(is.na(DF$diab_type2))


table(DF$CAN_DGN)
table(DF$CAN_DIAB_TY)



DF$vdurE <- round(DF$durDE/30.437)   # Make analysis on monthly level
DF$vdurE <- DF$vdurE*(DF$vdurE > 0) +  (DF$vdurE == 0)
DF$vCe <- DF$durDEC
DF$vdurS <- round(DF$durTX/30.437)   # Make analysis on monthly level
DF$vdurS <- DF$vdurS*(DF$vdurS > 0) +  (DF$vdurS == 0)
DF$vCs <- DF$durTXC 

DF$vCs <- as.numeric(DF$vdurS <= DF$vdurE )* DF$vCs          # adjust treatment indicator if time to treatment censored before exit occurs
DF$vdurS <- DF$vdurS * as.numeric(DF$vdurS <= DF$vdurE ) + DF$vdurE * as.numeric(DF$vdurS > DF$vdurE ) 



DF$vCe <- DF$vCe * as.numeric(DF$vdurE <= Rcens  ) 
DF$vdurE <- DF$vdurE * as.numeric(DF$vdurE <= Rcens  ) + Rcens * as.numeric(DF$vdurE > Rcens  )
DF$vCs <- DF$vCs * as.numeric(DF$vdurS <= Rcens  ) 
DF$vdurS <- DF$vdurS * as.numeric(DF$vdurS <= Rcens  ) + Rcens * as.numeric(DF$vdurS > Rcens  )
DF$vCe <- DF$vCe * (1- DF$vCe * as.numeric(DF$vdurS < DF$vdurE ) * as.numeric(DF$vCs == 0 ))
DF$vdurE <- DF$vdurE - (DF$vdurE - DF$vdurS) * as.numeric(DF$vdurS < DF$vdurE ) * as.numeric(DF$vCs == 0 ) 




sum(DF$vCe)


a = DF[(DF$CAN_ABO == "AB"),]
b = a[((a$vdurS <= Dtau)* (a$vCs == 1) == 1),] 
nrow(b)/nrow(a)

a = DF[(DF$CAN_ABO == "O"),]
b = a[((a$vdurS <= Dtau)* (a$vCs == 1) == 1),] 
nrow(b)/nrow(a)







#########################################################################
#### Figures describing covariate 'effect' (difference with CIs) of transplanted candidates
#########################################################################

DF$vdurS_tx = DF$vdurS * DF$vCs
DF5 = DF[(DF$vdurS_tx > 0),]



#DF5 = DF5[is.na(DF5$REC_A_MM_EQUIV_TX),]

#DF5 = DF5[(DF5$CAN_FUNCTN_STATn == 3),]
#DF5 = DF5[!is.na(DF5$CAN_FUNCTN_STATn),]


DF5$Z <- as.numeric(DF5$CAN_ABO == "AB")   # define regime

sum(is.na(DF5$CAN_FUNCTN_STATn))/nrow(DF5)

DF5$REC_A_MM_EQUIV_TX_miss = as.numeric(is.na(DF5$REC_A_MM_EQUIV_TX))
DF5$REC_B_MM_EQUIV_TX_miss = as.numeric(is.na(DF5$REC_B_MM_EQUIV_TX))
DF5$REC_DR_MM_EQUIV_TX_miss = as.numeric(is.na(DF5$REC_DR_MM_EQUIV_TX))
DF5$GRAFT_FAIL_miss = as.numeric(is.na(DF5$GRAFT_FAIL))
DF5$CAN_FUNCTN_STATn_miss = as.numeric(is.na(DF5$CAN_FUNCTN_STATn))
DF5$REC_MM_EQUIV_TX_miss =  as.numeric(is.na(DF5$REC_MM_EQUIV_TX))


# Define the variables to plot
vars_to_plot <- c("REC_A_MM_EQUIV_TX","REC_A_MM_EQUIV_TX_miss",
                  "REC_B_MM_EQUIV_TX", "REC_B_MM_EQUIV_TX_miss",
                  "REC_DR_MM_EQUIV_TX", "REC_DR_MM_EQUIV_TX_miss",
                  "GRAFT_FAIL", "GRAFT_FAIL_miss",
                  "DON_AGE", "CAN_BMI", "CAN_AGE_AT_LISTING",
                  "CAN_FUNCTN_STATn", "CAN_FUNCTN_STATn_miss",
                  "CAN_ACPT_HBC_POS1", "CAN_ACPT_HCV_POS1",
                  "DIAB_ENTRY")

vars_to_plot <- c("CAN_FUNCTN_STATn")

vars_to_plot <- c("REC_MM_EQUIV_TX","REC_MM_EQUIV_TX_miss",
                  "REC_A_MM_EQUIV_TX","REC_A_MM_EQUIV_TX_miss",
                  "REC_B_MM_EQUIV_TX", "REC_B_MM_EQUIV_TX_miss",
                  "REC_DR_MM_EQUIV_TX", "REC_DR_MM_EQUIV_TX_miss",
                  "GRAFT_FAIL", "GRAFT_FAIL_miss",
                  "CAN_FUNCTN_STATn", "CAN_FUNCTN_STATn_miss")



# Loop through each variable
for (var in vars_to_plot) {
  # Create an empty list to store results for each variable
  results <- list()

  rr = 100
  if (post2015 == 1) {
    rr <- 72
  }
  # Loop over each unique level of vdurS_tx
  for (time_point in 1:rr) {
    # Subset the data for the current time point
    subset_data <- DF5[DF5$vdurS_tx == time_point, ]

    # Run the OLS regression: var ~ Z
    model <- lm(as.formula(paste(var, "~ Z")), data = subset_data)

    # Calculate heteroskedasticity-robust standard errors using vcovHC
    robust_se <- sqrt(diag(vcovHC(model, type = "HC3")))[2]  # SE for Z (2nd row)

    # Extract the coefficient (Z effect) and compute 95% confidence interval
    coef_result <- tidy(model) %>%
      filter(term == "Z") %>%
      mutate(
        vdurS_tx = time_point,
        lower = estimate - 1.96 * robust_se,  # Confidence interval lower bound
        upper = estimate + 1.96 * robust_se   # Confidence interval upper bound
      )

    # Append the result to the list
    results[[length(results) + 1]] <- coef_result
  }


  # Combine the results into a single data frame for the current variable
  results_df <- bind_rows(results)

  # Filter the results for vdurS_tx <= 12 months
  results_df_sub <- results_df %>%
    filter(vdurS_tx <= 50)

  # Create the plot for the current variable
  p <- ggplot(results_df_sub, aes(x = vdurS_tx, y = estimate, ymin = lower, ymax = upper)) +
    geom_pointrange(position = position_dodge(width = 0.5), size = 0.7) +
    theme_minimal() +
    labs(
      x = "Time of transplant (in months)",
      y = "Difference for transplanted AB vs O"
    ) +
    theme(
      axis.text.x = element_text(angle = 45, hjust = 1),
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank()
    ) +
    geom_line() +
    geom_point(size = 2) +
    scale_x_continuous(breaks = seq(0, max(results_df_sub$vdurS_tx), by = 6)) +
    geom_hline(yintercept = 0, linetype = "solid", color = "black", size = 1.2)

  # Print the plot
  print(p)

  # Save plot based on conditions
  if (Dtau == 3 & post2015 == 0 & blood_types == 0 & livingdon == 0 & calentry == 0 & covadj == 0 &
      race == 1 & biosex == 0 & diab_t2 == 0 & educD == 0 & fun_abil == 0) {
    ggsave(paste0("Figures/Var_transpPre_", var, ".png"), plot = p, width = 8, height = 5)
  } else if (Dtau == 3 & post2015 == 1 & blood_types == 0 & livingdon == 0 & calentry == 0 & covadj == 0 &
             race == 1 & biosex == 0 & diab_t2 == 0 & educD == 0 & fun_abil == 0 ) {
    ggsave(paste0("Figures/Var_transpPost_", var, ".png"), plot = p, width = 8, height = 5)
  }
}




##################################



#
# # Loop through each variable and plot
# plots <- lapply(vars_to_plot, function(var) {
#   df_summary <- DF5 %>%
#     filter(vdurS_tx <= 3) %>%  # Stop at vdurS_tx == 60
#     group_by(vdurS_tx, Z) %>%
#     summarise(mean_value = mean(.data[[var]], na.rm = TRUE), .groups = "drop")
#
#   ggplot(df_summary, aes(x = vdurS_tx, y = mean_value, color = factor(Z))) +
#     geom_line() +
#     geom_point() +
#     labs(title = var, x = "Time of Transplant (vdurS_tx)", y = "Average Value", color = "Z") +
#     theme_minimal()
# })
#
# # Print plots
# for (p in plots) print(p)
#
#
# # Define the variables to plot
# vars_to_plot <- c("REC_A_MM_EQUIV_TX", "REC_B_MM_EQUIV_TX", "REC_DR_MM_EQUIV_TX", "GRAFT_FAIL",
#                   "DON_AGE","DON_WGT_KG",
#                   "DON_CAD_DON_COD_ANOX","DON_CAD_DON_COD_CERE","DON_CAD_DON_COD_HEAD",
#                   "CAN_BMI","CAN_AGE_AT_LISTING", "CAN_FUNCTN_STATn")
#
# vars_to_plot <- c("CAN_FUNCTN_STATn")
#
#
#
# # Loop through each variable and plot
# plots <- lapply(vars_to_plot, function(var) {
#   df_summary <- DF5 %>%
#     group_by(vdurS_tx, Z) %>%
#     summarise(mean_value = mean(.data[[var]], na.rm = TRUE), .groups = "drop")
#
#   ggplot(df_summary, aes(x = vdurS_tx, y = mean_value, color = factor(Z))) +
#     geom_line() +
#     geom_point() +
#     labs(title = var, x = "Time of Transplant (vdurS_tx)", y = "Average Value", color = "Z") +
#     theme_minimal()
# })
#
# # Print plots
# for (p in plots) print(p)
#
#
# # Loop through each variable and plot
# plots <- lapply(vars_to_plot, function(var) {
#   df_summary <- DF5 %>%
#     filter(vdurS_tx <= 3) %>%  # Stop at vdurS_tx == 60
#     group_by(vdurS_tx, Z) %>%
#     summarise(mean_value = mean(.data[[var]], na.rm = TRUE), .groups = "drop")
#
#   ggplot(df_summary, aes(x = vdurS_tx, y = mean_value, color = factor(Z))) +
#     geom_point(alpha = 0.5) +  # Keep points visible but not dominant
#     geom_smooth(method = "loess", se = FALSE, span = 0.3) +  # Smooth line
#     labs(title = var, x = "Time of Transplant (vdurS_tx)", y = "Average Value", color = "Z") +
#     theme_minimal()
# })

# Print plots
#for (p in plots) print(p)


#########################################################################
#### Figures describing  covariate evolution of transplanted candidates
#########################################################################

DF$vdurS_tx = DF$vdurS * DF$vCs
DF5 = DF[(DF$vdurS_tx > 0),]


DF5$Z <- as.numeric(DF5$CAN_ABO == "AB")   # define regime


# Define the variables to plot
#vars_to_plot <- c("REC_A_MM_EQUIV_TX", "REC_B_MM_EQUIV_TX", "REC_DR_MM_EQUIV_TX", "GRAFT_FAIL",
#                  "DON_AGE","CAN_BMI","CAN_AGE_AT_LISTING", "CAN_FUNCTN_STATn")

vars_to_plot <- c("REC_MM_EQUIV_TX","CAN_AGE_AT_LISTING", "CAN_FUNCTN_STATn")

DF5 = DF5[(DF5$vdurS_tx <= 60),]


# Loop through each variable and plot
plots <- lapply(vars_to_plot, function(var) {
  df_summary <- DF5 %>%
    group_by(vdurS_tx, Z) %>%
    summarise(mean_value = mean(.data[[var]], na.rm = TRUE), .groups = "drop")

  p <- ggplot(df_summary, aes(x = vdurS_tx, y = mean_value, color = factor(Z))) +
    geom_point(alpha = 0.5) +  # Keep points visible but not dominant
    geom_smooth(method = "loess", se = FALSE, span = 0.3) +  # Smooth line
    labs(
      x = "Time of Transplant (in months)",
      y = "Average Value",
      color = "Blood"
    ) +
    theme_minimal() +
    theme(
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank()
    ) +
    scale_color_manual(values = c("black", "gray70"), labels = c("O", "AB")) +
    scale_x_continuous(breaks = seq(0, 60, by = 6))

  # Save plot based on conditions
  if (Dtau == 3 & post2015 == 0 & blood_types == 0 & livingdon == 0 & calentry == 0 & covadj == 0 &
      race == 1 & biosex == 0 & diab_t2 == 0 & educD == 0 & fun_abil == 0) {
    ggsave(paste0("Figures/Var_transpPreAvg_", var, ".png"), plot = p, width = 8, height = 5)
  } else if (Dtau == 3 & post2015 == 1 & blood_types == 0 & livingdon == 0 & calentry == 0 & covadj == 0 &
             race == 1 & biosex == 0 & diab_t2 == 0 & educD == 0 & fun_abil == 0) {
    ggsave(paste0("Figures/Var_transpPostAvg_", var, ".png"), plot = p, width = 8, height = 5)
  }

  return(p)
})

# Print plots
for (p in plots) print(p)


#stop()




#######################################
## Main text: Effect of blood type on survival for treated at t=1
# Part 1: candidate covariates only
#######################################


# Initialize an empty data frame to store results
survival_results_df <- data.frame()



DF$Z <- as.numeric(DF$CAN_ABO == "AB")   # define regime
#DF2 = DF2[(DF2$vdurE > Dtau),]

DF2 = DF[,c("vdurE","vCe","vdurS","vCs","Z","CAN_AGE_AT_LISTING_35up","CAN_AGE_AT_LISTING_51",
             "CAN_AGE_AT_LISTING_58", "CAN_AGE_AT_LISTING_65", "CAN_BMI_1925", "CAN_BMI_2630", "CAN_BMI_over30",
             "FEMALE","CAN_PREV_TX", "DIAB_ENTRY","DIAL_ENTRY","DIAL_ENTRY_time", "ASIAN", "BLACK", "OTHER_NONWHITE", "CAN_MALIG", "CAN_FUNCTN_STATn",
             "CAN_ACPT_HBC_POS1", "CAN_ACPT_HCV_POS1", "CAN_BMI","CAN_DGN_POLY","CAN_DGN_HYPE","CAN_DGN_GLOM",
             'WHITE','CAN_EDUCATION_HS','CAN_EDUCATION_COL','CAN_EDUCATION_COLDEG',"CAN_LISTING_CTR_ID" )]
DF2 =  dummy_cols(DF2, select_columns = "CAN_LISTING_CTR_ID", remove_first_dummy = FALSE)
DF2 =  dummy_cols(DF2, select_columns = "CAN_FUNCTN_STATn", remove_first_dummy = FALSE)

if (post2015 >= 1) {
  DF2 <- cbind(DF2,EPTSlow20 = DF$EPTSlow20)
}

cat("Total observations =" , nrow(DF2))

### Imputing missing values on the X (this matters as dropping them shifts results)
## It doesn't make much of a difference in the results which I use (it matters more that I just don't drop the variables), but might in your application
## 1. imputing mode (fast)
impute_mode <- function(df) {
  for (col in names(df)) {
    if (any(is.na(df[[col]]))) {  # Check if column has missing values
      mode_val <- names(sort(table(df[[col]]), decreasing = TRUE))[1]  # Get mode
      df[[col]][is.na(df[[col]])] <- mode_val  # Impute mode
    }
  }
  return(df)
}

DF2 <- impute_mode(DF2)  # Apply function to your dataframe
DF2[] <- lapply(DF2, function(x) {
  if (is.character(x)) as.numeric(x) else x
})

## 2. Tree based approach (takes time)
# DF2 <- mice(DF2, method = "cart", m = 5)  # Uses Classification and Regression Trees (CART)

nrow(DF2)
DF4 <- DF2[complete.cases(DF2), ]  # drop missing rows
nrow(DF4)

#DF4 = DF4[(DF4$vdurE >= 60),]
survival_results_df <- data.frame()



DF4 = DF4[((DF4$vdurS <= Dtau)* (DF4$vCs == 1) == 1),]  # Select treated at t=1

cat("Total observations =" , nrow(DF4))
cat("O treated observations =" , sum(DF4$Z * DF4$vCs))
cat("O non-treated observations =" , sum(DF4$Z * (1- DF4$vCs)))
cat("not-O treated observations =" , sum((1-DF4$Z) * DF4$vCs))
cat("not-O non-treated observations =" , sum((1-DF4$Z)*(1- DF4$vCs)))

table(DF4$CAN_ABO)

Rcens1 <- c(12,24,36,48,60,72,84,96,108,120)
if (post2015 == 1) {
  Rcens1 <- c(12,24,36,48,60,72)
}

for (rr in Rcens1) {
  DF3 <- DF4

  # Data selection. none of these are strictly necessary for results but they are used in the main analysis so need to be consistent

  DF3$Y <- as.numeric(DF3$vdurE >= rr)
  DF3 <- DF3[!(as.numeric(DF3$vdurE < rr) + as.numeric(DF3$vCe == 0) == 2), ]  # remove randomly censored outcomes


  ### with no covariates
  sTreat <- "Z"
  streatX <- c(sTreat)
  B_ols_fn <- lm(as.formula(paste("Y ~ ", paste(streatX, collapse = "+"))), data = DF3)

  # Store the results in the data frame
  result <- data.frame(
    Time = rr,
    Estimate = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[2, "Estimate"],
    Std_Error = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[2, "Std. Error"],
    specif = "without cov"
  )

  survival_results_df <- rbind(survival_results_df, result)

  ### with baseline covariates
  if (post2015 == 0){
    sX <- c("CAN_AGE_AT_LISTING_35up")
  }else{

    sX <- c("EPTSlow20")
  }

  sTreat <- "Z"
  streatX <- c(sTreat, sX)
  B_ols_fn <- lm(as.formula(paste("Y ~ ", paste(streatX, collapse = "+"))), data = DF3)
  print(nrow(DF3))
  print(sum(complete.cases(DF3[,sX])))
  print(sum(complete.cases(DF3)))

  # Store the results in the data frame
  result <- data.frame(
    Time = rr,
    Estimate = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[2, "Estimate"],
    Std_Error = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[2, "Std. Error"],
    specif = "with base cov."
  )

  survival_results_df <- rbind(survival_results_df, result)


  ### double ML
  DF3 <- DF4[complete.cases(DF4), ]  # drop missing rows
  DF3$Y <- as.numeric(DF3$vdurE >= rr)
  DF3 <- DF3[!(as.numeric(DF3$vdurE < rr) + as.numeric(DF3$vCe == 0) == 2), ]  # remove randomly censored outcomes

  sX <- colnames(DF3[,6:(ncol(DF3)-1)])
  #print(sX)
  #print(DF3)

  # Define the data backend
  dml_data <- DoubleMLData$new(data = DF3, y_col = "Y", d_cols = "Z", x_cols = sX)

  # Define ML learners
  learner_lasso <- lrn("regr.cv_glmnet")  # LASSO for Y
  learner_ridge <- lrn("regr.cv_glmnet")  # Ridge for D (can use LASSO too)

  # Define DML model
  dml_plr <- DoubleMLPLR$new(dml_data, ml_l = learner_lasso, ml_m = learner_ridge)


  # Estimate the model
  dml_plr$fit()

  # Extract treatment effect and heteroskedasticity-robust standard error
  coef_estimate <- dml_plr$coef
  se_robust <- dml_plr$se

  result <- data.frame(
    Time = rr,
    Estimate =dml_plr$coef,
    Std_Error = dml_plr$se,
    specif = "double ML cand."
  )

  survival_results_df <- rbind(survival_results_df, result)

  print(survival_results_df)
}

# Print the resulting data frame
print(survival_results_df)


# Assuming you have a data frame named 'survival_results_df' containing your survival analysis results
# Make sure 'size', 'effect', 'effect_se', and 'specification' columns exist in the data frame

pd <- 3
print(ggplot(survival_results_df,
             aes(x     = Time,
                 y     = Estimate,
                 color = specif)) +
        geom_point(shape = 15,
                   size  = 4,
                   position = position_dodge(pd)) +  # Use position_dodge with the desired offset
        geom_errorbar(aes(ymin  = Estimate - 1.96*Std_Error,
                          ymax  = Estimate + 1.96*Std_Error),
                      width = 2,
                      size  = 1,
                      position = position_dodge(pd)) +  # Use the same offset for error bars
        theme_bw() +
        theme(text = element_text(size = 20),
              panel.grid = element_blank()) +  # Remove the background grid
        theme(legend.title = element_blank()) +
        theme(legend.position = c(0.15, 0.86)) +
        theme(legend.background = element_rect(fill = "white",
                                               size = 0.5, linetype = "solid",
                                               colour = "black")) +
        scale_color_grey() +
        scale_y_continuous(breaks = seq(-0.12, 0.18, by = 0.04)) +
        coord_cartesian(ylim = c(-0.12, 0.18)) +
        geom_hline(yintercept = 0, linetype = "dotted") +
        ylab("Difference in Pr(survival)") +
        xlab("Time in months"))




#######################################
## Main text: Effect of blood type on survival for treated at t=1
# Part 2: candidate, donor and match covariates
#######################################


# Note: Because there are a large amount of missing values in the donor and donor-candidate match
#       variables I need to set up the analysis again here

# Initialize an empty data frame to store results
#survival_results_df <- data.frame()



DF$Z <- as.numeric(DF$CAN_ABO == "AB")   # define regime
#DF2 = DF2[(DF2$vdurE > Dtau),]

DF2 = DF[,c("vdurE","vCe","vdurS","vCs","Z","CAN_AGE_AT_LISTING_35up","CAN_AGE_AT_LISTING_51",
            "CAN_AGE_AT_LISTING_58", "CAN_AGE_AT_LISTING_65", "CAN_BMI_1925", "CAN_BMI_2630", "CAN_BMI_over30",
            "FEMALE","CAN_PREV_TX", "DIAB_ENTRY","DIAL_ENTRY","DIAL_ENTRY_time", "ASIAN", "BLACK", "OTHER_NONWHITE", "CAN_MALIG", "CAN_FUNCTN_STATn",
            "CAN_ACPT_HBC_POS1", "CAN_ACPT_HCV_POS1", "CAN_BMI","CAN_DGN_POLY","CAN_DGN_HYPE","CAN_DGN_GLOM",
            'WHITE','CAN_EDUCATION_HS','CAN_EDUCATION_COL','CAN_EDUCATION_COLDEG',"CAN_LISTING_CTR_ID",
            "REC_A_MM_EQUIV_TX0", "REC_A_MM_EQUIV_TX1", "REC_A_MM_EQUIV_TX2", "REC_B_MM_EQUIV_TX0",
            "REC_B_MM_EQUIV_TX1","REC_B_MM_EQUIV_TX2","REC_DR_MM_EQUIV_TX0","REC_DR_MM_EQUIV_TX1","REC_DR_MM_EQUIV_TX2",
            "DON_ORG_SHARED","DON_AGE","DON_WGT_KG","DON_CAD_DON_COD_ANOX","DON_CAD_DON_COD_CERE","DON_CAD_DON_COD_HEAD",
            "DON_CAD_DON_COD_TUMO","DON_CAD_DON_COD_OTHE")]
DF2 =  dummy_cols(DF2, select_columns = "CAN_LISTING_CTR_ID", remove_first_dummy = FALSE)
DF2 =  dummy_cols(DF2, select_columns = "CAN_FUNCTN_STATn", remove_first_dummy = FALSE)

if (post2015 >= 1) {
  DF2 <- cbind(DF2, EPTSlow20 = DF$EPTSlow20)
}


cat("Total observations =" , nrow(DF2))

### Imputing missing values on the X (this matters as dropping them shifts results)
## It doesn't make much of a difference in the results which I use (it matters more that I just don't drop the variables), but might in your application
## 1. imputing mode (fast)
impute_mode <- function(df) {
  for (col in names(df)) {
    if (any(is.na(df[[col]]))) {  # Check if column has missing values
      mode_val <- names(sort(table(df[[col]]), decreasing = TRUE))[1]  # Get mode
      df[[col]][is.na(df[[col]])] <- mode_val  # Impute mode
    }
  }
  return(df)
}

DF2 <- impute_mode(DF2)  # Apply function to your dataframe
DF2[] <- lapply(DF2, function(x) {
  if (is.character(x)) as.numeric(x) else x
})

## 2. Tree based approach (takes time)
# DF2 <- mice(DF2, method = "cart", m = 5)  # Uses Classification and Regression Trees (CART)

nrow(DF2)
DF4 <- DF2[complete.cases(DF2), ]  # drop missing rows
nrow(DF4)


DF4 = DF4[((DF4$vdurS <= Dtau)* (DF4$vCs == 1) == 1),]  # Select treated at t=1


cat("Total observations =" , nrow(DF4))
cat("O treated observations =" , sum(DF4$Z * DF4$vCs))
cat("O non-treated observations =" , sum(DF4$Z * (1- DF4$vCs)))
cat("not-O treated observations =" , sum((1-DF4$Z) * DF4$vCs))
cat("not-O non-treated observations =" , sum((1-DF4$Z)*(1- DF4$vCs)))

table(DF4$CAN_ABO)

Rcens1 <- c(12,24,36,48,60,72,84,96,108,120)
if (post2015 == 1) {
  Rcens1 <- c(12,24,36,48,60,72)
}

for (rr in Rcens1) {
  DF3 <- DF4

  # Data selection. none of these are strictly necessary for results but they are used in the main analysis so need to be consistent

  DF3$Y <- as.numeric(DF3$vdurE >= rr)
  DF3 <- DF3[!(as.numeric(DF3$vdurE < rr) + as.numeric(DF3$vCe == 0) == 2), ]  # remove randomly censored outcomes


  # ### with no covariates
  # sTreat <- "Z"
  # streatX <- c(sTreat)
  # B_ols_fn <- lm(as.formula(paste("Y ~ ", paste(streatX, collapse = "+"))), data = DF3)
  #
  # # Store the results in the data frame
  # result <- data.frame(
  #   Time = rr,
  #   Estimate = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[2, "Estimate"],
  #   Std_Error = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[2, "Std. Error"],
  #   specif = "without cov"
  # )
  #
  # survival_results_df <- rbind(survival_results_df, result)
  #
  # ### with baseline covariates
  # if (post2015 == 0){
  #   sX <- c("CAN_AGE_AT_LISTING_35up")
  # }else{
  #
  #   sX <- c("EPTSlow20")
  # }
  #
  # sTreat <- "Z"
  # streatX <- c(sTreat, sX)
  # B_ols_fn <- lm(as.formula(paste("Y ~ ", paste(streatX, collapse = "+"))), data = DF3)
  # print(nrow(DF3))
  # print(sum(complete.cases(DF3[,sX])))
  # print(sum(complete.cases(DF3)))
  #
  # # Store the results in the data frame
  # result <- data.frame(
  #   Time = rr,
  #   Estimate = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[2, "Estimate"],
  #   Std_Error = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[2, "Std. Error"],
  #   specif = "with base cov."
  # )
  #
  # survival_results_df <- rbind(survival_results_df, result)
  #
  #
  #
  # ### with extensive covariates
  # if (post2015 == 0){
  #   if (educ == 0) {
  #     sX <- c("CAN_AGE_AT_LISTING_51", "CAN_AGE_AT_LISTING_58", "CAN_AGE_AT_LISTING_65", "CAN_BMI_1925", "CAN_BMI_2630", "CAN_BMI_over30",
  #             "FEMALE","CAN_PREV_TX", "DIAB_ENTRY","DIAL_ENTRY", "ASIAN", "BLACK", "OTHER_NONWHITE", "CAN_MALIG", "CAN_ACPT_HBC_POS1",
  #             "CAN_ACPT_HCV_POS1","CAN_BMI","CAN_DGN_POLY","CAN_DGN_HYPE","CAN_DGN_GLOM",
  #             "REC_A_MM_EQUIV_TX0", "REC_A_MM_EQUIV_TX1", "REC_A_MM_EQUIV_TX2", "REC_B_MM_EQUIV_TX0",
  #             "REC_B_MM_EQUIV_TX1","REC_B_MM_EQUIV_TX2","REC_DR_MM_EQUIV_TX0","REC_DR_MM_EQUIV_TX1","REC_DR_MM_EQUIV_TX2",
  #             "DON_ORG_SHARED","DON_AGE","DON_WGT_KG","DON_CAD_DON_COD_ANOX","DON_CAD_DON_COD_CERE","DON_CAD_DON_COD_HEAD",
  #             "DON_CAD_DON_COD_TUMO","DON_CAD_DON_COD_OTHE")
  #   }else{
  #     sX <- c("CAN_AGE_AT_LISTING_51", "CAN_AGE_AT_LISTING_58", "CAN_AGE_AT_LISTING_65", "CAN_BMI_1925", "CAN_BMI_2630", "CAN_BMI_over30",
  #             "FEMALE","CAN_PREV_TX", "DIAB_ENTRY","DIAL_ENTRY","DIAL_time_1YRplus", "ASIAN", "BLACK", "OTHER_NONWHITE", "CAN_MALIG", "CAN_ACPT_HBC_POS1",
  #             "CAN_ACPT_HCV_POS1","CAN_BMI","CAN_DGN_POLY","CAN_DGN_HYPE","CAN_DGN_GLOM","CAN_EDUCATION_HS","CAN_EDUCATION_COL","CAN_EDUCATION_COLDEG")
  #   }
  # }else{
  #   if (educ == 0) {
  #     sX <- c("EPTSlow20","CAN_AGE_AT_LISTING_51", "CAN_AGE_AT_LISTING_58", "CAN_AGE_AT_LISTING_65", "CAN_BMI_1925", "CAN_BMI_2630", "CAN_BMI_over30",
  #             "FEMALE","CAN_PREV_TX", "DIAB_ENTRY","DIAL_ENTRY","DIAL_time_1YRplus", "ASIAN", "BLACK", "OTHER_NONWHITE", "CAN_MALIG", "CAN_ACPT_HBC_POS1",
  #             "CAN_ACPT_HCV_POS1","CAN_BMI","CAN_DGN_POLY","CAN_DGN_HYPE","CAN_DGN_GLOM")
  #   }else{
  #     sX <- c("EPTSlow20","CAN_AGE_AT_LISTING_51", "CAN_AGE_AT_LISTING_58", "CAN_AGE_AT_LISTING_65", "CAN_BMI_1925", "CAN_BMI_2630", "CAN_BMI_over30",
  #             "FEMALE","CAN_PREV_TX", "DIAB_ENTRY","DIAL_ENTRY","DIAL_time_1YRplus", "ASIAN", "BLACK", "OTHER_NONWHITE", "CAN_MALIG", "CAN_ACPT_HBC_POS1",
  #             "CAN_ACPT_HCV_POS1","CAN_BMI","CAN_DGN_POLY","CAN_DGN_HYPE","CAN_DGN_GLOM","CAN_EDUCATION_HS","CAN_EDUCATION_COL","CAN_EDUCATION_COLDEG")
  #   }
  # }
  # sTreat <- "Z"
  # streatX <- c(sTreat, sX)
  # B_ols_fn <- lm(as.formula(paste("Y ~ ", paste(streatX, collapse = "+"))), data = DF3)
  #
  # print("check1")
  # #nrow(DF3)
  # print(sum(DF3$Z))
  # print(sum((1-DF3$Z)))
  # print("check2")
  #
  #
  # # Store the results in the data frame
  # result <- data.frame(
  #   Time = rr,
  #   Estimate = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[2, "Estimate"],
  #   Std_Error = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[2, "Std. Error"],
  #   specif = "with ext. cov."
  # )
  #
  # survival_results_df <- rbind(survival_results_df, result)
  #
  ### double ML with donor-match characteristics
  DF3 <- DF4[complete.cases(DF4), ]  # drop missing rows
  DF3$Y <- as.numeric(DF3$vdurE >= rr)
  DF3 <- DF3[!(as.numeric(DF3$vdurE < rr) + as.numeric(DF3$vCe == 0) == 2), ]  # remove randomly censored outcomes

  sX <- colnames(DF3[,6:(ncol(DF3)-1)])
  #print(sX)
  #print(DF3)

  # Define the data backend
  dml_data <- DoubleMLData$new(data = DF3, y_col = "Y", d_cols = "Z", x_cols = sX)

  # Define ML learners
  learner_lasso <- lrn("regr.cv_glmnet")  # LASSO for Y
  learner_ridge <- lrn("regr.cv_glmnet")  # Ridge for D (can use LASSO too)

  # Define DML model
  dml_plr <- DoubleMLPLR$new(dml_data, ml_l = learner_lasso, ml_m = learner_ridge)


  # Estimate the model
  dml_plr$fit()

  # Extract treatment effect and heteroskedasticity-robust standard error
  coef_estimate <- dml_plr$coef
  se_robust <- dml_plr$se

  result <- data.frame(
    Time = rr,
    Estimate =dml_plr$coef,
    Std_Error = dml_plr$se,
    specif = "double ML cand.-don."
  )

  survival_results_df <- rbind(survival_results_df, result)


  print(survival_results_df)
}

# Print the resulting data frame
print(survival_results_df)


# Assuming you have a data frame named 'survival_results_df' containing your survival analysis results
# Make sure 'size', 'effect', 'effect_se', and 'specification' columns exist in the data frame

pd <- 3
print(ggplot(survival_results_df,
             aes(x     = Time,
                 y     = Estimate,
                 color = specif)) +
        geom_point(shape = 15,
                   size  = 4,
                   position = position_dodge(pd)) +  # Use position_dodge with the desired offset
        geom_errorbar(aes(ymin  = Estimate - 1.96*Std_Error,
                          ymax  = Estimate + 1.96*Std_Error),
                      width = 2,
                      size  = 1,
                      position = position_dodge(pd)) +  # Use the same offset for error bars
        theme_bw() +
        theme(text = element_text(size = 20),
              panel.grid = element_blank()) +  # Remove the background grid
        theme(legend.title = element_blank()) +
        theme(legend.position = c(0.20, 0.84)) +
        theme(legend.background = element_rect(fill = "white",
                                               size = 0.5, linetype = "solid",
                                               colour = "black")) +
        scale_color_grey() +
        scale_y_continuous(breaks = seq(-0.08, 0.24, by = 0.04)) +
        coord_cartesian(ylim = c(-0.08, 0.24)) +
        geom_hline(yintercept = 0, linetype = "dotted") +
        ylab("Difference in Pr(survival)") +
        xlab("Time in months"))
if (Dtau == 1 & post2015 == 0 & blood_types == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 1 & biosex == 0 & diab_t2 ==0 & educD == 0 & fun_abil == 0){
  ggsave("Figures\\Trans_s1eff1mowhit.png", width = 8, height = 5)
} else if ( Dtau == 3 &  post2015 == 0 & blood_types == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 1 & biosex == 0 & diab_t2 ==0 & educD == 0 & fun_abil == 0){
  ggsave("Figures\\Trans_s1eff3mowhit.png", width = 8, height = 5)
}  else if ( Dtau == 3 &  post2015 == 1 & blood_types == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 1 & biosex == 0 & diab_t2 ==0 & educD == 0 & fun_abil == 0){
  ggsave("Figures\\Trans_s1eff3mo_postwhit.png", width = 8, height = 5)
}  else if ( Dtau == 6 &  post2015 == 1 & blood_types == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 1 & biosex == 0 & diab_t2 ==0 & educD == 0 & fun_abil == 0){
  ggsave("Figures\\Trans_s1eff6mo_postwhit.png", width = 8, height = 5)
}  else if ( Dtau == 3 &  post2015 == 2 & blood_types == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 1 & biosex == 0 & diab_t2 ==0 & educD == 0 & fun_abil == 0){
  ggsave("Figures\\Trans_s1eff3mo_allwhit.png", width = 8, height = 5)
}  else if ( Dtau == 3 &  post2015 == 0 & blood_types == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 1 & biosex == 0 & diab_t2 ==0 & educD == 0 & fun_abil == 1){
  ggsave("Figures\\Trans_s1eff3mowhit_high.png", width = 8, height = 5)
}





stop()















#######################################
## Main text: Effect of Blood type on overall survival
#######################################


# Initialize an empty data frame to store results
survival_results_df <- data.frame()






# DF2 = DF[,c("vdurE","vCe","vdurS","vCs","Z","CAN_AGE_AT_LISTING_35up","CAN_AGE_AT_LISTING_51",
#             "CAN_AGE_AT_LISTING_58", "CAN_AGE_AT_LISTING_65", "CAN_BMI_1925", "CAN_BMI_2630", "CAN_BMI_over30",
#             "FEMALE","CAN_PREV_TX", "DIAB_ENTRY","DIAL_ENTRY","DIAL_ENTRY_time", "ASIAN", "BLACK", "OTHER_NONWHITE", "CAN_MALIG",
#             "CAN_ACPT_HBC_POS1", "CAN_ACPT_HCV_POS1", "CAN_DGN_POLY","CAN_DGN_HYPE","CAN_DGN_GLOM",
#             'WHITE',"CAN_LISTING_CTR_ID")]
# DF2 =  dummy_cols(DF2, select_columns = "CAN_LISTING_CTR_ID", remove_first_dummy = FALSE)
# DF2 =  dummy_cols(DF2, select_columns = "CAN_FUNCTN_STATn", remove_first_dummy = FALSE)
# 
# cat("Total observations =" , nrow(DF2))
# 
# ### Imputing missing values on the X (this matters as dropping them shifts results)
# ## It doesn't make much of a difference in the results which I use (it matters more that I just don't drop the variables), but might in your application
# ## 1. imputing mode (fast)
# impute_mode <- function(df) {
#   for (col in names(df)) {
#     if (any(is.na(df[[col]]))) {  # Check if column has missing values
#       mode_val <- names(sort(table(df[[col]]), decreasing = TRUE))[1]  # Get mode
#       df[[col]][is.na(df[[col]])] <- mode_val  # Impute mode
#     }
#   }
#   return(df)
# }
# 
# DF2 <- impute_mode(DF2)  # Apply function to your dataframe
# DF2[] <- lapply(DF2, function(x) {
#   if (is.character(x)) as.numeric(x) else x
# })
# 
# ## 2. Tree based approach (takes time)
# # DF2 <- mice(DF2, method = "cart", m = 5)  # Uses Classification and Regression Trees (CART)
# 
# nrow(DF2)
# DF4 <- DF2[complete.cases(DF2), ]  # drop missing rows
# nrow(DF4)


# Initialize an empty data frame to store results
survival_results_df <- data.frame()


DF$Z <- as.numeric(DF$CAN_ABO == "AB")   # define regime
#DF2 = DF2[(DF2$vdurE > Dtau),]

DF2 = DF[,c("vdurE","vCe","vdurS","vCs","Z","CAN_AGE_AT_LISTING_35up","CAN_AGE_AT_LISTING_51",
            "CAN_AGE_AT_LISTING_58", "CAN_AGE_AT_LISTING_65", "CAN_BMI_1925", "CAN_BMI_2630", "CAN_BMI_over30",
            "FEMALE","CAN_PREV_TX", "DIAB_ENTRY","DIAL_ENTRY","DIAL_ENTRY_time", "ASIAN", "BLACK", "OTHER_NONWHITE", "CAN_MALIG", "CAN_FUNCTN_STATn",
            "CAN_ACPT_HBC_POS1", "CAN_ACPT_HCV_POS1", "CAN_BMI","CAN_DGN_POLY","CAN_DGN_HYPE","CAN_DGN_GLOM",
            'WHITE','CAN_EDUCATION_HS','CAN_EDUCATION_COL','CAN_EDUCATION_COLDEG',"CAN_LISTING_CTR_ID" )]
DF2 =  dummy_cols(DF2, select_columns = "CAN_LISTING_CTR_ID", remove_first_dummy = FALSE)
DF2 =  dummy_cols(DF2, select_columns = "CAN_FUNCTN_STATn", remove_first_dummy = FALSE)

if (post2015 >= 1) {
  DF2 <- cbind(DF2, EPTSlow20 = DF$EPTSlow20)
}

cat("Total observations =" , nrow(DF2))

### Imputing missing values on the X (this matters as dropping them shifts results)
## It doesn't make much of a difference in the results which I use (it matters more that I just don't drop the variables), but might in your application
## 1. imputing mode (fast)
impute_mode <- function(df) {
  for (col in names(df)) {
    if (any(is.na(df[[col]]))) {  # Check if column has missing values
      mode_val <- names(sort(table(df[[col]]), decreasing = TRUE))[1]  # Get mode
      df[[col]][is.na(df[[col]])] <- mode_val  # Impute mode
    }
  }
  return(df)
}

DF2 <- impute_mode(DF2)  # Apply function to your dataframe
DF2[] <- lapply(DF2, function(x) {
  if (is.character(x)) as.numeric(x) else x
})

## 2. Tree based approach (takes time)
# DF2 <- mice(DF2, method = "cart", m = 5)  # Uses Classification and Regression Trees (CART)

nrow(DF2)
DF4 <- DF2[complete.cases(DF2), ]  # drop missing rows
nrow(DF4)

#DF4 = DF4[(DF4$vdurE >= 60),]
survival_results_df <- data.frame()


cat("Total observations =" , nrow(DF4))
cat("O observations =" , sum(DF4$Z))
cat("AB observations =" , sum(1-DF4$Z))
cat("O treated observations =" , sum(DF4$Z * DF4$vCs))
cat("O non-treated observations =" , sum(DF4$Z * (1- DF4$vCs)))
cat("not-O treated observations =" , sum((1-DF4$Z) * DF4$vCs))
cat("not-O non-treated observations =" , sum((1-DF4$Z)*(1- DF4$vCs)))



table(DF2$CAN_ABO)

Rcens1 <- c(12,24,36,48,60,72,84,96,108,120, 132, 144)
if (post2015 == 1) {
  Rcens1 <- c(12,24,36,48,60,72)
}

for (rr in Rcens1) {
  DF3 <- DF4

  # Data selection. none of these are strictly necessary for results but they are used in the main analysis so need to be consistent



  DF3$Y <- as.numeric(DF3$vdurE >= rr)
  DF3 <- DF3[!(as.numeric(DF3$vdurE < rr) + as.numeric(DF3$vCe == 0) == 2), ]  # remove randomly censored outcomes

  ### with no covariates
  sTreat <- "Z"
  streatX <- c(sTreat)
  B_ols_fn <- lm(as.formula(paste("Y ~ ", paste(streatX, collapse = "+"))), data = DF3)

  # Store the results in the data frame
  result <- data.frame(
    Time = rr,
    Estimate = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[2, "Estimate"],
    Std_Error = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[2, "Std. Error"],
    specif = "without cov"
  )

  survival_results_df <- rbind(survival_results_df, result)

  ### with baseline covariates
  if (post2015 == 0){
    sX <- c("CAN_AGE_AT_LISTING_35up")
  }else{

    sX <- c("EPTSlow20")
  }

  sTreat <- "Z"
  streatX <- c(sTreat, sX)
  B_ols_fn <- lm(as.formula(paste("Y ~ ", paste(streatX, collapse = "+"))), data = DF3)
  print(nrow(DF3))
  print(sum(complete.cases(DF3[,sX])))


  # Store the results in the data frame
  result <- data.frame(
    Time = rr,
    Estimate = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[2, "Estimate"],
    Std_Error = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[2, "Std. Error"],
    specif = "with base cov."
  )

  survival_results_df <- rbind(survival_results_df, result)

  ### double ML candidate variables
  DF3 <- DF4[complete.cases(DF4), ]  # drop missing rows
  DF3$Y <- as.numeric(DF3$vdurE >= rr)
  DF3 <- DF3[!(as.numeric(DF3$vdurE < rr) + as.numeric(DF3$vCe == 0) == 2), ]  # remove randomly censored outcomes

  sX <- colnames(DF3[,6:(ncol(DF3)-1)])
  #print(sX)
  #print(DF3)

  # Define the data backend
  dml_data <- DoubleMLData$new(data = DF3, y_col = "Y", d_cols = "Z", x_cols = sX)
  #print(sX)

  # Define ML learners
  learner_lasso <- lrn("regr.cv_glmnet")  # LASSO for Y
  learner_ridge <- lrn("regr.cv_glmnet")  # Ridge for D (can use LASSO too)

  # Define DML model
  dml_plr <- DoubleMLPLR$new(dml_data, ml_l = learner_lasso, ml_m = learner_ridge)


  # Estimate the model
  dml_plr$fit()

  # Extract treatment effect and heteroskedasticity-robust standard error
  coef_estimate <- dml_plr$coef
  se_robust <- dml_plr$se

  result <- data.frame(
    Time = rr,
    Estimate =dml_plr$coef,
    Std_Error = dml_plr$se,
    specif = "double ML cand."
  )

  survival_results_df <- rbind(survival_results_df, result)

  print(survival_results_df)
}

# Print the resulting data frame
print(survival_results_df)


# Assuming you have a data frame named 'survival_results_df' containing your survival analysis results
# Make sure 'size', 'effect', 'effect_se', and 'specification' columns exist in the data frame

pd <- 3
print(ggplot(survival_results_df,
             aes(x     = Time,
                 y     = Estimate,
                 color = specif)) +
        geom_point(shape = 15,
                   size  = 4,
                   position = position_dodge(pd)) +  # Use position_dodge with the desired offset
        geom_errorbar(aes(ymin  = Estimate - 1.96*Std_Error,
                          ymax  = Estimate + 1.96*Std_Error),
                      width = 2,
                      size  = 1,
                      position = position_dodge(pd)) +  # Use the same offset for error bars
        theme_bw() +
        theme(text = element_text(size = 20),
              panel.grid = element_blank()) +  # Remove the background grid
        theme(legend.title = element_blank()) +
        theme(legend.position = c(0.15, 0.86)) +
        theme(legend.background = element_rect(fill = "white",
                                               size = 0.5, linetype = "solid",
                                               colour = "black")) +
        scale_color_grey() +
        scale_y_continuous(breaks = seq(-0.12, 0.08, by = 0.04)) +
        coord_cartesian(ylim = c(-0.12, 0.08)) +
        geom_hline(yintercept = 0, linetype = "dotted") +
        ylab("Difference in Pr(survival)") +
        xlab("Time in months"))
if ( Dtau == 3 &  post2015 == 0 & blood_types == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 1 & biosex == 0 & diab_t2 ==0 & educD == 0 & fun_abil == 0){
  ggsave("Figures\\Overall_seffwhit.png", width = 8, height = 5)
}  else if ( Dtau == 3 &  post2015 == 1 & blood_types == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 1 & biosex == 0 & diab_t2 ==0 & educD == 0 & fun_abil == 0){
  ggsave("Figures\\Overall_seff_postwhit.png", width = 8, height = 5)
}  else if ( Dtau == 3 &  post2015 == 2 & blood_types == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 1 & biosex == 0 & diab_t2 ==0 & educD == 0 & fun_abil == 0){
  ggsave("Figures\\Overall_seff_allwhit.png", width = 8, height = 5)
}   else if ( Dtau == 3 &  post2015 == 0 & blood_types == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 1 & biosex == 0 & diab_t2 ==0 & educD == 0 & fun_abil == 1){
  ggsave("Figures\\Overall_seffwhit_high.png", width = 8, height = 5)
}








































#
#
#
#
# #######################################
# ## Appendix: Heterogenous Effect of blood type on survival for treated at t=1 (appendix figure)
# #######################################
#
#
#
# # Initialize an empty data frame to store results
# survival_results_df1 <- data.frame()
# survival_results_df2 <- data.frame()
# survival_results_df3 <- data.frame()
#
#
#
# DF2 = DF[((DF$vdurS <= Dtau)* (DF$vCs == 1) == 1),]  # Select treated at t=1
# DF2$Z <- as.numeric(DF2$CAN_ABO == "AB")   # define regime
#
# DF2$Zint <- DF2$Z*DF2$diab_type2
# DF2$Zint1 <- DF2$Z*(1-DF2$diab_type2)
#
#
# ### B1 effects ###
#
# Rcens1 <- c(12,24,36,48,60,72,84,96,108,120)
# for (rr in Rcens1) {
#   DF3 <- DF2
#
#   # Data selection. none of these are strictly necessary for results but they are used in the main analysis so need to be consistent
#
#   ### with no covariates
#   DF3$Y <- as.numeric(DF3$vdurE >= rr)
#   DF3 <- DF3[!(as.numeric(DF3$vdurE < rr) + as.numeric(DF3$vCe == 0) == 2), ]  # remove randomly censored outcomes
#
#
#   streatX = c("diab_type2", "Zint1","Zint")
#   B_ols_fn <- lm(as.formula(paste("Y ~ ", paste(streatX, collapse = "+"))), data = DF3)
#
#   # Store the results in the data frame
#   result1 <- data.frame(
#     Time = rr,
#     Estimate = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[2, "Estimate"],
#     Std_Error = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[2, "Std. Error"],
#     specif = "without cov"
#   )
#   result2 <- data.frame(
#     Time = rr,
#     Estimate = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[3, "Estimate"],
#     Std_Error = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[3, "Std. Error"],
#     specif = "without cov"
#   )
#   result3 <- data.frame(
#     Time = rr,
#     Estimate = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[4, "Estimate"],
#     Std_Error = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[4, "Std. Error"],
#     specif = "without cov"
#   )
#
#   survival_results_df1 <- rbind(survival_results_df1, result1)
#   survival_results_df2 <- rbind(survival_results_df2, result2)
#   survival_results_df3 <- rbind(survival_results_df3, result3)
#
#   if (post2015 == 0){
#     sX <- c("CAN_AGE_AT_LISTING_35up")
#   }else{
#
#     sX <- c("EPTSlow20")
#   }
#
#   streatX = c("diab_type2", "Zint1","Zint", sX)
#   B_ols_fn <- lm(as.formula(paste("Y ~ ", paste(streatX, collapse = "+"))), data = DF3)
#   print(nrow(DF3))
#   print(sum(complete.cases(DF3[,sX])))
#
#
#   # Store the results in the data frame
#   result1 <- data.frame(
#     Time = rr,
#     Estimate = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[2, "Estimate"],
#     Std_Error = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[2, "Std. Error"],
#     specif = "with base cov."
#   )
#   result2 <- data.frame(
#     Time = rr,
#     Estimate = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[3, "Estimate"],
#     Std_Error = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[3, "Std. Error"],
#     specif = "with base cov."
#   )
#   result3 <- data.frame(
#     Time = rr,
#     Estimate = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[4, "Estimate"],
#     Std_Error = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[4, "Std. Error"],
#     specif = "with base cov."
#   )
#
#   survival_results_df1 <- rbind(survival_results_df1, result1)
#   survival_results_df2 <- rbind(survival_results_df2, result2)
#   survival_results_df3 <- rbind(survival_results_df3, result3)
#
#   if (post2015 == 0){
#     if (educ == 0) {
#       sX <- c("CAN_AGE_AT_LISTING_51", "CAN_AGE_AT_LISTING_58", "CAN_AGE_AT_LISTING_65", "CAN_BMI_1925", "CAN_BMI_2630", "CAN_BMI_over30", "FEMALE","CAN_PREV_TX", "DIAB_ENTRY", "ASIAN", "BLACK", "OTHER_NONWHITE", "CAN_MALIG", "CAN_ACPT_HBC_POS1", "CAN_ACPT_HCV_POS1")
#     }else{
#       sX <- c("CAN_AGE_AT_LISTING_51", "CAN_AGE_AT_LISTING_58", "CAN_AGE_AT_LISTING_65", "CAN_BMI_1925", "CAN_BMI_2630", "CAN_BMI_over30", "FEMALE","CAN_PREV_TX", "DIAB_ENTRY", "ASIAN", "BLACK", "OTHER_NONWHITE", "CAN_MALIG", "CAN_ACPT_HBC_POS1", "CAN_ACPT_HCV_POS1","CAN_EDUCATION_HS","CAN_EDUCATION_COL","CAN_EDUCATION_COLDEG")
#     }
#   }else{
#     if (educ == 0) {
#       sX <- c("EPTSlow20","CAN_AGE_AT_LISTING_51", "CAN_AGE_AT_LISTING_58", "CAN_AGE_AT_LISTING_65", "CAN_BMI_1925", "CAN_BMI_2630", "CAN_BMI_over30", "FEMALE","CAN_PREV_TX", "DIAB_ENTRY", "ASIAN", "BLACK", "OTHER_NONWHITE", "CAN_MALIG", "CAN_ACPT_HBC_POS1", "CAN_ACPT_HCV_POS1")
#     }else{
#       sX <- c("EPTSlow20","CAN_AGE_AT_LISTING_51", "CAN_AGE_AT_LISTING_58", "CAN_AGE_AT_LISTING_65", "CAN_BMI_1925", "CAN_BMI_2630", "CAN_BMI_over30", "FEMALE","CAN_PREV_TX", "DIAB_ENTRY", "ASIAN", "BLACK", "OTHER_NONWHITE", "CAN_MALIG", "CAN_ACPT_HBC_POS1", "CAN_ACPT_HCV_POS1","CAN_EDUCATION_HS","CAN_EDUCATION_COL","CAN_EDUCATION_COLDEG")
#     }
#   }
#   streatX = c("diab_type2", "Zint1","Zint", sX)
#   B_ols_fn <- lm(as.formula(paste("Y ~ ", paste(streatX, collapse = "+"))), data = DF3)
#
#   print("check1")
#   #nrow(DF3)
#   print(sum(DF3$Z))
#   print(sum((1-DF3$Z)))
#   print("check2")
#
#
#   # Store the results in the data frame
#   result1 <- data.frame(
#     Time = rr,
#     Estimate = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[2, "Estimate"],
#     Std_Error = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[2, "Std. Error"],
#     specif = "with ext. cov."
#   )
#   result2 <- data.frame(
#     Time = rr,
#     Estimate = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[3, "Estimate"],
#     Std_Error = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[3, "Std. Error"],
#     specif = "with ext. cov."
#   )
#   result3 <- data.frame(
#     Time = rr,
#     Estimate = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[4, "Estimate"],
#     Std_Error = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[4, "Std. Error"],
#     specif = "with ext. cov."
#   )
#
#   survival_results_df1 <- rbind(survival_results_df1, result1)
#   survival_results_df2 <- rbind(survival_results_df2, result2)
#   survival_results_df3 <- rbind(survival_results_df3, result3)
# }
#
# # Print the resulting data frame
# print(survival_results_df)
#
#
# # Assuming you have a data frame named 'survival_results_df' containing your survival analysis results
# # Make sure 'size', 'effect', 'effect_se', and 'specification' columns exist in the data frame
#
# ### B1 effects
# pd <- 3
# print(ggplot(survival_results_df1,
#              aes(x     = Time,
#                  y     = Estimate,
#                  color = specif)) +
#         geom_point(shape = 15,
#                    size  = 4,
#                    position = position_dodge(pd)) +  # Use position_dodge with the desired offset
#         geom_errorbar(aes(ymin  = Estimate - 1.96*Std_Error,
#                           ymax  = Estimate + 1.96*Std_Error),
#                       width = 2,
#                       size  = 1,
#                       position = position_dodge(pd)) +  # Use the same offset for error bars
#         theme_bw() +
#         theme(text = element_text(size = 20),
#               panel.grid = element_blank()) +  # Remove the background grid
#         theme(legend.title = element_blank()) +
#         theme(legend.position = c(0.15, 0.14)) +
#         theme(legend.background = element_rect(fill = "white",
#                                                size = 0.5, linetype = "solid",
#                                                colour = "black")) +
#         scale_color_grey() +
#         scale_y_continuous(breaks = seq(-0.45, 0.05, by = 0.10)) +
#         coord_cartesian(ylim = c(-0.45, 0.05)) +
#         geom_hline(yintercept = 0, linetype = "dotted") +
#         ylab("Difference in survival probability") +
#         xlab("Time in months"))
# if (Dtau == 1 & post2015 == 0 & blood_types == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & educD == 0 & fun_abil == 0){
#   ggsave("Figures\\Trans_s1eff1mo_hetB1.png", width = 8, height = 5)
# } else if ( Dtau == 3 &  post2015 == 0 & blood_types == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & educD == 0 & fun_abil == 0){
#   ggsave("Figures\\Trans_s1eff3mo_hetB1.png", width = 8, height = 5)
# }  else if ( Dtau == 3 &  post2015 == 1 & blood_types == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & educD == 0 & fun_abil == 0){
#   ggsave("Figures\\Trans_s1eff3mo_post_hetB1.png", width = 8, height = 5)
# }  else if ( Dtau == 3 &  post2015 == 2 & blood_types == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & educD == 0 & fun_abil == 0){
#   ggsave("Figures\\Trans_s1eff3mo_all_hetB1.png", width = 8, height = 5)
# }
#
# ### B2 effects
# pd <- 3
# print(ggplot(survival_results_df2,
#              aes(x     = Time,
#                  y     = Estimate,
#                  color = specif)) +
#         geom_point(shape = 15,
#                    size  = 4,
#                    position = position_dodge(pd)) +  # Use position_dodge with the desired offset
#         geom_errorbar(aes(ymin  = Estimate - 1.96*Std_Error,
#                           ymax  = Estimate + 1.96*Std_Error),
#                       width = 2,
#                       size  = 1,
#                       position = position_dodge(pd)) +  # Use the same offset for error bars
#         theme_bw() +
#         theme(text = element_text(size = 20),
#               panel.grid = element_blank()) +  # Remove the background grid
#         theme(legend.title = element_blank()) +
#         theme(legend.position = c(0.15, 0.14)) +
#         theme(legend.background = element_rect(fill = "white",
#                                                size = 0.5, linetype = "solid",
#                                                colour = "black")) +
#         scale_color_grey() +
#         scale_y_continuous(breaks = seq(-0.15, 0.18, by = 0.10)) +
#         coord_cartesian(ylim = c(-0.15, 0.18)) +
#         geom_hline(yintercept = 0, linetype = "dotted") +
#         ylab("Difference in survival probability") +
#         xlab("Time in months"))
# if (Dtau == 1 & post2015 == 0 & blood_types == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & educD == 0 & fun_abil == 0){
#   ggsave("Figures\\Trans_s1eff1mo_hetB2.png", width = 8, height = 5)
# } else if ( Dtau == 3 &  post2015 == 0 & blood_types == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & educD == 0 & fun_abil == 0){
#   ggsave("Figures\\Trans_s1eff3mo_hetB2.png", width = 8, height = 5)
# }  else if ( Dtau == 3 &  post2015 == 1 & blood_types == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & educD == 0 & fun_abil == 0){
#   ggsave("Figures\\Trans_s1eff3mo_post_hetB2.png", width = 8, height = 5)
# }  else if ( Dtau == 3 &  post2015 == 2 & blood_types == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & educD == 0 & fun_abil == 0){
#   ggsave("Figures\\Trans_s1eff3mo_all_hetB2.png", width = 8, height = 5)
# }
#
#
# ### B3 effects
# pd <- 3
# print(ggplot(survival_results_df3,
#              aes(x     = Time,
#                  y     = Estimate,
#                  color = specif)) +
#         geom_point(shape = 15,
#                    size  = 4,
#                    position = position_dodge(pd)) +  # Use position_dodge with the desired offset
#         geom_errorbar(aes(ymin  = Estimate - 1.96*Std_Error,
#                           ymax  = Estimate + 1.96*Std_Error),
#                       width = 2,
#                       size  = 1,
#                       position = position_dodge(pd)) +  # Use the same offset for error bars
#         theme_bw() +
#         theme(text = element_text(size = 20),
#               panel.grid = element_blank()) +  # Remove the background grid
#         theme(legend.title = element_blank()) +
#         theme(legend.position = c(0.15, 0.14)) +
#         theme(legend.background = element_rect(fill = "white",
#                                                size = 0.5, linetype = "solid",
#                                                colour = "black")) +
#         scale_color_grey() +
#         scale_y_continuous(breaks = seq(-0.15, 0.18, by = 0.10)) +
#         coord_cartesian(ylim = c(-0.15, 0.18)) +
#         geom_hline(yintercept = 0, linetype = "dotted") +
#         ylab("Difference in survival probability") +
#         xlab("Time in months"))
# if (Dtau == 1 & post2015 == 0 & blood_types == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & educD == 0 & fun_abil == 0){
#   ggsave("Figures\\Trans_s1eff1mo_hetB3.png", width = 8, height = 5)
# } else if ( Dtau == 3 &  post2015 == 0 & blood_types == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & educD == 0 & fun_abil == 0){
#   ggsave("Figures\\Trans_s1eff3mo_hetB3.png", width = 8, height = 5)
# }  else if ( Dtau == 3 &  post2015 == 1 & blood_types == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & educD == 0 & fun_abil == 0){
#   ggsave("Figures\\Trans_s1eff3mo_post_hetB3.png", width = 8, height = 5)
# } else if ( Dtau == 3 &  post2015 == 2 & blood_types == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & educD == 0 & fun_abil == 0){
#   ggsave("Figures\\Trans_s1eff3mo_all_hetB3.png", width = 8, height = 5)
# }
#
#
#
#
#
#
#
# #######################################
# ## Appendix: Heterogenous Effect of Blood type on overall survival (appendix figure)
# #######################################
#
#
#
# # Initialize an empty data frame to store results
# survival_results_df1 <- data.frame()
# survival_results_df2 <- data.frame()
# survival_results_df3 <- data.frame()
#
#
#
# DF2 = DF
# DF2$Z <- as.numeric(DF2$CAN_ABO == "AB")   # define regime
#
# DF2$Zint <- DF2$Z*DF2$diab_type2
# DF2$Zint1 <- DF2$Z*(1-DF2$diab_type2)
#
#
# ### B1 effects ###
#
# Rcens1 <- c(12,24,36,48,60,72,84,96,108,120)
# for (rr in Rcens1) {
#   DF3 <- DF2
#
#   # Data selection. none of these are strictly necessary for results but they are used in the main analysis so need to be consistent
#
#
#   DF3$Y <- as.numeric(DF3$vdurE >= rr)
#   DF3 <- DF3[!(as.numeric(DF3$vdurE < rr) + as.numeric(DF3$vCe == 0) == 2), ]  # remove randomly censored outcomes
#
#   streatX = c("diab_type2", "Zint1","Zint")
#   B_ols_fn <- lm(as.formula(paste("Y ~ ", paste(streatX, collapse = "+"))), data = DF3)
#
#   # Store the results in the data frame
#   result1 <- data.frame(
#     Time = rr,
#     Estimate = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[2, "Estimate"],
#     Std_Error = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[2, "Std. Error"],
#     specif = "without cov"
#   )
#   result2 <- data.frame(
#     Time = rr,
#     Estimate = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[3, "Estimate"],
#     Std_Error = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[3, "Std. Error"],
#     specif = "without cov"
#   )
#   result3 <- data.frame(
#     Time = rr,
#     Estimate = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[4, "Estimate"],
#     Std_Error = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[4, "Std. Error"],
#     specif = "without cov"
#   )
#
#   survival_results_df1 <- rbind(survival_results_df1, result1)
#   survival_results_df2 <- rbind(survival_results_df2, result2)
#   survival_results_df3 <- rbind(survival_results_df3, result3)
#   if (post2015 == 0){
#     sX <- c("CAN_AGE_AT_LISTING_35up")
#   }else{
#
#     sX <- c("EPTSlow20")
#   }
#
#   streatX = c("diab_type2", "Zint1","Zint", sX)
#   B_ols_fn <- lm(as.formula(paste("Y ~ ", paste(streatX, collapse = "+"))), data = DF3)
#   print(nrow(DF3))
#   print(sum(complete.cases(DF3[,sX])))
#
#
#   # Store the results in the data frame
#   result1 <- data.frame(
#     Time = rr,
#     Estimate = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[2, "Estimate"],
#     Std_Error = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[2, "Std. Error"],
#     specif = "with base cov."
#   )
#   result2 <- data.frame(
#     Time = rr,
#     Estimate = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[3, "Estimate"],
#     Std_Error = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[3, "Std. Error"],
#     specif = "with base cov."
#   )
#   result3 <- data.frame(
#     Time = rr,
#     Estimate = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[4, "Estimate"],
#     Std_Error = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[4, "Std. Error"],
#     specif = "with base cov."
#   )
#
#   survival_results_df1 <- rbind(survival_results_df1, result1)
#   survival_results_df2 <- rbind(survival_results_df2, result2)
#   survival_results_df3 <- rbind(survival_results_df3, result3)
#
#   if (post2015 == 0){
#     if (educ == 0) {
#       sX <- c("CAN_AGE_AT_LISTING_51", "CAN_AGE_AT_LISTING_58", "CAN_AGE_AT_LISTING_65", "CAN_BMI_1925", "CAN_BMI_2630", "CAN_BMI_over30", "FEMALE","CAN_PREV_TX", "DIAB_ENTRY", "ASIAN", "BLACK", "OTHER_NONWHITE", "CAN_MALIG", "CAN_ACPT_HBC_POS1", "CAN_ACPT_HCV_POS1")
#     }else{
#       sX <- c("CAN_AGE_AT_LISTING_51", "CAN_AGE_AT_LISTING_58", "CAN_AGE_AT_LISTING_65", "CAN_BMI_1925", "CAN_BMI_2630", "CAN_BMI_over30", "FEMALE","CAN_PREV_TX", "DIAB_ENTRY", "ASIAN", "BLACK", "OTHER_NONWHITE", "CAN_MALIG", "CAN_ACPT_HBC_POS1", "CAN_ACPT_HCV_POS1","CAN_EDUCATION_HS","CAN_EDUCATION_COL","CAN_EDUCATION_COLDEG")
#     }
#   }else{
#     if (educ == 0) {
#       sX <- c("EPTSlow20","CAN_AGE_AT_LISTING_51", "CAN_AGE_AT_LISTING_58", "CAN_AGE_AT_LISTING_65", "CAN_BMI_1925", "CAN_BMI_2630", "CAN_BMI_over30", "FEMALE","CAN_PREV_TX", "DIAB_ENTRY", "ASIAN", "BLACK", "OTHER_NONWHITE", "CAN_MALIG", "CAN_ACPT_HBC_POS1", "CAN_ACPT_HCV_POS1")
#     }else{
#       sX <- c("EPTSlow20","CAN_AGE_AT_LISTING_51", "CAN_AGE_AT_LISTING_58", "CAN_AGE_AT_LISTING_65", "CAN_BMI_1925", "CAN_BMI_2630", "CAN_BMI_over30", "FEMALE","CAN_PREV_TX", "DIAB_ENTRY", "ASIAN", "BLACK", "OTHER_NONWHITE", "CAN_MALIG", "CAN_ACPT_HBC_POS1", "CAN_ACPT_HCV_POS1","CAN_EDUCATION_HS","CAN_EDUCATION_COL","CAN_EDUCATION_COLDEG")
#     }
#   }
#   streatX = c("diab_type2", "Zint1","Zint", sX)
#   B_ols_fn <- lm(as.formula(paste("Y ~ ", paste(streatX, collapse = "+"))), data = DF3)
#
#   print("check1")
#   #nrow(DF3)
#   print(sum(DF3$Z))
#   print(sum((1-DF3$Z)))
#   print("check2")
#
#
#   # Store the results in the data frame
#   result1 <- data.frame(
#     Time = rr,
#     Estimate = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[2, "Estimate"],
#     Std_Error = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[2, "Std. Error"],
#     specif = "with ext. cov."
#   )
#   result2 <- data.frame(
#     Time = rr,
#     Estimate = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[3, "Estimate"],
#     Std_Error = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[3, "Std. Error"],
#     specif = "with ext. cov."
#   )
#   result3 <- data.frame(
#     Time = rr,
#     Estimate = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[4, "Estimate"],
#     Std_Error = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[4, "Std. Error"],
#     specif = "with ext. cov."
#   )
#
#   survival_results_df1 <- rbind(survival_results_df1, result1)
#   survival_results_df2 <- rbind(survival_results_df2, result2)
#   survival_results_df3 <- rbind(survival_results_df3, result3)
# }
#
# # Print the resulting data frame
# print(survival_results_df)
#
#
# # Assuming you have a data frame named 'survival_results_df' containing your survival analysis results
# # Make sure 'size', 'effect', 'effect_se', and 'specification' columns exist in the data frame
#
# ### B1 effects
# pd <- 3
# print(ggplot(survival_results_df1,
#              aes(x     = Time,
#                  y     = Estimate,
#                  color = specif)) +
#         geom_point(shape = 15,
#                    size  = 4,
#                    position = position_dodge(pd)) +  # Use position_dodge with the desired offset
#         geom_errorbar(aes(ymin  = Estimate - 1.96*Std_Error,
#                           ymax  = Estimate + 1.96*Std_Error),
#                       width = 2,
#                       size  = 1,
#                       position = position_dodge(pd)) +  # Use the same offset for error bars
#         theme_bw() +
#         theme(text = element_text(size = 20),
#               panel.grid = element_blank()) +  # Remove the background grid
#         theme(legend.title = element_blank()) +
#         theme(legend.position = c(0.15, 0.14)) +
#         theme(legend.background = element_rect(fill = "white",
#                                                size = 0.5, linetype = "solid",
#                                                colour = "black")) +
#         scale_color_grey() +
#         scale_y_continuous(breaks = seq(-0.45, 0.05, by = 0.10)) +
#         coord_cartesian(ylim = c(-0.45, 0.05)) +
#         geom_hline(yintercept = 0, linetype = "dotted") +
#         ylab("Difference in survival probability") +
#         xlab("Time in months"))
# if ( Dtau == 3 &  post2015 == 0 & blood_types == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & educD == 0 & fun_abil == 0){
#   ggsave("Figures\\Overall_s1eff_hetB1.png", width = 8, height = 5)
# }  else if ( Dtau == 3 &  post2015 == 1 & blood_types == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & educD == 0 & fun_abil == 0){
#   ggsave("Figures\\Overall_s1eff_post_hetB1.png", width = 8, height = 5)
# }  else if ( Dtau == 3 &  post2015 == 2 & blood_types == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & educD == 0 & fun_abil == 0){
#   ggsave("Figures\\Overall_s1eff_all_hetB1.png", width = 8, height = 5)
# }
#
# ### B2 effects
# pd <- 3
# print(ggplot(survival_results_df2,
#              aes(x     = Time,
#                  y     = Estimate,
#                  color = specif)) +
#         geom_point(shape = 15,
#                    size  = 4,
#                    position = position_dodge(pd)) +  # Use position_dodge with the desired offset
#         geom_errorbar(aes(ymin  = Estimate - 1.96*Std_Error,
#                           ymax  = Estimate + 1.96*Std_Error),
#                       width = 2,
#                       size  = 1,
#                       position = position_dodge(pd)) +  # Use the same offset for error bars
#         theme_bw() +
#         theme(text = element_text(size = 20),
#               panel.grid = element_blank()) +  # Remove the background grid
#         theme(legend.title = element_blank()) +
#         theme(legend.position = c(0.15, 0.14)) +
#         theme(legend.background = element_rect(fill = "white",
#                                                size = 0.5, linetype = "solid",
#                                                colour = "black")) +
#         scale_color_grey() +
#         scale_y_continuous(breaks = seq(-0.15, 0.18, by = 0.10)) +
#         coord_cartesian(ylim = c(-0.15, 0.18)) +
#         geom_hline(yintercept = 0, linetype = "dotted") +
#         ylab("Difference in survival probability") +
#         xlab("Time in months"))
# if ( Dtau == 3 &  post2015 == 0 & blood_types == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & educD == 0 & fun_abil == 0){
#   ggsave("Figures\\Overall_s1eff_hetB2.png", width = 8, height = 5)
# }  else if ( Dtau == 3 &  post2015 == 1 & blood_types == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & educD == 0 & fun_abil == 0){
#   ggsave("Figures\\Overall_s1eff_post_hetB2.png", width = 8, height = 5)
# } else if ( Dtau == 3 &  post2015 == 2 & blood_types == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & educD == 0 & fun_abil == 0){
#   ggsave("Figures\\Overall_s1eff_all_hetB2.png", width = 8, height = 5)
# }
#
#
# ### B3 effects
# pd <- 3
# print(ggplot(survival_results_df3,
#              aes(x     = Time,
#                  y     = Estimate,
#                  color = specif)) +
#         geom_point(shape = 15,
#                    size  = 4,
#                    position = position_dodge(pd)) +  # Use position_dodge with the desired offset
#         geom_errorbar(aes(ymin  = Estimate - 1.96*Std_Error,
#                           ymax  = Estimate + 1.96*Std_Error),
#                       width = 2,
#                       size  = 1,
#                       position = position_dodge(pd)) +  # Use the same offset for error bars
#         theme_bw() +
#         theme(text = element_text(size = 20),
#               panel.grid = element_blank()) +  # Remove the background grid
#         theme(legend.title = element_blank()) +
#         theme(legend.position = c(0.15, 0.14)) +
#         theme(legend.background = element_rect(fill = "white",
#                                                size = 0.5, linetype = "solid",
#                                                colour = "black")) +
#         scale_color_grey() +
#         scale_y_continuous(breaks = seq(-0.15, 0.18, by = 0.10)) +
#         coord_cartesian(ylim = c(-0.15, 0.18)) +
#         geom_hline(yintercept = 0, linetype = "dotted") +
#         ylab("Difference in survival probability") +
#         xlab("Time in months"))
# if ( Dtau == 3 &  post2015 == 0 & blood_types == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & educD == 0 & fun_abil == 0){
#   ggsave("Figures\\Overall_s1eff_hetB3.png", width = 8, height = 5)
# }  else if ( Dtau == 3 &  post2015 == 1 & blood_types == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & educD == 0 & fun_abil == 0){
#   ggsave("Figures\\Overall_s1eff_post_hetB3.png", width = 8, height = 5)
# } else if ( Dtau == 3 &  post2015 == 2 & blood_types == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & educD == 0 & fun_abil == 0){
#   ggsave("Figures\\Overall_s1eff_all_hetB3.png", width = 8, height = 5)
# }
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
# #######################################
# ## Appendix: Effect on Probability of treatment at t=1 for many treatment windows (appendix figure)
# #######################################
#
# # Initialize an empty data frame to store results
# survival_results_df <- data.frame()
#
#
# for (dt in dtau1){
#   Dtau = dt # period t=1 interval
#
#   DF1 = DF
#   # Data selection. none of these are strictly necessary for results but they are used on main analysis so need to be consistent
#
#
#
#   DF1$Z <- as.numeric(DF1$CAN_ABO == "AB")   # define regime
#   DF1$Zint <- DF1$Z*DF1$diab_type2
#
#   DF1$D1 = as.numeric((DF1$vdurS <= Dtau)* (DF1$vCs == 1) == 1)
#
#   sTreat <- "Z"
#   streatX = c("diab_type2", sTreat,"Zint")
#
#
#   B_ols_fn = lm(as.formula(paste("D1 ~ ", paste(streatX, collapse= "+"))) , data=DF1)
#   print(coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3")))
#
#
#   # Store the results in the data frame
#   result <- data.frame(
#     Param = c("BZ","BW","BZW"),
#     Estimate = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[2:4, "Estimate"],
#     Std_Error = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[2:4, "Std. Error"],
#     specif = "without cov."
#   )
#
#   survival_results_df <- rbind(survival_results_df, result)
#
#
#   if (post2015 == 0){
#     sX <- c("CAN_AGE_AT_LISTING_35up")
#   }else{
#
#     sX <- c("EPTSlow20")
#   }
#
#   sTreat <- "Z"
#   streatX = c("diab_type2", sTreat,"Zint",sX)
#
#
#
#   B_ols_fn = lm(as.formula(paste("D1 ~ ", paste(streatX, collapse= "+"))) , data=DF1)
#   print(coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3")))
#
#   # Store the results in the data frame
#   result <- data.frame(
#     Param = c("BZ","BW","BZW"),
#     Estimate = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[2:4, "Estimate"],
#     Std_Error = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[2:4, "Std. Error"],
#     specif = "with base cov."
#   )
#
#   survival_results_df <- rbind(survival_results_df, result)
#
#   if (post2015 == 0){
#     if (educ == 0) {
#       sX <- c("CAN_AGE_AT_LISTING_51", "CAN_AGE_AT_LISTING_58", "CAN_AGE_AT_LISTING_65", "CAN_BMI_1925", "CAN_BMI_2630", "CAN_BMI_over30", "FEMALE","CAN_PREV_TX", "DIAB_ENTRY", "ASIAN", "BLACK", "OTHER_NONWHITE", "CAN_MALIG", "CAN_ACPT_HBC_POS1", "CAN_ACPT_HCV_POS1")
#     }else{
#       sX <- c("CAN_AGE_AT_LISTING_51", "CAN_AGE_AT_LISTING_58", "CAN_AGE_AT_LISTING_65", "CAN_BMI_1925", "CAN_BMI_2630", "CAN_BMI_over30", "FEMALE","CAN_PREV_TX", "DIAB_ENTRY", "ASIAN", "BLACK", "OTHER_NONWHITE", "CAN_MALIG", "CAN_ACPT_HBC_POS1", "CAN_ACPT_HCV_POS1","CAN_EDUCATION_HS","CAN_EDUCATION_COL","CAN_EDUCATION_COLDEG")
#     }
#   }else{
#     if (educ == 0) {
#       sX <- c("EPTSlow20","CAN_AGE_AT_LISTING_51", "CAN_AGE_AT_LISTING_58", "CAN_AGE_AT_LISTING_65", "CAN_BMI_1925", "CAN_BMI_2630", "CAN_BMI_over30", "FEMALE","CAN_PREV_TX", "DIAB_ENTRY", "ASIAN", "BLACK", "OTHER_NONWHITE", "CAN_MALIG", "CAN_ACPT_HBC_POS1", "CAN_ACPT_HCV_POS1")
#     }else{
#       sX <- c("EPTSlow20","CAN_AGE_AT_LISTING_51", "CAN_AGE_AT_LISTING_58", "CAN_AGE_AT_LISTING_65", "CAN_BMI_1925", "CAN_BMI_2630", "CAN_BMI_over30", "FEMALE","CAN_PREV_TX", "DIAB_ENTRY", "ASIAN", "BLACK", "OTHER_NONWHITE", "CAN_MALIG", "CAN_ACPT_HBC_POS1", "CAN_ACPT_HCV_POS1","CAN_EDUCATION_HS","CAN_EDUCATION_COL","CAN_EDUCATION_COLDEG")
#     }
#   }
#   sTreat <- "Z"
#   streatX = c("diab_type2", sTreat,"Zint",sX)
#
#
#
#   B_ols_fn = lm(as.formula(paste("D1 ~ ", paste(streatX, collapse= "+"))) , data=DF1)
#   print(coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3")))
#
#   # Store the results in the data frame
#   result <- data.frame(
#     Param = c("BZ","BW","BZW"),
#     Estimate = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[2:4, "Estimate"],
#     Std_Error = coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type = "HC3"))[2:4, "Std. Error"],
#     specif = "with ext. cov."
#   )
#
#   survival_results_df <- rbind(survival_results_df, result)
#
#
#   # print(paste("t=1 treatment window:", dt))
#   # print(coeftest(B_ols_fn, vcov = vcovHC(B_ols_fn, type="HC3"))[1:4,])
# }
#
#
# pd <- 0.3
# print(ggplot(survival_results_df,
#              aes(x     = Param,
#                  y     = Estimate,
#                  color = specif)) +
#         geom_point(shape = 15,
#                    size  = 4,
#                    position = position_dodge(pd)) +  # Use position_dodge with the desired offset
#         geom_errorbar(aes(ymin  = Estimate - 1.96*Std_Error,
#                           ymax  = Estimate + 1.96*Std_Error),
#                       width = 0.4,
#                       size  = 1,
#                       position = position_dodge(pd)) +  # Use the same offset for error bars
#         theme_bw() +
#         theme(text = element_text(size = 20),
#               panel.grid = element_blank()) +  # Remove the background grid
#         theme(legend.title = element_blank()) +
#         theme(legend.position = c(0.16, 0.87)) +
#         theme(legend.background = element_rect(fill = "white",
#                                                size = 0.5, linetype = "solid",
#                                                colour = "black")) +
#         scale_color_grey() +
#         scale_y_continuous(breaks = seq(-0.08, 0.04, by = 0.03)) +
#         coord_cartesian(ylim = c(-0.08, 0.04)) +
#         geom_hline(yintercept = 0, linetype = "dotted") +
#         ylab("Effects on transplant probability") +
#         xlab("Parameter Estimates") +
#         scale_x_discrete(labels = c("BZ" = expression(bold(beta[Z])),
#                                     "BW" = expression(bold(beta[W])),
#                                     "BZW" = expression(bold(paste(beta[ZW]))))))
# if (post2015 == 0 & blood_types == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & educD == 0 & fun_abil == 0){
#   ggsave("Figures\\Trans_prob.png", width = 8, height = 5)
# } else if (post2015 == 1 & blood_types == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & educD == 0 & fun_abil == 0){
#     ggsave("Figures\\Trans_prob_post.png", width = 8, height = 5)
# } else if (post2015 == 2 & blood_types == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & educD == 0 & fun_abil == 0){
#   ggsave("Figures\\Trans_prob_all.png", width = 8, height = 5)
# }
#
#
#
# #######################################
# ## Appendix: Distribution of offered kidney scenario
# #######################################
#
#
# # Install and load the required package
#
# # Load the required package
# # Load the required package
# library(ggplot2)
#
# # Data
# data <- data.frame(
#   x = c(0, 1/4, 2/4, 1, 1/4, 2/4,     0, 1/4, 2/4, 1, 1/4, 2/4,    0, 1/4, 2/4, 1, 1/4, 2/4),
#   y = c(2/4, 2/4, 1/3.9, 1/3.9, 1/3.9, 1/3.9,  1/3, 1/3, 1/3, 1/3, 1/3, 1/3,  1/4.1, 1/4.1, 1/4.1, 2/4, 1/4.1, 2/4 ),
#   Skew = c("Right", "Right", "Right", "Right", "Right", "Right",
#             "Zero", "Zero", "Zero", "Zero", "Zero", "Zero",
#             "Left", "Left", "Left", "Left", "Left", "Left")
# )
#
# # Plot
# ggplot(data, aes(x = x, y = y, color = Skew)) +
#   geom_line(aes(linetype = Skew), size = 1) +
#   scale_color_manual(values = c("Right" = "black", "Zero" = "black", "Left" = "black")) +
#   scale_linetype_manual(values = c("Right" = "solid", "Zero" = "longdash", "Left" = "dotdash")) +
#   labs(x = "Kidney Quality", y = "Fraction of Kidneys Offered in Each Quality Interval") +
#   theme_minimal() +
#   theme(
#     axis.text = element_text(size = 12),
#     axis.title = element_text(size = 12),
#     legend.position = "top",
#     panel.grid = element_blank()  # Remove background grid
#   ) +
#   geom_segment(aes(x = 0, y = 0, xend = 1, yend = 0), arrow = arrow(length = unit(0.3, "cm")), color = "black") +
#   geom_segment(aes(x = 1, y = 0, xend = 1, yend = -0.03), arrow = arrow(length = unit(0.3, "cm")), color = "black") +
#   scale_x_continuous(breaks = c(0, 1/4, 2/4, 1), labels = c("0", "k_h", "k_l", "")) +
#   scale_y_continuous(limits = c(0, 0.6), breaks = seq(0, 3/4, 1/4)) +
#   geom_vline(xintercept = c(1/4, 2/4), linetype = "dotted", color = "black")
# ggsave("Figures\\diffaccptrate.png", width = 8, height = 5)
#
#
#
#
#
#
#
#
#

# > sessionInfo()
# R version 4.3.1 (2023-06-16 ucrt)
# Platform: x86_64-w64-mingw32/x64 (64-bit)
# Running under: Windows 11 x64 (build 22631)
#
# Matrix products: default
#
#
# locale:
#   [1] LC_COLLATE=English_United Kingdom.utf8  LC_CTYPE=English_United Kingdom.utf8    LC_MONETARY=English_United Kingdom.utf8
# [4] LC_NUMERIC=C                            LC_TIME=English_United Kingdom.utf8
#
# time zone: Europe/London
# tzcode source: internal
#
# attached base packages:
#   [1] stats     graphics  grDevices utils     datasets  methods   base
#
# other attached packages:
#   [1] clubSandwich_0.5.10 sandwich_3.0-2      lmtest_0.9-40       zoo_1.8-12          ggplot2_3.4.2       tidyr_1.3.0
# [7] dplyr_1.1.2         foreign_0.8-84
#
#

