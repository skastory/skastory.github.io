########################################################################
##  Paper Title: Causally Evaluating Selection: Biological, 
##               Behavioral and Institutional Effects on
##               the Kidney Transplant Waitlist
#####
##                                                                    
##  Purpose: plot Survival probabilities and transplant hazard curves 
##
##  Reproducibility Information: see end of code for environment info 
##                                                                    
##  Author: Stephen Kastoryano                                        
##  Date  : 30 June 2024                                                 
##                                                      
##           
##  input:  "DF_pre.RData", "DF_post.RData", "DF_all.RData" from KidneyExp_clean
##          
##
##  output: Figures 1 and 3 in Text and All pre-transplant survival figures in Appendices: 'Additional figures and estimates on subgroups' & 'Selection on education'
##           
##
##  Instructions: Set post2015 = 2, all others 0 for Figure 1
##                Set blood_types = 3, all others 0 for Figure 3a, 3b and Appendix 'Additional figures and estimates on subgroups': Hazard and overall survival for different blood types
##                Set blood_types = 3, race = 1, all others 0 for Figure Appendix 'Additional figures and estimates on subgroups': Hazard, transplant and survival probabilities for different blood types conditional on being White
##                Set post2015 = 2, blood_types = 3, race = 1, educD = 2 all others 0 for KM pre-transplant survival curves in Figure Appendix 'Additional figures and estimates on subgroups': Hazard, transplant and survival probabilities for different blood types conditional on being White and attending some college
##                Set all 0s except in turn switch on livingdon = 1; race =1; race=2; biosex=1; biosex=2 for KM pre-transplant survival curves in Figures Appendix 'Additional figures and estimates on subgroups': Pre-transplant survival and effect βz for different subsamples. 
##                Set all 0s except in turn switch on educ_adj = 1; educD =1; educD=2; educD=3; race=1 & educD=2; for KM pre-transplant survival curves in Figures Appendix 'Selection on education': Pre-transplant survival and effect βz for different subsamples
##
##                                                                    
######################################################################################                                          



library("dplyr")
library("tidyr")
library("ggplot2")    
library("survival") 
library("survminer") 

setwd("C:/Users/skast/Dropbox/ContDurMA/CompCode 2023")

set.seed(5327456)


####################
### LOAD DATA, DEFINE SAMPLE
####################



post2015 = 0   # Equal to 0 for pre-2015 reform analysis, 1 for post-2015 reform analysis, 2 for pre- and post-2015 figures
blood_types =  0   # Equal to 0 for AB vs O type, 1 for B vs O type, 2 for A vs O type, 3 for all
livingdon = 0     # 0 for baseline without living donor transplant candidates,Equal to 1 if we want to keep living donor transplants in data
calentry = 0      # 0 for baseline 2002-6-01 -- 2014-12-01, 1 for 2002-6-01 -- 2008-9-01, 2 for 2008-9-01 -- 2014-12-01. Ensures 6 years and 3 months of calendar entries for each 
covadj = 0        # 0 for baseline, 1 for specification with additional adjustments on covariates to check small differences in balance are not driving selection on observables  
race = 1          # 0 for baseline all, 1 for white, 2 for non-white
biosex = 0        # 0 for baseline all, 1 for male, 2 for female
diab_ent = 1       # 0 for baseline all, 1 for diabetes at entry, 2 no diabetes at entry
diab_t2 = 0       # 0 for baseline all, 1 for Type 2 diabetes as main reason for transplant, 2 for not Type 2 diabetes as main reason for transplant
dial = 2         # 0 for baseline all, 1 only including people on dialysis at entry, 2 dropping people on dialysis at entry, 
hcv_pos_don = 0   # 0 is baseline not removing candidates who would accept HCV positive donor kidney (very unhealthy kidney), 1 if removing
cpra = 0          # 0 is baseline removing candidates who have CPRA above 0, 1 if all CPRA included
educD <- 4         # 0 is baseline including everyone, 1 includes HS degree or less, 2 includes 'some college', 3 includes at least a college degree,  4 includes at least 'some college'      
educ_adj = 0      # 0 is baseline without re-balancing education for O vs AB blood group, 1 when re-balancing education for O vs AB blood group (only to be used in O vs AB comparison)     
tau = 216          # tau is duration since entering waitlist, 116 is baseline to make pre- and post- comparable
if (post2015 == 0) {
  tau = 120
} else if (post2015 == 1) {
  tau = 72
}



##  Load files 
if (post2015 == 0){
  if (calentry == 0) {
    load("DF_pre.RData")
  } else if (calentry == 1) {
    load("DF_pre0208.RData")  
  } else {
    load("DF_pre0814.RData") 
  }
} else if (post2015 == 1){
  load("DF_post.RData")
} else {
  load("DF_all.RData") 
  
}

nrow(DF)
length(unique(DF$PERS_ID))


max(round(DF$durDE/30.437))


####################
### DATA SELECTION
####################


## Select blood types for comparison

if (blood_types == 0) {  # AB vs O
  # These lines must be include for AB vs. O analysis
  DF = DF[(DF$CAN_ABO != "A"),]   # Drop type A blood types 
  DF = DF[(DF$CAN_ABO != "B"),]   # Drop type B blood types 
  print(table(DF$CAN_ABO))
} else if (blood_types == 1) {  # B vs O
  DF = DF[(DF$CAN_ABO != "A"),]   # Drop type A blood types 
  DF = DF[(DF$CAN_ABO != "AB"),]   # Drop type AB blood types 
  print(table(DF$CAN_ABO))
} else if (blood_types == 2) {  # A vs O
  DF = DF[(DF$CAN_ABO != "B"),]   # Drop type B blood types 
  DF = DF[(DF$CAN_ABO != "AB"),]   # Drop type AB blood types 
  print(table(DF$CAN_ABO))
}


## Include living donors or not
if (livingdon == 0){
  DF =DF[(DF$DON_TY !="L"),]   # remove anyone who received kidney from living donor
}
nrow(DF)








if (covadj == 1){
  ### This code ensures that the distribution of health related variables are balanced in their mean
  ## It is ad hoc, in the sense that this code should not be replicated for other subsamples than the baseline one (all intial variables set to 0 besides 'covadj = 1')
  set.seed(3263)
  
  # Adjust for potential differences in age
  
  # Set the parameter to control the share of rows to drop
  param <- 0.152  # Adjust this value based on your preference
  # Calculate the probability of dropping each row based on CAN_AGE_AT_LISTING
  prob_drop <- 1-pnorm(DF$CAN_AGE_AT_LISTING, mean = mean(DF$CAN_AGE_AT_LISTING), sd = sd(DF$CAN_AGE_AT_LISTING))
  # Adjust the probability based on the parameter
  prob_drop <- prob_drop * param
  # Create a logical vector indicating whether each row of "not AB" should be dropped
  rows_to_drop <- DF$CAN_ABO != "AB" & runif(nrow(DF)) < prob_drop
  # Create the modified data frame by dropping the selected rows
  df_modified <- DF[!rows_to_drop, ]
  
  # Adjust for potential differences in diabetes 
  
  # Set the parameter to control the share of rows to drop
  param <- 0.045  # Adjust this value based on your preference
  # Calculate the probability of dropping each row based on CAN_AGE_AT_LISTING
  prob_drop <- 1-pnorm(df_modified$DIAB_ENTRY, mean = mean(df_modified$DIAB_ENTRY), sd = sd(df_modified$DIAB_ENTRY))
  # Adjust the probability based on the parameter
  prob_drop <- prob_drop * param
  # Create a logical vector indicating whether each row of "not AB" should be dropped
  rows_to_drop <- df_modified$CAN_ABO != "AB" & runif(nrow(df_modified)) < prob_drop
  # Create the modified data frame by dropping the selected rows
  df_modified <- df_modified[!rows_to_drop, ]
  
  
  # Adjust for potential differences in whether person received previous transplant 
  
  # Set the parameter to control the share of rows to drop
  param <- 0.29  # Adjust this value based on your preference
  # Calculate the probability of dropping each row based on CAN_AGE_AT_LISTING
  prob_drop <- 1-pnorm(df_modified$CAN_PREV_TX, mean = mean(df_modified$CAN_PREV_TX), sd = sd(df_modified$CAN_PREV_TX))
  # Adjust the probability based on the parameter
  prob_drop <- prob_drop * param
  # Create a logical vector indicating whether each row of "not AB" should be dropped
  rows_to_drop <- df_modified$CAN_ABO != "AB" & runif(nrow(df_modified)) < prob_drop
  # Create the modified data frame by dropping the selected rows
  df_modified <- df_modified[!rows_to_drop, ]
  
  # Check balance
  mean(df_modified$CAN_AGE_AT_LISTING[(df_modified$CAN_ABO == 'AB')], na.rm = TRUE)
  mean(df_modified$CAN_AGE_AT_LISTING[(df_modified$CAN_ABO != 'AB')], na.rm = TRUE)
  
  mean(df_modified$DIAB_ENTRY[(df_modified$CAN_ABO == 'AB')], na.rm = TRUE)
  mean(df_modified$DIAB_ENTRY[(df_modified$CAN_ABO != 'AB')], na.rm = TRUE)
  
  mean(df_modified$CAN_MALIG[(df_modified$CAN_ABO == 'AB')], na.rm = TRUE)
  mean(df_modified$CAN_MALIG[(df_modified$CAN_ABO != 'AB')], na.rm = TRUE)
  
  mean(df_modified$CAN_PREV_TX[(df_modified$CAN_ABO == 'AB')], na.rm = TRUE)
  mean(df_modified$CAN_PREV_TX[(df_modified$CAN_ABO != 'AB')], na.rm = TRUE)
  
  
  sum(DF$CAN_ABO == 'AB')
  sum(df_modified$CAN_ABO == 'AB')
  sum(DF$CAN_ABO != 'AB')
  sum(df_modified$CAN_ABO != 'AB')
  
  DF = df_modified
  
}
nrow(DF)




if (race == 1){
  DF = DF[(DF$CAN_RACE_SRTR == "WHITE"),]
} else if (race == 2){
  DF = DF[(DF$CAN_RACE_SRTR != "WHITE"),]
}
nrow(DF)


if (biosex == 1){
  DF = DF[(DF$FEMALE == 0),]
} else if (biosex == 2){
  DF = DF[(DF$FEMALE == 1),]
}

if (diab_ent == 1){
  DF = DF[(DF$DIAB_ENTRY == 1 ),]
} else if (diab_ent == 2){
  DF = DF[(DF$DIAB_ENTRY == 0 ),]
}

if (dial == 1){
  DF = DF[(DF$DIAL_ENTRY == 1 ),]
} else if (dial == 2){
  DF = DF[(DF$DIAL_ENTRY == 0 ),]
}

if (diab_t2 == 1){
  DF = DF[(DF$CAN_DGN == 3070 ),]
} else if (diab_t2 == 2){
  DF = DF[(DF$CAN_DGN != 3070 ),]
}


if (hcv_pos_don == 1){
  DF = DF[(DF$CAN_ACPT_HCV_POS1==0 ),]   # Drop anyone who would accept an HCV positive donor
}
nrow(DF)

if (cpra == 0){
  DF =DF[(DF$CANHX_CPRA == 0),]   # only keep CPRA == 0 people. So excluding all individuals with antibodies
}


nrow(DF)
if (educ_adj == 1){
  ### This code ensures that the distribution of education among
  set.seed(123)  # For reproducibility
  
  share_to_drop = 0.18
  num_to_drop <- round(share_to_drop*sum(as.numeric(DF$CAN_EDUCATION_HS == 1)* as.numeric(DF$CAN_ABO == 'O'),na.rm=T))
  # Filter rows that match the criteria
  rows_to_consider <- DF %>%
    filter(CAN_EDUCATION_HS == 1, CAN_ABO == 'O')
  
  # Randomly sample the rows to drop
  ids_to_drop <- sample(rows_to_consider$PERS_ID, num_to_drop)
  
  # Create an index of rows to keep
  DF_updated <- DF %>%
    filter(!PERS_ID %in% ids_to_drop)
  
  # Return the dataframe with specified rows dropped
  DF <- DF_updated
}
nrow(DF)



if (educD == 1) {  # includes HS degree or less
  DF = DF[!is.na(DF$CAN_EDUCATION_HS),]
  DF = DF[(DF$CAN_EDUCATION_HS == 1),]
} else if (educD == 2) {  # includes 'some college'
  DF = DF[!is.na(DF$CAN_EDUCATION_COL),]
  DF = DF[(DF$CAN_EDUCATION_COL == 1),] 
} else if (educD == 3) {  # includes some college degree
  DF = DF[!is.na(DF$CAN_EDUCATION_COLDEG),]
  DF = DF[(DF$CAN_EDUCATION_COLDEG == 1),]
} else if (educD == 4) {  # includes HS or less
  DF = DF[!is.na(DF$CAN_EDUCATION_COLDEG),]
  DF = DF[!is.na(DF$CAN_EDUCATION_COL),]
  DF = DF[(DF$CAN_EDUCATION_COLDEG == 1 | DF$CAN_EDUCATION_COL == 1),]
}


## Prepare treatment and outcome durations

DF$durDE =  round(DF$durDE/30.437)
DF$durDE <- DF$durDE*(DF$durDE > 0) +  (DF$durDE == 0)
DF$durDEn =  round(DF$durDEn/30.437)
DF$durDEn <- DF$durDEn*(DF$durDEn > 0) +  (DF$durDEn == 0)
DF$durTX =  round(DF$durTX/30.437)
DF$durTX <- DF$durTX*(DF$durTX > 0) +  (DF$durTX == 0)




cat("Total observations =" , nrow(DF))
cat("O observations =" , sum(as.numeric(DF$CAN_ABO == "O")))
cat("not-O observations =" , sum(as.numeric(DF$CAN_ABO != "O")))







######################################
#### Plot Survival Functions and Hazard Rates
#####################################


######################################
#### Figures 1a, 1c, 1d
#####################################


nrow(DF)

########################################
##  Figure 1d
########################################

if (blood_types == 0){
  print(ggsurvplot(
    fit = survfit(Surv(DF$durDE,DF$durDEC) ~ CAN_ABO, data = DF), 
    xlab = "Months", 
    ylab = "Survival probability",
    conf.int = TRUE,
    censor.size=0.1, 
    size = 0.2,
    xlim=c(0, (tau)),
    break.time.by = 12,
    ylim=c(0.4,1),
    font.legend = c(14, "plain", "black"),
    legend.title="Type",
    legend.labs = c("AB","O"),
    legend = c(0.85, 0.8),
    palette = c("gray60", "gray10")))
  if (post2015 == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 & diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\Surv_OvsAB.png", width = 6, height = 4)
  } else if (post2015 == 1 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\Surv_OvsABpost2015.png", width = 6, height = 4)
  } else if (post2015 == 2 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\Surv_OvsABally.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 1 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\Surv_OvsABlivdon.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 1 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\Surv_OvsABcalentry0208.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 2 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\Surv_OvsABcalentry0814.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 1 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\Surv_OvsABcovadj.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 1 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\Surv_OvsABwhite.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 2 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\Surv_OvsABnonwhite.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 1 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\Surv_OvsABmale.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 2 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\Surv_OvsABfemale.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==1 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\Surv_OvsABdabt2Yes.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==2 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\Surv_OvsABdiabt2No.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 1 & educ_adj == 0){
    ggsave("Figures\\Surv_OvsABeducHSless.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 2 & educ_adj == 0){
    ggsave("Figures\\Surv_OvsABeducCOLsom.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 3 & educ_adj == 0){
    ggsave("Figures\\Surv_OvsABeducColdeg.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 4 & educ_adj == 0){
    ggsave("Figures\\Surv_OvsABscollpl.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 1){
    ggsave("Figures\\Surv_OvsAB_Eadj.png", width = 6, height = 4) 
  }
} else if (blood_types == 1){
  print(ggsurvplot(
    fit = survfit(Surv(DF$durDE,DF$durDEC) ~ CAN_ABO, data = DF), 
    xlab = "Months", 
    ylab = "Survival probability",
    conf.int = TRUE,
    censor.size=0.1, 
    size = 0.2,
    xlim=c(0, (tau)),
    break.time.by = 12,
    ylim=c(0.4,1),
    font.legend = c(14, "plain", "black"),
    legend.title="Type",
    legend.labs = c("B","O"),
    legend = c(0.85, 0.8),
    palette = c("gray60", "gray10")))
  if (post2015 == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\Surv_OvsB.png", width = 6, height = 4)
  }
} else if (blood_types == 2){
  print(ggsurvplot(
    fit = survfit(Surv(DF$durDE,DF$durDEC) ~ CAN_ABO, data = DF), 
    xlab = "Months", 
    ylab = "Survival probability",
    conf.int = TRUE,
    censor.size=0.1, 
    size = 0.2,
    xlim=c(0, (tau)),
    break.time.by = 12,
    ylim=c(0.4,1),
    font.legend = c(14, "plain", "black"),
    legend.title="Type",
    legend.labs = c("A","O"),
    legend = c(0.85, 0.8),
    palette = c("gray60", "gray10")))
  if (post2015 == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\Surv_OvsA.png", width = 6, height = 4)
  }
}



########################################
##  Figure 1c
########################################
if (blood_types == 0){
  print(ggsurvplot(
    fit = survfit(Surv(DF$durDEn,DF$durDEnC) ~ CAN_ABO, data = DF), 
    xlab = "Months", 
    ylab = "Survival probability with censoring",
    conf.int = TRUE,
    censor.size=0.1, 
    size = 0.2,
    xlim=c(0, (tau)),
    break.time.by = 12,
    ylim=c(0.4,1),
    font.legend = c(14, "plain", "black"),
    legend.title="Type",
    legend.labs = c("AB","O"),
    legend = c(0.85, 0.8),
    palette = c("gray60", "gray10")))
  if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\SurvC_OvsAB.png", width = 6, height = 4)
  } else if (post2015 == 1 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\SurvC_OvsABpost2015.png", width = 6, height = 4)
  } else if (post2015 == 2 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\SurvC_OvsABally.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 1 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\SurvC_OvsABlivdon.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 1 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\SurvC_OvsABcalentry0208.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 2 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\SurvC_OvsABcalentry0814.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 1 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\SurvC_OvsABcovadj.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 1 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\SurvC_OvsABwhite.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 2 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\SurvC_OvsABnonwhite.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 1 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\SurvC_OvsABmale.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 2 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\SurvC_OvsABfemale.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==1 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\SurvC_OvsABdabt2Yes.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==2 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\SurvC_OvsABdiabt2No.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 1 & educ_adj == 0){
    ggsave("Figures\\SurvC_OvsABeducHSless.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 2 & educ_adj == 0){
    ggsave("Figures\\SurvC_OvsABeducCOLsom.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 3 & educ_adj == 0){
    ggsave("Figures\\SurvC_OvsABeducColdeg.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 4 & educ_adj == 0){
    ggsave("Figures\\SurvC_OvsABscollpl.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 1){
    ggsave("Figures\\SurvC_OvsAB_Eadj.png", width = 6, height = 4) 
  }
} else if (blood_types == 1){
  print(ggsurvplot(
    fit = survfit(Surv(DF$durDEn,DF$durDEnC) ~ CAN_ABO, data = DF), 
    xlab = "Months", 
    ylab = "Survival probability with censoring",
    conf.int = TRUE,
    censor.size=0.1, 
    size = 0.2,
    xlim=c(0, (tau)),
    break.time.by = 12,
    ylim=c(0.4,1),
    font.legend = c(14, "plain", "black"),
    legend.title="Type",
    legend.labs = c("B","O"),
    legend = c(0.85, 0.8),
    palette = c("gray60", "gray10")))
  if (post2015 == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\SurvC_OvsB.png", width = 6, height = 4)
  }
} else if (blood_types == 2){
  print(ggsurvplot(
    fit = survfit(Surv(DF$durDEn,DF$durDEnC) ~ CAN_ABO, data = DF), 
    xlab = "Months", 
    ylab = "Survival probability with censoring",
    conf.int = TRUE,
    censor.size=0.1, 
    size = 0.2,
    xlim=c(0, (tau)),
    break.time.by = 12,
    ylim=c(0.4,1),
    font.legend = c(14, "plain", "black"),
    legend.title="Type",
    legend.labs = c("A","O"),
    legend = c(0.85, 0.8),
    palette = c("gray60", "gray10")))
  if (post2015 == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\SurvC_OvsA.png", width = 6, height = 4)
  }
}


########################################
##  Figure 1a - this gives proability of transplant relative to total entering waitlist
########################################

DF$durTXa = DF$durTX*DF$durTXC + (tau+10)*(1-DF$durTXC)
if (blood_types == 0){
  print(ggsurvplot(
    fit = survfit(Surv(DF$durTXa,DF$durTXC) ~ CAN_ABO, data = DF), 
    xlab = "Months", 
    ylab = "Transplant probability",
    conf.int = TRUE,
    censor.size=0.1, 
    size = 0.2,
    xlim=c(0, (tau+3)),
    break.time.by = 12,
    ylim=c(0,1),
    font.legend = c(14, "plain", "black"),
    legend.title="Type",
    legend.labs = c("AB","O"),
    legend = c(0.85, 0.2),
    palette = c("gray60", "gray10"),fun = "event"))
  if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\SurvT_OvsAB.png", width = 6, height = 4)
  } else if (post2015 == 1 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\SurvT_OvsABpost2015.png", width = 6, height = 4)
  } else if (post2015 == 2 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\SurvT_OvsABally.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 1 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\SurvT_OvsABlivdon.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 1 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\SurvT_OvsABcalentry0208.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 2 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\SurvT_OvsABcalentry0814.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 1 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\SurvT_OvsABcovadj.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 1 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\SurvT_OvsABwhite.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 2 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\SurvT_OvsABnonwhite.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 1 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\SurvT_OvsABmale.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 2 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\SurvT_OvsABfemale.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==1 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\SurvT_OvsABdabt2Yes.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==2 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\SurvT_OvsABdiabt2No.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 1 & educ_adj == 0){
    ggsave("Figures\\SurvT_OvsABeducHSless.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 2 & educ_adj == 0){
    ggsave("Figures\\SurvT_OvsABeducCOLsom.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 3 & educ_adj == 0){
    ggsave("Figures\\SurvT_OvsABeducColdeg.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 4 & educ_adj == 0){
    ggsave("Figures\\SurvT_OvsABscollpl.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 1){
    ggsave("Figures\\SurvT_OvsAB_Eadj.png", width = 6, height = 4)   
  }
} else if (blood_types == 1){
  print(ggsurvplot(
    fit = survfit(Surv(DF$durTX,DF$durTXC) ~ CAN_ABO, data = DF), 
    xlab = "Months", 
    ylab = "Transplant probability",
    conf.int = TRUE,
    censor.size=0.1, 
    size = 0.2,
    xlim=c(0, (tau+3)),
    break.time.by = 12,
    ylim=c(0,1),
    font.legend = c(14, "plain", "black"),
    legend.title="Type",
    legend.labs = c("B","O"),
    legend = c(0.85, 0.2),
    palette = c("gray60", "gray10"),fun = "event"))
  if (post2015 == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\SurvT_OvsB.png", width = 6, height = 4)
  }
} else if (blood_types == 2){
  print(ggsurvplot(
    fit = survfit(Surv(DF$durTX,DF$durTXC) ~ CAN_ABO, data = DF), 
    xlab = "Months", 
    ylab = "Transplant probability",
    conf.int = TRUE,
    censor.size=0.1, 
    size = 0.2,
    xlim=c(0, (tau+3)),
    break.time.by = 12,
    ylim=c(0,1),
    font.legend = c(14, "plain", "black"),
    legend.title="Type",
    legend.labs = c("A","O"),
    legend = c(0.85, 0.2),
    palette = c("gray60", "gray10"),fun = "event"))
  if (post2015 == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\SurvT_OvsA.png", width = 6, height = 4)
  }
}


# 
# ########################################
# ##  Figure 1a v2 - this gives probability of transplant in KM way, not relative to total entering waitlist
# ########################################
# 
# 
# if (blood_types == 0){
#   print(ggsurvplot(
#     fit = survfit(Surv(DF$durTX,DF$durTXC) ~ CAN_ABO, data = DF),
#     xlab = "Months",
#     ylab = "Transplant probability",
#     conf.int = TRUE,
#     censor.size=0.1,
#     size = 0.2,
#     xlim=c(0, (tau+3)),
#     break.time.by = 12,
#     ylim=c(0,1),
#     font.legend = c(14, "plain", "black"),
#     legend.title="Type",
#     legend.labs = c("AB","O"),
#     legend = c(0.85, 0.2),
#     palette = c("gray60", "gray10"),fun = "event"))
#   if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
#     ggsave("Figures\\SurvT_OvsAB.png", width = 6, height = 4)
#   } else if (post2015 == 1 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
#     ggsave("Figures\\SurvT_OvsABpost2015.png", width = 6, height = 4)
#   } else if (post2015 == 2 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
#     ggsave("Figures\\SurvT_OvsABally.png", width = 6, height = 4)
#   } else if (post2015 == 0 &  livingdon == 1 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
#     ggsave("Figures\\SurvT_OvsABlivdon.png", width = 6, height = 4)
#   } else if (post2015 == 0 &  livingdon == 0 & calentry == 1 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
#     ggsave("Figures\\SurvT_OvsABcalentry0208.png", width = 6, height = 4)
#   } else if (post2015 == 0 &  livingdon == 0 & calentry == 2 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
#     ggsave("Figures\\SurvT_OvsABcalentry0814.png", width = 6, height = 4)
#   } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 1 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
#     ggsave("Figures\\SurvT_OvsABcovadj.png", width = 6, height = 4)
#   } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 1 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
#     ggsave("Figures\\SurvT_OvsABwhite.png", width = 6, height = 4)
#   } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 2 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
#     ggsave("Figures\\SurvT_OvsABnonwhite.png", width = 6, height = 4)
#   } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 1 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
#     ggsave("Figures\\SurvT_OvsABmale.png", width = 6, height = 4)
#   } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 2 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
#     ggsave("Figures\\SurvT_OvsABfemale.png", width = 6, height = 4)
#   } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==1 & educD == 0 & educ_adj == 0){
#     ggsave("Figures\\SurvT_OvsABdabt2Yes.png", width = 6, height = 4)
#   } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==2 & educD == 0 & educ_adj == 0){
#     ggsave("Figures\\SurvT_OvsABdiabt2No.png", width = 6, height = 4)
#   } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 1 & educ_adj == 0){
#     ggsave("Figures\\SurvT_OvsABeducHSless.png", width = 6, height = 4)
#   } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 2 & educ_adj == 0){
#     ggsave("Figures\\SurvT_OvsABeducCOLsom.png", width = 6, height = 4)
#   } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 3 & educ_adj == 0){
#     ggsave("Figures\\SurvT_OvsABeducColdeg.png", width = 6, height = 4)
#   } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 1 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 2 & educ_adj == 0){
#     ggsave("Figures\\SurvT_OvsABwhiteCOLsom.png", width = 6, height = 4)
#   } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 1){
#     ggsave("Figures\\SurvT_OvsAB_Eadj.png", width = 6, height = 4)
#   }
# } else if (blood_types == 1){
#   print(ggsurvplot(
#     fit = survfit(Surv(DF$durTX,DF$durTXC) ~ CAN_ABO, data = DF),
#     xlab = "Months",
#     ylab = "Transplant probability",
#     conf.int = TRUE,
#     censor.size=0.1,
#     size = 0.2,
#     xlim=c(0, (tau+3)),
#     break.time.by = 12,
#     ylim=c(0,1),
#     font.legend = c(14, "plain", "black"),
#     legend.title="Type",
#     legend.labs = c("B","O"),
#     legend = c(0.85, 0.2),
#     palette = c("gray60", "gray10"),fun = "event"))
#   if (post2015 == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
#     ggsave("Figures\\SurvT_OvsB.png", width = 6, height = 4)
#   }
# } else if (blood_types == 2){
#   print(ggsurvplot(
#     fit = survfit(Surv(DF$durTX,DF$durTXC) ~ CAN_ABO, data = DF),
#     xlab = "Months",
#     ylab = "Transplant probability",
#     conf.int = TRUE,
#     censor.size=0.1,
#     size = 0.2,
#     xlim=c(0, (tau+3)),
#     break.time.by = 12,
#     ylim=c(0,1),
#     font.legend = c(14, "plain", "black"),
#     legend.title="Type",
#     legend.labs = c("A","O"),
#     legend = c(0.85, 0.2),
#     palette = c("gray60", "gray10"),fun = "event"))
#   if (post2015 == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
#     ggsave("Figures\\SurvT_OvsA.png", width = 6, height = 4)
#   }
# }
# 
# 



######################################
#### Figures 1b
#####################################

if (blood_types == 0){
  # Generate Hazard rates 
  vHazTX_AB <- matrix(0,max(DF$durDE),1)
  vHazTX_O <- matrix(0,max(DF$durDE),1)
  for (t in 1:(max(DF$durDE)-1)) {
    denomTX_AB = sum((as.numeric(DF$durTX == t)*as.numeric(DF$durTXC == 1)+as.numeric(DF$durTX > t))*as.numeric(DF$CAN_ABO == 'AB'))
    vHazTX_AB[t] = sum(as.numeric(DF$durTX == t)*as.numeric(DF$durTXC == 1)*as.numeric(DF$CAN_ABO == 'AB'))/denomTX_AB
    
    denomTX_O = sum((as.numeric(DF$durTX == t)*as.numeric(DF$durTXC == 1)+as.numeric(DF$durTX > t))*as.numeric(DF$CAN_ABO == 'O'))
    vHazTX_O[t] = sum(as.numeric(DF$durTX == t)*as.numeric(DF$durTXC == 1)*as.numeric(DF$CAN_ABO == 'O'))/denomTX_O
  }
  
  ## Plot hazard
  x <- 1:(tau+5)
  y_AB <- vHazTX_AB[1:(tau+5)]
  y_O <- vHazTX_O[1:(tau+5)]
  
  haz_frame = data.frame(cbind("Months"=x,"O"=y_O,"AB"=y_AB))
  #Reshape data from wide to long
  df2 <- gather(haz_frame,Type,val,c(O,AB))
  
  
  print(ggplot(df2, aes(x = Months, y = val)) +
          geom_smooth(aes(colour = Type),se = F) +
          ylab("Transplant hazard") +
          theme_bw() +
          theme_classic() +
          scale_color_grey(start = 0.72, end = 0.4) +
          theme(legend.position = c(0.85, 0.80)) + 
          theme(legend.text = element_text(size = 15)) +
          theme(legend.title = element_text(size = 15)) +
          theme(legend.key.height = unit(0.8, 'cm'), legend.key.width = unit(1, 'cm')) +
          scale_x_continuous(breaks = seq(0, (tau+5), by = 12)) +
          theme(axis.title.x = element_text(size = 14, family = "sans", colour = "black")) +
          theme(axis.title.y = element_text(size = 14, family = "sans", colour = "black")) +
          theme(axis.text = element_text(face = "bold")) +
          labs(linetype = "Type")
  )
  if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\Thaz_OvsAB.png", width = 6, height = 4)
  } else if (post2015 == 1 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\Thaz_OvsABpost2015.png", width = 6, height = 4)
  } else if (post2015 == 2 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\Thaz_OvsABally.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 1 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\Thaz_OvsABlivdon.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 1 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\Thaz_OvsABcalentry0208.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 2 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\Thaz_OvsABcalentry0814.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 1 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\Thaz_OvsABcovadj.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 1 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\Thaz_OvsABwhite.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 2 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\Thaz_OvsABnonwhite.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 1 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\Thaz_OvsABmale.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 2 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\Thaz_OvsABfemale.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==1 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\Thaz_OvsABdabt2Yes.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==2 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\Thaz_OvsABdiabt2No.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 1 & educ_adj == 0){
    ggsave("Figures\\Thaz_OvsABeducHSless.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 2 & educ_adj == 0){
    ggsave("Figures\\Thaz_OvsABeducCOLsom.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 3 & educ_adj == 0){
    ggsave("Figures\\Thaz_OvsABeducColdeg.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 2 & educ_adj == 0){
    ggsave("Figures\\Thaz_OvsABscollpl.png", width = 6, height = 4)
  } else if (post2015 == 0 &  livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 1){
    ggsave("Figures\\Thaz_OvsAB_Eadj.png", width = 6, height = 4)
  }
} else if (blood_types == 1){
  # Generate Hazard rates 
  vHazTX_B <- matrix(0,max(DF$durDE),1)
  vHazTX_O <- matrix(0,max(DF$durDE),1)
  for (t in 1:(max(DF$durDE)-1)) {
    denomTX_B = sum((as.numeric(DF$durTX == t)*as.numeric(DF$durTXC == 1)+as.numeric(DF$durTX > t))*as.numeric(DF$CAN_ABO == 'B'))
    vHazTX_B[t] = sum(as.numeric(DF$durTX == t)*as.numeric(DF$durTXC == 1)*as.numeric(DF$CAN_ABO == 'B'))/denomTX_B
    
    denomTX_O = sum((as.numeric(DF$durTX == t)*as.numeric(DF$durTXC == 1)+as.numeric(DF$durTX > t))*as.numeric(DF$CAN_ABO == 'O'))
    vHazTX_O[t] = sum(as.numeric(DF$durTX == t)*as.numeric(DF$durTXC == 1)*as.numeric(DF$CAN_ABO == 'O'))/denomTX_O
  }
  
  ## Plot hazard
  x <- 1:(tau+5)
  y_B <- vHazTX_B[1:(tau+5)]
  y_O <- vHazTX_O[1:(tau+5)]
  
  haz_frame = data.frame(cbind("Months"=x,"O"=y_O,"B"=y_B))
  #Reshape data from wide to long
  df2 <- gather(haz_frame,Type,val,c(O,B))
  
  
  print(ggplot(df2,aes(x = Months, y = val)) +
          geom_smooth(aes(colour = Type),se = F) +        
          ylab("Transplant hazard") +
          theme_bw() +
          theme_classic() +
          scale_color_grey(start = 0.72, end = 0.4) +
          theme(legend.position = c(0.85, 0.80)) + 
          theme(legend.text = element_text(size=15)) +
          theme(legend.title = element_text(size=15)) +
          theme(legend.key.height= unit(0.8, 'cm'),legend.key.width= unit(1.5, 'cm')) +
          scale_x_continuous(breaks = seq(0, (tau+5), by = 12)) +
          theme(axis.title.x = element_text(size=14,  family="sans",colour="black")) +
          theme(axis.title.y = element_text(size=14,  family="sans",colour="black")) +
          theme(axis.text = element_text(face="bold")))
  if (post2015 == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\Thaz_OvsB.png", width = 6, height = 4)
  }
} else if (blood_types == 2){
  # Generate Hazard rates 
  vHazTX_A <- matrix(0,max(DF$durDE),1)
  vHazTX_O <- matrix(0,max(DF$durDE),1)
  for (t in 1:(max(DF$durDE)-1)) {
    denomTX_A = sum((as.numeric(DF$durTX == t)*as.numeric(DF$durTXC == 1)+as.numeric(DF$durTX > t))*as.numeric(DF$CAN_ABO == 'A'))
    vHazTX_A[t] = sum(as.numeric(DF$durTX == t)*as.numeric(DF$durTXC == 1)*as.numeric(DF$CAN_ABO == 'A'))/denomTX_A
    
    denomTX_O = sum((as.numeric(DF$durTX == t)*as.numeric(DF$durTXC == 1)+as.numeric(DF$durTX > t))*as.numeric(DF$CAN_ABO == 'O'))
    vHazTX_O[t] = sum(as.numeric(DF$durTX == t)*as.numeric(DF$durTXC == 1)*as.numeric(DF$CAN_ABO == 'O'))/denomTX_O
  }
  
  ## Plot hazard
  x <- 1:(tau+5)
  y_A <- vHazTX_A[1:(tau+5)]
  y_O <- vHazTX_O[1:(tau+5)]
  
  haz_frame = data.frame(cbind("Months"=x,"O"=y_O,"A"=y_A))
  #Reshape data from wide to long
  df2 <- gather(haz_frame,Type,val,c(O,A))
  
  
  print(ggplot(df2,aes(x = Months, y = val)) +
          geom_smooth(aes(colour = Type),se = F) +         
          ylab("Transplant hazard") +
          theme_bw() +
          theme_classic() +
          scale_color_grey(start = 0.72, end = 0.4) +
          theme(legend.position = c(0.85, 0.80)) + 
          theme(legend.text = element_text(size=15)) +
          theme(legend.title = element_text(size=15)) +
          theme(legend.key.height= unit(0.8, 'cm'),legend.key.width= unit(1.5, 'cm')) +
          scale_x_continuous(breaks = seq(0, (tau+5), by = 12)) +
          theme(axis.title.x = element_text(size=14,  family="sans",colour="black")) +
          theme(axis.title.y = element_text(size=14,  family="sans",colour="black")) +
          theme(axis.text = element_text(face="bold")))
  if (post2015 == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\Thaz_OvsA.png", width = 6, height = 4)
  }
}













##################################
## Code required to obtain Figure 4
##################################



nrow(DF)

table(DF$CAN_ABO)

if (blood_types == 3) {
  
  ########################################
  ##  Figure 4d
  ######################################## 
  
  print(ggsurvplot(
    fit = survfit(Surv(DF$durDE,DF$durDEC) ~ CAN_ABO, data = DF),
    xlab = "Months",
    ylab = "Survival probability",
    conf.int = FALSE,
    censor.size=0.1,
    size = 0.2,
    xlim=c(0, (tau+3)),
    break.time.by = 12,
    ylim=c(0.4,1),
    font.legend = c(14, "plain", "black"),
    legend.title="Type",
    legend.labs = c("A","AB","B","O"),
    legend = c(0.85, 0.8),
    palette = c("gray85", "gray50","gray31", "black")))
  if (post2015 == 0 & blood_types == 3 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\Surv_all.png", width = 6, height = 4)
  } else if (post2015 == 0 & blood_types == 3 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 1 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\Surv_all_white.png", width = 6, height = 4)
  } else if (post2015 == 2 & blood_types == 3 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 1 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 &  educD ==2 & educ_adj == 0){
    ggsave("Figures\\Surv_all_white_somecoll.png", width = 6, height = 4)
  }
  
  ########################################
  ##  Figure 4c
  ######################################## 
  
  print(ggsurvplot(
    fit = survfit(Surv(DF$durDEn,DF$durDEnC) ~ CAN_ABO, data = DF),
    xlab = "Months",
    ylab = "Survival probability with censoring",
    conf.int = FALSE,
    censor.size=0.1,
    size = 0.2,
    xlim=c(0, (tau+3)),
    break.time.by = 12,
    ylim=c(0.4,1),
    font.legend = c(14, "plain", "black"),
    legend.title="Type",
    legend.labs = c("A","AB","B","O"),
    legend = c(0.85, 0.8),
    palette = c("gray85", "gray50","gray31", "black")))
  if (post2015 == 0 & blood_types == 3 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\SurvC_all.png", width = 6, height = 4)
  } else if (post2015 == 0 & blood_types == 3 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 1 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\SurvC_all_white.png", width = 6, height = 4)
  } else if (post2015 == 2 & blood_types == 3 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 1 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 &  educD ==2 & educ_adj == 0){
    ggsave("Figures\\SurvC_all_white_somecoll.png", width = 6, height = 4)
  }
  
  ########################################
  ##  Figure 4a
  ######################################## 
  
  DF$durTXa = DF$durTX*DF$durTXC + (tau+20)*(1-DF$durTXC)
  print(ggsurvplot(
    fit = survfit(Surv(DF$durTXa,DF$durTXC) ~ CAN_ABO, data = DF),
    xlab = "Months",
    ylab = "Transplant probability",
    conf.int = FALSE,
    censor.size=0.1,
    size = 0.2,
    xlim=c(0, (tau+3)),
    break.time.by = 12,
    ylim=c(0,1),
    font.legend = c(14, "plain", "black"),
    legend.title="Type",
    legend.labs = c("A","AB","B","O"),
    legend = c(0.15, 0.8),
    palette = c("gray85", "gray50","gray31", "black"),fun = "event"))
  if (post2015 == 0 & blood_types == 3 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\SurvT_all.png", width = 6, height = 4)
  } else if (post2015 == 0 & blood_types == 3 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 1 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\SurvT_all_white.png", width = 6, height = 4)
  } else if (post2015 == 2 & blood_types == 3 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 1 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 &  educD ==2 & educ_adj == 0){
    ggsave("Figures\\SurvT_all_white_somecoll.png", width = 6, height = 4)
  }
  
  # print(ggsurvplot(
  #   fit = survfit(Surv(DF$durTX,DF$durTXC) ~ CAN_ABO, data = DF),
  #   xlab = "Months",
  #   ylab = "Transplant probability",
  #   conf.int = FALSE,
  #   censor.size=0.1,
  #   size = 0.2,
  #   xlim=c(0, (tau+3)),
  #   break.time.by = 12,
  #   ylim=c(0,1),
  #   font.legend = c(14, "plain", "black"),
  #   legend.title="Type",
  #   legend.labs = c("A","AB","B","O"),
  #   legend = c(0.15, 0.8),
  #   palette = c("gray85", "gray50","gray31", "black"),fun = "event"))
  # if (post2015 == 0 & blood_types == 3 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
  #   ggsave("Figures\\SurvT_all.png", width = 6, height = 4)
  # } else if (post2015 == 0 & blood_types == 3 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 1 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
  #   ggsave("Figures\\SurvT_all_white.png", width = 6, height = 4)
  # } else if (post2015 == 2 & blood_types == 3 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 1 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 &  educD ==2 & educ_adj == 0){
  #   ggsave("Figures\\SurvT_all_white_somecoll.png", width = 6, height = 4)
  # }
  
  
  # Generate Hazard rates
  vHazTX_A <- matrix(0,max(DF$durDE),1)
  vHazTX_AB <- matrix(0,max(DF$durDE),1)
  vHazTX_B <- matrix(0,max(DF$durDE),1)
  vHazTX_O <- matrix(0,max(DF$durDE),1)
  # Generate hazard rates
  for (t in 1:(max(DF$durDE)-1)) {
    denomTX_AB = sum((as.numeric(DF$durTX == t)*as.numeric(DF$durTXC == 1)+as.numeric(DF$durTX > t))*as.numeric(DF$CAN_ABO == 'AB'))
    vHazTX_AB[t] = sum(as.numeric(DF$durTX == t)*as.numeric(DF$durTXC == 1)*as.numeric(DF$CAN_ABO == 'AB'))/denomTX_AB
    
    denomTX_A = sum((as.numeric(DF$durTX == t)*as.numeric(DF$durTXC == 1)+as.numeric(DF$durTX > t))*as.numeric(DF$CAN_ABO == 'A'))
    vHazTX_A[t] = sum(as.numeric(DF$durTX == t)*as.numeric(DF$durTXC == 1)*as.numeric(DF$CAN_ABO == 'A'))/denomTX_A
    
    denomTX_B = sum((as.numeric(DF$durTX == t)*as.numeric(DF$durTXC == 1)+as.numeric(DF$durTX > t))*as.numeric(DF$CAN_ABO == 'B'))
    vHazTX_B[t] = sum(as.numeric(DF$durTX == t)*as.numeric(DF$durTXC == 1)*as.numeric(DF$CAN_ABO == 'B'))/denomTX_B
    
    denomTX_O = sum((as.numeric(DF$durTX == t)*as.numeric(DF$durTXC == 1)+as.numeric(DF$durTX > t))*as.numeric(DF$CAN_ABO == 'O'))
    vHazTX_O[t] = sum(as.numeric(DF$durTX == t)*as.numeric(DF$durTXC == 1)*as.numeric(DF$CAN_ABO == 'O'))/denomTX_O
    
  }
  
  ## Plot hazard
  x <- 1:(tau+5)
  y_AB <- vHazTX_AB[1:(tau+5)]
  y_A <- vHazTX_A[1:(tau+5)]
  y_B <- vHazTX_B[1:(tau+5)]
  y_O <- vHazTX_O[1:(tau+5)]
  
  sum(DF$CAN_ABO == 'A')
  sum(DF$CAN_ABO == 'AB')
  sum(DF$CAN_ABO == 'B')
  sum(DF$CAN_ABO == 'O')
  
  
  haz_frame = data.frame(cbind("Months"=x,"A"=y_A,"AB"=y_AB,"B"=y_B,"O"=y_O))
  #Reshape data from wide to long
  df2 <- gather(haz_frame,Type,val,c(A,AB,B,O))
  
  
  ########################################
  ##  Figure 4b
  ######################################## 
  
  print(ggplot(df2,aes(x = Months, y = val)) +
          geom_smooth(aes(colour = Type),se = FALSE, method = "loess", span = 0.27, size = 1.3) +
          ylab("Transplant hazard") +
          theme_bw() +
          theme_classic() +
          scale_color_grey(start = 0.95, end = 0.30) +
          theme(legend.position = c(0.85, 0.80)) +
          theme(legend.text = element_text(size=15)) +
          theme(legend.title = element_text(size=15)) +
          theme(legend.key.height= unit(0.8, 'cm'),legend.key.width= unit(1.5, 'cm')) +
          scale_x_continuous(breaks = seq(0, (tau+5), by = 12)) +
          scale_linetype_manual(values=c("solid", "dotted","dash", "twodash" )) +
          theme(axis.title.x = element_text(size=14,  family="sans",colour="black")) +
          theme(axis.title.y = element_text(size=14,  family="sans",colour="black")) +
          theme(axis.text = element_text(face="bold")))
  if (post2015 == 0 & blood_types == 3 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\Thaz_all.png", width = 6, height = 4)
  } else if (post2015 == 0 & blood_types == 3 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 1 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 & educD == 0 & educ_adj == 0){
    ggsave("Figures\\Thaz_all_white.png", width = 6, height = 4)
  } else if (post2015 == 2 & blood_types == 3 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 1 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0 &  educD ==2 & educ_adj == 0){
    ggsave("Figures\\Thaz_all_white_somecoll.png", width = 6, height = 4)
  }
  
  
}







cat("Total observations =" , nrow(DF))
cat("O observations =" , sum(as.numeric(DF$CAN_ABO == "O")))
cat("AB observations =" , sum(as.numeric(DF$CAN_ABO == "AB")))
cat("B observations =" , sum(as.numeric(DF$CAN_ABO == "B")))
cat("A observations =" , sum(as.numeric(DF$CAN_ABO == "A")))
























# 
# 
# #  table(DF$CAN_DGN)
# # DF$diab_type2 = as.numeric(DF$CAN_DGN == 3040 )
# 
# ## Add KM Figures segmented by Diabetes status
# ###############################################
# 
# 
# 
# if (blood_types == 0) {
#   print(ggsurvplot(
#     fit = survfit(Surv(DF$durDE,DF$durDEC) ~ diab_type2, data = DF),
#     xlab = "Months",
#     ylab = "Survival probability",
#     conf.int = TRUE,
#     censor.size=0.1,
#     size = 0.2,
#     xlim=c(0, 120),
#     break.time.by = 12,
#     ylim=c(0.4,1),
#     font.legend = c(14, "plain", "black"),
#     legend.title="Type-II Diabetes",
#     legend.labs = c("No","Yes"),
#     legend = c(0.85, 0.8),
#     palette = c("gray60", "gray10")))
#   if (post2015 == 0  & blood_types == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0  & educD == 0 & educ_adj == 0){
#     ggsave("Figures\\Surv_OandAB_diab.png", width = 6, height = 4)
#   }
# 
# 
#   print(ggsurvplot(
#     fit = survfit(Surv(DF$durDEn,DF$durDEnC) ~ diab_type2, data = DF),
#     xlab = "Months",
#     ylab = "Survival probability with censoring",
#     conf.int = TRUE,
#     censor.size=0.1,
#     size = 0.2,
#     xlim=c(0, 120),
#     break.time.by = 12,
#     ylim=c(0.4,1),
#     font.legend = c(14, "plain", "black"),
#     legend.title="Type-II Diabetes",
#     legend.labs = c("No","Yes"),
#     legend = c(0.85, 0.8),
#     palette = c("gray60", "gray10")))
#   if (post2015 == 0 & blood_types == 0 & livingdon == 0 & calentry == 0 & covadj == 0 & race == 0 & biosex == 0 & diab_ent == 0 &  diab_t2 ==0  & educD == 0 & educ_adj == 0){
#     ggsave("Figures\\SurvC_OandAB_diab.png", width = 6, height = 4)
#   }
# 
# }
# 
# 
# sum(DF$diab_type2, na.rm = TRUE)
# sum(1-DF$diab_type2, na.rm = TRUE)
# 
# 
# 
# 
# 
# # > sessionInfo()
# # R version 4.3.1 (2023-06-16 ucrt)
# # Platform: x86_64-w64-mingw32/x64 (64-bit)
# # Running under: Windows 11 x64 (build 22631)
# # 
# # Matrix products: default
# # 
# # 
# # locale:
# #   [1] LC_COLLATE=English_United Kingdom.utf8  LC_CTYPE=English_United Kingdom.utf8    LC_MONETARY=English_United Kingdom.utf8
# # [4] LC_NUMERIC=C                            LC_TIME=English_United Kingdom.utf8    
# # 
# # time zone: Europe/London
# # tzcode source: internal
# # 
# # attached base packages:
# #   [1] stats     graphics  grDevices utils     datasets  methods   base     
# # 
# # other attached packages:
# #   [1] survminer_0.4.9 ggpubr_0.6.0    survival_3.5-5  ggplot2_3.4.2   tidyr_1.3.0     dplyr_1.1.2 
