####################################################################################
##  Code for: Regime and Treatment Effects in Duration Models: 
##            Decomposing Expectation and Transplant Effects on
##            the Kidney Waitlist
#####
##                                                                    
##  Author: Stephen Kastoryano                                        
##  Date  : 20 May 2022                                               
##                                                                    
##  Purpose: Clean and prepare SRTR kidney data for analysis by blood type 
##           
##                                                                        
##           
##  input:  "cand_kipa.sas7bdat" - SRTR kidney data. 
##           Contact SRTR to request data at https://www.srtr.org/requesting-srtr-data/data-requests/
##          
##
##  output: "df_can_final.txt", "df_can_final_post2015.txt" - for LARTE_kidney.R
##           and Figures 1, 4, 5
##
##          * To obtain Figure 1 and "df_can_final.txt" set post2015=0 and plot_appFig2 = 0 on lines 43-44 
##          * To obtain Figure 5 and "df_can_final_post2015.txt" set post2015=1 and plot_appFig2 = 0 on lines 43-44     
##          * To obtain Figure 4 set post2015=0 and plot_appFig2 = 1 on lines 43-44 
##            
##
##                                                                    
######################################################################################

library("haven")     
library("foreign")
library("dplyr")
library("tidyr")
library("ggplot2")    
library("survival") 
library("survminer") 



df_can1 <- read_sas("D:\\Transplant data\\cand_kipa.sas7bdat")
head(df_can1)


post2015 = 1   # Equal to 0 for pre-2015 reform analysis, 1 for post-2015 reform analysis
plot_appFig2 = 0   # Should be equal to 1 to generate appendix Figure 2 trend for all blood types


df_can=df_can1
nrow(df_can)


df_can =df_can[!(is.na(df_can$CAN_ACTIVATE_DT)),]  # remove people who don't have an activation date
nrow(df_can)

df_can= df_can[(df_can$WL_ORG =="KI"),]  # select only people set to receive kidney transplant
nrow(df_can)


df_can= df_can[(df_can$CAN_ACTIVATE_DT >="2002-12-01"),]   
nrow(df_can)

if (post2015 == 0) {
  df_can= df_can[(df_can$CAN_ACTIVATE_DT <="2014-12-01"),]   # "2014-12-01" because allocation system was rehauled in late 2014
  
} else {
  df_can= df_can[(df_can$CAN_ACTIVATE_DT >"2014-12-01"),]   # "2014-12-01" because allocation system was rehauled in late 2014
}

nrow(df_can)

# Only keep first observation
length(df_can$PERS_ID)
length(unique(df_can$PERS_ID))
df_can <- df_can[order(df_can$PERS_ID,df_can$CAN_ACTIVATE_DT),] # sort variables
df_can = df_can[!(duplicated(df_can[,c("PERS_ID")])),]
nrow(df_can)



df_can= df_can[!is.na(df_can$CAN_ABO),]  # Drop observations with no blood type data (only 1 observation dropped)
table(df_can$CAN_ABO)
sum(is.na(df_can$CAN_ABO))
nrow(df_can)

df_can= df_can[(df_can$CAN_AGE_AT_LISTING >=18),]  # because under 18s have different priority
nrow(df_can)


nrow(df_can)
shareAB = sum(as.numeric(df_can$CAN_ABO == 'AB'))/sum(as.numeric(df_can$CAN_ABO == 'AB')+ as.numeric(df_can$CAN_ABO == 'B') + as.numeric(df_can$CAN_ABO == 'O'))
sum(as.numeric(df_can$CAN_ABO == 'AB'))
shareAB

# Received kidney from living donor
sum((df_can_final$CAN_ABO != 'AB')*(df_can_final$DON_TY == "L"))/sum((df_can_final$CAN_ABO != 'AB'))
sum((df_can_final$CAN_ABO == 'AB')*(df_can_final$DON_TY == "L"))/sum((df_can_final$CAN_ABO == 'AB'))
table(df_can$DON_TY)
sum(is.na(df_can$DON_TY))
df_can =df_can[(df_can$DON_TY !="L"),]   # remove anyone who received kidney from living donor
nrow(df_can)
# This variable is problematic. You probably want to do an analysis with and without these observation

shareAB = sum(as.numeric(df_can$CAN_ABO == 'AB'))/sum(as.numeric(df_can$CAN_ABO == 'AB')+ as.numeric(df_can$CAN_ABO == 'B') + as.numeric(df_can$CAN_ABO == 'O'))
sum(as.numeric(df_can$CAN_ABO == 'AB'))
shareAB
# From the shares, it doesn't seem that drastically more AB types find living donor matches...but you should still run robustness test on this.

df_can =df_can[!(is.na(df_can$CAN_ACTIVATE_DT)),]  # remove people who don't have an activation date
nrow(df_can)






## Preparing outcome variables ##

if (post2015 == 0) {
  df_can$CAN_DEATH_DT[(df_can$CAN_DEATH_DT> "2014-12-01")] <- "2014-12-01"   # replace death dates larger than  "2014-12-01" by "2014-12-01"
  df_can$CAN_DEATH_DT = df_can$CAN_DEATH_DT %>% replace_na("2014-12-01")  # replace for death date NA values with last date in dataset
  sum((df_can$CAN_DEATH_DT == "2014-12-01"))
  sum(!(df_can$CAN_DEATH_DT == "2014-12-01"))
  
  df_can$PERS_NEXTTX[(df_can$PERS_NEXTTX> "2014-12-01")] <- "2014-12-01"   # replace transplant dates larger than  "2014-12-01" by "2014-12-01"
  df_can$PERS_NEXTTX = df_can$PERS_NEXTTX %>% replace_na("2014-12-01")   # replace for transplant date NA values with last date in dataset
  sum((df_can$PERS_NEXTTX == "2014-12-01"))
  sum(!(df_can$PERS_NEXTTX == "2014-12-01"))
  
  
  # Define duration to outcome and duration to treamtent variables
  df_can$durDE = df_can$CAN_DEATH_DT -df_can$CAN_ACTIVATE_DT          # duration to death
  df_can$durDEC = as.numeric(df_can$CAN_DEATH_DT != "2014-12-01")     # dummy =1 if death occured, 0 otherwise
  
  df_can$durTX = as.numeric(df_can$PERS_NEXTTX != "2014-12-01")*(df_can$PERS_NEXTTX -df_can$CAN_ACTIVATE_DT) + as.numeric(df_can$PERS_NEXTTX == "2014-12-01")* df_can$durDE          # duration to transplant
  df_can$durTXC = as.numeric(df_can$durDE != df_can$durTX)       # dummy =1 if transplant occured, 0 otherwise
  
} else {
  df_can$CAN_DEATH_DT = df_can$CAN_DEATH_DT %>% replace_na("2021-03-03")  # replace for death date NA values with last date in dataset
  sum((df_can$CAN_DEATH_DT == "2021-03-03"))
  sum(!(df_can$CAN_DEATH_DT == "2021-03-03"))
  
  df_can$PERS_NEXTTX = df_can$PERS_NEXTTX %>% replace_na("2021-03-03")   # replace for transplant date NA values with last date in dataset
  sum((df_can$PERS_NEXTTX == "2021-03-03"))
  sum(!(df_can$PERS_NEXTTX == "2021-03-03"))
  
  
  # Define duration to outcome and duration to treamtent variables
  df_can$durDE = df_can$CAN_DEATH_DT -df_can$CAN_ACTIVATE_DT          # duration to death
  df_can$durDEC = as.numeric(df_can$CAN_DEATH_DT != "2021-03-03")     # dummy =1 if death occured, 0 otherwise
  
  df_can$durTX = as.numeric(df_can$PERS_NEXTTX != "2021-03-03")*(df_can$PERS_NEXTTX -df_can$CAN_ACTIVATE_DT) + as.numeric(df_can$PERS_NEXTTX == "2021-03-03")* df_can$durDE          # duration to transplant
  df_can$durTXC = as.numeric(df_can$durDE != df_can$durTX)       # dummy =1 if transplant occured, 0 otherwise
}




## Remove some strange observations, assumed to be random typos, non-systematic ##
nrow(df_can)
df_can =df_can[!(df_can$durDE<1),]  # remove people who have non-positive duration to death
nrow(df_can)
df_can =df_can[!(df_can$durTX<1),]  # remove people who have non-positive duration to transplant
nrow(df_can)
df_can =df_can[!(df_can$durDE <df_can$durTX ),]  # remove people who have duration to transplant larger than duration to death (1 observation)
nrow(df_can)


sum(df_can$durTXC)  # number of people who received transplant
sum(df_can$durDEC)  # number of people who died


table(df_can$CAN_ABO)  ## Tabulate number of people with different blood types
aggregate(df_can$durTX, list(df_can$CAN_ABO), mean)  # Average time to treatment by blood type
aggregate(df_can$durDE, list(df_can$CAN_ABO), mean)  # Average time to death by blood type

# df_can2 = df_can[(df_can$durDEC ==1),] 
# table(df_can2$CAN_ABO)
# 
# aggregate(df_can2$durTX, list(df_can2$CAN_ABO), mean)
# aggregate(df_can2$durDE, list(df_can2$CAN_ABO), mean)

df_can =df_can[!(df_can$CAN_ABO == "A1"),]  # remove few indivudals with non-standard blood types
df_can =df_can[!(df_can$CAN_ABO == "A2"),]  # remove few indivudals with non-standard blood types
df_can =df_can[!(df_can$CAN_ABO == "A1B"),]  # remove few indivudals with non-standard blood types
df_can =df_can[!(df_can$CAN_ABO == "A2B"),]  # remove few indivudals with non-standard blood types
nrow(df_can)




# duration to death when censoring all death durations at the moment a person enters treatment 
df_can$durDEn = df_can$durDE*as.numeric(df_can$durDE<= df_can$durTX ) + df_can$durTX*as.numeric(df_can$durDE> df_can$durTX )
df_can$durDEnC =  as.numeric(df_can$durDE == df_can$durDEn)* as.numeric(df_can$CAN_DEATH_DT != "2021-03-03")*df_can$durDEC




df_can_final = df_can

table(df_can_final$CAN_ABO)

if (plot_appFig2 == 0) {
# These lines must be include for AB vs. B/O analysis
df_can_final = df_can[(df_can$CAN_ABO != "A"),]   # Drop type A blood types who have probability of treatment between AB and BorO
#df_can_final = df_can_final[(df_can_final$CAN_ABO != "B"),]   # Drop type B blood types who have probability of treatment between AB and BorO
print(table(df_can_final$CAN_ABO))
df_can_final$CAN_ABO[(df_can_final$CAN_ABO != 'AB')] <-  "BorO"    # merge A and O blood types together
}

# # These lines must be include for A vs. B/O analysis
# df_can_final = df_can[(df_can$CAN_ABO != "AB"),]   # Drop type AB blood types who have probability of treatment between A and BorO
# df_can_final$CAN_ABO[(df_can_final$CAN_ABO != 'A')] <-  "BorO"    # merge A and O blood types together




nrow(df_can_final)

table(df_can_final$CAN_ABO)

save(df_can_final,file="D:\\Dropbox\\ContDurMA\\CompCode 2022\\Cleaning1.Rda")

## Select and clean covariates ##




load("D:\\Dropbox\\ContDurMA\\CompCode 2022\\Cleaning1.Rda") 




nrow(df_can_final)
## Cleaning and including PRA  ##

df_canPRA1 <- read_sas("D:\\Transplant data\\pra_hist.sas7bdat")
head(df_canPRA1)

df_canPRA <- df_canPRA1
nrow(df_canPRA)

df_canPRA =df_canPRA[(df_canPRA$WL_ORG == "KI"),]  # remove people who are not registered for kidney transpant
nrow(df_canPRA)

df_canPRA = df_canPRA[!(duplicated(df_canPRA[,c("PX_ID")])),]

df_canPRA_merge = df_canPRA[,c("PX_ID", "CANHX_CPRA")]

df_can_final <- merge(df_can_final, df_canPRA_merge, df_canPRA_merge="PX_ID")


nrow(df_can_final)


#table(df_can_final$CANHX_CPRA) # CPRA distribution
sum(is.na(df_can_final$CANHX_CPRA)) 


sum(as.numeric(df_can_final$CANHX_CPRA == 0))
sum(as.numeric(df_can_final$CANHX_CPRA <= 0.60))
sum(as.numeric(df_can_final$CANHX_CPRA > 0.60))

df_can_final$CANHX_CPRA_0 = as.numeric(df_can_final$CANHX_CPRA == 0)
df_can_final$CANHX_CPRA_60 = as.numeric(df_can_final$CANHX_CPRA <= 0.6)
df_can_final$CANHX_CPRA_100 =  as.numeric(df_can_final$CANHX_CPRA > 0.6)


# Look at whether distributions for blood types are skewed
shareAB = sum(as.numeric(df_can_final$CANHX_CPRA_100 ==1)*as.numeric(df_can_final$CAN_ABO == 'AB'))/sum(as.numeric(df_can_final$CAN_ABO == 'AB'))
shareBO = sum(as.numeric(df_can_final$CANHX_CPRA_100 ==1)*as.numeric(df_can_final$CAN_ABO != 'AB'))/sum(as.numeric(df_can_final$CAN_ABO != 'AB'))
shareAB
shareBO
# These distributions look comparable
c1 <- rgb(173,216,230,max = 255, alpha = 80, names = "lt.blue")
c2 <- rgb(255,192,203, max = 255, alpha = 80, names = "lt.pink")
A = df_can_final$CANHX_CPRA[(df_can_final$CAN_ABO == 'AB')]
B = df_can_final$CANHX_CPRA[(df_can_final$CAN_ABO != 'AB')]
B =  B[sample(length(B), length(A)) ]
hgA <- hist(A, breaks = 25, plot = FALSE) # Save first histogram data
hgB <- hist(B, breaks = 25, plot = FALSE) # Save 2nd histogram data
plot(hgA, col = c1,ylim=c(0,200)) # Plot 1st histogram using a transparent color
plot(hgB, col = c2,ylim=c(0,200), add = TRUE) # Add 2nd histogram using different color
table(A)
table(B)
# These distributions look comparable



nrow(df_can_final)


shareAB = sum(as.numeric(df_can_final$CAN_ABO == 'AB'))/nrow(df_can_final)
sum(as.numeric(df_can_final$CAN_ABO == 'AB'))
shareAB

nrow(df_can_final)
df_can_final =df_can_final[(df_can_final$CANHX_CPRA == 0),]   # only keep CPRA == 0 people. So excluding all individuals with antibodies
nrow(df_can_final)
# This variable is problematic. You probably want to do an analysis with an without these observation and then conduct robustness check


shareAB = sum(as.numeric(df_can_final$CAN_ABO == 'AB'))/nrow(df_can_final)
sum(as.numeric(df_can_final$CAN_ABO == 'AB'))
shareAB




# I don't love this dialysis variable. It is inconsistent across CAN_DIAL_DT and CAN_DIAL
# Also, almost everyone is on dialysis by entry into waitlist and most others go on dialysis shortly after entry
df_can_final$DIAL_ENTRY = as.numeric(df_can_final$CAN_DIAL_DT <= (df_can_final$CAN_ACTIVATE_DT))  # create binary variable=1 if on dialysis when entering the waitlist
#df_can_final$DIAL_ENTRY[is.na(df_can_final$DIAL_ENTRY)] <- 1  # I will make the assumption that NA individuals were on dialysis at entry into waitlist
table(df_can_final$DIAL_ENTRY)  # On Dialysis when entering the waitlist
sum(is.na(df_can_final$DIAL_ENTRY)) 



# Selection on Dialysis variable 
df_can_final$DIAL_ENTRY[is.na(df_can_final$DIAL_ENTRY)] <- 999
nrow(df_can_final)
df_can_final =df_can_final[(df_can_final$DIAL_ENTRY != 0),]   # only keep people observed to be on dialysis. 
nrow(df_can_final)
df_can_final$DIAL_ENTRY[(df_can_final$DIAL_ENTRY == 999)] <- NA
# This variable is problematic. You probably want to do an analysis with an without these observation and then conduct robustness check



# Look at whether distributions for blood types are skewed
shareAB = sum(as.numeric(df_can_final$DIAL_ENTRY ==1)*as.numeric(df_can_final$CAN_ABO == 'AB'))/sum(as.numeric(df_can_final$CAN_ABO == 'AB'))
shareBO = sum(as.numeric(df_can_final$DIAL_ENTRY ==1)*as.numeric(df_can_final$CAN_ABO != 'AB'))/sum(as.numeric(df_can_final$CAN_ABO != 'AB'))
shareAB
shareBO
# These distributions look comparable

#table(df_can_final$CAN_DIAL_DT) 
sum(is.na(df_can_final$CAN_DIAL_DT))
table(df_can_final$CAN_DIAL) 
sum(is.na(df_can_final$CAN_DIAL))

# check = df_can_final[,c("CAN_ACTIVATE_DT", "CAN_DIAL_DT","CAN_DIAL")]
# 
# dialdiff =  df_can_final$CAN_DIAL_DT - df_can_final$CAN_ACTIVATE_DT
# dialdiff = as.numeric(dialdiff[!is.na(dialdiff)])
# dialdiff = order(dialdiff[(dialdiff>0)])
# hist(dialdiff,
#      xlim=c(0,5000),
#      breaks=500) 
# 
# length(dialdiff)


# Which Kidney charactersitcs will not be accepted



table(df_can_final$CAN_ACPT_HBC_POS)   # Accept an Hepatitis B Core Antibody Positive Donor?
sum(is.na(df_can_final$CAN_ACPT_HBC_POS))
df_can_final$CAN_ACPT_HBC_POS1 = as.numeric(df_can_final$CAN_ACPT_HBC_POS == "Y")


# Look at whether distributions for blood types are skewed
shareAB = sum(as.numeric(df_can_final$CAN_ACPT_HBC_POS1 ==1)*as.numeric(df_can_final$CAN_ABO == 'AB'))/sum(as.numeric(df_can_final$CAN_ABO == 'AB'))
shareBO = sum(as.numeric(df_can_final$CAN_ACPT_HBC_POS1 ==1)*as.numeric(df_can_final$CAN_ABO != 'AB'))/sum(as.numeric(df_can_final$CAN_ABO != 'AB'))
shareAB
shareBO
# These distributions look comparable


table(df_can_final$CAN_ACPT_HCV_POS)   # Accept an HCV Positive donor?
sum(is.na(df_can_final$CAN_ACPT_HCV_POS))
df_can_final$CAN_ACPT_HCV_POS1 = as.numeric(df_can_final$CAN_ACPT_HCV_POS == "Y")

# Look at whether distributions for blood types are skewed
shareAB = sum(as.numeric(df_can_final$CAN_ACPT_HCV_POS1 ==1)*as.numeric(df_can_final$CAN_ABO == 'AB'))/sum(as.numeric(df_can_final$CAN_ABO == 'AB'))
shareBO = sum(as.numeric(df_can_final$CAN_ACPT_HCV_POS1 ==1)*as.numeric(df_can_final$CAN_ABO != 'AB'))/sum(as.numeric(df_can_final$CAN_ABO != 'AB'))
shareAB
shareBO
# These distributions look comparable



table(df_can_final$CAN_MIN_PEAK_CREAT) # Accepted Creatinine level of Donor?
sum(is.na(df_can_final$CAN_MIN_PEAK_CREAT))

nrow(df_can_final)
df_can_final$CAN_MIN_PEAK_CREAT[(df_can_final$CAN_MIN_PEAK_CREAT > 20)] <- NA  # Values above 20 are missing values
nrow(df_can_final)
sum(as.numeric(df_can_final$CAN_MIN_PEAK_CREAT <= 5))
sum(as.numeric(df_can_final$CAN_MIN_PEAK_CREAT > 5))

df_can_final$CAN_MIN_PEAK_CREAT_5up = as.numeric(df_can_final$CAN_MIN_PEAK_CREAT > 5)


# Look at whether distributions for blood types are skewed
c1 <- rgb(173,216,230,max = 255, alpha = 80, names = "lt.blue")
c2 <- rgb(255,192,203, max = 255, alpha = 80, names = "lt.pink")
A = df_can_final$CAN_MIN_PEAK_CREAT[(df_can_final$CAN_ABO == 'AB')]
B = df_can_final$CAN_MIN_PEAK_CREAT[(df_can_final$CAN_ABO != 'AB')]
B =  B[sample(length(B), length(A)) ]
hgA <- hist(A, breaks = 20, plot = FALSE) # Save first histogram data
hgB <- hist(B, breaks = 20, plot = FALSE) # Save 2nd histogram data
plot(hgA, col = c1,ylim=c(0,3000)) # Plot 1st histogram using a transparent color
plot(hgB, col = c2,ylim=c(0,3000), add = TRUE) # Add 2nd histogram using different color
table(A)
table(B)
# These distributions look comparable


# Most other acceptance variables have excessively large amounts of NA

nrow(df_can_final)

table(df_can_final$CAN_AGE_AT_LISTING)  # Calculated Candidate Age at Listing
sum(is.na(df_can_final$CAN_AGE_AT_LISTING))
sum(as.numeric(df_can_final$CAN_AGE_AT_LISTING > 0))
sum(as.numeric(df_can_final$CAN_AGE_AT_LISTING <= 41))
sum(as.numeric(df_can_final$CAN_AGE_AT_LISTING > 41)*as.numeric(df_can_final$CAN_AGE_AT_LISTING <= 51))
sum(as.numeric(df_can_final$CAN_AGE_AT_LISTING > 51)*as.numeric(df_can_final$CAN_AGE_AT_LISTING <= 58))
sum(as.numeric(df_can_final$CAN_AGE_AT_LISTING > 58)*as.numeric(df_can_final$CAN_AGE_AT_LISTING <= 65))
sum(as.numeric(df_can_final$CAN_AGE_AT_LISTING > 65))

df_can_final$CAN_AGE_AT_LISTING_41 = as.numeric(df_can_final$CAN_AGE_AT_LISTING <= 41)
df_can_final$CAN_AGE_AT_LISTING_51 = as.numeric(df_can_final$CAN_AGE_AT_LISTING > 41)*as.numeric(df_can_final$CAN_AGE_AT_LISTING <= 51)
df_can_final$CAN_AGE_AT_LISTING_58 = as.numeric(df_can_final$CAN_AGE_AT_LISTING > 51)*as.numeric(df_can_final$CAN_AGE_AT_LISTING <= 58)
df_can_final$CAN_AGE_AT_LISTING_65 = as.numeric(df_can_final$CAN_AGE_AT_LISTING > 58)*as.numeric(df_can_final$CAN_AGE_AT_LISTING <= 65)
df_can_final$CAN_AGE_AT_LISTING_65up = as.numeric(df_can_final$CAN_AGE_AT_LISTING > 65)
df_can_final$CAN_AGE_AT_LISTING_SQ = df_can_final$CAN_AGE_AT_LISTING^2
df_can_final$CAN_AGE_AT_LISTING_CB = df_can_final$CAN_AGE_AT_LISTING^3

# Look at whether distributions for blood types are skewed
c1 <- rgb(173,216,230,max = 255, alpha = 80, names = "lt.blue")
c2 <- rgb(255,192,203, max = 255, alpha = 80, names = "lt.pink")
A = df_can_final$CAN_AGE_AT_LISTING[(df_can_final$CAN_ABO == 'AB')]
B = df_can_final$CAN_AGE_AT_LISTING[(df_can_final$CAN_ABO != 'AB')]
B =  B[sample(length(B), length(A)) ]
hgA <- hist(A, breaks = 20, plot = FALSE) # Save first histogram data
hgB <- hist(B, breaks = 20, plot = FALSE) # Save 2nd histogram data
plot(hgA, col = c1,ylim=c(0,3000)) # Plot 1st histogram using a transparent color
plot(hgB, col = c2,ylim=c(0,3000), add = TRUE) # Add 2nd histogram using different color
table(A)
table(B)
# These distributions look comparable

table(df_can_final$CAN_EDUCATION)  # Calculated Candidate Age at Listing  35 + 12327 + 403 variables are NA, problematic. Could drop them
sum(is.na(df_can_final$CAN_EDUCATION))
df_can_final$CAN_EDUCATION[(df_can_final$CAN_EDUCATION > 6)] <- NA
df_can_final$CAN_EDUCATION_HS = as.numeric(df_can_final$CAN_EDUCATION < 4)
df_can_final$CAN_EDUCATION_COL = as.numeric(df_can_final$CAN_EDUCATION == 4)
df_can_final$CAN_EDUCATION_COLDEG = as.numeric(df_can_final$CAN_EDUCATION > 4)


# Look at whether distributions for blood types are skewed
c1 <- rgb(173,216,230,max = 255, alpha = 80, names = "lt.blue")
c2 <- rgb(255,192,203, max = 255, alpha = 80, names = "lt.pink")
A = df_can_final$CAN_EDUCATION[(df_can_final$CAN_ABO == 'AB')]
B = df_can_final$CAN_EDUCATION[(df_can_final$CAN_ABO != 'AB')]
B =  B[sample(length(B), length(A)) ]
hgA <- hist(A, breaks = 6, plot = FALSE) # Save first histogram data
hgB <- hist(B, breaks = 6, plot = FALSE) # Save 2nd histogram data
plot(hgA, col = c1,ylim=c(0,5000)) # Plot 1st histogram using a transparent color
plot(hgB, col = c2,ylim=c(0,5000), add = TRUE) # Add 2nd histogram using different color
table(A)
table(B)
# These distributions look comparable

table(df_can_final$CAN_EMPL_STAT)  # Patient/s Employment Status - Pre-6/30/2004   <- check that this variable is not NA for Post-6/30/2004
sum(is.na(df_can_final$CAN_EMPL_STAT))  ## ->>> Unusable, too many NA

table(df_can_final$CAN_BMI)  # Candidate BMI
sum(is.na(df_can_final$CAN_BMI))  
df_can_final$CAN_BMI[(df_can_final$CAN_BMI > 70)] <- NA
df_can_final$CAN_BMI_under19 = as.numeric(df_can_final$CAN_BMI <=19)
df_can_final$CAN_BMI_1925= as.numeric(df_can_final$CAN_BMI > 19)*as.numeric(df_can_final$CAN_BMI <= 25)
df_can_final$CAN_BMI_2630= as.numeric(df_can_final$CAN_BMI > 25)*as.numeric(df_can_final$CAN_BMI <= 30)
df_can_final$CAN_BMI_over30 = as.numeric(df_can_final$CAN_BMI > 30)


# Look at whether distributions for blood types are skewed
c1 <- rgb(173,216,230,max = 255, alpha = 80, names = "lt.blue")
c2 <- rgb(255,192,203, max = 255, alpha = 80, names = "lt.pink")
A = df_can_final$CAN_BMI[(df_can_final$CAN_ABO == 'AB')]
B = df_can_final$CAN_BMI[(df_can_final$CAN_ABO != 'AB')]
B =  B[sample(length(B), length(A)) ]
hgA <- hist(A, breaks = 25, plot = FALSE) # Save first histogram data
hgB <- hist(B, breaks = 25, plot = FALSE) # Save 2nd histogram data
plot(hgA, col = c1,ylim=c(0,5000)) # Plot 1st histogram using a transparent color
plot(hgB, col = c2,ylim=c(0,5000), add = TRUE) # Add 2nd histogram using different color
table(A)
table(B)
# These distributions look comparable


table(df_can_final$CAN_DRUG_TREAT_HYPERTEN) # Patient hypertension. There are too many unobserved variables to add as covariate
sum(is.na(df_can_final$CAN_DRUG_TREAT_HYPERTEN))

# Creatinine measures of candidate are not very well registered
# CAN_MOST_RECENT_CREAT has about 33% missing values
# CAN_CREAT_CLEAR has about has 96% missing values
table(df_can_final$CAN_CREAT_CLEAR) # Candidate creatinine measure. There are too many unobserved variables to add as covariate
sum(is.na(df_can_final$CAN_CREAT_CLEAR))


table(df_can_final$CAN_MALIG) # 	Any previous Malignancy
sum(is.na(df_can_final$CAN_MALIG)) 
df_can_final$CAN_MALIG[as.logical(1-as.numeric((df_can_final$CAN_MALIG == "Y"))-as.numeric((df_can_final$CAN_MALIG == "N")))] <- NA
df_can_final$CAN_MALIG[(df_can_final$CAN_MALIG == "Y")] <- 1
df_can_final$CAN_MALIG[(df_can_final$CAN_MALIG == "N")] <- 0

check = df_can_final[!is.na(df_can_final$CAN_MALIG), c("CAN_MALIG", "CAN_ABO")]


# Look at whether distributions for blood types are skewed
shareAB = sum(as.numeric(check$CAN_MALIG == 1)*as.numeric(check$CAN_ABO == 'AB'))/sum(as.numeric(check$CAN_ABO == 'AB'))
shareBO = sum(as.numeric(check$CAN_MALIG == 1)*as.numeric(check$CAN_ABO != 'AB'))/sum(as.numeric(check$CAN_ABO != 'AB'))
shareAB
shareBO
# These distributions look comparable




table(df_can_final$CAN_RACE_SRTR)  # SRTR Patient Race
sum(is.na(df_can_final$CAN_RACE_SRTR)) 
df_can_final$ASIAN = as.numeric(df_can_final$CAN_RACE_SRTR == "ASIAN")
df_can_final$BLACK = as.numeric(df_can_final$CAN_RACE_SRTR == "BLACK")
df_can_final$OTHER_NONWHITE = as.numeric(df_can_final$CAN_RACE_SRTR == "MULTI") + as.numeric(df_can_final$CAN_RACE_SRTR == "NATIVE") + as.numeric(df_can_final$CAN_RACE_SRTR == "PACIFIC")
df_can_final$WHITE = as.numeric(df_can_final$CAN_RACE_SRTR == "WHITE")

# Look at whether distributions for blood types are skewed
shareAB = sum(as.numeric(df_can_final$ASIAN ==1)*as.numeric(df_can_final$CAN_ABO == 'AB'))/sum(as.numeric(df_can_final$CAN_ABO == 'AB'))
shareBO = sum(as.numeric(df_can_final$ASIAN ==1)*as.numeric(df_can_final$CAN_ABO != 'AB'))/sum(as.numeric(df_can_final$CAN_ABO != 'AB'))
shareAB
shareBO

shareAB = sum(as.numeric(df_can_final$BLACK ==1)*as.numeric(df_can_final$CAN_ABO == 'AB'))/sum(as.numeric(df_can_final$CAN_ABO == 'AB'))
shareBO = sum(as.numeric(df_can_final$BLACK ==1)*as.numeric(df_can_final$CAN_ABO != 'AB'))/sum(as.numeric(df_can_final$CAN_ABO != 'AB'))
shareAB
shareBO

shareAB = sum(as.numeric(df_can_final$OTHER_NONWHITE ==1)*as.numeric(df_can_final$CAN_ABO == 'AB'))/sum(as.numeric(df_can_final$CAN_ABO == 'AB'))
shareBO = sum(as.numeric(df_can_final$OTHER_NONWHITE ==1)*as.numeric(df_can_final$CAN_ABO != 'AB'))/sum(as.numeric(df_can_final$CAN_ABO != 'AB'))
shareAB
shareBO

shareAB = sum(as.numeric(df_can_final$WHITE ==1)*as.numeric(df_can_final$CAN_ABO == 'AB'))/sum(as.numeric(df_can_final$CAN_ABO == 'AB'))
shareBO = sum(as.numeric(df_can_final$WHITE ==1)*as.numeric(df_can_final$CAN_ABO != 'AB'))/sum(as.numeric(df_can_final$CAN_ABO != 'AB'))
shareAB
shareBO
# These distributions look comparable




table(df_can_final$CAN_PREV_TX)  # Previous Transplants
sum(is.na(df_can_final$CAN_PREV_TX)) 


# Look at whether distributions for blood types are skewed
shareAB = sum(as.numeric(df_can_final$CAN_PREV_TX ==1)*as.numeric(df_can_final$CAN_ABO == 'AB'))/sum(as.numeric(df_can_final$CAN_ABO == 'AB'))
shareBO = sum(as.numeric(df_can_final$CAN_PREV_TX ==1)*as.numeric(df_can_final$CAN_ABO != 'AB'))/sum(as.numeric(df_can_final$CAN_ABO != 'AB'))
shareAB
shareBO
# These distributions look comparable


df_can_final$FEMALE = as.numeric(df_can_final$CAN_GENDER == "F")

# Look at whether distributions for blood types are skewed
shareAB = sum(as.numeric(df_can_final$FEMALE ==1)*as.numeric(df_can_final$CAN_ABO == 'AB'))/sum(as.numeric(df_can_final$CAN_ABO == 'AB'))
shareBO = sum(as.numeric(df_can_final$FEMALE ==1)*as.numeric(df_can_final$CAN_ABO != 'AB'))/sum(as.numeric(df_can_final$CAN_ABO != 'AB'))
shareAB
shareBO
# These distributions look comparable

table(df_can_final$CAN_AGE_DIAB)  # Age at Diabetes Onset
sum(is.na(df_can_final$CAN_AGE_DIAB))  


# Look at whether distributions for blood types are skewed
c1 <- rgb(173,216,230,max = 255, alpha = 80, names = "lt.blue")
c2 <- rgb(255,192,203, max = 255, alpha = 80, names = "lt.pink")
A = df_can_final$CAN_AGE_DIAB[(df_can_final$CAN_ABO == 'AB')]
B = df_can_final$CAN_AGE_DIAB[(df_can_final$CAN_ABO != 'AB')]
B =  B[sample(length(B), length(A)) ]
hgA <- hist(A, breaks = 80, plot = FALSE) # Save first histogram data
hgB <- hist(B, breaks = 80, plot = FALSE) # Save 2nd histogram data
plot(hgA, col = c1,ylim=c(0,300)) # Plot 1st histogram using a transparent color
plot(hgB, col = c2,ylim=c(0,300), add = TRUE) # Add 2nd histogram using different color
table(A)
table(B)
# These distributions look comparable



df_can_final$DIAB_ENTRY = as.numeric(df_can_final$CAN_AGE_DIAB <= df_can_final$CAN_AGE_AT_LISTING )   # create binary variable=1 if diabetic when entering the waitlist
df_can_final$DIAB_ENTRY[is.na(df_can_final$DIAB_ENTRY)] <-0
table(df_can_final$DIAB_ENTRY)  # Diabetic when entering the waitlist
sum(is.na(df_can_final$DIAB_ENTRY)) 


# Look at whether distributions for blood types are skewed
shareAB = sum(as.numeric(df_can_final$DIAB_ENTRY ==1)*as.numeric(df_can_final$CAN_ABO == 'AB'))/sum(as.numeric(df_can_final$CAN_ABO == 'AB'))
shareBO = sum(as.numeric(df_can_final$DIAB_ENTRY ==1)*as.numeric(df_can_final$CAN_ABO != 'AB'))/sum(as.numeric(df_can_final$CAN_ABO != 'AB'))
shareAB
shareBO
# These distributions look comparable


table(df_can_final$CAN_REM_CD)  # Reason why candidate was removed (removal code)  -> These are endogenous, and those observations should not be excluded. Some, others should be consiered like 10: Candidate listed in error  
sum(is.na(df_can_final$CAN_REM_CD)) 


sum(!as.numeric(df_can_final$CAN_ABO == 'AB'))



##############################################################
## PLOT KALPLAN-MEIER SURVIVOR CURVES FOR ALL MAIN BLOOD TYPES
##############################################################

df_can2 = df_can_final

df_can2$durDE =  round(df_can2$durDE/30.437)
df_can2$durDE <- df_can2$durDE*(df_can2$durDE > 0) +  (df_can2$durDE == 0)
df_can2$durDEn =  round(df_can2$durDEn/30.437)
df_can2$durDEn <- df_can2$durDEn*(df_can2$durDEn > 0) +  (df_can2$durDEn == 0)
df_can2$durTX =  round(df_can2$durTX/30.437)
df_can2$durTX <- df_can2$durTX*(df_can2$durTX > 0) +  (df_can2$durTX == 0)


if (plot_appFig2 == 0) {
if (post2015 == 0) {



######################################
#### Figures 1a, 1c, 1d
#####################################

# In case you want to look at graphs on estimate data with non NA value covariates, uncomment these two lines:
# df_can2 = df_can2[,c("durDE", "durDEC", "durDEn", "durDEnC","durTX","durTXC", "CAN_ABO", "CAN_ACPT_HBC_POS1","CAN_ACPT_HCV_POS1",  "CAN_MIN_PEAK_CREAT_5up", "CAN_AGE_AT_LISTING_41","CAN_AGE_AT_LISTING_51","CAN_AGE_AT_LISTING_58","CAN_AGE_AT_LISTING_65","CAN_AGE_AT_LISTING_65up", "CAN_EDUCATION_HS","CAN_EDUCATION_COL","CAN_EDUCATION_COLDEG","CAN_BMI_under19","CAN_BMI_1925","CAN_BMI_2630","CAN_BMI_over30", "CAN_MALIG", "ASIAN", "BLACK", "OTHER_NONWHITE","CAN_PREV_TX","FEMALE","DIAB_ENTRY", "DIAL_ENTRY", "CANHX_CPRA_0","CANHX_CPRA_60", "CANHX_CPRA_100" )]
# df_can2 <- df_can2[complete.cases(df_can2), ]

nrow(df_can2)

  ########################################
  ##  Figure 1d
  ########################################
  
print(ggsurvplot(
  fit = survfit(Surv(df_can2$durDE,df_can2$durDEC) ~ CAN_ABO, data = df_can2), 
  xlab = "Months", 
  ylab = "Survival probability",
  conf.int = TRUE,
  censor.size=0.1, 
  size = 0.2,
  xlim=c(0, 100),
  break.time.by = 12,
  ylim=c(0.7,1),
  font.legend = c(14, "plain", "black"),
  legend.title="Type",
  legend.labs = c("AB","BO"),
  legend = c(0.85, 0.8),
  palette = c("gray60", "gray10")))
ggsave("D:\\Dropbox\\ContDurMA\\TeX\\Surv_main.png", width = 6, height = 4)

########################################
##  Figure 1c
########################################
print(ggsurvplot(
  fit = survfit(Surv(df_can2$durDEn,df_can2$durDEnC) ~ CAN_ABO, data = df_can2), 
  xlab = "Months", 
  ylab = "Survival probability with censoring",
  conf.int = TRUE,
  censor.size=0.1, 
  size = 0.2,
  xlim=c(0, 100),
  break.time.by = 12,
  ylim=c(0.7,1),
  font.legend = c(14, "plain", "black"),
  legend.title="Type",
  legend.labs = c("AB","BO"),
  legend = c(0.85, 0.8),
  palette = c("gray60", "gray10")))
ggsave("D:\\Dropbox\\ContDurMA\\TeX\\SurvC_main.png", width = 6, height = 4)

########################################
##  Figure 1a
########################################
print(ggsurvplot(
  fit = survfit(Surv(df_can2$durTX,df_can2$durTXC) ~ CAN_ABO, data = df_can2), 
  xlab = "Months", 
  ylab = "Transplant probability",
  conf.int = TRUE,
  censor.size=0.1, 
  size = 0.2,
  xlim=c(0, 100),
  break.time.by = 12,
  ylim=c(0,0.7),
  font.legend = c(14, "plain", "black"),
  legend.title="Type",
  legend.labs = c("AB","BO"),
  legend = c(0.85, 0.2),
  palette = c("gray60", "gray10"),fun = "event"))
ggsave("D:\\Dropbox\\ContDurMA\\TeX\\SurvT_main.png", width = 6, height = 4)

# print(ggsurvplot(
#   fit = survfit(Surv(df_can2$durDE,df_can2$durDEC) ~ CAN_ABO, data = df_can2), 
#   xlab = "Months", 
#   ylab = "Survival probability",
#   conf.int = TRUE,
#   censor.size=0.1, 
#   size = 0.2,
#   xlim=c(0, 55),
#   break.time.by = 12,
#   ylim=c(0.80,1),
#   legend.title="Type",
#   legend.labs = c("AB","BO"),
#   legend = c(0.9, 0.85),
#   palette = c("gray50", "gray20")))
# print(ggsurvplot(
#   fit = survfit(Surv(df_can2$durDEn,df_can2$durDEnC) ~ CAN_ABO, data = df_can2), 
#   xlab = "Months", 
#   ylab = "Survival probability with censoring",
#   conf.int = TRUE,
#   censor.size=0.1, 
#   size = 0.2,
#   xlim=c(0, 55),
#   break.time.by = 12,
#   ylim=c(0.75,1),
#   legend.title="Type",
#   legend.labs = c("AB","BO"),
#   legend = c(0.9, 0.85),
#   palette = c("gray50", "gray20")))
# print(ggsurvplot(
#   fit = survfit(Surv(df_can2$durTX,df_can2$durTXC) ~ CAN_ABO, data = df_can2), 
#   xlab = "Months", 
#   ylab = "Transplant probability",
#   conf.int = TRUE,
#   censor.size=0.1, 
#   size = 0.2,
#   xlim=c(0, 55),
#   break.time.by = 12,
#   ylim=c(0,0.65),
#   legend.title="Type",
#   legend.labs = c("AB","BO"),
#   legend = c(0.9, 0.85),
#   palette = c("gray50", "gray20"),fun = "event"))




# Generate Hazard rates 
vHazDE <- matrix(0,max(df_can2$durDE),1)
vHazTX <- matrix(0,max(df_can2$durDE),1)
vHazDE_AB <- matrix(0,max(df_can2$durDE),1)
vHazTX_AB <- matrix(0,max(df_can2$durDE),1)
vHazDE_BO <- matrix(0,max(df_can2$durDE),1)
vHazTX_BO <- matrix(0,max(df_can2$durDE),1)
# Generate hazard rates
for (t in 1:(max(df_can2$durDE)-1)) {
  denomDE = sum(as.numeric(df_can2$durDE == t)*as.numeric(df_can2$durDEC == 1)+as.numeric(df_can2$durDE > t))
  vHazDE[t] = sum(as.numeric(df_can2$durDE == t)*as.numeric(df_can2$durDEC == 1))/denomDE
  
  numerTX = sum(as.numeric(df_can2$durTX == t)*as.numeric(df_can2$durTXC == 1)+as.numeric(df_can2$durTX > t))
  vHazTX[t] = sum(as.numeric(df_can2$durTX == t)*as.numeric(df_can2$durTXC == 1))/numerTX
  
  denomDE_AB = sum((as.numeric(df_can2$durDE == t)*as.numeric(df_can2$durDEC == 1) +as.numeric(df_can2$durDE > t))*as.numeric(df_can2$CAN_ABO == 'AB'))
  vHazDE_AB[t] = sum(as.numeric(df_can2$durDE == t)*as.numeric(df_can2$durDEC == 1)*as.numeric(df_can2$CAN_ABO == 'AB'))/denomDE_AB
  
  denomTX_AB = sum((as.numeric(df_can2$durTX == t)*as.numeric(df_can2$durTXC == 1)+as.numeric(df_can2$durTX > t))*as.numeric(df_can2$CAN_ABO == 'AB'))
  vHazTX_AB[t] = sum(as.numeric(df_can2$durTX == t)*as.numeric(df_can2$durTXC == 1)*as.numeric(df_can2$CAN_ABO == 'AB'))/denomTX_AB
  
  denomDE_BO = sum((as.numeric(df_can2$durDE == t)*as.numeric(df_can2$durDEC == 1) +as.numeric(df_can2$durDE > t))*as.numeric(df_can2$CAN_ABO != 'AB'))
  vHazDE_BO[t] = sum(as.numeric(df_can2$durDE == t)*as.numeric(df_can2$durDEC == 1)*as.numeric(df_can2$CAN_ABO != 'AB'))/denomDE_BO
  
  denomTX_BO = sum((as.numeric(df_can2$durTX == t)*as.numeric(df_can2$durTXC == 1)+as.numeric(df_can2$durTX > t))*as.numeric(df_can2$CAN_ABO != 'AB'))
  vHazTX_BO[t] = sum(as.numeric(df_can2$durTX == t)*as.numeric(df_can2$durTXC == 1)*as.numeric(df_can2$CAN_ABO != 'AB'))/denomTX_BO
}
vHazDEres <- vHazDE*100
vHazTXres <- vHazTX*100
vHazDEres <- vHazDE_AB*100
vHazTXres <- vHazTX_AB*100
vHazDEres <- vHazDE_BO*100
vHazTXres <- vHazTX_BO*100

max(df_can2$durDE)


## Plot hazard
x <- 1:100
y_AB <- vHazTX_AB[1:100]
y_BO <- vHazTX_BO[1:100]


haz_frame = data.frame(cbind("Months"=x,"BO"=y_BO,"AB"=y_AB))
#Reshape data from wide to long
df2 <- gather(haz_frame,Type,val,c(BO,AB))


######################################
#### Figures 1b
#####################################

print(ggplot(df2,aes(x = Months, y = val)) +
  geom_smooth(aes(colour = Type),se = F) +
  ylab("Transplant hazard") +
  theme_bw() +
  theme_classic() +
  scale_color_grey(start = 0.75, end = 0.4) +
  theme(legend.position = c(0.85, 0.80)) + 
  theme(legend.text = element_text(size=15)) +
  theme(legend.title = element_text(size=15)) +
  theme(legend.key.height= unit(0.8, 'cm'),legend.key.width= unit(1.5, 'cm')) +
  scale_x_continuous(breaks = seq(0, 100, by = 12)) +
  theme(axis.title.x = element_text(size=14,  family="sans",colour="black")) +
  theme(axis.title.y = element_text(size=14,  family="sans",colour="black")) +
  theme(axis.text = element_text(face="bold")))
ggsave("D:\\Dropbox\\ContDurMA\\TeX\\Thaz_main.png", width = 6, height = 4)

nrow(df_can_final)


df_can_final = df_can_final[,c("durDE", "durDEC", "durTX","durTXC", "CAN_ABO", "CAN_ACPT_HBC_POS1","CAN_ACPT_HCV_POS1",  "CAN_MIN_PEAK_CREAT_5up", "CAN_AGE_AT_LISTING_41","CAN_AGE_AT_LISTING_51","CAN_AGE_AT_LISTING_58","CAN_AGE_AT_LISTING_65","CAN_AGE_AT_LISTING_65up", "CAN_EDUCATION_HS","CAN_EDUCATION_COL","CAN_EDUCATION_COLDEG","CAN_BMI_under19","CAN_BMI_1925","CAN_BMI_2630","CAN_BMI_over30", "CAN_MALIG", "ASIAN", "BLACK", "OTHER_NONWHITE","CAN_PREV_TX","FEMALE","DIAB_ENTRY", "DIAL_ENTRY", "CANHX_CPRA_0","CANHX_CPRA_60", "CANHX_CPRA_100", "CAN_AGE_AT_LISTING","CAN_EDUCATION_HS","CAN_BMI","WHITE"  )]


write.table(df_can_final, file="D:\\Dropbox\\ContDurMA\\CompCode 2022\\df_can_final.txt", row.names=FALSE, col.names=FALSE)


} else {

  
  ######################################
  #### Figures in appendix B Figure 5
  #####################################
  
  # In case you want to look at graphs on estimate data with non NA value covariates, uncomment these two lines:
  # df_can2 = df_can2[,c("durDE", "durDEC", "durDEn", "durDEnC","durTX","durTXC", "CAN_ABO", "CAN_ACPT_HBC_POS1","CAN_ACPT_HCV_POS1",  "CAN_MIN_PEAK_CREAT_5up", "CAN_AGE_AT_LISTING_41","CAN_AGE_AT_LISTING_51","CAN_AGE_AT_LISTING_58","CAN_AGE_AT_LISTING_65","CAN_AGE_AT_LISTING_65up", "CAN_EDUCATION_HS","CAN_EDUCATION_COL","CAN_EDUCATION_COLDEG","CAN_BMI_under19","CAN_BMI_1925","CAN_BMI_2630","CAN_BMI_over30", "CAN_MALIG", "ASIAN", "BLACK", "OTHER_NONWHITE","CAN_PREV_TX","FEMALE","DIAB_ENTRY", "DIAL_ENTRY", "CANHX_CPRA_0","CANHX_CPRA_60", "CANHX_CPRA_100")]
  # df_can2 <- df_can2[complete.cases(df_can2), ]
  
  nrow(df_can2)
  
  ########################################
  ##  Figure 5d
  ######################################## 
  print(ggsurvplot(
    fit = survfit(Surv(df_can2$durDE,df_can2$durDEC) ~ CAN_ABO, data = df_can2), 
    xlab = "Months", 
    ylab = "Survival probability",
    conf.int = TRUE,
    censor.size=0.1, 
    size = 0.2,
    xlim=c(0, 60),
    break.time.by = 12,
    ylim=c(0.8,1),
    font.legend = c(14, "plain", "black"),
    legend.title="Type",
    legend.labs = c("AB","BO"),
    legend = c(0.88, 0.85),
    palette = c("gray60", "gray10")))
  ggsave("D:\\Dropbox\\ContDurMA\\TeX\\Surv_post2015.png", width = 6, height = 4)
  
  ########################################
  ##  Figure 5c
  ######################################## 
  print(ggsurvplot(
    fit = survfit(Surv(df_can2$durDEn,df_can2$durDEnC) ~ CAN_ABO, data = df_can2), 
    xlab = "Months", 
    ylab = "Survival probability with censoring",
    conf.int = TRUE,
    censor.size=0.1, 
    size = 0.2,
    xlim=c(0, 60),
    break.time.by = 12,
    ylim=c(0.8,1),
    font.legend = c(14, "plain", "black"),
    legend.title="Type",
    legend.labs = c("AB","BO"),
    legend = c(0.88, 0.85),
    palette = c("gray60", "gray10")))
  ggsave("D:\\Dropbox\\ContDurMA\\TeX\\SurvC_post2015.png", width = 6, height = 4)
  
  ########################################
  ##  Figure 5b
  ########################################  
  print(ggsurvplot(
    fit = survfit(Surv(df_can2$durTX,df_can2$durTXC) ~ CAN_ABO, data = df_can2), 
    xlab = "Months", 
    ylab = "Transplant probability",
    conf.int = TRUE,
    censor.size=0.1, 
    size = 0.2,
    xlim=c(0, 60),
    break.time.by = 12,
    ylim=c(0,0.9),
    font.legend = c(14, "plain", "black"),
    legend.title="Type",
    legend.labs = c("AB","BO"),
    legend = c(0.88, 0.15),
    palette = c("gray60", "gray10"),fun = "event"))
  ggsave("D:\\Dropbox\\ContDurMA\\TeX\\SurvT_post2015.png", width = 6, height = 4)
  

  
  
  # Generate Hazard rates 
  vHazDE <- matrix(0,max(df_can2$durDE),1)
  vHazTX <- matrix(0,max(df_can2$durDE),1)
  vHazDE_AB <- matrix(0,max(df_can2$durDE),1)
  vHazTX_AB <- matrix(0,max(df_can2$durDE),1)
  vHazDE_BO <- matrix(0,max(df_can2$durDE),1)
  vHazTX_BO <- matrix(0,max(df_can2$durDE),1)
  # Generate hazard rates
  for (t in 1:(max(df_can2$durDE)-1)) {
    denomDE = sum(as.numeric(df_can2$durDE == t)*as.numeric(df_can2$durDEC == 1)+as.numeric(df_can2$durDE > t))
    vHazDE[t] = sum(as.numeric(df_can2$durDE == t)*as.numeric(df_can2$durDEC == 1))/denomDE
    
    numerTX = sum(as.numeric(df_can2$durTX == t)*as.numeric(df_can2$durTXC == 1)+as.numeric(df_can2$durTX > t))
    vHazTX[t] = sum(as.numeric(df_can2$durTX == t)*as.numeric(df_can2$durTXC == 1))/numerTX
    
    denomDE_AB = sum((as.numeric(df_can2$durDE == t)*as.numeric(df_can2$durDEC == 1) +as.numeric(df_can2$durDE > t))*as.numeric(df_can2$CAN_ABO == 'AB'))
    vHazDE_AB[t] = sum(as.numeric(df_can2$durDE == t)*as.numeric(df_can2$durDEC == 1)*as.numeric(df_can2$CAN_ABO == 'AB'))/denomDE_AB
    
    denomTX_AB = sum((as.numeric(df_can2$durTX == t)*as.numeric(df_can2$durTXC == 1)+as.numeric(df_can2$durTX > t))*as.numeric(df_can2$CAN_ABO == 'AB'))
    vHazTX_AB[t] = sum(as.numeric(df_can2$durTX == t)*as.numeric(df_can2$durTXC == 1)*as.numeric(df_can2$CAN_ABO == 'AB'))/denomTX_AB
    
    denomDE_BO = sum((as.numeric(df_can2$durDE == t)*as.numeric(df_can2$durDEC == 1) +as.numeric(df_can2$durDE > t))*as.numeric(df_can2$CAN_ABO != 'AB'))
    vHazDE_BO[t] = sum(as.numeric(df_can2$durDE == t)*as.numeric(df_can2$durDEC == 1)*as.numeric(df_can2$CAN_ABO != 'AB'))/denomDE_BO
    
    denomTX_BO = sum((as.numeric(df_can2$durTX == t)*as.numeric(df_can2$durTXC == 1)+as.numeric(df_can2$durTX > t))*as.numeric(df_can2$CAN_ABO != 'AB'))
    vHazTX_BO[t] = sum(as.numeric(df_can2$durTX == t)*as.numeric(df_can2$durTXC == 1)*as.numeric(df_can2$CAN_ABO != 'AB'))/denomTX_BO
  }
  vHazDEres <- vHazDE*100
  vHazTXres <- vHazTX*100
  vHazDEres <- vHazDE_AB*100
  vHazTXres <- vHazTX_AB*100
  vHazDEres <- vHazDE_BO*100
  vHazTXres <- vHazTX_BO*100
  
  max(df_can2$durDE)
  
  
  ## Plot hazard
  x <- 1:60
  y_AB <- vHazTX_AB[1:100]
  y_BO <- vHazTX_BO[1:100]
  
  
  haz_frame = data.frame(cbind("Months"=x,"BO"=y_BO,"AB"=y_AB))
  #Reshape data from wide to long
  df2 <- gather(haz_frame,Type,val,c(BO,AB))
  
  
  
  ########################################
  ##  Figure 5b
  ########################################   
  print(ggplot(df2,aes(x = Months, y = val)) +
    geom_smooth(aes(colour = Type),se = F) +
    ylab("Transplant hazard") +
    theme_bw() +
    theme_classic() +
    scale_color_grey(start = 0.75, end = 0.4) +
    theme(legend.position = c(0.88, 0.85)) + 
    theme(legend.text = element_text(size=15)) +
    theme(legend.title = element_text(size=15)) +
    theme(legend.key.height= unit(0.8, 'cm'),legend.key.width= unit(1.5, 'cm')) +
    scale_x_continuous(breaks = seq(0, 60, by = 12)) +
    theme(axis.title.x = element_text(size=14,  family="sans",colour="black")) +
    theme(axis.title.y = element_text(size=14,  family="sans",colour="black")) +
    theme(axis.text = element_text(face="bold")))
  ggsave("D:\\Dropbox\\ContDurMA\\TeX\\Thaz_post2015.png", width = 6, height = 4)

  
  nrow(df_can_final)
  
  
  df_can_final = df_can_final[,c("durDE", "durDEC", "durTX","durTXC", "CAN_ABO", "CAN_ACPT_HBC_POS1","CAN_ACPT_HCV_POS1",  "CAN_MIN_PEAK_CREAT_5up", "CAN_AGE_AT_LISTING_41","CAN_AGE_AT_LISTING_51","CAN_AGE_AT_LISTING_58","CAN_AGE_AT_LISTING_65","CAN_AGE_AT_LISTING_65up", "CAN_EDUCATION_HS","CAN_EDUCATION_COL","CAN_EDUCATION_COLDEG","CAN_BMI_under19","CAN_BMI_1925","CAN_BMI_2630","CAN_BMI_over30", "CAN_MALIG", "ASIAN", "BLACK", "OTHER_NONWHITE","CAN_PREV_TX","FEMALE","DIAB_ENTRY", "DIAL_ENTRY", "CANHX_CPRA_0","CANHX_CPRA_60", "CANHX_CPRA_100","CAN_AGE_AT_LISTING","CAN_EDUCATION_HS","CAN_BMI","WHITE" )]
  
  
  
  write.table(df_can_final, file="D:\\Dropbox\\ContDurMA\\CompCode 2022\\df_can_final_post2015.txt", row.names=FALSE, col.names=FALSE)
  
  
}
}









##################################
## Code required to obtain Figure 4
##################################


# Step 1: COmment out lines 159-161 as follows:
# These lines must be include for AB vs. B/O analysis
# df_can_final = df_can[(df_can$CAN_ABO != "A"),]   # Drop type A blood types who have probability of treatment between AB and BorO
# df_can_final$CAN_ABO[(df_can_final$CAN_ABO != 'AB')] <-  "BorO"    # merge A and O blood types together



if (plot_appFig2 == 1) {

print(ggsurvplot(
  fit = survfit(Surv(df_can2$durDE,df_can2$durDEC) ~ CAN_ABO, data = df_can2),
  xlab = "Months",
  ylab = "Survival probability",
  conf.int = TRUE,
  censor.size=0.1,
  size = 0.2,
  xlim=c(0, 100),
  break.time.by = 12,
  ylim=c(0.7,1),
  font.legend = c(14, "plain", "black"),
  legend.title="Type",
  legend.labs = c("A","AB","B","O"),
  legend = c(0.85, 0.8),
  palette = c("gray75", "gray50","gray10", "black")))
print(ggsurvplot(
  fit = survfit(Surv(df_can2$durDEn,df_can2$durDEnC) ~ CAN_ABO, data = df_can2),
  xlab = "Months",
  ylab = "Survival probability with censoring",
  conf.int = TRUE,
  censor.size=0.1,
  size = 0.2,
  xlim=c(0, 100),
  break.time.by = 12,
  ylim=c(0.7,1),
  font.legend = c(14, "plain", "black"),
  legend.title="Type",
  legend.labs = c("A","AB","B","O"),
  legend = c(0.85, 0.8),
  palette = c("gray75", "gray50","gray10", "black")))

########################################
##  Figure 4a
######################################## 
print(ggsurvplot(
  fit = survfit(Surv(df_can2$durTX,df_can2$durTXC) ~ CAN_ABO, data = df_can2),
  xlab = "Months",
  ylab = "Transplant probability",
  conf.int = TRUE,
  censor.size=0.1,
  size = 0.2,
  xlim=c(0, 100),
  break.time.by = 12,
  ylim=c(0,0.7),
  font.legend = c(14, "plain", "black"),
  legend.title="Type",
  legend.labs = c("A","AB","B","O"),
  legend = c(0.85, 0.2),
  palette = c("gray75", "gray50","gray10", "black"),fun = "event"))
ggsave("D:\\Dropbox\\ContDurMA\\TeX\\SurvT_all.png", width = 6, height = 4)



# Generate Hazard rates
vHazTX_A <- matrix(0,max(df_can2$durDE),1)
vHazTX_AB <- matrix(0,max(df_can2$durDE),1)
vHazTX_B <- matrix(0,max(df_can2$durDE),1)
vHazTX_O <- matrix(0,max(df_can2$durDE),1)
# Generate hazard rates
for (t in 1:(max(df_can2$durDE)-1)) {
  denomTX_AB = sum((as.numeric(df_can2$durTX == t)*as.numeric(df_can2$durTXC == 1)+as.numeric(df_can2$durTX > t))*as.numeric(df_can2$CAN_ABO == 'AB'))
  vHazTX_AB[t] = sum(as.numeric(df_can2$durTX == t)*as.numeric(df_can2$durTXC == 1)*as.numeric(df_can2$CAN_ABO == 'AB'))/denomTX_AB

  denomTX_A = sum((as.numeric(df_can2$durTX == t)*as.numeric(df_can2$durTXC == 1)+as.numeric(df_can2$durTX > t))*as.numeric(df_can2$CAN_ABO == 'A'))
  vHazTX_A[t] = sum(as.numeric(df_can2$durTX == t)*as.numeric(df_can2$durTXC == 1)*as.numeric(df_can2$CAN_ABO == 'A'))/denomTX_A

  denomTX_B = sum((as.numeric(df_can2$durTX == t)*as.numeric(df_can2$durTXC == 1)+as.numeric(df_can2$durTX > t))*as.numeric(df_can2$CAN_ABO == 'B'))
  vHazTX_B[t] = sum(as.numeric(df_can2$durTX == t)*as.numeric(df_can2$durTXC == 1)*as.numeric(df_can2$CAN_ABO == 'B'))/denomTX_B

  denomTX_O = sum((as.numeric(df_can2$durTX == t)*as.numeric(df_can2$durTXC == 1)+as.numeric(df_can2$durTX > t))*as.numeric(df_can2$CAN_ABO == 'O'))
  vHazTX_O[t] = sum(as.numeric(df_can2$durTX == t)*as.numeric(df_can2$durTXC == 1)*as.numeric(df_can2$CAN_ABO == 'O'))/denomTX_O

}




## Plot hazard
x <- 1:100
y_AB <- vHazTX_AB[1:100]
y_A <- vHazTX_A[1:100]
y_B <- vHazTX_B[1:100]
y_O <- vHazTX_O[1:100]

sum(df_can2$CAN_ABO == 'A')
sum(df_can2$CAN_ABO == 'AB')
sum(df_can2$CAN_ABO == 'B')
sum(df_can2$CAN_ABO == 'O')


haz_frame = data.frame(cbind("Months"=x,"A"=y_A,"AB"=y_AB,"B"=y_B,"O"=y_O))
#Reshape data from wide to long
df2 <- gather(haz_frame,Type,val,c(A,AB,B,O))


########################################
##  Figure 4b
######################################## 

print(ggplot(df2,aes(x = Months, y = val)) +
  geom_smooth(aes(colour = Type),se = F) +
  ylab("Transplant hazard") +
  theme_bw() +
  theme_classic() +
  scale_color_grey(start = 0.75, end = 0.4) +
  theme(legend.position = c(0.85, 0.80)) +
  theme(legend.text = element_text(size=15)) +
  theme(legend.title = element_text(size=15)) +
  theme(legend.key.height= unit(0.8, 'cm'),legend.key.width= unit(1.5, 'cm')) +
  scale_x_continuous(breaks = seq(0, 100, by = 12)) +
  scale_linetype_manual(values=c("solid", "dotted","dash", "twodash" )) +
  theme(axis.title.x = element_text(size=14,  family="sans",colour="black")) +
  theme(axis.title.y = element_text(size=14,  family="sans",colour="black")) +
  theme(axis.text = element_text(face="bold")))
ggsave("D:\\Dropbox\\ContDurMA\\TeX\\Thaz_all.png", width = 6, height = 4)


}



