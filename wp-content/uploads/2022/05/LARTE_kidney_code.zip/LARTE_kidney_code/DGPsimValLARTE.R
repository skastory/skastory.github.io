########################################################################
##  Code for: Regime and Treatment Effects in Duration Models: 
##            Decomposing Expectation and Transplant Effects on
##            the Kidney Waitlist
#####
##
##  Code for Dynamic Discrete Choice Model in online Appendix
##                                                                    
##  Author: Stephen Kastoryano                                        
##  Date  : 20 May 2022                                         
##
##  input:  "DGPz1c.m","DGPz1S.m","DGPz1Sc.m", "DGPz0cER.m","DGPz0SER.m","DGPz0ScER.m"
##           - from DGPsim.ox:  DGP potential outcomes to compare to sample estimates in simulation
##
##  output: "simDGPval_3060.txt" for dgpLARTE.R
##                                                                    
########################################################################



#library("Hmisc","survival","MASS","ggplot2")
#library(Hmisc,MASS,dplyr,survival,ggplot2, lib.loc="C:\\Users\\Stephen Kastoryano\\Documents\\R\\win-library\\3.6")
library(survival, lib.loc="C:\\Users\\Stephen Kastoryano\\Documents\\R\\win-library\\3.6")
library(survminer, lib.loc="C:\\Users\\Stephen Kastoryano\\Documents\\R\\win-library\\3.6")
library(dplyr, lib.loc="C:\\Users\\Stephen Kastoryano\\Documents\\R\\win-library\\3.6")


# In order to make the results from the simulation consistent with the discussion in the paper
# I switch here the Z=0 and Z=1 groups around in order to guarantee that Pr(T^{1,inf} >= s) > Pr(T^{0,inf} >= s) holds
# The reason for this is that we specify a negative treatment effect in the simulation so lower probability of treatment
# will lead to higher survival  bgt

mDatZ1S0 <-read.table("D:\\Dropbox\\ContDurMA\\CompCode 2022\\DGPz1c.m",skip = 1) # For all agents Z=1, pi=0.03 but do not enter treatment
mDatZ1S0 <- cbind(mDatZ1S0[,6],mDatZ1S0[,8])
colnames(mDatZ1S0, do.NULL = FALSE)
colnames(mDatZ1S0) <- c( "vdurSstarZ1S0", "vdurEZ1S0")



mDatZ1S1 <-read.table("D:\\Dropbox\\ContDurMA\\CompCode 2022\\DGPz1S.m",skip = 1) # For all agents Z=1, pi=0.03 and enter treatment
mDatZ1S1 <- cbind(mDatZ1S1[,6],mDatZ1S1[,8])
colnames(mDatZ1S1, do.NULL = FALSE)
colnames(mDatZ1S1) <- c( "vdurSstarZ1S1", "vdurEZ1S1")

mDatZ1S1c <-read.table("D:\\Dropbox\\ContDurMA\\CompCode 2022\\DGPz1Sc.m",skip = 1) # For all agents Z=1, pi=0.03 and enter treatment but have no effect from treatment (and anticipation stops)
mDatZ1S1c <- cbind(mDatZ1S1c[,6],mDatZ1S1c[,8])
colnames(mDatZ1S1c, do.NULL = FALSE)
colnames(mDatZ1S1c) <- c("vdurSstarZ1S1c", "vdurEZ1S1c")


mDatZ0S0 <-read.table("D:\\Dropbox\\ContDurMA\\CompCode 2022\\DGPz0cER.m",skip = 1) # For all agents Z=0, pi=0.01 but do not enter treatment for when Exclusion restriction holds (poorly labeled upload files, but correct)
mDatZ0S0 <- cbind(mDatZ0S0[,6],mDatZ0S0[,8])
colnames(mDatZ0S0, do.NULL = FALSE)
colnames(mDatZ0S0) <- c( "vdurSstarZ0S0ER", "vdurEZ0S0ER")   # for exclusion restriction holds case only

mDatZ0S1 <-read.table("D:\\Dropbox\\ContDurMA\\CompCode 2022\\DGPz0SER.m",skip = 1) # For all agents Z=0, pi=0.01 and enter treatment for when Exclusion restriction holds (poorly labeled upload files, but correct)
mDatZ0S1 <- cbind(mDatZ0S1[,6],mDatZ0S1[,8])
colnames(mDatZ0S1, do.NULL = FALSE)
colnames(mDatZ0S1) <- c( "vdurSstarZ0S1ER", "vdurEZ0S1ER")  # for exclusion restriction holds case only

mDatZ0S1c <-read.table("D:\\Dropbox\\ContDurMA\\CompCode 2022\\DGPz0ScER.m",skip = 1) # For all agents Z=0, pi=0.01 and enter treatment but have no effect from treatment (and anticipation stops) for when Exclusion restriction holds (poorly labeled upload files, but correct)
mDatZ0S1c <- cbind(mDatZ0S1c[,6],mDatZ0S1c[,8])
colnames(mDatZ0S1c, do.NULL = FALSE)
colnames(mDatZ0S1c) <- c("vdurSstarZ0S1cER", "vdurEZ0S1cER")  # for exclusion restriction holds case only





## DGP effects for when exclusion restriction does not hold ##

mData <- cbind(mDatZ0S0,mDatZ1S0,mDatZ1S1,mDatZ1S0, mDatZ0S1,mDatZ0S0)


obs <- dim(mData)[1]


print(cbind(mDatZ1S0[,2], mDatZ0S0[,2]))

mean(mDatZ1S0[,2])
mean(mDatZ0S0[,2])


DGPeffectFn <- function(mins, dS, dT, dTmov) {
  

  mPTreatS1 <- matrix(0,1+dS,1)   # weight for avg. effect on potentially treated
  B0 <- matrix(0,1+dS,1) 
  B0ns <- matrix(0,1+dS,1) 
  B0cs <- matrix(0,1+dS,1) 
  B0as <- matrix(0,1+dS,1) 
  BZ <- matrix(0,1+dS,1) 
  BZcs <- matrix(0,1+dS,1) 
  BZas <- matrix(0,1+dS,1) 
  BS <- matrix(0,1+dS,1) 
  BZS <- matrix(0,1+dS,1) 
  Pns <- matrix(0,1+dS,1)  
  Pcs <- matrix(0,1+dS,1)  
  Pas <- matrix(0,1+dS,1) 
  Pds <- matrix(0,1+dS,1)  # defier survivors. These are assumued away for identification, but can occur in our DGP sample
  B0ds <- matrix(0,1+dS,1)
  BZds <-  matrix(0,1+dS,1)
  BSas <-  matrix(0,1+dS,1)
  BSds <-  matrix(0,1+dS,1)
  BZScs <-  matrix(0,1+dS,1)
  BZSas <-  matrix(0,1+dS,1)
  BZSds <-  matrix(0,1+dS,1)
  

  
  Swin <- 5  # Window for treated observations is 2*Swin+1 --> smoothes out DGP results 
  
  for (s in mins:(mins+dS))  # For weights of MSE calculations for averages
  {
    if (s<Swin)
    {
      mPTreatS1[(s-mins+1)] <- sum(as.numeric(mData[,3] >= s)*as.numeric(mData[,3] <= s+Swin))  # For averages, to weight by probability of treatment later, prob treatment for Z=1, pi=0.03 group
      }
    else
    {
      mPTreatS1[(s-mins+1)] <- sum(as.numeric(mData[,3] >= s-Swin)*as.numeric(mData[,3] <= s+Swin))   # For averages, to weight by probability of treatment later, prob treatment for Z=1, pi=0.03 group
      }
  }
  

  for (s in mins:(mins+dS)) 
  {
    if (dTmov==0) {
     t <- dT 
     } else { 
     t <- s+dT 
     }
    

    # Calculate probability of being of each type
    Pns[(s-mins+1)] <- sum(as.numeric(mData[,2] < s)*as.numeric(mData[,4] < s))/obs  # Prob of being a never survivor at (s-mins+1)
    Pas[(s-mins+1)] <- sum(as.numeric(mData[,2] >= s)*as.numeric(mData[,4] >= s))/obs  # Prob of being a always survivor at (s-mins+1)
    Pcs[(s-mins+1)] <- sum(as.numeric(mData[,2] < s)*as.numeric(mData[,4] >= s))/obs  # Prob of being a complier survivor at (s-mins+1)
    Pds[(s-mins+1)] <- 1-Pas[(s-mins+1)]-Pns[(s-mins+1)]-Pcs[(s-mins+1)]  # Prob of being a defier survivor at (s-mins+1) 
    
    
    
    
    # Calculate B0
    B0[(s-mins+1)] <- sum(as.numeric(mData[,2] <= t))/obs  # B0 effect total at (s-mins+1)
    B0ns[(s-mins+1)] <- Pns[(s-mins+1)]  # B0 contribution from never survivors
    B0cs[(s-mins+1)] <- Pcs[(s-mins+1)]  # B0 contribution from complier survivors
    B0as[(s-mins+1)] <- sum(as.numeric(mData[,2] >= s)*as.numeric(mData[,4] >= s)*as.numeric(mData[,2] <= t))/obs  # B0 contribution from always survivors
    B0ds[(s-mins+1)] <- B0[(s-mins+1)] - B0ns[(s-mins+1)] - B0cs[(s-mins+1)] - B0as[(s-mins+1)]
    
    #print(cbind(B0[(s-mins+1)],B0ds[(s-mins+1)]))
    
    # Calculate BZ
    BZ[(s-mins+1)] <- sum(as.numeric(mData[,4] <= t))/obs - sum(as.numeric(mData[,2] <= t))/obs   # BZ effect total at (s-mins+1) 
    BZas[(s-mins+1)] <- (sum(as.numeric(mData[,2] >= s)*as.numeric(mData[,4] >= s)*as.numeric(mData[,4] <= t))/obs -
                                  sum(as.numeric(mData[,2] >= s)*as.numeric(mData[,4] >= s)*as.numeric(mData[,2] <= t))/obs) # BZ contribution from always survivors
    BZcs[(s-mins+1)] <- (sum(as.numeric(mData[,2] < s)*as.numeric(mData[,4] >= s)*as.numeric(mData[,4] <= t))/obs -
                           sum(as.numeric(mData[,2] < s)*as.numeric(mData[,4] >= s)*as.numeric(mData[,2] <= t))/obs) # BZ contribution from always survivors
    BZds[(s-mins+1)] <- BZ[(s-mins+1)]-BZas[(s-mins+1)]-BZcs[(s-mins+1)]  # BZ contribution from complier survivors
    


    
    if (s<Swin) 
    { 
      # BS effect total at (s-mins+1) which is only equal to contribution of always survivors
      BS[(s-mins+1)] <- sum(as.numeric(mData[,9] >= s)*as.numeric(mData[,9] <= s+Swin)*as.numeric(mData[,10] <= t))/sum(as.numeric(mData[,9] >= s)*as.numeric(mData[,9] <= s+Swin)) -
       sum(as.numeric(mData[,11] >= s)*as.numeric(mData[,11] <= s+Swin)*as.numeric(mData[,12] <=t)) /sum(as.numeric(mData[,11] >= s)*as.numeric(mData[,11] <= s+Swin))
      BSas[(s-mins+1)] <- sum(as.numeric(mData[,2] >= s)*as.numeric(mData[,4] >= s)*as.numeric(mData[,9] >= s)*as.numeric(mData[,9] <= s+Swin)*as.numeric(mData[,10] <= t))/sum(as.numeric(mData[,9] >= s)*as.numeric(mData[,9] <= s+Swin)) -
                            sum(as.numeric(mData[,2] >= s)*as.numeric(mData[,4] >= s)*as.numeric(mData[,11] >= s)*as.numeric(mData[,11] <= s+Swin)*as.numeric(mData[,12] <=t)) /sum(as.numeric(mData[,11] >= s)*as.numeric(mData[,11] <= s+Swin))
      BSds[(s-mins+1)] <- BS[(s-mins+1)] - BSas[(s-mins+1)]
      
      # BZS effect total at (s-mins+1) which is only equal to contribution of complier survivors
      BZS[(s-mins+1)] <- sum(as.numeric(mData[,5] >= s)*as.numeric(mData[,5] <= s+Swin)*as.numeric(mData[,6] <= t))/sum(as.numeric(mData[,5] >= s)*as.numeric(mData[,5] <= s+Swin))  -
                           sum(as.numeric(mData[,7] >= s)*as.numeric(mData[,7] <= s+Swin)*as.numeric(mData[,8] <=t))/sum(as.numeric(mData[,7] >= s)*as.numeric(mData[,7] <= s+Swin)) - BS[(s-mins+1)]
      BZScs[(s-mins+1)] <- sum(as.numeric(mData[,2] < s)*as.numeric(mData[,4] >= s)*as.numeric(mData[,5] >= s)*as.numeric(mData[,5] <= s+Swin)*as.numeric(mData[,6] <= t))/sum(as.numeric(mData[,5] >= s)*as.numeric(mData[,5] <= s+Swin)) -
                             sum(as.numeric(mData[,2] < s)*as.numeric(mData[,4] >= s)*as.numeric(mData[,7] >= s)*as.numeric(mData[,7] <= s+Swin)*as.numeric(mData[,8] <=t))/sum(as.numeric(mData[,7] >= s)*as.numeric(mData[,7] <= s+Swin)) 
      BZSas[(s-mins+1)] <- sum(as.numeric(mData[,2] >= s)*as.numeric(mData[,4] >= s)*as.numeric(mData[,5] >= s)*as.numeric(mData[,5] <= s+Swin)*as.numeric(mData[,6] <= t)) /sum(as.numeric(mData[,5] >= s)*as.numeric(mData[,5] <= s+Swin))  -
                             sum(as.numeric(mData[,2] >= s)*as.numeric(mData[,4] >= s)*as.numeric(mData[,7] >= s)*as.numeric(mData[,7] <= s+Swin)*as.numeric(mData[,8] <=t))/sum(as.numeric(mData[,7] >= s)*as.numeric(mData[,7] <= s+Swin)) - BSas[(s-mins+1)]
      BZSds[(s-mins+1)] <- BZS[(s-mins+1)] - BZScs[(s-mins+1)] - BZSas[(s-mins+1)]
      
      
    }
    else
    {
      
      # BS effect total at (s-mins+1) which is only equal to contribution of always survivors
      BS[(s-mins+1)] <- sum(as.numeric(mData[,9] >= s-Swin)*as.numeric(mData[,9] <= s+Swin)*as.numeric(mData[,10] <= t))/sum(as.numeric(mData[,9] >= s-Swin)*as.numeric(mData[,9] <= s+Swin)) -
            sum(as.numeric(mData[,11] >= s-Swin)*as.numeric(mData[,11] <= s+Swin)*as.numeric(mData[,12] <=t)) /sum(as.numeric(mData[,11] >= s-Swin)*as.numeric(mData[,11] <= s+Swin))
      BSas[(s-mins+1)] <- sum(as.numeric(mData[,2] >= s)*as.numeric(mData[,4] >= s)*as.numeric(mData[,9] >= s-Swin)*as.numeric(mData[,9] <= s+Swin)*as.numeric(mData[,10] <= t)) /sum(as.numeric(mData[,9] >= s-Swin)*as.numeric(mData[,9] <= s+Swin)) -
                            sum(as.numeric(mData[,2] >= s)*as.numeric(mData[,4] >= s)*as.numeric(mData[,11] >= s-Swin)*as.numeric(mData[,11] <= s+Swin)*as.numeric(mData[,12] <=t))/sum(as.numeric(mData[,11] >= s-Swin)*as.numeric(mData[,11] <= s+Swin))
      BSds[(s-mins+1)] <- BS[(s-mins+1)] - BSas[(s-mins+1)]
      
      # BZS effect total at (s-mins+1) which is only equal to contribution of complier survivors
      BZS[(s-mins+1)] <- sum(as.numeric(mData[,5] >= s-Swin)*as.numeric(mData[,5] <= s+Swin)*as.numeric(mData[,6] <= t))/sum(as.numeric(mData[,5] >= s-Swin)*as.numeric(mData[,5] <= s+Swin))  -
                          sum(as.numeric(mData[,7] >= s-Swin)*as.numeric(mData[,7] <= s+Swin)*as.numeric(mData[,8] <=t))/sum(as.numeric(mData[,7] >= s-Swin)*as.numeric(mData[,7] <= s+Swin)) - BS[(s-mins+1)]
      BZScs[(s-mins+1)] <- sum(as.numeric(mData[,2] < s)*as.numeric(mData[,4] >= s)*as.numeric(mData[,5] >= s-Swin)*as.numeric(mData[,5] <= s+Swin)*as.numeric(mData[,6] <= t))/sum(as.numeric(mData[,5] >= s-Swin)*as.numeric(mData[,5] <= s+Swin)) -
        sum(as.numeric(mData[,2] < s)*as.numeric(mData[,4] >= s)*as.numeric(mData[,7] >= s-Swin)*as.numeric(mData[,7] <= s+Swin)*as.numeric(mData[,8] <=t))/sum(as.numeric(mData[,7] >= s-Swin)*as.numeric(mData[,7] <= s+Swin)) 
      BZSas[(s-mins+1)] <- sum(as.numeric(mData[,2] >= s)*as.numeric(mData[,4] >= s)*as.numeric(mData[,5] >= s-Swin)*as.numeric(mData[,5] <= s+Swin)*as.numeric(mData[,6] <= t)) /sum(as.numeric(mData[,5] >= s-Swin)*as.numeric(mData[,5] <= s+Swin)) - 
       sum(as.numeric(mData[,2] >= s)*as.numeric(mData[,4] >= s)*as.numeric(mData[,7] >= s-Swin)*as.numeric(mData[,7] <= s+Swin)*as.numeric(mData[,8] <=t))/sum(as.numeric(mData[,7] >= s-Swin)*as.numeric(mData[,7] <= s+Swin)) - BSas[(s-mins+1)]
      BZSds[(s-mins+1)] <- BZS[(s-mins+1)] - BZScs[(s-mins+1)] - BZSas[(s-mins+1)]
      
      print(BS[(s-mins+1)])
      
    }
    
    print(s)   

    

  } 
  


  # Obtain average effects
  B0_avg <- sum(mPTreatS1*B0)/sum(mPTreatS1)
  B0ns_avg <- sum(mPTreatS1*B0ns)/sum(mPTreatS1)
  B0as_avg <- sum(mPTreatS1*B0as)/sum(mPTreatS1)
  B0cs_avg <- sum(mPTreatS1*B0cs)/sum(mPTreatS1)
  B0ds_avg <- sum(mPTreatS1*B0ds)/sum(mPTreatS1)
  
  #print(cbind(B0,B0ds))
  
  #print(cbind(B0_avg,B0ds_avg))
  
  BZ_avg <- sum(mPTreatS1*BZ)/sum(mPTreatS1)
  BZas_avg <- sum(mPTreatS1*BZas)/sum(mPTreatS1)
  BZcs_avg <- sum(mPTreatS1*BZcs)/sum(mPTreatS1)
  BZds_avg <- sum(mPTreatS1*BZds)/sum(mPTreatS1)
  
  BS_avg <- sum(mPTreatS1*BS)/sum(mPTreatS1)
  BSas_avg <- sum(mPTreatS1*BZas)/sum(mPTreatS1)
  BSds_avg <- sum(mPTreatS1*BZds)/sum(mPTreatS1)
  
  BZS_avg <- sum(mPTreatS1*BZS)/sum(mPTreatS1)
  BZSas_avg <- sum(mPTreatS1*BZSas)/sum(mPTreatS1)
  BZScs_avg <- sum(mPTreatS1*BZScs)/sum(mPTreatS1)
  BZSds_avg <- sum(mPTreatS1*BZSds)/sum(mPTreatS1)
  
  Pns_avg <- sum(mPTreatS1*Pns)/sum(mPTreatS1)
  Pas_avg <- sum(mPTreatS1*Pas)/sum(mPTreatS1)
  Pcs_avg <- sum(mPTreatS1*Pcs)/sum(mPTreatS1)
  Pds_avg <- sum(mPTreatS1*Pds)/sum(mPTreatS1)
  
  print(B0_avg)
  print(BZ_avg)
  print(BS_avg)
  print(BZS_avg)

  
  mOut <- matrix(0,1,24)  
  

  for (s in 1:nrow(B0)) 
  {
    mOut <- rbind(mOut,cbind(B0[s], BZ[s], BS[s], BZS[s], Pns[s], Pcs[s], Pas[s], Pds[s], B0_avg, B0ns_avg, B0cs_avg, B0as_avg, BZ_avg, BZcs_avg, BZas_avg, BS_avg, BZS_avg, 
                             B0ds_avg,BZds_avg,BSas_avg,BSds_avg,BZScs_avg,BZSas_avg,BZSds_avg))
  }
  
  mOut = mOut[2:(nrow(B0)+1),]
  

  
  return( mOut ) 
}





mins <- 1; dS <- 29; dT <- 60; dTmov <- 0; plGr <- 1; 
mOutput <- DGPeffectFn(mins, dS, dT, dTmov)

colnames(mOutput) <- c("B0[s]", "BZ[s]", "BS[s]", "BZS[s]", "Pns[s]", "Pcs[s]", "Pas[s]", "Pds[s]", "B0_avg", "B0ns_avg", "B0cs_avg", "B0as_avg", "BZ_avg", "BZcs_avg", "BZas_avg", "BS_avg", "BZS_avg",  "B0ds_avg", "BZds_avg", "BSas_avg", "BSds_avg", "BZScs_avg", "BZSas_avg", "BZSds_avg" )
print(mOutput)


# Output file is matrix of (B0[s], BZ[s], BS[s], BZS[s], Pns[s], Pcs[s], Pas[s], Pds[s], B0_avg, B0ns_avg, B0cs_avg, B0as_avg, BZ_avg, BZcs_avg, BZas_avg, BS_avg, BZS_avg, 
#                           B0ds_avg,BZds_avg,BSas_avg,BSds_avg,BZScs_avg,BZSas_avg,BZSds_avg )
# First columns are for graphs over time, columns of averages are repeated
write.table(mOutput, file="D:\\Dropbox\\ContDurMA\\CompCode 2022\\simDGPval_3060.txt", row.names=FALSE, col.names=FALSE)



