####################################################################################
##  Code for: Regime and Treatment Effects in Duration Models: 
##            Decomposing Expectation and Transplant Effects on
##            the Kidney Waitlist
#####
##                                                                    
##  Author: Stephen Kastoryano                                        
##  Date  : 20 May 2022                                               
##                                                                    
##  Purpose: Produce descriptive statistics Table
##           
##                                                                        
##           
##  input:  "df_can_final.txt", "df_can_final_post2015.txt" - from LARTE_kidney_clean.R
##          "df_can_finalCPRA.txt", "df_can_finalCPRA_post2015.txt", "df_can_finalCPRA0.txt", "df_can_finalCPRA0_post2015.txt" - from LARTE_kidney_cleanCPRA.R
##          
##
##  output: Table 2
##            
##
##                                                                    
######################################################################################

#library(survival, lib.loc="C:\\Users\\Stephen Kastoryano\\Documents\\R\\win-library\\3.6")
#library(survminer, lib.loc="C:\\Users\\Stephen Kastoryano\\Documents\\R\\win-library\\3.6")

library(missForest,lib.loc="C:\\Users\\Stephen Kastoryano\\Documents\\R\\win-library\\3.6")
library(dplyr, lib.loc="C:\\Users\\Stephen Kastoryano\\Documents\\R\\win-library\\3.6")
library(Hmisc, lib.loc="C:\\Users\\Stephen Kastoryano\\Documents\\R\\win-library\\3.6")
library(MASS, lib.loc="C:\\Users\\Stephen Kastoryano\\Documents\\R\\win-library\\3.6")

## Load Data ##
###############
# <<INPUT>> #

set.seed(5327456)

mDat_Bloodpre <-read.table("D:\\Dropbox\\ContDurMA\\CompCode 2022\\df_can_final.txt")  # Pre-2015 reform AB vs. BO data
colnames(mDat_Bloodpre, do.NULL = FALSE)
colnames(mDat_Bloodpre) <- c("durDE", "durDEC", "durTX","durTXC", "CAN_ABO", "CAN_ACPT_HBC_POS1","CAN_ACPT_HCV_POS1", "CAN_MIN_PEAK_CREAT_5up", "CAN_AGE_AT_LISTING_41","CAN_AGE_AT_LISTING_51","CAN_AGE_AT_LISTING_58","CAN_AGE_AT_LISTING_65","CAN_AGE_AT_LISTING_65up", "CAN_EDUCATION_HS","CAN_EDUCATION_COL","CAN_EDUCATION_COLDEG","CAN_BMI_under19","CAN_BMI_1925","CAN_BMI_2630","CAN_BMI_over30", "CAN_MALIG", "ASIAN", "BLACK", "OTHER_NONWHITE","CAN_PREV_TX","FEMALE","DIAB_ENTRY", "DIAL_ENTRY", "CANHX_CPRA_0", "CANHX_CPRA_40", "CANHX_CPRA_100","CAN_AGE_AT_LISTING","CAN_EDUCATION_HS","CAN_BMI","WHITE")

mDat_Bloodpost <-read.table("D:\\Dropbox\\ContDurMA\\CompCode 2022\\df_can_final_post2015.txt")  # Post 2015 reform AB vs. BO data
colnames(mDat_Bloodpost, do.NULL = FALSE)
colnames(mDat_Bloodpost) <- c("durDE", "durDEC", "durTX","durTXC", "CAN_ABO", "CAN_ACPT_HBC_POS1","CAN_ACPT_HCV_POS1", "CAN_MIN_PEAK_CREAT_5up", "CAN_AGE_AT_LISTING_41","CAN_AGE_AT_LISTING_51","CAN_AGE_AT_LISTING_58","CAN_AGE_AT_LISTING_65","CAN_AGE_AT_LISTING_65up", "CAN_EDUCATION_HS","CAN_EDUCATION_COL","CAN_EDUCATION_COLDEG","CAN_BMI_under19","CAN_BMI_1925","CAN_BMI_2630","CAN_BMI_over30", "CAN_MALIG", "ASIAN", "BLACK", "OTHER_NONWHITE","CAN_PREV_TX","FEMALE","DIAB_ENTRY", "DIAL_ENTRY", "CANHX_CPRA_0", "CANHX_CPRA_40", "CANHX_CPRA_100","CAN_AGE_AT_LISTING","CAN_EDUCATION_HS","CAN_BMI","WHITE" )

mDat_cPRApre <-read.table("D:\\Dropbox\\ContDurMA\\CompCode 2022\\df_can_finalCPRA.txt")
colnames(mDat_cPRApre, do.NULL = FALSE)
colnames(mDat_cPRApre) <- c("durDE", "durDEC", "durTX","durTXC", "CAN_ABO", "CAN_ACPT_HBC_POS1","CAN_ACPT_HCV_POS1",  "CAN_MIN_PEAK_CREAT_5up", "CAN_AGE_AT_LISTING_41","CAN_AGE_AT_LISTING_51","CAN_AGE_AT_LISTING_58","CAN_AGE_AT_LISTING_65","CAN_AGE_AT_LISTING_65up", "CAN_EDUCATION_HS","CAN_EDUCATION_COL","CAN_EDUCATION_COLDEG","CAN_BMI_under19","CAN_BMI_1925","CAN_BMI_2630","CAN_BMI_over30", "CAN_MALIG", "ASIAN", "BLACK", "OTHER_NONWHITE","CAN_PREV_TX","FEMALE","DIAB_ENTRY", "DIAL_ENTRY", "CPRAhigh", "BLOOD_A", "BLOOD_B", "BLOOD_AB", "BLOOD_O","CAN_AGE_AT_LISTING","CAN_EDUCATION_HS","CAN_BMI","WHITE" )
mDat_cPRApre <- mDat_cPRApre[(mDat_cPRApre$CAN_PREV_TX ==0),]  # only take observations which did not experience previous transplant

mDat_cPRApost <-read.table("D:\\Dropbox\\ContDurMA\\CompCode 2022\\df_can_finalCPRA_post2015.txt")
colnames(mDat_cPRApost, do.NULL = FALSE)
colnames(mDat_cPRApost) <- c("durDE", "durDEC", "durTX","durTXC", "CAN_ABO", "CAN_ACPT_HBC_POS1","CAN_ACPT_HCV_POS1",  "CAN_MIN_PEAK_CREAT_5up", "CAN_AGE_AT_LISTING_41","CAN_AGE_AT_LISTING_51","CAN_AGE_AT_LISTING_58","CAN_AGE_AT_LISTING_65","CAN_AGE_AT_LISTING_65up", "CAN_EDUCATION_HS","CAN_EDUCATION_COL","CAN_EDUCATION_COLDEG","CAN_BMI_under19","CAN_BMI_1925","CAN_BMI_2630","CAN_BMI_over30", "CAN_MALIG", "ASIAN", "BLACK", "OTHER_NONWHITE","CAN_PREV_TX","FEMALE","DIAB_ENTRY", "DIAL_ENTRY", "CPRAhigh", "BLOOD_A", "BLOOD_B", "BLOOD_AB", "BLOOD_O","CAN_AGE_AT_LISTING","CAN_EDUCATION_HS","CAN_BMI","WHITE" )
mDat_cPRApost <- mDat_cPRApost[(mDat_cPRApost$CAN_PREV_TX ==0),]  # only take observations which did not experience previous transplant

mDat_cPRA0pre <-read.table("D:\\Dropbox\\ContDurMA\\CompCode 2022\\df_can_finalCPRA0.txt")
colnames(mDat_cPRA0pre, do.NULL = FALSE)
colnames(mDat_cPRA0pre) <- c("durDE", "durDEC", "durTX","durTXC", "CAN_ABO", "CAN_ACPT_HBC_POS1","CAN_ACPT_HCV_POS1",  "CAN_MIN_PEAK_CREAT_5up", "CAN_AGE_AT_LISTING_41","CAN_AGE_AT_LISTING_51","CAN_AGE_AT_LISTING_58","CAN_AGE_AT_LISTING_65","CAN_AGE_AT_LISTING_65up", "CAN_EDUCATION_HS","CAN_EDUCATION_COL","CAN_EDUCATION_COLDEG","CAN_BMI_under19","CAN_BMI_1925","CAN_BMI_2630","CAN_BMI_over30", "CAN_MALIG", "ASIAN", "BLACK", "OTHER_NONWHITE","CAN_PREV_TX","FEMALE","DIAB_ENTRY", "DIAL_ENTRY", "CPRAhigh", "BLOOD_A", "BLOOD_B", "BLOOD_AB", "BLOOD_O","CAN_AGE_AT_LISTING","CAN_EDUCATION_HS","CAN_BMI","WHITE" )
mDat_cPRA0pre <- mDat_cPRA0pre[(mDat_cPRA0pre$CAN_PREV_TX ==0),]  # only take observations which did not experience previous transplant
mDat_cPRA0pre <- mDat_cPRA0pre[(mDat_cPRA0pre$CPRAhigh ==1),]

mDat_cPRA0post <-read.table("D:\\Dropbox\\ContDurMA\\CompCode 2022\\df_can_finalCPRA0_post2015.txt")
colnames(mDat_cPRA0post, do.NULL = FALSE)
colnames(mDat_cPRA0post) <- c("durDE", "durDEC", "durTX","durTXC", "CAN_ABO", "CAN_ACPT_HBC_POS1","CAN_ACPT_HCV_POS1",  "CAN_MIN_PEAK_CREAT_5up", "CAN_AGE_AT_LISTING_41","CAN_AGE_AT_LISTING_51","CAN_AGE_AT_LISTING_58","CAN_AGE_AT_LISTING_65","CAN_AGE_AT_LISTING_65up", "CAN_EDUCATION_HS","CAN_EDUCATION_COL","CAN_EDUCATION_COLDEG","CAN_BMI_under19","CAN_BMI_1925","CAN_BMI_2630","CAN_BMI_over30", "CAN_MALIG", "ASIAN", "BLACK", "OTHER_NONWHITE","CAN_PREV_TX","FEMALE","DIAB_ENTRY", "DIAL_ENTRY", "CPRAhigh", "BLOOD_A", "BLOOD_B", "BLOOD_AB", "BLOOD_O","CAN_AGE_AT_LISTING","CAN_EDUCATION_HS","CAN_BMI","WHITE" )
mDat_cPRA0post <- mDat_cPRA0post[(mDat_cPRA0post$CAN_PREV_TX ==0),]  # only take observations which did not experience previous transplant
mDat_cPRA0post <- mDat_cPRA0post[(mDat_cPRA0post$CPRAhigh ==1),]


### Covariate Matrices ###
mDat = mDat_Bloodpre[(mDat_Bloodpre$CAN_ABO == "AB"), ]
mX_BloAB_pre <- cbind(mDat$CAN_AGE_AT_LISTING, mDat$CAN_ACPT_HBC_POS1, mDat$CAN_ACPT_HCV_POS1, mDat$CAN_EDUCATION_HS, mDat$CAN_EDUCATION_COL, mDat$CAN_EDUCATION_COLDEG,  mDat$CAN_BMI, mDat$CAN_MALIG, mDat$ASIAN, mDat$BLACK, mDat$WHITE, mDat$OTHER_NONWHITE, mDat$FEMALE,  mDat$DIAB_ENTRY, mDat$CAN_PREV_TX)   # enter matrix(0,NROW(mDat),2) if no covariates used for estimation
mDat = mDat_Bloodpost[(mDat_Bloodpost$CAN_ABO == "AB"), ]
mX_BloAB_post <- cbind(mDat$CAN_AGE_AT_LISTING , mDat$CAN_ACPT_HBC_POS1, mDat$CAN_ACPT_HCV_POS1, mDat$CAN_EDUCATION_HS, mDat$CAN_EDUCATION_COL, mDat$CAN_EDUCATION_COLDEG,  mDat$CAN_BMI, mDat$CAN_MALIG, mDat$ASIAN, mDat$BLACK,  mDat$WHITE, mDat$OTHER_NONWHITE, mDat$FEMALE,  mDat$DIAB_ENTRY, mDat$CAN_PREV_TX)   # enter matrix(0,NROW(mDat),2) if no covariates used for estimation

mDat = mDat_Bloodpre[(mDat_Bloodpre$CAN_ABO == "BorO"), ]
mX_BloBO_pre <- cbind(mDat$CAN_AGE_AT_LISTING, mDat$CAN_ACPT_HBC_POS1, mDat$CAN_ACPT_HCV_POS1, mDat$CAN_EDUCATION_HS, mDat$CAN_EDUCATION_COL, mDat$CAN_EDUCATION_COLDEG,  mDat$CAN_BMI, mDat$CAN_MALIG, mDat$ASIAN, mDat$BLACK, mDat$WHITE, mDat$OTHER_NONWHITE, mDat$FEMALE, mDat$DIAB_ENTRY, mDat$CAN_PREV_TX)   # enter matrix(0,NROW(mDat),2) if no covariates used for estimation
mDat = mDat_Bloodpost[(mDat_Bloodpost$CAN_ABO == "BorO"), ]
mX_BloBO_post <- cbind(mDat$CAN_AGE_AT_LISTING , mDat$CAN_ACPT_HBC_POS1, mDat$CAN_ACPT_HCV_POS1, mDat$CAN_EDUCATION_HS, mDat$CAN_EDUCATION_COL, mDat$CAN_EDUCATION_COLDEG,  mDat$CAN_BMI, mDat$CAN_MALIG, mDat$ASIAN, mDat$BLACK, mDat$WHITE, mDat$OTHER_NONWHITE, mDat$FEMALE, mDat$DIAB_ENTRY, mDat$CAN_PREV_TX)   # enter matrix(0,NROW(mDat),2) if no covariates used for estimation


mDat = mDat_cPRApre[(mDat_cPRApre$CPRAhigh == 0), ]
mX_PRAlow_pre <- cbind(mDat$CAN_AGE_AT_LISTING, mDat$CAN_ACPT_HBC_POS1, mDat$CAN_ACPT_HCV_POS1, mDat$CAN_EDUCATION_HS, mDat$CAN_EDUCATION_COL, mDat$CAN_EDUCATION_COLDEG,  mDat$CAN_BMI, mDat$CAN_MALIG, mDat$ASIAN, mDat$BLACK, mDat$WHITE, mDat$OTHER_NONWHITE, mDat$FEMALE, mDat$DIAB_ENTRY, mDat$BLOOD_A, mDat$BLOOD_B, mDat$BLOOD_AB, mDat$BLOOD_O)
mDat = mDat_cPRApre[(mDat_cPRApre$CPRAhigh == 1), ]
mX_PRAhigh_pre <- cbind(mDat$CAN_AGE_AT_LISTING , mDat$CAN_ACPT_HBC_POS1, mDat$CAN_ACPT_HCV_POS1, mDat$CAN_EDUCATION_HS, mDat$CAN_EDUCATION_COL, mDat$CAN_EDUCATION_COLDEG,  mDat$CAN_BMI, mDat$CAN_MALIG, mDat$ASIAN, mDat$BLACK, mDat$WHITE, mDat$OTHER_NONWHITE, mDat$FEMALE, mDat$DIAB_ENTRY, mDat$BLOOD_A, mDat$BLOOD_B, mDat$BLOOD_AB, mDat$BLOOD_O)
mDat = mDat_cPRA0pre[(mDat_cPRA0pre$CPRAhigh == 1), ]
mX_PRA0_pre <- cbind(mDat$CAN_AGE_AT_LISTING , mDat$CAN_ACPT_HBC_POS1, mDat$CAN_ACPT_HCV_POS1, mDat$CAN_EDUCATION_HS, mDat$CAN_EDUCATION_COL, mDat$CAN_EDUCATION_COLDEG,  mDat$CAN_BMI, mDat$CAN_MALIG, mDat$ASIAN, mDat$BLACK, mDat$WHITE, mDat$OTHER_NONWHITE, mDat$FEMALE, mDat$DIAB_ENTRY, mDat$BLOOD_A, mDat$BLOOD_B, mDat$BLOOD_AB, mDat$BLOOD_O)

mDat = mDat_cPRApost[(mDat_cPRApost$CPRAhigh == 0), ]
mX_PRAlow_post <- cbind(mDat$CAN_AGE_AT_LISTING, mDat$CAN_ACPT_HBC_POS1, mDat$CAN_ACPT_HCV_POS1, mDat$CAN_EDUCATION_HS, mDat$CAN_EDUCATION_COL, mDat$CAN_EDUCATION_COLDEG,  mDat$CAN_BMI, mDat$CAN_MALIG, mDat$ASIAN, mDat$BLACK, mDat$WHITE, mDat$OTHER_NONWHITE, mDat$FEMALE, mDat$DIAB_ENTRY, mDat$BLOOD_A, mDat$BLOOD_B, mDat$BLOOD_AB, mDat$BLOOD_O)
mDat = mDat_cPRApost[(mDat_cPRApost$CPRAhigh == 1), ]
mX_PRAhigh_post <- cbind(mDat$CAN_AGE_AT_LISTING , mDat$CAN_ACPT_HBC_POS1, mDat$CAN_ACPT_HCV_POS1, mDat$CAN_EDUCATION_HS, mDat$CAN_EDUCATION_COL, mDat$CAN_EDUCATION_COLDEG,  mDat$CAN_BMI, mDat$CAN_MALIG, mDat$ASIAN, mDat$BLACK, mDat$WHITE, mDat$OTHER_NONWHITE, mDat$FEMALE, mDat$DIAB_ENTRY, mDat$BLOOD_A, mDat$BLOOD_B, mDat$BLOOD_AB, mDat$BLOOD_O)
mDat = mDat_cPRA0post[(mDat_cPRA0post$CPRAhigh == 1), ]
mX_PRA0_post <- cbind(mDat$CAN_AGE_AT_LISTING , mDat$CAN_ACPT_HBC_POS1, mDat$CAN_ACPT_HCV_POS1, mDat$CAN_EDUCATION_HS, mDat$CAN_EDUCATION_COL, mDat$CAN_EDUCATION_COLDEG,  mDat$CAN_BMI, mDat$CAN_MALIG, mDat$ASIAN, mDat$BLACK, mDat$WHITE, mDat$OTHER_NONWHITE, mDat$FEMALE, mDat$DIAB_ENTRY, mDat$BLOOD_A, mDat$BLOOD_B, mDat$BLOOD_AB, mDat$BLOOD_O)

list_mX = c("mX_BloAB_pre","mX_BloBO_pre","mX_PRAhigh_pre","mX_PRAlow_pre","mX_PRA0_pre","mX_PRAhigh_post","mX_PRAlow_post","mX_PRA0_post")


descr_mX_all = matrix(0, 3,1)


for (i in 1:NROW(list_mX)) {
  mX = eval(parse(text = list_mX[i]))
  descr_mX = matrix(0, ncol(mX_PRAlow_pre)*3+3,1)
  for (j in 1:NCOL(mX)) {

    descr_mX[((j-1)*3+1)] = mean(mX[!is.na(mX[,j]),j])
    descr_mX[((j-1)*3+2)] = sd(mX[!is.na(mX[,j]),j])
    descr_mX[((j-1)*3+3)] = sum(is.na(mX[,j]))/nrow(mX)

  }

  descr_mX_all = rbind(descr_mX_all,descr_mX)
  #print(descr_mX_all)
}


###############################
##  Table 2
###############################
round(descr_mX_all, digits =3)






#### Calculate share of cPRA candidates pre-reform, and share with previous transplant  ###

mDat_cPRApre <-read.table("D:\\Dropbox\\ContDurMA\\CompCode 2022\\df_can_finalCPRA.txt")
colnames(mDat_cPRApre, do.NULL = FALSE)
colnames(mDat_cPRApre) <- c("durDE", "durDEC", "durTX","durTXC", "CAN_ABO", "CAN_ACPT_HBC_POS1","CAN_ACPT_HCV_POS1",  "CAN_MIN_PEAK_CREAT_5up", "CAN_AGE_AT_LISTING_41","CAN_AGE_AT_LISTING_51","CAN_AGE_AT_LISTING_58","CAN_AGE_AT_LISTING_65","CAN_AGE_AT_LISTING_65up", "CAN_EDUCATION_HS","CAN_EDUCATION_COL","CAN_EDUCATION_COLDEG","CAN_BMI_under19","CAN_BMI_1925","CAN_BMI_2630","CAN_BMI_over30", "CAN_MALIG", "ASIAN", "BLACK", "OTHER_NONWHITE","CAN_PREV_TX","FEMALE","DIAB_ENTRY", "DIAL_ENTRY", "CPRAhigh", "BLOOD_A", "BLOOD_B", "BLOOD_AB", "BLOOD_O","CAN_AGE_AT_LISTING","CAN_EDUCATION_HS","CAN_BMI","WHITE" )
h_cPRA = sum(mDat_cPRApre$CPRAhigh)  # Number of obs with high-cPRA including previously transplanted candidates
l_cPRA = (nrow(mDat_cPRApre)-sum(mDat_cPRApre$CPRAhigh))  # Number of obs with low-cPRA including previously transplanted candidates
mDat_cPRApre <- mDat_cPRApre[(mDat_cPRApre$CAN_PREV_TX ==0),]  # only take observations which did not experience previous transplant
h_cPRA_w = sum(mDat_cPRApre$CPRAhigh)  # Number of obs with high-cPRA without previously transplanted candidates
l_cPRA_w = (nrow(mDat_cPRApre)-sum(mDat_cPRApre$CPRAhigh))  # Number of obs with low-cPRA without previously transplanted candidates



mDat_cPRA0pre <-read.table("D:\\Dropbox\\ContDurMA\\CompCode 2022\\df_can_finalCPRA0.txt")
colnames(mDat_cPRA0pre, do.NULL = FALSE)
colnames(mDat_cPRA0pre) <- c("durDE", "durDEC", "durTX","durTXC", "CAN_ABO", "CAN_ACPT_HBC_POS1","CAN_ACPT_HCV_POS1",  "CAN_MIN_PEAK_CREAT_5up", "CAN_AGE_AT_LISTING_41","CAN_AGE_AT_LISTING_51","CAN_AGE_AT_LISTING_58","CAN_AGE_AT_LISTING_65","CAN_AGE_AT_LISTING_65up", "CAN_EDUCATION_HS","CAN_EDUCATION_COL","CAN_EDUCATION_COLDEG","CAN_BMI_under19","CAN_BMI_1925","CAN_BMI_2630","CAN_BMI_over30", "CAN_MALIG", "ASIAN", "BLACK", "OTHER_NONWHITE","CAN_PREV_TX","FEMALE","DIAB_ENTRY", "DIAL_ENTRY", "CPRAhigh", "BLOOD_A", "BLOOD_B", "BLOOD_AB", "BLOOD_O","CAN_AGE_AT_LISTING","CAN_EDUCATION_HS","CAN_BMI","WHITE" )
mDat_cPRA0pre <- mDat_cPRA0pre[(mDat_cPRA0pre$CPRAhigh ==1),]
zero_cPRA = sum(mDat_cPRA0pre$CPRAhigh)  # Number of obs with high-cPRA including previously transplanted candidates
mDat_cPRA0pre <- mDat_cPRA0pre[(mDat_cPRA0pre$CAN_PREV_TX ==0),]   # only take observations which did not experience previous transplant
zero_cPRA_w = sum(mDat_cPRA0pre$CPRAhigh)  # Number of obs with high-cPRA without previously transplanted candidates

zero_cPRA/(zero_cPRA+l_cPRA+h_cPRA)
l_cPRA/(zero_cPRA+l_cPRA+h_cPRA)
h_cPRA/(zero_cPRA+l_cPRA+h_cPRA)

1-(zero_cPRA_w)/zero_cPRA
1-(l_cPRA_w)/l_cPRA
1-(h_cPRA_w)/h_cPRA



