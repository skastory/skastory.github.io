
Project: Regime and Treatment Effects in Duration Models: Decomposing Expectation and Transplant Effects on the Kidney Waitlist 
                                                                    
Author: Stephen P. Kastoryano                                        
Date  : 20 May 2022   
                                       
Purpose: Estimate and plot average and time-varying decomposition effects, produce Kaplan-Meier Figures. 
                                              

Files: 

For Figures 1-6 and Tables 1-3:
- LARTE_kidney_clean.R cleans and prepares SRTR kidney data for analysis by blood type:
    input: 
    * "cand_kipa.sas7bdat" - SRTR kidney data. Contact SRTR to request data at https://www.srtr.org/requesting-srtr-data/data-requests/
    outputs:
    * "df_can_final.txt", "df_can_final_post2015.txt" - for LARTE_kidney.R
    * Figures 1, 4, 5
- LARTE_kidney_cleanCPRA.R cleans and prepares SRTR kidney data for analysis by cPRA type:
    input: 
    * "cand_kipa.sas7bdat" - SRTR kidney data.
    outputs:
    * "df_can_finalCPRA.txt", "df_can_finalCPRA_post2015.txt", "df_can_finalCPRA0.txt", "df_can_finalCPRA0_post2015.txt" - for LARTE_kidney.R
    * Figures 2, 3, 6
- DescrStats.R produce descriptive statistics table:
    input: 
    * "df_can_final.txt", "df_can_final_post2015.txt" - from LARTE_kidney_clean.R
    * "df_can_finalCPRA.txt", "df_can_finalCPRA_post2015.txt", "df_can_finalCPRA0.txt", "df_can_finalCPRA0_post2015.txt" - from LARTE_kidney_cleanCPRA.R
    outputs:
    * Table 2  
- LARTE_kidney.R main analysis file generating all table results:
    input: 
    * "df_can_final.txt", "df_can_final_post2015.txt" - from LARTE_kidney_clean.R
    * "df_can_finalCPRA.txt", "df_can_finalCPRA_post2015.txt", "df_can_finalCPRA0.txt", "df_can_finalCPRA0_post2015.txt" - from LARTE_kidney_cleanCPRA.R
    outputs:
    * Table 1,3 results



For Appendix secion E: Dynamic Discrete Choice Simulation exercise (Table 5, Figures 7-8):
- DGPsim.ox generates data from DDC model.
    outputs: 
    * "DGPsampleER.m" - for dgpLARTE.R
    * "DGPz1c.m","DGPz1S.m","DGPz1Sc.m", "DGPz0cER.m","DGPz0SER.m","DGPz0ScER.m" - for DGPsimValLARTE.R
- DGPsimValLARTE.R calculates true DGP effect values for DDC model. 
    inputs: 
    * "DGPz1c.m","DGPz1S.m","DGPz1Sc.m", "DGPz0cER.m","DGPz0SER.m","DGPz0ScER.m" - from DGPsim.ox; 
    output: 
    * "simDGPval_3060.txt" - for dgpLARTE.R
- dgpLARTE.R is estimation code for effects, bias, variance, MSE of simulated data. 
    inputs:
    * "simDGPval_3060.txt" - from DGPsimValLARTE.R 
    * "DGPsampleER.m" - from DGPsim.ox
    outputs:
    * Table 5, Figures 7-8


