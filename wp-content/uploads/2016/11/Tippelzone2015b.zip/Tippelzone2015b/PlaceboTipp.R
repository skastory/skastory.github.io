

library(readstata13,plm)

set.seed(53278352)

mData <-read.dta13("C:\\Users\\skastoryano\\Dropbox\\Tippelzone G\\TempTipp\\Tippelzone2015\\CBSregist2015.dta")

## Select 22 cities
mData <- mData[!(mData$city %in% c("Amsterdam","Rotterdam","Den Haag")),]
EIN2011 <- 10*2011   # argument to drop closing year 2011 for Eindhoven
mData <- mData[(mData$city1*mData$year!=EIN2011),]


## Generate year factors
year.f <- factor(mData$year)
myearD <- model.matrix(~year.f)
myearDid <- colnames(myearD[,2:dim(myearD)[2]])

## Define covariates
Xid <- c("logpopmale1565","logpopdens","inkhh","educhpc","nondutchpc","insurWWAO","mayorCDA","mayorCU","mayorD66","mayorVVD")
mXid <- mData[,Xid]

## Estimate panel treatment effect
mOutcomes <- mData[,c("lnrapesexaN","lnsexassaultN","lnrapeN","lndrugsN","lnweaponsN","lnmaltreatN")]
vBopening <- matrix(0,1, dim(mOutcomes)[2])
vBeveropenNoReg <- matrix(0,1, dim(mOutcomes)[2])
vBopeningRegA <- matrix(0,1, dim(mOutcomes)[2])
vBopeningRegP <- matrix(0,1, dim(mOutcomes)[2])

for (j in 1:dim(mOutcomes)[2])
{  
  Treatid <- "opening"
  vTreat <- mData[,Treatid]
  treatXid <-c(Treatid, mXid)
  mFEpanel <-  data.frame(mData[,c("city1","year",Treatid,Xid)],myearD[,2:dim(myearD)[2]],mOutcomes[,j])
  fmla <- as.formula(paste("mOutcomes[,j] ~ ", paste(cbind(treatXid,myearDid), collapse= "+")))
  FEout <- plm(fmla, data=mFEpanel, index=c("city1","year"), model="within")
  vBopening[j] <- FEout$coefficients["opening"]

  Treatid <- c("everopenNoReg","openingRegP","openingRegA")
  vTreat <- mData[,Treatid]
  treatXid <-c(Treatid, mXid)
  mFEpanel <-  data.frame(mData[,c("city1","year",Treatid,Xid)],myearD[,2:dim(myearD)[2]],mOutcomes[,j])
  fmla <- as.formula(paste("mOutcomes[,j] ~ ", paste(cbind(treatXid,myearDid), collapse= "+")))
  FEout <- plm(fmla, data=mFEpanel, index=c("city1","year"), model="within")
  vBeveropenNoReg[j] <- FEout$coefficients["everopenNoReg"]
  vBopeningRegA[j] <-FEout$coefficients["openingRegP"]
  vBopeningRegP[j] <- FEout$coefficients["openingRegA"]
}


## Generate placebo inference
B <- 999  # nbr placebo replications
mBopeningpl <- matrix(0,B, dim(mOutcomes)[2])
mBeveropenNoRegpl <- matrix(0,B, dim(mOutcomes)[2])
mBopeningRegApl <- matrix(0,B, dim(mOutcomes)[2])
mBopeningRegPpl <- matrix(0,B, dim(mOutcomes)[2])

vContrcitiesI <- c(5,7,8,9,11,13,15,16,17,18,19,20,22,23,24,25)
minDistrTyear <- 1994
maxDistrTyear <- 2008
for (b in 1:B) 
{
  vTreatpl <- sample(vContrcitiesI, 6, replace = FALSE)

  ## Define vTreatpl[1] as Utrecht placebo, vTreatpl[1] as Groningen placebo
  ##        vTreatpl[2:3] as Nimegen & Arnhem placebo, vTreatpl[2:3] as Einndhoven & Heerlen placebo
  vyearOpl <- matrix(2012, dim(mData)[1],1) - (2012-1994)*as.numeric(mData$city1 == vTreatpl[1]) -
              ((2011-maxDistrTyear)+round(runif(1, 0, maxDistrTyear-minDistrTyear))) *as.numeric(mData$city1==vTreatpl[2]) -
              ((2011-maxDistrTyear)+round(runif(1, 0, maxDistrTyear-minDistrTyear))) *as.numeric(mData$city1==vTreatpl[3]) -
              ((2011-maxDistrTyear)+round(runif(1, 0, maxDistrTyear-minDistrTyear))) *as.numeric(mData$city1==vTreatpl[4]) -
              ((2011-maxDistrTyear)+round(runif(1, 0, maxDistrTyear-minDistrTyear))) *as.numeric(mData$city1==vTreatpl[5]) -
              ((2011-maxDistrTyear)+round(runif(1, 0, maxDistrTyear-minDistrTyear))) *as.numeric(mData$city1==vTreatpl[6]) 
  

  vyearLicpl <- 2012 *(1-as.numeric(mData$city1 %in% vTreatpl[1:5]))  +
          (vyearOpl+round((2012-vyearOpl) *runif(1, 0, 1))) *as.numeric(mData$city1==vTreatpl[1]) +
          (vyearOpl+round((2012-vyearOpl) *runif(1, 0, 1))) *as.numeric(mData$city1==vTreatpl[2]) +
          (vyearOpl+round((2012-vyearOpl) *runif(1, 0, 1))) *as.numeric(mData$city1==vTreatpl[3]) +
          vyearOpl *as.numeric(mData$city1  %in% vTreatpl[4:5]) 
  
  openingpl <- matrix(0, dim(mData)[1],1) +
              as.numeric(mData$city1 %in% vTreatpl)*as.numeric(mData$year >= vyearOpl)
  everopenNoRegpl <- openingpl - as.numeric(mData$city1  %in% vTreatpl[4:5])*as.numeric(mData$year >= vyearOpl)
  openingRegApl <- openingpl *as.numeric(mData$city1  %in% vTreatpl[4:5])
  openingRegPpl <- matrix(0, dim(mData)[1],1) +
                as.numeric(mData$city1  %in% vTreatpl[1:3] )*as.numeric(mData$year >= vyearLicpl)


  for (j in 1:dim(mOutcomes)[2]) 
  {
  
    Treatid <- "openingpl"
    vTreat <- openingpl
    treatXid <-c(Treatid, mXid)
    mFEpanel <-  data.frame(mData[,c("city1","year",Xid)],myearD[,2:dim(myearD)[2]],mOutcomes[,j],vTreat)
    fmla <- as.formula(paste("mOutcomes[,j] ~ ", paste(cbind(treatXid,myearDid), collapse= "+")))
    FEout <- plm(fmla, data=mFEpanel, index=c("city1","year"), model="within")
    mBopeningpl[b,j] <- FEout$coefficients["openingpl"]
    
    Treatid <- c("everopenNoRegpl","openingRegPpl","openingRegApl")
    vTreat <- cbind(everopenNoRegpl,openingRegPpl,openingRegApl)
    treatXid <-c(Treatid, mXid)
    mFEpanel <-  data.frame(mData[,c("city1","year",Xid)],myearD[,2:dim(myearD)[2]],mOutcomes[,j],vTreat)
    fmla <- as.formula(paste("mOutcomes[,j] ~ ", paste(cbind(treatXid,myearDid), collapse= "+")))
    FEout <- plm(fmla, data=mFEpanel, index=c("city1","year"), model="within")
    mBeveropenNoRegpl[b,j] <- FEout$coefficients["everopenNoRegpl"]
    mBopeningRegApl[b,j] <- FEout$coefficients["openingRegPpl"]
    mBopeningRegPpl[b,j] <- FEout$coefficients["openingRegApl"]
    
  }
  print("Remaining placebo estimates")
  print(B-b)
}

vPvalopening <- matrix(0,1, dim(mOutcomes)[2])
vPvaleveropenNoReg <- matrix(0,1, dim(mOutcomes)[2])
vPvalopeningRegA <- matrix(0,1, dim(mOutcomes)[2])
vPvalopeningRegP <- matrix(0,1, dim(mOutcomes)[2])


for (j in 1:dim(mOutcomes)[2]) 
{
 
vPvalopening[j] <- (1/(B+1))*( as.numeric(vBopening[j] >= 0)*(sum(as.numeric(vBopening[j] < mBopeningpl[,j])) ) +
               as.numeric(vBopening[j] < 0)*(sum(as.numeric(vBopening[j] > mBopeningpl[,j])) )  )

vPvaleveropenNoReg[j] <- (1/(B+1))*( as.numeric(vBeveropenNoReg[j] >= 0)*(sum(as.numeric(vBeveropenNoReg[j] < mBeveropenNoRegpl[,j])) ) +
                                        as.numeric(vBeveropenNoReg[j] < 0)*(sum(as.numeric(vBeveropenNoReg[j] > mBeveropenNoRegpl[,j])) ))
vPvalopeningRegA[j] <- (1/(B+1))*( as.numeric(vBopeningRegA[j] >= 0)*(sum(as.numeric(vBopeningRegA[j] < mBopeningRegApl[,j])) ) +
                                      as.numeric(vBopeningRegA[j] < 0)*(sum(as.numeric(vBopeningRegA[j] > mBopeningRegApl[,j])) ))
vPvalopeningRegP[j] <- (1/(B+1))*( as.numeric(vBopeningRegP[j] >= 0)*(sum(as.numeric(vBopeningRegP[j] < mBopeningRegPpl[,j])) ) +
                                      as.numeric(vBopeningRegP[j] < 0)*(sum(as.numeric(vBopeningRegP[j] > mBopeningRegPpl[,j])) ))

}


for (j in 1:dim(mOutcomes)[2]) 
{
  
  vPvalopening[j] <- (1/(B+1))* (sum(as.numeric(abs(vBopening[j]) < abs(mBopeningpl[,j])))) 
  
  vPvaleveropenNoReg[j] <- (1/(B+1))* (sum(as.numeric(abs(vBeveropenNoReg[j]) < abs(mBeveropenNoRegpl[,j])))) 
                                       
  vPvalopeningRegA[j] <- (1/(B+1))* (sum(as.numeric(abs(vBopeningRegA[j]) < abs(mBopeningRegApl[,j])))) 
  
  vPvalopeningRegP[j] <- (1/(B+1))* (sum(as.numeric(abs(vBopeningRegP[j]) < abs(mBopeningRegPpl[,j]))))
  
}

print("P values from placebo inference")
print("Crimes in order: lnrapesexaN,  lnsexassaultN,  lnrapeN,  lndrugsN,  lnweaponsN,  lnmaltreatN")
print("Model 1: P value opening")
vPvalopening
print("Model 2: P values everopenNoReg,  openingRegA,  openingRegP")
vPvaleveropenNoReg
print("Model 2: P values openingRegP")
vPvalopeningRegP
print("Model 2: P values openingRegA")
vPvalopeningRegA



