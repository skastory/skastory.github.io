/*
**   Dynamic Evaluation of Job Search Training 
**

**    Purpose:

**    Dynamic Treatment Effect Propensity Score Methods

**    Propensity Score Matching Methods to Estimate Dynamic Treatment Effect

**


**  Date:

**    28/06/15
**

**  Author:

**   Stephen Kastoryano, Bas van der Klaauw
*/



README.txt

File	
			
Description

--------------------------------------------------------------------------------


jobtraining.csv		

Contains the duration data needed for the analysis of
			
Dynamic Treatment Effects



MatchingLogit.do	

Do-file that prepares the sample and runs the analysis,
			
estimation settings can be changed there. Uses logit 
			
method derived in the paper.
		


MatchingLogit.ado	

Contains the DynTraining programme and MATA estimation
			
routine. Should not be changed.
					


MatchingMethods.do
	
Do-file that prepares the sample and runs the analysis,
			
estimation settings can be changed there. Uses different
			
methods from Lechner, Sianesi and Fredriksson & Johansson.

		

MatchingMethods.ado
	
Contains the DynTraining programme and MATA estimation
			
routine. Should not be changed.			




--------------------------------------------------------------------------------

GENERAL PROGRAMME SYNTAX

--------------------------------------------------------------------------------



DynTraining, duur(..) censor(..) covariates(..) s(..) dt(..) d(..) dd(..) b(..) isub(..) ismooth(..) matchmethod(..) hazmethod(..) 

Option
			

Describe

--------------------------------------------------------------------------------


duur(..)		
Specify varlist of unemployment duration and waiting duration
			
until treatment assignment e.g. duur1 duur2
					


censor(..)		
Specify varlist of binary censoring indicators for the 
			
durations specified in duur(..) e.g. censor1 censor2
					


covariates(..)		
Specify varlist of at least two covariates.



s(..)			
Left border of treatment interval [s, s+d)



dt(..)			
Evaluation length [s, s + dt] which contains treatment interval
			
and all ex-post intervals
	


d(..)			
Treatment interval length / Propensity Matching subintervals



dd(..)			
Ex-post interval length / Interval length for Exit probability



b(..)			
Number of subsamples for variance estimation e.g. 300



isub(..)		
Size of subsamples as percentage of full sample e.g. 95



ismooth(..)		
Number of days used for smoothing treatment effects e.g. 5



matchmethod(..)		
0: Propensity Score Matching, 
1: Nearest Neighbour,
			
2: Propensity Score Weighting
					


hazmethod(..)		
Only used in MatchingMethods.do. 
Technique for calculation
			
of hazard rates:
			
0: Fredriksson & Johansson, 1: Sianesi, 2: Lechner					


















