########################################################################
##  Code for: Decomposing Causal Mechanisms with Duration Outcomes  ####
##
##  Code for Dynamic Discrete Choice Model in online Appendix
##                                                                   
##  Author: Stephen Kastoryano                                        
##  Date  : 20 April 2020                                          
##
##  input:  "DGPsample.m" from DGPsim.ox is duration output from DGP dynamic
##                         discrete choice model
##          "simDGPval_3090.txt" from DGPsimVal.R are true DGP effect values
##
##  output: Causal decomposition effects of DGPsample.m 
##          + DGP MSE statistics
##     
##                                                                    
##  To obtain results from Table 3 must vary
##  code line 50 to obs <- 2500, 1000, 500 for Table 3 frame 1,2,3
##  and comment out line 135 for Table 3 frame 4
##  
########################################################################

#library("Hmisc","survival","MASS","ggplot2")
#library(Hmisc,MASS,dplyr,survival,ggplot2, lib.loc="C:\\Users\\Stephen Kastoryano\\Documents\\R\\win-library\\3.6")
library(survival, lib.loc="C:\\Users\\Stephen Kastoryano\\Documents\\R\\win-library\\3.6")
library(survminer, lib.loc="C:\\Users\\Stephen Kastoryano\\Documents\\R\\win-library\\3.6")

library(missForest,lib.loc="C:\\Users\\Stephen Kastoryano\\Documents\\R\\win-library\\3.6")
library(dplyr, lib.loc="C:\\Users\\Stephen Kastoryano\\Documents\\R\\win-library\\3.6")
library(Hmisc, lib.loc="C:\\Users\\Stephen Kastoryano\\Documents\\R\\win-library\\3.6")
library(MASS, lib.loc="C:\\Users\\Stephen Kastoryano\\Documents\\R\\win-library\\3.6")
library(ggplot2, lib.loc="C:\\Users\\Stephen Kastoryano\\Documents\\R\\win-library\\3.6")

## Load Data ##
###############
mDatS <-read.table("D:\\Dropbox\\ContDurMA\\Comp code\\DGPsample.m")     # duration output from DGP dynamic discrete choice model
colnames(mDatS, do.NULL = FALSE)
colnames(mDatS) <- c("vA", "vE", "vZtilda", "vZ", "vPrS","vdurSstar", "vOututil","vdurE","vW")

vCe <- as.numeric(mDatS["vdurE"] < max(mDatS["vdurE"]))
vCs <- as.numeric(mDatS["vdurSstar"] < mDatS["vdurE"])  # note this is correct because there are no observations with vdurSstar = vdurE <5001

mDat <- cbind(mDatS["vdurE"],vCe,mDatS["vdurSstar"],vCs,mDatS["vZ"],mDatS["vA"],mDatS["vOututil"],mDatS["vE"])
colnames(mDat, do.NULL = FALSE)
colnames(mDat) <- c("vdurE", "vCe", "vdurS", "vCs", "vZ", "vA","vOututil","vE")

set.seed(532783521)
obs <- dim(mDat)[1]

# Select fraction of observations for MSE stats calculations (note DGP values will be wrong unless using the full sample)
obs <- 2500   # Change this to 1000 or 500 for other entries of Table 3
mDataSsample <- mDat[sample(nrow(mDat), obs), ]
mDat <- mDataSsample

# For Simulation exercise impute no effect training times on Z=0 population 
mDat$vdurS <- mDat$vZ * mDat$vdurS + (1-mDat$vZ) * round(runif(obs, 1, (max(mDat$vdurS))))
mDat$vCs <- mDat$vZ * mDat$vCs + (1-mDat$vZ) * as.numeric(mDat$vdurS <= mDat$vdurE  ) 
mDat$vdurS <- mDat$vZ * mDat$vdurS + (1-mDat$vZ) * (  mDat$vdurE * as.numeric(mDat$vdurS > mDat$vdurE)  + 
                                                        mDat$vdurS * as.numeric(mDat$vdurS <= mDat$vdurE)  ) 

## Data Preparation #######################################
###########################################################

#
# Declaring the different durations and indicators:
#   vdurE= time until exit		          // the first possible day of exit is at t=2
#   vCe = exit indicator =1 if exit observed =0 if censored
#   vdurS = time until treatment,		 // the first possible day of treatment is at t=1
#   vCs = treatment indicator =1 if treatment observed =0 if censored
#   vZ  = 1 if subject to regime with anticipated treatment, = 0 with unanticipated treatment
#   vA  = observed variable 'ability' takes discrete integer values in [1,6]
#   vOututil = accepted utility at exit 
#   vE  = unobserved variable 'effort' takes discrete integer values in [1,3]
#   mX  = matrix of time 0 covariates
#
##  Warning!! first time period must be t=1 !!   ##



vdurE <- mDat$vdurE
vCe <- mDat$vCe
vdurS <- mDat$vdurS
vCs <- mDat$vCs
vCs <- as.numeric(vdurS <= vdurE )* vCs          # adjust treatment indicator if time to treatment censored before exit occurs
vdurS <- vdurS * as.numeric(vdurS <= vdurE ) + vdurE * as.numeric(vdurS > vdurE ) 

vZ <- mDat$vZ                          # Policy regime 
mX <- cbind(mDat$vA)           # Include all time t=0 covariates here 

### Generate right censoring and random censoring in sample ###
Rcens <- 250   # Right Censoring: Cuttoff after which there are no more observed exits
vCs <- as.numeric(vdurS <= vdurE )* vCs 
vdurS <- vdurS * as.numeric(vdurS <= vdurE ) + vdurE * as.numeric(vdurS > vdurE ) 

vCe <- vCe * as.numeric(vdurE <= Rcens  ) 
vdurE <- vdurE * as.numeric(vdurE <= Rcens  ) + Rcens * as.numeric(vdurE > Rcens  )
vCs <- vCs * as.numeric(vdurS <= Rcens  ) 
vdurS <- vdurS * as.numeric(vdurS <= Rcens  ) + Rcens * as.numeric(vdurS > Rcens  )
vCe <- vCe * (1- vCe * as.numeric(vdurS < vdurE ) * as.numeric(vCs == 0 ))
vdurE <- vdurE - (vdurE - vdurS) * as.numeric(vdurS < vdurE ) * as.numeric(vCs == 0 ) 

print(" Fraction of right censored observations:")
print(sum(1-vCe)/obs)

Randcens <- 0.15-(sum(vdurE == Rcens)/obs)  # Have that ~15% of the sample is censored
rbinomCens <- 1-as.numeric(sample(1:obs, obs, replace=F) <= Randcens*obs)
rdurCens <- round(runif(obs)*vdurE)
vCe <- vCe * rbinomCens
vdurE <- vdurE * rbinomCens + rdurCens * (1-rbinomCens)
vCs <- vCs * as.numeric(vdurS <= vdurE  )
vdurS <- vdurS * as.numeric(vdurS <= vdurE ) + vdurE * as.numeric(vdurS > vdurE )

print(" Fraction of censored observations:")
print(sum(1-vCe)/obs)

vTime <- seq(max(vdurE))

# Check values
sum(as.numeric(vdurS > vdurE))   ## NEEDS TO BE 0 !
sum(as.numeric(vdurS < vdurE)*as.numeric(vCs == 0))   ## NEEDS TO BE 0 !

## Duration dependence cuttoffs based on exit and treatment densities 
summary(vdurS)
plot(density(vdurS), main="Training Density",
     xlab="Time")
quantile(vdurS, probs=c(0,0.05,0.10,0.15,0.20,0.25,0.30,0.35,0.40,0.45,0.50,0.55,0.60,0.65,0.70,0.75,0.80,0.85,0.90, 0.95, 1))
summary(vdurE)
plot(density(vdurE),, main="Exit Density",
     xlab="Time")
quantile(vdurE, probs=c(0,0.05,0.10,0.15,0.20,0.25,0.30,0.35,0.40,0.45,0.50,0.55,0.60,0.65,0.70,0.75,0.80,0.85,0.90, 0.95, 1))


## Define cuttoffs of piecewise duration dependence terms based on above densities
dmax <- max(vdurE) 
d <- c(20,40, dmax-60)     # Table 3 frame 4
d <- dmax          # Table 3 frame 1,2 & 3


## Summary Statistics #############################################

## Plot Exit and Treatment survivors ##

#Need to Load these only with survival and surminer packages, other libraries have funcions which block the plots
# mDat <- cbind(vdurE,vCe,vdurS,vCs, vZ, mX)
# mDatplot <- as.data.frame(mDat)
# recid.survE <- survfit(Surv(vdurE,vCe, type=c('right')) ~vZ, data=mDatplot) 
# plot(recid.survE, lty = 1:2, mark.time=FALSE, xlab="Time", ylab="Exit Survival Probability") 
# legend((dmax-50),1, c("Z=0", "Z=1"), lty = 1:2) 
# #dev.off()
# 
# recid.survS <- survfit(Surv(time=vdurS, event = vCs, type=c('right')) ~vZ, data=mDatplot) 
# plot(recid.survS, lty = 1:2, mark.time=FALSE, xlab="Time", ylab="Treatment Survival Probability") 
# legend((dmax-120),1, c("Z=0", "Z=1"), lty = 1:2) 



## Table summary statistics covariates ##

print("Total")
c(obs,sum(vZ)/obs, sum(1-vZ)/obs, sum(vZ*vCe)/obs, sum((1-vZ)*vCe)/obs, sum(vZ*vCs)/obs, sum((1-vZ)*vCs)/obs)
print("Any post-release job: No Job")
vStat <- 1-vCs; obsS <- sum(vStat);c(obsS,sum(vZ*vStat)/obsS, sum((1-vZ)*vStat)/obsS, sum(vZ*vCe*vStat)/obsS, sum((1-vZ)*vCe*vStat)/obsS, sum(vZ*vCs*vStat)/obsS, sum((1-vZ)*vCs*vStat)/obsS)
print("Any post-release job: Job")
vStat <- vCs;obsS <- sum(vStat);c(obsS,sum(vZ*vStat)/obsS, sum((1-vZ)*vStat)/obsS, sum(vZ*vCe*vStat)/obsS, sum((1-vZ)*vCe*vStat)/obsS, sum(vZ*vCs*vStat)/obsS, sum((1-vZ)*vCs*vStat)/obsS)
# and further by covariate

## Functions ##############################################

PHlikbuildFn <- function(par,dE,dS,Cs,Z,Durdep) {    # Function: generate time varying part of exit and treatment densities
  # Initialisation of Exit and Treatment hazards
  denshE <- matrix(0,NROW(dE),2)  # col 1 for prob survival, col 2 for hazard
  denshS <- matrix(0,NROW(dE),2)
  
  if (Durdep == 0) {
    for (i in 1:NROW(d)) # For every duration dependence of dependent variable fill
    {  
      denshS[,1] <- denshS[,1] + d[i] * exp(par[i] + Z*par[NROW(d)+i]) * as.numeric(dS > d[i]) +
        exp(par[i] + Z*par[NROW(d)+i]) * dS * as.numeric(dS > 0) * as.numeric(dS <= d[i])
      
      denshS[,2] <- denshS[,2] + exp(par[i] + Z*par[NROW(d)+i]) * as.numeric(dS > 0) * as.numeric(dS <= d[i])
      
      denshE[,1] <- denshE[,1] +
        as.numeric(dE > d[i]) *
        (d[i] * exp(par[2*NROW(d)+i] + Z*par[3*NROW(d)+i]) * as.numeric(dS > d[i]) +
           d[i] * exp(par[2*NROW(d)+i] + Z*par[3*NROW(d)+i]) * exp(par[4*NROW(d)+i] + Z*par[5*NROW(d)+i]) * as.numeric(dS <= 0) +
           exp(par[2*NROW(d)+i] + Z*par[3*NROW(d)+i]) * (dS-1  + exp(par[4*NROW(d)+i] + Z*par[5*NROW(d)+i]) * (d[i]-(dS-1))) * 
           as.numeric(dS > 0) * as.numeric(dS <= d[i])) +
        as.numeric(dE > 0) * as.numeric(dE <= d[i]) * 
        (exp(par[2*NROW(d)+i] + Z*par[3*NROW(d)+i]) * 
           (dS-1 +(1-Cs)*as.numeric(dE == dS) + exp(par[4*NROW(d)+i] + Z*par[5*NROW(d)+i]) * (dE - (dS-1 +(1-Cs)*as.numeric(dE == dS)))) * as.numeric(dS > 0) +
           exp(par[2*NROW(d)+i] + Z*par[3*NROW(d)+i]) * exp(par[4*NROW(d)+i] + Z*par[5*NROW(d)+i]) * dE * as.numeric(dS <= 0))  
      
      denshE[,2] <- denshE[,2] + exp(par[2*NROW(d)+i] + Z*par[3*NROW(d)+i]) * as.numeric(dE > 0) * as.numeric(dE <= d[i]) * as.numeric(dS == dE)*(1-Cs) + 
        exp(par[2*NROW(d)+i ]+ Z*par[3*NROW(d)+i]) * exp(par[4*NROW(d)+i] + Z*par[5*NROW(d)+i]) *
        as.numeric(dE > 0) * as.numeric(dE <= d[i]) * (as.numeric(dS < dE) + as.numeric(dS == dE)*Cs)
      
      dE <- dE - d[i]
      dS <- dS - d[i]
    }
  }
  else {
    parZ1s  <- par[(NROW(d)+1)]
    parZ10e <- par[(2*NROW(d)+2)]
    parZ01e <- par[(2*NROW(d)+3)]
    parZ11e <- par[(2*NROW(d)+4)]
    
    # For every duration dependence of dependent variable fill
    for (i in 1:NROW(d)) 
    {  
      denshS[,1] <- denshS[,1] + d[i] * exp(par[i] + Z*parZ1s) * as.numeric(dS > d[i]) +       
        exp(par[i] + Z*parZ1s) * dS * as.numeric(dS > 0) * as.numeric(dS <= d[i])
      
      denshS[,2] <- denshS[,2] + exp(par[i] + Z*parZ1s) * as.numeric(dS > 0) * as.numeric(dS <= d[i])  
      
      denshE[,1] <- denshE[,1] +
        as.numeric(dE > d[i]) *
        (d[i] * exp(par[NROW(d)+1+i] + Z*parZ10e) * as.numeric(dS > d[i]) +
           d[i] * exp(par[NROW(d)+1+i] + Z*parZ10e) * exp(parZ01e + Z*parZ11e) * as.numeric(dS <= 0) +
           exp(par[NROW(d)+1+i] + Z*parZ10e) * (dS-1  + exp(parZ01e + Z*parZ11e) * (d[i]-(dS-1))) * 
           as.numeric(dS > 0) * as.numeric(dS <= d[i])) +
        as.numeric(dE > 0) * as.numeric(dE <= d[i]) * 
        (exp(par[NROW(d)+1+i] + Z*parZ10e) * 
           (dS-1 +(1-Cs)*as.numeric(dE == dS) + exp(parZ01e + Z*parZ11e) * (dE - (dS-1 +(1-Cs)*as.numeric(dE == dS)))) * as.numeric(dS > 0) +
           exp(par[2*NROW(d)+i] + Z*parZ10e) * exp(parZ01e + Z*parZ11e) * dE * as.numeric(dS <= 0))  
      
      denshE[,2] <- denshE[,2] + exp(par[NROW(d)+1+i] + Z*parZ10e) * as.numeric(dE > 0) * as.numeric(dE <= d[i]) * as.numeric(dS == dE)*(1-Cs) + 
        exp(par[NROW(d)+1+i]+ Z*parZ10e) * exp(parZ01e + Z*parZ11e) *
        as.numeric(dE > 0) * as.numeric(dE <= d[i]) * (as.numeric(dS < dE) + as.numeric(dS == dE)*Cs)
      
      dE <- dE - d[i]
      dS <- dS - d[i]
    }
  }
  
  return( cbind(denshE,denshS) )
}  # Function: generate time varying part of exit and treatment densities

CovarEffFn <- function(par,Durdep) {  # Function: Construct covariate effects on hazard
  if (Durdep == 0) { 
    mxb <- cbind(mX%*%par[(6*NROW(d)+1):(6*NROW(d)+NCOL(mX))],mX%*%par[(6*NROW(d)+NCOL(mX)+1):(6*NROW(d)+2*NCOL(mX))])
  }
  else {
    mxb <- cbind(mX%*%par[(2*NROW(d)+5):(2*NROW(d)+4+NCOL(mX))], mX%*%par[(2*NROW(d)+4+NCOL(mX)+1):(2*NROW(d)+4+2*NCOL(mX))])
  }
  return ( mxb) 
}  # Function: Construct covariate effects on hazard

PHloglikFn <- function(par) {            # Function: generate loglikelihood function
  
  # Duration until exit, duration until training
  xb <-  CovarEffFn(par,Durdep)
  xbS <- exp(xb[,1])              # Matrix of Explanatory variables affecting treatment
  xbE <- exp(xb[,2])	  # Matrix of Explanatory variables affecting exit  
  
  densh <- PHlikbuildFn(par,vdurE,vdurS,vCs,vZ,Durdep)
  denshE <- densh[,1:2]
  denshS <- densh[,3:4]
  
  
  ## Generating likelihood fnuction to be minimized ##
  lik = (xbE * denshE[,2])^vCe * exp(- xbE * denshE[,1]) * (xbS * denshS[,2])^vCs * exp(- xbS * denshS[,1])
  logl <- log(lik)

  return(logl)
}  # Function: generate loglikelihood function

PHlikFn <- function(par) {            # Function: loglikelihood function to be minimized
  logl <- PHloglikFn(par)
  #print("PARAMETER");print(par)
  
  loglik <- -mean(logl)
}  # Function: loglikelihood function to be minimized

derivPHlikFn	<- function(par) {  	 # Function: estimate score matrix for Delta method
  
  scorePH <- matrix(0,obs,NROW(par))
  for (j in 1:NROW(par)) 
  { 
    d0 <- max(c(abs(0.0005*par[j]),0.0005))		# increment in dx of dloglik(x)/dx
    p <- par
    p[j] <- p[j] + d0
    z1 <- PHloglikFn(p)
    p <- par
    p[j] <- p[j] - d0
    z2 <- PHloglikFn(p)
    scorePH[,j] <- ((z1-z2)/(2*d0))
  }
  
  return(scorePH)  # returns obs. x nbr. parameters score matrix
}  # Function: estimate score matrix for Delta method

LikparamFn <- function(CovLik,Durdep) {   # Function: Estimate parameters of hazard model
  
  if (Durdep == 0) { 
    print("## Hazard model parameter estimation with piecewise constant duration dependence ################################")
    print("# par[1:NROW(d)] duration dependence for treatment hazard under Z=0")
    print("# par[(NROW(d)+1):(2*NROW(d))] duration dependence for treatment hazard under Z=1")
    print("# par[(2*NROW(d)+1):(3*NROW(d))] duration dependence for exit hazard under Z=0 and vdurS>vdurE (no treatment)")
    print("# par[(3*NROW(d)+1):(4*NROW(d))] duration dependence for exit hazard under Z=1 and vdurS>vdurE (no treatment)")
    print("# par[(4*NROW(d)+1):(5*NROW(d))] duration dependence for exit hazard under Z=0 and vdurS<=vdurE (treatment)")
    print("# par[(5*NROW(d)+1):(6*NROW(d))] duration dependence for exit hazard under Z=1 and vdurS<=vdurE (treatment)")
    print("# par[(6*NROW(d)+1):(6*NROW(d)+NCOL(mX))] covariate effects on treatment hazard")
    print("# par[(6*NROW(d)+NCOL(mX)+1):(6*NROW(d)+2*NCOL(mX))] covariate effects on exit hazard")
    print("#################################################################################################################")
    
    par <- matrix(0,6*NROW(d)+2*NCOL(mX),1)
  }
  else {
    print("## Proportional Hazard model parameter estimation with proportional effect of each randomization on duration dependence ########")
    print("# par[1:NROW(d)] duration dependence for treatment hazard under Z=0")
    print("# par[(NROW(d)+1)] proportional effect of Z=1 on treatment duration dependence")
    print("# par[(NROW(d)+2):(2*NROW(d)+1)] duration dependence for exit hazard under Z=0 and vdurS>vdurE (no treatment)")
    print("# par[(2*NROW(d)+2)] proportional effect of Z=1 and vdurS>vdurE on exit duration dependence (no treatment)")
    print("# par[(2*NROW(d)+3)] proportional effect of Z=0 and vdurS<=vdurE on exit duration dependence (treatment)")
    print("# par[(2*NROW(d)+4)] proportional effect of Z=1 and vdurS<=vdurE on exit duration dependence (treatment)")
    print("# par[(2*NROW(d)+5):(2*NROW(d)+4+NCOL(mX))] covariate effects on treatment hazard")
    print("# par[(2*NROW(d)+4+NCOL(mX)+1):(2*NROW(d)+4+2*NCOL(mX))] covariate effects on exit hazard")
    print("################################################################################################################################")
    
    par <- matrix(0,(2*NROW(d)+4+2*NCOL(mX)),1)
  }
  
  PHestim <- optim(par,PHlikFn,method = "BFGS", hessian = TRUE)
  par <- PHestim$par
  
  if (CovLik == 0) {        # Variance- Covariance Matrix
    scorePH <- derivPHlikFn(par)
    covPH <- solve(t(scorePH)%*%scorePH) }       # This version may not be possible if matrix to be inverted is singular
  else { 
    Hess <- PHestim$hessian
    covPH <- Hess  }
  sdev <- sqrt(diag(covPH))    # Standard Errors of parameters
  
  # Calculate p-values
  iNull <- 0   # H_0=0 is null hypothesis
  tTest <- (abs(par-iNull))/sdev   # t-test	conditional probability	 	 
  PvalT <- 2*(1-pt(tTest,obs-NROW(par)))
  
  
  print("Output of Log-likelihood Estimation")
  print(c("parameter","stand. dev.", "p-values"))
  print(cbind(par,sdev,PvalT))
  
  return( cbind(par,sdev,covPH) )  # Output is nbr. parameters x 3 matrix of parameter, standard deviation and P-values
}  # Function: Estimate parameters of hazard model

EffectprepFn <- function(par, Durdep, s, t, mSurEz0, indSurZ) { # Function: Generates counterfactual treatment times and unweighted estimates
  
  
  # Duration until exit, duration until training 
  xb <-  CovarEffFn(par,Durdep)
  xbS <- exp(xb[,1])              # Matrix of Explanatory variables affecting treatment
  xbE <- exp(xb[,2])	  # Matrix of Explanatory variables affecting exit 
  
  s1 <- matrix(s,obs,1)       # treatment time under Z=1
  t1 <- matrix(t,obs,1)      # exit time under Z=1  
  
  Z <- matrix(1,obs,1)   ## Obtain survivor functions at t=s when Z=1 
  SurEz1s0 <- exp(- xbE * PHlikbuildFn(par,s1,s1,matrix(0,obs,1),Z,Durdep)[,1])      # Z=1 non-treat counterfactual Exit survivor function
  mSurEz1s0 <- matrix(SurEz1s0,obs,ncol(mSurEz0))                   
  
  
  ## Define counterfactual treatment times under Z=0 for treated at s under Z=1
  
  checkSur <- as.numeric(as.vector(t(mSurEz1s0)) >= as.vector(t(mSurEz0)))  
  if (indSurZ==1)
  { s0 <- rowSums(t(matrix(checkSur,ncol(mSurEz0),obs))) }
  else
  { s0 <- rowSums(t(matrix(-(checkSur-1),ncol(mSurEz0),obs))) }
  
  if (s==1)
  { s0 <- s1}
  else
  {s0 <- s0 + as.numeric(s0>1)*rbinom(obs, 1, 0.5) + as.numeric(s0==0) }    # treatment time under Z=0 ; as.numeric(s0>0)*sample(c(0,1),1) to remove bias from discrete nature of time variable
  
  t0 <- t1+(s0-s1)                # exit time under Z=0
  #print(cbind(s0,s1))
  
  ## Ex-Ante Effect
  Z <- matrix(0,obs,1)  ## Obtain survivors at all t when Z=0
  SurEz0s0 <- exp(- xbE * PHlikbuildFn(par,s1,s1,matrix(0,obs,1),Z,Durdep)[,1])      # Z=0 non-treat counterfactual survivor function
  ExAnte <- (SurEz0s0-SurEz1s0)
  
  ## Ex-post Baseline Effect
  Z <- matrix(0,obs,1)
  SurEz0t0 <- exp(- xbE * PHlikbuildFn(par,t0,t0,matrix(0,obs,1),Z,Durdep)[,1])
  SurEz0t1 <- exp(- xbE * PHlikbuildFn(par,t0,s0,matrix(1,obs,1),Z,Durdep)[,1])
  bExPost <- (SurEz0t0-SurEz0t1)
  
  SurEz0t0b <- exp(- xbE * PHlikbuildFn(par,t1,t1,matrix(0,obs,1),Z,Durdep)[,1])
  ## Ex-post Interaction Effect
  Z <- matrix(1,obs,1)
  SurEz1t1 <- exp(- xbE * PHlikbuildFn(par,t1,s1,matrix(1,obs,1),Z,Durdep)[,1])
  
  SurEz1t0 <- exp(- xbE * PHlikbuildFn(par,t1,t1,matrix(0,obs,1),Z,Durdep)[,1])
  #iExPost <- (SurEz1t0-SurEz1t1)  # THIS IS WRONG!!!!
  iExPost <- (SurEz0t1-SurEz1t1)  # THIS IS RIGHT!!!
  
  return( cbind((ExAnte+bExPost+iExPost),ExAnte,bExPost,iExPost) )  # Output is obs x 4 matrix of unweighted causal effects
} # Function: Generates counterfactual treatment times and unweighted estimates

MeaneffectFn <- function(par, Durdep, mins, dS, dT, dTmov) {  # Function: Estimate time varying and average effects over treatment time interval [mins:mins+dS]
  
  # Duration until exit, duration until training 
  xb <-  CovarEffFn(par,Durdep)
  xbS <- exp(xb[,1])              # Matrix of Explanatory variables affecting treatment
  xbE <- exp(xb[,2])	  # Matrix of Explanatory variables affecting exit 
  
  mSurEz0 <- matrix(0,obs,max(vdurE))  # matrix of probability of exit at S>=s with treatment at S>s under Z=0
  mSurEz1 <- matrix(0,obs,max(vdurE))  # matrix of probability of exit at S>=s with treatment at S>s under Z=1
  Wden <- matrix(0,obs,max(vdurE))
  WdenST <- matrix(0,obs,max(vdurE))
  mDensSh <- matrix(0,obs,2)
  mDensS <- matrix(0,obs,max(vdurE))
  
  for (tt in 1:max(vdurE)) 
  {
    ddS <- matrix(tt,obs,1)
    mSurEz0[,tt] <- exp(- xbE * PHlikbuildFn(par,ddS,ddS,matrix(0,obs,1),matrix(0,obs,1),Durdep)[,1])   
    mSurEz1[,tt] <- exp(- xbE * PHlikbuildFn(par,ddS,ddS,matrix(0,obs,1),matrix(1,obs,1),Durdep)[,1])   
    mDensSh <- PHlikbuildFn(par,ddS,ddS,matrix(1,obs,1),matrix(1,obs,1),Durdep)[,3:4]       # probability (density) of treatment at S=s under Z=1
    mDensS[,tt] <- (xbS * mDensSh[,2]) * exp(- xbS * mDensSh[,1])    # generate probability of treatment at S=s under Z=1 (numerator of weight function)
    WdenST[,tt] <- sum(mDensS[,tt]*mSurEz1[,tt])*matrix(1,obs,1)     # generate denominator of wATSThat
    Wden[,tt] <- sum(mDensS[,tt])*matrix(1,obs,1)                    # generate denominator of wATThat
  }
  
  wEff <- mDensS/Wden        # weights for effects on potentially treated wATThat
  wEffST <- mDensS/WdenST    # weights for effects on surviving treated wATSThat
  
  indSurZ <- as.numeric(sum(mSurEz1[,1]) >  sum(mSurEz0[,1]))   # Indicator for which treatment regime Z generates faster ex-ante exit. Used for efficient coding when finding s0 corrresponding to s1 in EffectprepFn(...)
  
  DeltaITT <- matrix(0,4,1)
  colnames(DeltaITT) <- c("ITT")
  if (mins == 1 )                  # Generate Intention to treat of Z when mins=1
  { 
    mtempZ <- cbind(matrix(dT,obs,1),vdurS,vCs,vZ,xbE)
    mtempZ1 <- mtempZ[(mtempZ[,4] == 1),]
    mtempZ1[,3] <- as.numeric(mtempZ1[,2] <= mtempZ1[,1] )* mtempZ1[,3] 
    mtempZ1[,2] <- mtempZ1[,2] * as.numeric(mtempZ1[,2] <= mtempZ1[,1] ) + mtempZ1[,1] * as.numeric(mtempZ1[,2] > mtempZ1[,1] ) 
    mtempZ0 <- mtempZ[(mtempZ[,4] == 0),]
    mtempZ0[,3] <- as.numeric(mtempZ0[,2] <= mtempZ0[,1] )* mtempZ0[,3] 
    mtempZ0[,2] <- mtempZ0[,2] * as.numeric(mtempZ0[,2] <= mtempZ0[,1] ) + mtempZ0[,1] * as.numeric(mtempZ0[,2] > mtempZ0[,1] ) 
    
    SurEz1 <- exp(- mtempZ1[,5:ncol(mtempZ1)] * PHlikbuildFn(par,mtempZ1[,1],mtempZ1[,2],mtempZ1[,3],mtempZ1[,4],Durdep)[,1])
    SurEz0 <- exp(- mtempZ0[,5:ncol(mtempZ0)] * PHlikbuildFn(par,mtempZ0[,1],mtempZ0[,2],mtempZ0[,3],mtempZ0[,4],Durdep)[,1])
    DeltaITT[1] <- (sum(SurEz1)/length(SurEz1)-sum(SurEz0)/length(SurEz0))
  }  
  
  mDelta <- matrix(0,4,(dS+1))    # matrix of causal effects for each s for potential treated at S=s
  colnames(mDelta) <- paste('PotTreat at s=',mins:(mins+dS))
  mDeltaST <- matrix(0,4,(dS+1))    # matrix of causal effects for each s for surviving treated at S=s
  colnames(mDeltaST) <- paste('SurTreat at s=',mins:(mins+dS))
  
  DeltaAvg <- matrix(0,4,1)
  DeltaAvgST <- matrix(0,4,1)
  for (s in mins:(mins+dS)) 
  {
    if (dTmov==0)
    { t <- dT }
    else
    { t <- s+dT }
    
    unweightEst <- EffectprepFn(par, Durdep, s, t, mSurEz0,indSurZ) 
    mDelta[,(s-mins+1)] <- t(colSums(wEff[,s] * unweightEst)) 
    mDeltaST[,(s-mins+1)] <- t(colSums(wEffST[,s] * unweightEst))  
    
    DeltaAvg <- DeltaAvg + colSums(mDensS[,s]/sum(Wden[1,mins:(mins+dS)]) * unweightEst)
    DeltaAvgST <- DeltaAvgST + colSums(mDensS[,s]/sum(WdenST[1,mins:(mins+dS)])  * unweightEst )
    
  }
  colnames(DeltaAvg) <- c("avg. PotTreat")
  colnames(DeltaAvgST) <- c("avg. SurTreat")
  
  
  
  
  
  Effectout <- cbind(DeltaITT,DeltaAvg,DeltaAvgST,mDelta,mDeltaST)
  
  return( Effectout )  # return 4 x ((dS+1)x2+3) matrix of time varyig effects + average effects over  [mins:mins+dS] + average effects for surviving treated over  [mins:mins+dS] + intention to treat when mins==1
}

EffectFn <- function(par, Durdep, mins, dS, dT, dTmov, varP, plGr)	{ # Function: Estimate standard errors and print results
  
  mEffects <- MeaneffectFn(par, Durdep, mins, dS, dT, dTmov)
  rownames(mEffects) <- c("total (par)", "ex-ante (par)", "ex-post base. (par)","ex-post inter. (par)")
  
  #print("Computing Standard Errors: ")
  scoreEff <- array(0,dim=c(NROW(mEffects),NCOL(mEffects),NROW(par)))
  
  time1 <- 0
  time2 <- 0
  ptm <- proc.time()  # Start the clock!
  for (j in 1:NROW(par)) 
  { 
    d0 <- max(c(abs(0.005*par[j]),0.005))		# increment in dx of dloglik(x)/dx
    p <- par
    p[j] <- p[j] + d0
    z1 <- MeaneffectFn(p, Durdep, mins, dS, dT, dTmov)
    p <- par
    p[j] <- p[j] - d0
    z2 <- MeaneffectFn(p, Durdep, mins, dS, dT, dTmov)
    scoreEff[,,j] <- (z1-z2)/(2*d0)
    
    time1 <- time1+1 ; timeN <-  (proc.time() - ptm);time2 <- (time2*(time1-1) + timeN[3])/time1    # Stop the clock
    ptm <- proc.time()  # Start the clock
    print("Approximate minutes remaining =");print((NROW(par)-j)*(time2/60))
  }
  
  
  mEffse <- matrix(0,NROW(mEffects),NCOL(mEffects))
  mEffpval <- matrix(0,NROW(mEffects),NCOL(mEffects))
  for (k in 1:NCOL(mEffects)) 
  {
    
    
    scoreEff[,k,]%*%varP%*%t(scoreEff[,k,])
    
    varE <- scoreEff[,k,]%*%varP%*%t(scoreEff[,k,])
    mEffse[,k] <- sqrt(diag(varE))
    mEffpval[,k] <- 2*(1-pt(abs(mEffects[,k])/mEffse[,k],obs-NROW(par)))  # Calculate p-values with null hypothesis =0
    
  }
  
  
  rownames(mEffse) <- c("total (se )", "ex-ante (se )", "ex-post base. (se )","ex-post inter. (se )")
  colnames(mEffse) <- colnames(mEffects)
  rownames(mEffpval) <- c("total (pV)", "ex-ante (Pv)", "ex-post base. (Pv)","ex-post inter. (Pv)")
  colnames(mEffpval) <- colnames(mEffects)
  
  if (plGr==1)
  {
    graphEffectsFn(mins,dS, dT,mEffects,mEffse) 
  }

  mEffprint <- rbind(mEffects[1,],mEffse[1,],mEffpval[1,],mEffects[2,],mEffse[2,],mEffpval[2,],
                     mEffects[3,],mEffse[3,],mEffpval[3,],mEffects[4,],mEffse[4,],mEffpval[4,])
  rownames(mEffprint) <- c("total", "    (se)","  [P-val]", "ex-ante", "    (se)","  [P-val]",
                           "ex-post base.", "    (se)","  [P-val]","ex-post inter.", "    (se)","  [P-val]")
  print("---------------------------------------------------------------------------------------------------------------------")
  print(c("mins=",mins, "mins+dS=", (mins+dS),"dT=",dT, "dTmov=",dTmov))
  print("ITT effect of policy regime Z = ");print(cbind(mEffprint[1:3,1]))
  print("Avg. Effect on Potentially Treated over support of s = ");print(cbind(mEffprint[,2]))
  print("Avg. Effect on Surviving Treated over support of s = ");print(cbind(mEffprint[,3]))
  print("Effect on Potentially Treated at each s = "); print(mEffprint[,4:(dS+4)])
  print("Effect on Surviving Treated at each s = "); print(mEffprint[,(dS+5):(dS*2+5)])
  print("---------------------------------------------------------------------------------------------------------------------")
  
  simDGPval <- read.table("D:\\Dropbox\\ContDurMA\\Comp code\\simDGPval_3090.txt")
  DGPvalSTavg <- simDGPval[,NCOL(simDGPval)]
  
  mMSEstats <- cbind(mEffects[,3], (mEffects[,3]-DGPvalSTavg),
    rbind(mEffprint[2,3]^2,mEffprint[5,3]^2,mEffprint[8,3]^2,mEffprint[11,3]^2 ),
    rbind(mEffprint[2,3]^2,mEffprint[5,3]^2,mEffprint[8,3]^2,mEffprint[11,3]^2 )+ (mEffects[,3]-DGPvalSTavg)^2)
  rownames(mMSEstats) <- c("total", "ex-ante", "ex-post base.","ex-post inter.")
  colnames(mMSEstats) <- c("Estimates", "Bias", "Variance", "MSE") 
  print("---------------------------------------------------------------------------------------------------------------------")
  print("Mean squared Error Statistics Table")
  print( mMSEstats )
  print("---------------------------------------------------------------------------------------------------------------------")
  
  return( rbind(mEffects,mEffse,mEffpval) )
}

graphEffectsFn <- function(mins,dS, dT,mEffects,mEffse) 	{
  
  #cbind(DeltaITT,DeltaAvg,DeltaAvgST,mDelta,mDeltaST)
  save(mEffects,file="D:\\Dropbox\\ContDurMA\\Comp code\\mEffects.Rda")
  save(mEffse,file="D:\\Dropbox\\ContDurMA\\Comp code\\mEffse.Rda")
  
  load("D:\\Dropbox\\ContDurMA\\Comp code\\mEffects.Rda") 
  load("D:\\Dropbox\\ContDurMA\\Comp code\\mEffse.Rda") 
  
  simDGPval <- read.table("D:\\Dropbox\\ContDurMA\\Comp code\\simDGPval_3090.txt") 
  
  # generate 95% conf. bands and plot effects
  mEf <- mEffects[,(NCOL(mEffects)-(dS)):NCOL(mEffects)]
  mEfse <- mEffse[,(NCOL(mEffects)-(dS)):NCOL(mEffects)]
  m95up <- mEf+ 1.96*mEfse
  m95lo <- mEf- 1.96*mEfse
  simDGP <- simDGPval[,1:(NCOL(simDGPval)-2)]
  
  
  # get the range for the x and y axis 
  vT <- seq(dS+1)+(mins-1)
  plotData1a <- as.data.frame(cbind(vT, mEf[2,1:(1+dS)],m95lo[2,1:(1+dS)],m95up[2,1:(1+dS)]))
  plotData1b <- as.data.frame(cbind(vT,t(simDGP[2,])))
  print(ggplot(data=plotData1a, aes(x=vT, y=plotData1a[,2], ymin=plotData1a[,3], ymax=plotData1a[,4])) + 
    geom_line() + 
    geom_ribbon(alpha=0.2) + 
    geom_hline(yintercept=0, linetype="dashed", color = "red", size=1) +
    geom_line(data = plotData1b, aes(x = vT, y = plotData1b[,2]),  color = "blue", size=1) +
    theme_bw() +
    xlab("Time at treatment") + 
    ylab("Ex-Ante Effect"))
  
  plotData2a <- as.data.frame(cbind(vT, mEf[3,1:(1+dS)],m95lo[3,1:(1+dS)],m95up[3,1:(1+dS)]))
  plotData2b <- as.data.frame(cbind(vT,t(simDGP[3,])))
  print(ggplot(data=plotData2a, aes(x=vT, y=plotData2a[,2], ymin=plotData2a[,3], ymax=plotData2a[,4]))  + 
    geom_line() + 
    geom_ribbon(alpha=0.2) + 
    geom_hline(yintercept=0, linetype="dashed", color = "red", size=1) +
    geom_line(data = plotData2b, aes(x = vT, y = plotData2b[,2]), color = "blue", size=1) +
    theme_bw() +
    xlab("Time at treatment") + 
    ylab("Ex-Post Baseline Effect"))
  
  plotData3a <- as.data.frame(cbind(vT, mEf[4,1:(1+dS)],m95lo[4,1:(1+dS)],m95up[4,1:(1+dS)]))
  plotData3b <- as.data.frame(cbind(vT,t(simDGP[4,])))
  print(ggplot(data=plotData3a, aes(x=vT, y=plotData3a[,2], ymin=plotData3a[,3], ymax=plotData3a[,4])) + 
    geom_line() + 
    geom_ribbon(alpha=0.2) +
    geom_hline(yintercept=0, linetype="dashed", color = "red", size=1) +
    geom_line(data = plotData3b, aes(x = vT, y = plotData3b[,2]), color = "blue", size=1) +
    theme_bw() +
    xlab("Time at treatment") + 
    ylab("Ex-Post Interaction Effect") +
    theme(legend.position="top"))


  #
  # plot(vT ,mEf[2,1:(1+dS)],type="l", main="Ex-Ante Effects",
  #      xlab="Time", ylab="Effect on Probability of Exit",
  #      xlim=c(mins-1, mins+(dT+2)), ylim=c(min(rbind(mEf[2,],m95up[2,],m95lo[2,])), max(rbind(mEf[2,],m95up[2,],m95lo[2,]))))
  # lines(vT ,m95up[2,1:(1+dS)],lty = 3)
  # lines(vT ,m95lo[2,1:(1+dS)],lty = 3)
  #
  # plot(vT ,mEf[3,1:(1+dS)],type="l", main="Ex-Post Baseline Effects",
  #      xlab="Time", ylab="Effect on Probability of Exit",
  #      xlim=c(mins-1, mins+(dT+2)), ylim=c(min(rbind(mEf[3,],m95up[3,],m95lo[3,])), max(rbind(mEf[3,],m95up[3,],m95lo[3,]))))
  # lines(vT ,m95up[3,1:(1+dS)],lty = 3)
  # lines(vT ,m95lo[3,1:(1+dS)],lty = 3)
  #
  # plot(vT ,mEf[4,1:(1+dS)],type="l", main="Ex-Post Interaction Effects",
  #      xlab="Time", ylab="Effect on Probability of Exit",
  #      xlim=c(mins-1, mins+(dT+2)), ylim=c(min(rbind(mEf[4,],m95up[4,],m95lo[4,])), max(rbind(mEf[4,],m95up[4,],m95lo[4,]))))
  # lines(vT ,m95up[4,1:(1+dS)],lty = 3)
  # lines(vT ,m95lo[4,1:(1+dS)],lty = 3)
  #
   plot(vT ,mEf[2,1:(1+dS)],type="l",
        xlab="Time", ylab="Effect on Probability of Exit",
        xlim=c(mins-1, mins+(dS+2)), ylim=c(min(rbind(mEf[2:4,],m95up[2:4,],m95lo[2:4,])), max(rbind(mEf[2:4,],m95up[2:4,],m95lo[2:4,]))))
   lines(vT ,m95up[2,1:(1+dS)],lty = 3)
   lines(vT ,m95lo[2,1:(1+dS)],lty = 3)
   lines(vT ,mEf[3,1:(1+dS)],lty = 5)
   lines(vT ,m95up[3,1:(1+dS)],lty = 3)
   lines(vT ,m95lo[3,1:(1+dS)],lty = 3)
   lines(vT ,mEf[4,1:(1+dS)],lty = 6)
   lines(vT ,m95up[4,1:(1+dS)],lty = 3)
   lines(vT ,m95lo[4,1:(1+dS)],lty = 3)
  
  return(1)
}




## Results Output #############################################

# CovLik  -> Covariance of parameters from likelihood estimation: 0 for calculation using outer product score, 1 using hessian.
# Durdep  -> Specification of duration dependence term: 0 piecewise constant for each randomization (policy regime
#            and treatments); 1 common piecewise constant duration dependence with constant 
#            proportional effects for each randomization  (policy regime and treatments)       
# mins    -> Initial period for multiple treatment estimation
# dS      -> Treatment interval over which Mean effect calculated
# dT      -> To define post treatment evaluation Length (along with dTmov)
# dTmov   -> Post treatment evaluation length: 1 if fixed at a constant dT; 0 if reducing with s, ie dT-s, for increasing s (end
#                                              evaluation period FIXED so must have mins+dS <= dT)
# plGr    -> Produce plots of effects: 0 no plot of effects, 1 plot of time varying effects

CovLik <- 0; Durdep <- 0;  

Likpar <- LikparamFn(CovLik,Durdep)
#save(Likpar,file="D:\\Dropbox\\ContDurMA\\Comp code\\Likpar.Rda")

#load("D:\\Dropbox\\ContDurMA\\Comp code\\Likpar.Rda") 
par <- Likpar[,1:2] 
covPH <- Likpar[,3:NCOL(Likpar)]


mins <- 1; dS <- 29; dT <- 90; dTmov <- 0; plGr <- 1; 
mOutput <- EffectFn(par,Durdep, mins, dS, dT, dTmov, covPH, plGr)




