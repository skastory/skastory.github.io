########################################################################
##  Code for: Decomposing Causal Mechanisms with Duration Outcomes  ####
##
##  Code for Dynamic Discrete Choice Model in online Appendix
##                                                                    
##  Author: Stephen Kastoryano                                        
##  Date  : 20 April 2020                                          
##
##  input:  "DGPz0.m","DGPz0c.m","DGPz1.m","DGPz1c.m"  DGP potential
##           outcomes from DGPsim.ox 
##
##  output: "simDGPval_3090.txt" for durMAdgp.R
##                                                                    
########################################################################



#library("Hmisc","survival","MASS","ggplot2")
#library(Hmisc,MASS,dplyr,survival,ggplot2, lib.loc="C:\\Users\\Stephen Kastoryano\\Documents\\R\\win-library\\3.6")
library(survival, lib.loc="C:\\Users\\Stephen Kastoryano\\Documents\\R\\win-library\\3.6")
library(survminer, lib.loc="C:\\Users\\Stephen Kastoryano\\Documents\\R\\win-library\\3.6")
library(dplyr, lib.loc="C:\\Users\\Stephen Kastoryano\\Documents\\R\\win-library\\3.6")

mDatZ0S0 <-read.table("D:\\Dropbox\\ContDurMA\\Comp code\\DGPz0.m") # For all agents Z=0 and do not enter treatment
mDatZ0S0 <- cbind(mDatZ0S0[,6],mDatZ0S0[,8])
colnames(mDatZ0S0, do.NULL = FALSE)
colnames(mDatZ0S0) <- c("vdurSstarZ0S0", "vdurEZ0S0")

mDatZ1S0 <-read.table("D:\\Dropbox\\ContDurMA\\Comp code\\DGPz0c.m") # For all agents Z=1 but do not enter treatment
mDatZ1S0 <- cbind(mDatZ1S0[,6],mDatZ1S0[,8])
colnames(mDatZ1S0, do.NULL = FALSE)
colnames(mDatZ1S0) <- c( "vdurSstarZ1S0", "vdurEZ1S0")

mDatZ1S1 <-read.table("D:\\Dropbox\\ContDurMA\\Comp code\\DGPz1.m") # For all agents Z=1 and enter treatment
mDatZ1S1 <- cbind(mDatZ1S1[,6],mDatZ1S1[,8])
colnames(mDatZ1S1, do.NULL = FALSE)
colnames(mDatZ1S1) <- c( "vdurSstarZ1S1", "vdurEZ1S1")

mDatZ1Sc <-read.table("D:\\Dropbox\\ContDurMA\\Comp code\\DGPz1c.m") # For all agents Z=1 and enter treatment but have no effect from treatment (and anticipation stops)
mDatZ1Sc <- cbind(mDatZ1Sc[,6],mDatZ1Sc[,8])
colnames(mDatZ1Sc, do.NULL = FALSE)
colnames(mDatZ1Sc) <- c("vdurSstarZ1Sc", "vdurEZ1Sc")


mData <- cbind(mDatZ0S0,mDatZ1S0,mDatZ1S1,mDatZ1Sc)
colnames(mData, do.NULL = FALSE)
colnames(mData) <- c("vdurSstarZ0S0", "vdurEZ0S0","vdurSstarZ1S0", "vdurEZ1S0","vdurSstarZ1S1", "vdurEZ1S1","vdurSstarZ1Sc", "vdurEZ1Sc") 
mData


obs <- dim(mData)[1]
obs
sum(mData[,1])

DGPeffectFn <- function(mins, dS, dT, dTmov) { 
  mPTreatS1 <- matrix(0,1+dS,1)   # weight for avg. effect on potentially treated
  mPsurTreatS1 <- matrix(0,1+dS,1)   # weight for avg. effect on surviving treated
  mPexitS1 <- matrix(0,1+dS,1) 
  mExAnte <- matrix(0,1+dS,1)
  mExAnteST <- matrix(0,1+dS,1)
  mbExPostST <- matrix(0,1+dS,1)
  miExPostST <- matrix(0,1+dS,1)
  mTotalST <- matrix(0,1+dS,1)
  
  Swin <- 5  # Window for treated observations is 2*Swin+1 --> smoothes out DGP results 
  
  for (s in mins:(mins+dS))  # For weights of MSE calculations for averages
  {
    if (s<Swin)
    {
      mPsurTreatS1[(s-mins+1)] <- sum(as.numeric(mData[,4] >= s)*as.numeric(mData[,3] >= s)*as.numeric(mData[,3] <= s+Swin))
      mPTreatS1[(s-mins+1)] <- sum(as.numeric(mData[,3] >= s)*as.numeric(mData[,3] <= s+Swin))
    }
    else
    {
      mPsurTreatS1[(s-mins+1)] <- sum(as.numeric(mData[,4] >= s)*as.numeric(mData[,3] >= s-Swin)*as.numeric(mData[,3] <= s+Swin))
      mPTreatS1[(s-mins+1)] <- sum(as.numeric(mData[,3] >= s-Swin)*as.numeric(mData[,3] <= s+Swin))
    }
  }
  

  for (s in mins:(mins+dS)) 
  {
    if (dTmov==0)
    { t <- dT }
    else
    { t <- s+dT }
    
    mPexitS1[(s-mins+1)] <- sum(as.numeric(mData[,4] >= s))/obs
    
    mExAnteST[(s-mins+1)] <- (sum(as.numeric(mData[,2] >= s))- sum(as.numeric(mData[,4] >= s)))/sum(as.numeric(mData[,4] >= s))
    mbExPostST[(s-mins+1)] <-   0
    
    if (s<Swin)
    {
      miExPostST[(s-mins+1)] <- (sum(as.numeric(mData[,5] >= s)*as.numeric(mData[,5] <= s+Swin)*as.numeric(mData[,6] >= s)*as.numeric(mData[,6] <= t)) 
                                 - sum(as.numeric(mData[,5] >= s)*as.numeric(mData[,5] <= s+Swin)*as.numeric(mData[,8] >= s)*as.numeric(mData[,8] <=t)) )/
        sum(as.numeric(mData[,5] >= s-Swin)*as.numeric(mData[,5] <= s+Swin)*as.numeric(mData[,6] >= s)) 
      
    }
    else
    {
      miExPostST[(s-mins+1)] <- (sum(as.numeric(mData[,5] >= s-Swin)*as.numeric(mData[,5] <= s+Swin)*as.numeric(mData[,6] >= s)*as.numeric(mData[,6] <= t)) 
                                 - sum(as.numeric(mData[,5] >= s-Swin)*as.numeric(mData[,5] <= s+Swin)*as.numeric(mData[,8] >= s)*as.numeric(mData[,8] <= t)) )/
        sum(as.numeric(mData[,5] >= s-Swin)*as.numeric(mData[,5] <= s+Swin)*as.numeric(mData[,6] >= s)) 
      
    }
    print(cbind(sum(as.numeric(mData[,5] >= s-Swin)*as.numeric(mData[,5] <= s+Swin)*as.numeric(mData[,6] >= s)*as.numeric(mData[,6] <= t)), sum(as.numeric(mData[,5] >= s-Swin)*as.numeric(mData[,5] <= s+Swin)*as.numeric(mData[,8] >= s)*as.numeric(mData[,8] <= t)),
      sum(as.numeric(mData[,5] >= s-Swin)*as.numeric(mData[,5] <= s+Swin)*as.numeric(mData[,6] >= s)) ))
    mTotalST[(s-mins+1)] <- mExAnte[(s-mins+1)] + mbExPostST[(s-mins+1)] + miExPostST[(s-mins+1)]
  } 


  mExAnteSTavg <- sum(mPsurTreatS1*mExAnteST)/sum(mPsurTreatS1)
  mbExPostSTavg <- sum(mPsurTreatS1*mbExPostST)/sum(mPsurTreatS1)
  miExPostSTavg <- sum(mPsurTreatS1*miExPostST)/sum(mPsurTreatS1)
  mTotalSTavg <- mExAnteSTavg +mbExPostSTavg + miExPostSTavg
  
  mExAnteavg <- sum(mPTreatS1*mExAnte*mPexitS1)/sum(mPTreatS1)
  mbExPostavg <- sum(mPTreatS1*mbExPostST*mPexitS1)/sum(mPTreatS1)
  miExPostavg <- sum(mPTreatS1*miExPostST*mPexitS1)/sum(mPTreatS1)
  mTotalavg <- mExAnteavg +mbExPostavg + miExPostavg
  
  mEffST <- t(cbind(mTotalST,mExAnteST,mbExPostST,miExPostST))
  mEffavg <-   rbind(mTotalavg,mExAnteavg,mbExPostavg,miExPostavg)
  mEffSTavg <-  rbind(mTotalSTavg,mExAnteSTavg,mbExPostSTavg,miExPostSTavg)
  
  return( cbind(mEffST,mEffavg,mEffSTavg) ) 
}



mins <- 1; dS <- 29; dT <- 90; dTmov <- 0; plGr <- 1; 
mOutput <- DGPeffectFn(mins, dS, dT, dTmov)
print(mOutput)

write.table(mOutput, file="D:\\Dropbox\\ContDurMA\\Comp code\\simDGPval_3090.txt", row.names=FALSE, col.names=FALSE)


mOutputt <- mOutput[,3:(3+dS)]

vT <- seq(dS+1)+(mins-1)

plot(vT ,mOutputt[2,1:(1+dS)],type="l",
     xlab="Time", ylab="Effect on Probability of Exit")

plot(vT ,mOutputt[4,1:(1+dS)],type="l",
     xlab="Time", ylab="Effect on Probability of Exit")

plot(vT ,mOutputt[2,1:(1+dS)],type="l",
     xlab="Time", ylab="Effect on Probability of Exit")
lines(vT ,mOutputt[3,1:(1+dS)],lty = 5)
lines(vT ,mOutputt[4,1:(1+dS)],lty = 6)

