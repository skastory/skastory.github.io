########################################################################
##  Code for: Decomposing Causal Mechanisms with Duration Outcomes  ####
##
##  Data preparation and cleaning for Job Corps application
##                                                                   
##  Author: Stephen Kastoryano                                        
##  Date  : 20 April 2020                                          
##
##
##  output: DataMfinalJobArr.Rda
##     
##                                                                    
##  
########################################################################


library(sas7bdat, lib.loc="C:\\Users\\Stephen Kastoryano\\Documents\\R\\win-library\\3.6")
library(dplyr, lib.loc="C:\\Users\\Stephen Kastoryano\\Documents\\R\\win-library\\3.6")
library(survival, lib.loc="C:\\Users\\Stephen Kastoryano\\Documents\\R\\win-library\\3.6")
library(survminer, lib.loc="C:\\Users\\Stephen Kastoryano\\Documents\\R\\win-library\\3.6")
library(foreign, lib.loc="C:\\Users\\Stephen Kastoryano\\Documents\\R\\win-library\\3.6")




# NOTE: dplyr clashes with MASS::select, plyr::summarise and stats::filter among other things, especially when 
#       loading packages which load one of those libraries via library (they shouldn't, but some still do) 
#       or when you load dplyr in your .Rprofile (don't!). And it can lead to pretty obscure problems, not 
#       always an error message, especially conflicts with plyr.


#######################################################################################
#######      CLEANING QUARTERLY DATA                  #################################
#######################################################################################

##  Read in the SAS data  ## 
############################
impactData <- read.sas7bdat("C:\\Users\\Stephen Kastoryano\\Dropbox\\ContDurMA\\Data\\original data\\impact.sas7bdat") 

# Build Treatment and Outcome variables

impactData1 <- select(impactData,MPRID,contains("EDTQX"),contains("EDHPWQ"),contains("INACQ"),contains("INVOCQ"),
                      contains("WORKQ"),contains("PWORKQ"),contains("HRSWQ"),contains("EARNQ"),contains("ANYPQ"),
                      contains("EVARRQ"),contains("EVARRC"),contains("EVCNVC"),A_ANYPEV,MU_ARR,SERCONV,EVERJAIL,MOSJAIL1)



###  Generate QUARTERLY duration until Arrested with and without criminal conviction  ###
#########################################################################################

# Note: The MU_ARR data which supposedly represents months to arrest is nonsense, it is constructed from constructed quarterly variables, not from the raw data

loopframe <- as.data.frame(select(impactData1,contains("EVARRQ"), contains("EVARRC"), contains("EVCNVC"), contains("EVERJAIL"), MPRID))  # Select variables indicating quarterly arrest status
loopframe <- replace(loopframe , is.na(loopframe), NA )
EvCha <- rowSums(select(loopframe,contains("EVARRC")),na.rm = TRUE) # construct binary for ever charged
EvCha <- replace(EvCha, as.logical(EvCha > 1),1)
EvCon <- rowSums(select(loopframe,contains("EVCNVC")),na.rm = TRUE) # construct binary for ever convicted
EvCon <- replace(EvCon, as.logical(EvCon > 1),1)
dim(loopframe)
summary(loopframe)


durArr <- replace(loopframe$EVARRQ1, is.na(loopframe$EVARRQ1),0)
durArr <- replace(durArr, as.logical(rowSums(1*is.na(loopframe[,1:16])) == 16), NA) # force NA on rows where always NA observed
summary(durArr)
durCon <- durArr*EvCon

durArrC <- durArr            # Vector indicator of Arrest status in 1st quarter
durConC <- durArrC*EvCon                              # Vector indicator of Convicted for arrest status in 1st quarter

durArrl <- durArr
durArrCl <- durArrC
durConl <- durCon
durConCl <- durConC

Nperiods <- 16    # Number of time periods 
for (j in 2:Nperiods) 
{ 
  durArrCNA <- replace(loopframe[,j], is.na(loopframe[,j]),0)
  durArrC <- durArrCl + as.numeric(durArrCNA == 1)*as.numeric(durArrCl == 0)
  durArr <- durArrl + j*as.numeric(durArrCNA == 1)*as.numeric(durArrl == 0) 
  
  durArrl <- durArr
  durArrCl <- durArrC
  
  durConC <- durConCl + as.numeric(durArrCNA*EvCon == 1)*as.numeric(durConCl == 0)
  durCon <- durConl + j*as.numeric(durArrCNA*EvCon == 1)*as.numeric(durConl == 0)
  
  durConl <- durCon
  durConCl <- durConC
}
durArr <- replace(durArr, as.logical(as.numeric(durArr==0)*as.numeric(is.na(loopframe$EVARRQ16))), Nperiods)  #Some observations have all 0s until quarter 16 where they are NA, so I impute 16 quarters (not 17) for these values
durCon <- replace(durCon, as.logical(as.numeric(durCon==0)*as.numeric(is.na(loopframe$EVARRQ16))), Nperiods)
durArr <- replace(durArr, as.logical(durArr==0), (Nperiods+1)) # For agents who never got arrested they survived until period after 16
durCon <- replace(durCon, as.logical(durCon==0), (Nperiods+1)) # For agents who never got arrested they survived until period after 16
loopframe <- cbind(durArr, durArrC,durCon,durConC,EvCon, loopframe)
summary(durArr)
summary(durCon)


# Duration until first arrest
durArr <- matrix(durArr, NROW(loopframe),1)
durArrC <- matrix(durArrC, NROW(loopframe),1)
durArrplot <- cbind(durArr,durArrC)
durArrplot <- durArrplot[!is.na(durArrplot[,1]),]
summary(durArrplot)
plot(density(durArrplot[,1]), main="Arrest Density", xlab="Time")
quantile(durArrplot[,1], probs=c(0,0.05,0.10,0.15,0.20,0.25,0.30,0.35,0.40,0.45,0.50,0.55,0.60,0.65,0.70,0.75,0.80,0.85,0.90, 0.95, 1))

recid.surv <- survfit(Surv(time=durArrplot[,1], event = durArrplot[,2], type=c('right')) ~1, conf.type="none") 
plot(recid.surv, lty = 1:2, mark.time=FALSE, xlab="Time", ylab="Arrest Survival Probability") 



# Duration until first arrest if convicted
sum(durArrC-EvCha)  # Note Number of people arrested but not charged only 18, so we being arrested almost always results in a charge
sum(durArrC)
sum(EvCon)
sum(durArrC-EvCon)  #Number of people arrested but not convicted
sum(durArrC-durConC,na.rm = TRUE)  #Number of people arrested but not convicted

durCon <- matrix(durCon, NROW(loopframe),1)
durConC <- matrix(durConC, NROW(loopframe),1)
durConplot <- cbind(durCon,durConC)
durConplot <- durConplot[!is.na(durConplot[,1]),]
summary(durConplot)
plot(density(durConplot[,1]), main="Arrest and Convicted Density", xlab="Time")
quantile(durConplot[,1], probs=c(0,0.05,0.10,0.15,0.20,0.25,0.30,0.35,0.40,0.45,0.50,0.55,0.60,0.65,0.70,0.75,0.80,0.85,0.90, 0.95, 1))

recid.surv <- survfit(Surv(time=durConplot[,1], event = durConplot[,2], type=c('right')) ~1, conf.type="none") 
plot(recid.surv, lty = 1:2, mark.time=FALSE, xlab="Time", ylab="Arrest and Convicted Survival Probability") 




###  Generate QUARTERLY duration until finding a job  ###
#########################################################

# Check summary statistics of percentage weeks employed per quarter to define cutoff for working
loopframe <- select(impactData1, contains("PWORKQ")) 
loopframe <- replace(loopframe , is.na(loopframe), NA )
loopframe[loopframe == 0] <- NA
denMweeks <- 16-rowSums(matrix(as.numeric(is.na(loopframe)),NROW(loopframe),NCOL(loopframe)))
checkMweeks <- (rowSums(loopframe,na.rm = TRUE)/denMweeks)
checkMweeks <- checkMweeks[!is.na(checkMweeks)]
summary(checkMweeks)
quantile(checkMweeks, probs=c(0,0.05,0.10,0.15,0.20,0.25,0.30,0.35,0.40,0.45,0.50,0.55,0.60,0.65,0.70,0.75,0.80,0.85,0.90, 0.95, 1))
plot(density(checkMweeks), main="Percentage Weeks Density")


loopframe <- as.data.frame(select(impactData1,contains("WORKQ"), contains("PWORKQ"), MPRID))  # Select variables indicating quarterly work status
loopframe[,12:16] <- round(loopframe[,12:16],digits=0)   # some values are in fractions, so convert to nearest integer 0 or 1
loopframe <- replace(loopframe , is.na(loopframe), NA )
dim(loopframe)
summary(loopframe)

PCut <- 50   # Minimum percentage of weeks worked to be considered as "working"
loopframe$WORKQ1 <- replace(loopframe$WORKQ1, as.logical(loopframe$PWORKQ1 < PCut),0)  
loopframe$WORKQ2 <- replace(loopframe$WORKQ2, as.logical(loopframe$PWORKQ2 < PCut),0)
checkNA <- loopframe[is.na(loopframe$WORKQ1),]            # For 1st quarter, for NA values: Take second quarter Job status if it is not NA and 1st quarter Job status is NA, otherwise keep as NA if both NA.
durJob <- matrix(loopframe$WORKQ1, NROW(loopframe), 1)
durJob <- replace(loopframe$WORKQ1,is.na(loopframe$WORKQ1),checkNA$WORKQ2)  # Vector of 1st quarter Job status
loopframe$WORKQ1 <- replace(loopframe$WORKQ1,is.na(loopframe$WORKQ1),0)  # Useful for the loop

durJobC <- matrix(durJob, NROW(loopframe), 1)             # Vector indicator of Job status in 1st quarter


durJobl <- durJob
durJobCl <- durJobC
Nperiods <- 16    # Number of time periods 
for (j in 2:Nperiods) 
{ 
  loopframe[,j] <- replace(loopframe[,j] , as.logical(loopframe[,(j+Nperiods)]  < PCut),0)
  durJobCNA <- replace(loopframe[,j], is.na(loopframe[,j]),0)
  durJobC <- durJobCl + as.numeric(durJobCNA == 1)*as.numeric(durJobCl == 0)*(1-as.numeric(is.na(rowSums(loopframe[,1:j]))))
  durJob <- durJobl + j*as.numeric(durJobCNA == 1)*as.numeric(durJobl == 0)*(1-as.numeric(is.na(rowSums(loopframe[,1:j])))) + 
    j*as.numeric(is.na(loopframe[,j]))*as.numeric(durJobl == 0)
  
  durJobl <- durJob
  durJobCl <- durJobC
}
durJob <- replace(durJob, as.logical(durJob==0), (Nperiods+1)) # For agents who never found a job

summary(durJob)

durJob <- matrix(durJob, NROW(loopframe),1)
durJobC <- matrix(durJobC, NROW(loopframe),1)
durJobplot <- cbind(durJob,durJobC)
durJobplot <- durJobplot[!is.na(durJobplot[,1]),]
summary(durJobplot)
plot(density(durJobplot[,1]), main="Employment Density", xlab="Time")
quantile(durJobplot[,1], probs=c(0,0.05,0.10,0.15,0.20,0.25,0.30,0.35,0.40,0.45,0.50,0.55,0.60,0.65,0.70,0.75,0.80,0.85,0.90, 0.95, 1))

recid.surv <- survfit(Surv(time=durJobplot[,1], event = durJobplot[,2], type=c('right')) ~1, conf.type="none") 
plot(recid.surv, lty = 1:2, mark.time=FALSE, xlab="Time", ylab="Job Survival Probability") 




###  Generate QUARTERLY duration until Starting education or vocational training  ###
#####################################################################################

# Check summary statistics of number of hours worked per week to define cutoff for Educ and Voc. training
loopframe <- select(impactData1, contains("EDHPWQ")) 
loopframe <- replace(loopframe , is.na(loopframe), NA )
loopframe[loopframe == 0] <- NA
denMhours <- 16-rowSums(matrix(as.numeric(is.na(loopframe)),NROW(loopframe),NCOL(loopframe)))
checkMhours <- (rowSums(loopframe,na.rm = TRUE)/denMhours)
checkMhours <- checkMhours[!is.na(checkMhours)]
summary(checkMhours)
quantile(checkMhours, probs=c(0,0.05,0.10,0.15,0.20,0.25,0.30,0.35,0.40,0.45,0.50,0.55,0.60,0.65,0.70,0.75,0.80,0.85,0.90, 0.95, 1))
plot(density(checkMhours), main="Number Hours Density")


loopframe <- select(impactData1,contains("EDTQX"), contains("EDHPWQ"), MPRID)  # Select variables indicating quarterly education or voc. training status (Educ for short)
loopframe <- cbind(loopframe[,6:16],loopframe[,1:5], loopframe[,22:32],loopframe[,17:21],loopframe[,33])
loopframe[,12:16] <- round(loopframe[,12:16],digits=0)   # some values are in fractions, so convert to nearest integer 0 or 1
loopframe <- replace(loopframe , is.na(loopframe), NA )
dim(loopframe)
summary(loopframe)

PCut <- 4   # Minimum nbr of hours in education or vocational training to be considered as "education"
loopframe$EDTQX1 <- replace(loopframe$EDTQX1, as.logical(loopframe$EDHPWQ1 < PCut),0)  
loopframe$EDTQX2 <- replace(loopframe$EDTQX2, as.logical(loopframe$EDHPWQ2 < PCut),0)
checkNA <- loopframe[is.na(loopframe$EDTQX1),]            # For 1st quarter, for NA values: Take second quarter Educ status if it is not NA and 1st quarter Educ status is NA, otherwise keep as NA if both NA.
durEdu <- matrix(loopframe$EDTQX1, NROW(loopframe), 1)
durEdu <- replace(loopframe$EDTQX1,is.na(loopframe$EDTQX1),checkNA$EDTQX2)  # Vector of 1st quarter Educ status
loopframe$EDTQX1 <- replace(loopframe$EDTQX1,is.na(loopframe$EDTQX1),0)  # Useful for the loop

durEduC <- matrix(durEdu, NROW(loopframe), 1)             # Vector indicator of Educ status in 1st quarter

durEdul <- durEdu
durEduCl <- durEduC
Nperiods <- 16    # Number of time periods 
for (j in 2:Nperiods) 
{ 
  loopframe[,j] <- replace(loopframe[,j] , as.logical(loopframe[,(j+Nperiods)]  < PCut),0)
  durEduCNA <- replace(loopframe[,j], is.na(loopframe[,j]),0)
  durEduC <- durEduCl + as.numeric(durEduCNA == 1)*as.numeric(durEduCl == 0)*(1-as.numeric(is.na(rowSums(loopframe[,1:j]))))
  durEdu <- durEdul + j*as.numeric(durEduCNA == 1)*as.numeric(durEdul == 0) *(1-as.numeric(is.na(rowSums(loopframe[,1:j])))) +
    j*as.numeric(is.na(loopframe[,j]))*as.numeric(durEdul == 0)
  
  durEdul <- durEdu
  durEduCl <- durEduC
}
durEdu <- replace(durEdu, as.logical(durEdu==0), (Nperiods+1)) # For agents who never found education 
cbind(durEdu,durEduC)
summary(durEdu)


durEdu <- matrix(durEdu, NROW(loopframe),1)
durEduC <- matrix(durEduC, NROW(loopframe),1)
durEduplot <- cbind(durEdu,durEduC)
durEduplot <- durEduplot[!is.na(durEduplot[,1]),]
summary(durEduplot)
plot(density(durEduplot[,1]), main="Education or Vocational Training Density", xlab="Time")
quantile(durEduplot[,1], probs=c(0,0.05,0.10,0.15,0.20,0.25,0.30,0.35,0.40,0.45,0.50,0.55,0.60,0.65,0.70,0.75,0.80,0.85,0.90, 0.95, 1))

recid.surv <- survfit(Surv(time=durEduplot[,1], event = durEduplot[,2], type=c('right')) ~1, conf.type="none") 
plot(recid.surv, lty = 1:2, mark.time=FALSE, xlab="Time", ylab="Education Survival Probability") 




###  Generate QUARTERLY duration until End of Benefits  ###
###########################################################

# Received AFDC/TANF, food stamp, SSI/SSA, or general assistance (GA) benefits

# Check summary statistics of total dollars from benefits to define cutoff for Benefits
loopframe <- select(impactData1, contains("ANYPQ"), contains("A_ANYPEV"))  # Select variables indicating quarterly benefits
checkMearn0 <- replace(loopframe,is.na(loopframe),0)
checkMearn <- loopframe$A_ANYPEV/rowSums(checkMearn0[,1:16])
checkMearn <- replace(checkMearn,as.logical(loopframe$A_ANYPEV == 0),0)
checkMearn <- checkMearn[!is.na(checkMearn)] 
summary(checkMearn)
quantile(checkMearn, probs=c(0,0.05,0.10,0.15,0.20,0.25,0.30,0.35,0.40,0.45,0.50,0.55,0.60,0.65,0.70,0.75,0.80,0.85,0.90, 0.95, 1))
plot(density(checkMearn), main="Benefits per quarter when receiving benefits Density")


loopframe <- select(impactData1,contains("ANYPQ"), contains("A_ANYPEV"), MPRID)  # Select variables indicating quarterly benefits
loopframe <- replace(loopframe , is.na(loopframe), NA )
dim(loopframe)
summary(loopframe)

PCut <- 200   # Minimum earnings per quarter from benefits to be considered as "benefits"
checkMearn0 <- replace(loopframe,is.na(loopframe),0)
checkMearn <- loopframe$A_ANYPEV/rowSums(checkMearn0[,1:16])
checkMearn <- replace(checkMearn,as.logical(loopframe$A_ANYPEV == 0),0)
checkMearn <- checkMearn[!is.na(checkMearn)] 
summary(checkMearn)

loopframe$ANYPQ1 <- replace(loopframe$ANYPQ1, as.logical(checkMearn < PCut),0)  
loopframe$ANYPQ2 <- replace(loopframe$ANYPQ2, as.logical(checkMearn < PCut),0)
checkNA <- loopframe[is.na(loopframe$ANYPQ1),]            # For 1st quarter, for NA values: Take second quarter benefits status if it is not NA and 1st quarter Benefits status is NA, otherwise keep as NA if both NA.
durBen <- matrix(abs(loopframe$ANYPQ1-1), NROW(loopframe), 1)
durBen <- replace(durBen,is.na(loopframe$ANYPQ1),(abs(checkNA$ANYPQ2-1)))  # Vector of 1st quarter Benefits status
loopframe$ANYPQ1 <- replace(loopframe$ANYPQ1,is.na(loopframe$ANYPQ1),1)  # Useful for the loop
loopframe$ANYPQ1 <- abs(loopframe$ANYPQ1-1)  # Useful for the loop

durBenC <- matrix(durBen, NROW(loopframe), 1)             # Vector indicator of Benefits status in 1st quarter


durBenl <- durBen
durBenCl <- durBenC
Nperiods <- 16    # Number of time periods 
for (j in 2:Nperiods) 
{ 
  loopframe[,j] <- abs(loopframe[,j]-1)
  loopframe[,j] <- replace(loopframe[,j] , as.logical(checkMearn  < PCut),0)
  durBenCNA <- replace(loopframe[,j], is.na(loopframe[,j]),0)
  durBenC <- durBenCl + as.numeric(durBenCNA == 1)*as.numeric(durBenCl == 0)*(1-as.numeric(is.na(rowSums(loopframe[,1:j]))))
  
  durBen <- durBenl + j*as.numeric(durBenCNA == 1)*as.numeric(durBenl == 0) *(1-as.numeric(is.na(rowSums(loopframe[,1:j])))) +
    j*as.numeric(is.na(loopframe[,j]))*as.numeric(durBenl == 0)
  
  durBenl <- durBen
  durBenCl <- durBenC
}
durBen <- replace(durBen, as.logical(durBen==0), (Nperiods+1)) # For agents who never received benefits 
cbind(durBen,durBenC)
summary(durBen)


durBen <- matrix(durBen, NROW(loopframe),1)
durBenC <- matrix(durBenC, NROW(loopframe),1)
durBenplot <- cbind(durBen,durBenC)
durBenplot <- durBenplot[!is.na(durBenplot[,1]),]
summary(durBenplot)
plot(density(durBenplot[,1]), main="Benefits Density", xlab="Time")
quantile(durBenplot[,1], probs=c(0,0.05,0.10,0.15,0.20,0.25,0.30,0.35,0.40,0.45,0.50,0.55,0.60,0.65,0.70,0.75,0.80,0.85,0.90, 0.95, 1))

recid.surv <- survfit(Surv(time=durBenplot[,1], event = durBenplot[,2], type=c('right')) ~1, conf.type="none") 
plot(recid.surv, lty = 1:2, mark.time=FALSE, xlab="Time", ylab="Benefits Survival Probability") 




###  Generate QUARTERLY duration until Job and Educ/Voc clean  ###
##################################################################
#  Generate duration until Job and Educ/Voc clean of the other, so 

# For duration until (Job or Edu/Voc), censor any observation at time of other (Educ/Voc or Job)

durJobG<- durEdu*as.numeric((durJob-durEdu) >= 0) + durJob*as.numeric((durJob-durEdu) < 0)
durJobGC<- durJobC*as.numeric((durJob-durEdu) < 0) 
sum(durJobC-durJobGC)

durEduG<- durJob*as.numeric((durEdu-durJob) >= 0) + durEdu*as.numeric((durEdu-durJob) < 0)
durEduGC<- durEduC*as.numeric((durEdu-durJob) < 0) 
sum(durEduC-durEduGC)


loopframe <- select(impactData1, contains("EDHPWQ")) 
denMhours <- 16-rowSums(matrix(as.numeric(is.na(loopframe)),NROW(loopframe),NCOL(loopframe)))
checkMhours <- (rowSums(loopframe,na.rm = TRUE)/denMhours)
checkMhours <- checkMhours[!is.na(checkMhours)]
summary(checkMhours)
quantile(checkMhours, probs=c(0,0.05,0.10,0.15,0.20,0.25,0.30,0.35,0.40,0.45,0.50,0.55,0.60,0.65,0.70,0.75,0.80,0.85,0.90, 0.95, 1))
plot(density(checkMhours), main="Number Hours Density")

###  Generate QUARTERLY duration until Starting enough hours in Job or education or vocational training (JEV)  ###
##################################################################################################################
# All variables here constructed based on number of hours in total activities

# Check summary statistics of number of hours worked per week to define cutoff for JEV (Job, or Educ or Voc. training)
loopframe <- select(impactData1, contains("EDHPWQ")) 
loopframe <- cbind(loopframe[,6:16],loopframe[,1:5])
loopframe <- replace(loopframe , is.na(loopframe), NA )
loopframe[loopframe == 0] <- NA
denMhours <- 16-rowSums(matrix(as.numeric(is.na(loopframe)),NROW(loopframe),NCOL(loopframe)))
checkMhours <- (rowSums(loopframe,na.rm = TRUE)/denMhours)
checkMhours <- checkMhours[!is.na(checkMhours)]
summary(checkMhours)
quantile(checkMhours, probs=c(0,0.05,0.10,0.15,0.20,0.25,0.30,0.35,0.40,0.45,0.50,0.55,0.60,0.65,0.70,0.75,0.80,0.85,0.90, 0.95, 1))
plot(density(checkMhours), main="Number Hours Density")

loopframe <- select(impactData1, contains("HRSWQ")) 
loopframe <- replace(loopframe , is.na(loopframe), NA )
loopframe[loopframe == 0] <- NA
denMhours <- 16-rowSums(matrix(as.numeric(is.na(loopframe)),NROW(loopframe),NCOL(loopframe)))
checkMhours <- (rowSums(loopframe,na.rm = TRUE)/denMhours)
checkMhours <- checkMhours[!is.na(checkMhours)]
summary(checkMhours)
quantile(checkMhours, probs=c(0,0.05,0.10,0.15,0.20,0.25,0.30,0.35,0.40,0.45,0.50,0.55,0.60,0.65,0.70,0.75,0.80,0.85,0.90, 0.95, 1))
plot(density(checkMhours), main="Number Hours Density")

loopframe <- select(impactData1, contains("EDHPWQ"),contains("HRSWQ")) 
loopframe <- cbind(loopframe[,6:16],loopframe[,1:5]) + loopframe[,17:32]
loopframe <- replace(loopframe , is.na(loopframe), NA )
loopframe[loopframe == 0] <- NA
denMhours <- 16-rowSums(matrix(as.numeric(is.na(loopframe)),NROW(loopframe),NCOL(loopframe)))
checkMhours <- (rowSums(loopframe,na.rm = TRUE)/denMhours)
checkMhours <- checkMhours[!is.na(checkMhours)]
summary(checkMhours)
quantile(checkMhours, probs=c(0,0.05,0.10,0.15,0.20,0.25,0.30,0.35,0.40,0.45,0.50,0.55,0.60,0.65,0.70,0.75,0.80,0.85,0.90, 0.95, 1))
plot(density(checkMhours), main="Number Hours Density")



loopframe <- select(impactData1,contains("EDHPWQ"), contains("HRSWQ"), MPRID)  # Select variables indicating quarterly education or voc. training status (Educ for short)
loopframe <- cbind(loopframe[,6:16],loopframe[,1:5],loopframe[,17:32],loopframe[,33])
loopframe <- replace(loopframe , is.na(loopframe), NA )
dim(loopframe)
summary(loopframe)

mJEV <- matrix(0,NROW(loopframe),16)
Nperiods <- 16    # Number of time periods 
loop1 <- replace(loopframe, is.na(loopframe), 0)
for (i in 1:Nperiods) 
{ 
  mJEV[,i] <-  (loop1[,i]+loop1[,(i+16)])*as.numeric(!is.na(loopframe[,i]))*as.numeric(!is.na(loopframe[,(i+16)])) +
    loop1[,i]*as.numeric(!is.na(loopframe[,i]))*as.numeric(is.na(loopframe[,(i+16)])) +
    loop1[,(i+16)]*as.numeric(is.na(loopframe[,i]))*as.numeric(!is.na(loopframe[,(i+16)])) +
    9999*as.numeric(is.na(loopframe[,i]))*as.numeric(is.na(loopframe[,(i+16)]))
}
mJEV <- replace(mJEV , as.logical(mJEV == 9999),NA)  
mJEV1 <- mJEV


PCut <- 16   # Minimum nbr of hours in JEV
mJEV[,1] <- as.numeric(mJEV[,1] >= PCut)
mJEV[,2] <- as.numeric(mJEV[,2] >= PCut)
checkNA <- mJEV[is.na(mJEV[,1]),]            # For 1st quarter, for NA values: Take second quarter Educ status if it is not NA and 1st quarter Educ status is NA, otherwise keep as NA if both NA.
durJEV <- matrix(mJEV[,1], NROW(loopframe), 1)
durJEV <- replace(mJEV[,1],is.na(mJEV[,1]),checkNA[,2])  # Vector of 1st quarter Educ status
mJEV[,1] <- replace(mJEV[,1],is.na(mJEV[,1]),0)  # Useful for the loop

durJEVC <- matrix(durJEV, NROW(loopframe), 1)             # Vector indicator of Educ status in 1st quarter

durJEVl <- durJEV
durJEVCl <- durJEVC

for (j in 2:Nperiods) 
{ 
  mJEV[,j] <- as.numeric(mJEV1[,j] >= PCut)
  durJEVCNA <- replace(mJEV[,j], is.na(mJEV[,j]),0)
  durJEVC <- durJEVCl + as.numeric(durJEVCNA == 1)*as.numeric(durJEVCl == 0)*(1-as.numeric(is.na(rowSums(mJEV[,1:j]))))
  durJEV <- durJEVl + j*as.numeric(durJEVCNA == 1)*as.numeric(durJEVl == 0) *(1-as.numeric(is.na(rowSums(mJEV[,1:j])))) +
    j*as.numeric(is.na(mJEV[,j]))*as.numeric(durJEVl == 0)
  
  durJEVl <- durJEV
  durJEVCl <- durJEVC
}
durJEV <- replace(durJEV, as.logical(durJEV==0), (Nperiods+1)) # For agents who never found education 
cbind(durJEV,durJEVC,mJEV1[,1:6],mJEV[,1:6])
summary(durJEV)


durJEV <- matrix(durJEV, NROW(loopframe),1)
durJEVC <- matrix(durJEVC, NROW(loopframe),1)
durJEVplot <- cbind(durJEV,durJEVC)
durJEVplot <- durJEVplot[!is.na(durJEVplot[,1]),]
summary(durJEVplot)
plot(density(durJEVplot[,1]), main="Job or Education or Vocational Training Density", xlab="Time")
quantile(durJEVplot[,1], probs=c(0,0.05,0.10,0.15,0.20,0.25,0.30,0.35,0.40,0.45,0.50,0.55,0.60,0.65,0.70,0.75,0.80,0.85,0.90, 0.95, 1))

recid.surv <- survfit(Surv(time=durJEVplot[,1], event = durJEVplot[,2], type=c('right')) ~1, conf.type="none") 
plot(recid.surv, lty = 1:2, mark.time=FALSE, xlab="Time", ylab="JEV Survival Probability") 



DATAimpact <- cbind(impactData1$MPRID,durArr,durArrC,durCon,durConC, durJob,durJobC,durEdu,durEduC,durBen,durBenC,durJobG,durJobGC,durEduG,durEduGC,durJEV,durJEVC)
colnames(DATAimpact, do.NULL = FALSE)
colnames(DATAimpact) <- c("MPRID", "durArr" , "durArrC","durCon","durConC", "durJob","durJobC","durEdu","durEduC","durBen","durBenC","durJobG","durJobGC","durEduG","durEduGC", "durJEV", "durJEVC")





### Select Covariates at Baseline survey  ###
#############################################

keyvarsData <- read.sas7bdat("C:\\Users\\Stephen Kastoryano\\Dropbox\\ContDurMA\\Data\\original data\\key_vars.sas7bdat")

keyvarsData1 <- select(keyvarsData,MPRID,TREATMNT,AGE_CAT,AGEGROUP,ARRST_GR,EDUC_GR,HS_GED,FEMALE,HASCHLD,RACE_ALL,TYPEAREA)


AGE16_17 <- as.numeric(keyvarsData1$AGE_CAT <= 18)    # baseline is 19-24 year olds
ARRESTall <-  as.numeric(keyvarsData1$ARRST_GR > 1)   # Ever arrested for a crime before JC
ARRESTseri <- as.numeric(keyvarsData1$ARRST_GR == 3)  # Arrested for serious crime
RACEblack <-  as.numeric(keyvarsData1$RACE_ALL == 2)  # baseline reference will be white, non-hispanic
RACEhisp <- as.numeric(keyvarsData1$RACE_ALL == 3)    # baseline reference will be white, non-hispanic
RACEother <-  as.numeric(keyvarsData1$RACE_ALL >3)    # baseline reference will be white, non-hispanic


DATAkey <- cbind(keyvarsData1$MPRID,keyvarsData1$TREATMNT, keyvarsData1$AGEGROUP,keyvarsData1$HS_GED, keyvarsData1$FEMALE,
                 keyvarsData1$HASCHLD,keyvarsData1$TYPEAREA,AGE16_17,ARRESTall,ARRESTseri,RACEblack,RACEhisp,
                 RACEother)
colnames(DATAkey, do.NULL = FALSE)
colnames(DATAkey) <- c("MPRID", "TREATMNT","AGEGROUP","HS_GED","FEMALE","HASCHLD","TYPEAREA","AGE16_17",
                       "ARRESTall","ARRESTseri","RACEblack","RACEhisp","RACEother")



DataQfinal <- merge(DATAimpact, DATAkey, by.DATAimpact="MPRID", by.DATAkey="MPRID")
dim(DataQfinal)

save(DataQfinal,file="C:\\Users\\Stephen Kastoryano\\Dropbox\\ContDurMA\\Comp code\\DataQfinal.Rda")
load("C:\\Users\\Stephen Kastoryano\\Dropbox\\ContDurMA\\Comp code\\DataQfinal.Rda")





#######################################################################################
#######      CLEANING MONTHLY DATA                     ################################
#######################################################################################

###  Generate Monthly duration until Arrest  ###
###############################################




###  Generate Monthly duration until Arrested with and without criminal conviction  ###
#########################################################################################

# Note: The MU_ARR data which supposedly represents months to arrest is nonsense, it is constructed as averages from already constructed quarterly variables, not from the raw data

# back out month and year of randomization for each individual from RandData$rand_wk

RandData <- read.dta("C:\\Users\\Stephen Kastoryano\\Dropbox\\ContDurMA\\Data\\Job Corps various stata files\\Job Corps all\\rand_dat.dta")

RandData1 <- cbind(RandData,randm, randy)

randm <- matrix(0, NROW(RandData),1)
randm <- 11*as.numeric(RandData[,3] >=1)*as.numeric(RandData[,3] <= 4) +
         12*as.numeric(RandData[,3] >4)*as.numeric(RandData[,3] <= 8) +
         1*as.numeric(RandData[,3] >8)*as.numeric(RandData[,3] <= 12) +
         2*as.numeric(RandData[,3] >12)*as.numeric(RandData[,3] <= 16) +
         3*as.numeric(RandData[,3] >16)*as.numeric(RandData[,3] <= 20) +
         4*as.numeric(RandData[,3] >20)*as.numeric(RandData[,3] <= 25) +
         5*as.numeric(RandData[,3] >25)*as.numeric(RandData[,3] <= 29) +
         6*as.numeric(RandData[,3] >29)*as.numeric(RandData[,3] <= 33) +
         7*as.numeric(RandData[,3] >33)*as.numeric(RandData[,3] <= 38) +
         8*as.numeric(RandData[,3] >38)*as.numeric(RandData[,3] <= 42) +
         9*as.numeric(RandData[,3] >42)*as.numeric(RandData[,3] <= 47) +
         10*as.numeric(RandData[,3] >47)*as.numeric(RandData[,3] <= 51) +
         11*as.numeric(RandData[,3] >51)*as.numeric(RandData[,3] <= 55) +
         12*as.numeric(RandData[,3] >55)*as.numeric(RandData[,3] <= 60) +
         1*as.numeric(RandData[,3] >60)*as.numeric(RandData[,3] <= 64) +
         2*as.numeric(RandData[,3] >64)*as.numeric(RandData[,3] <= 68) +
         3*as.numeric(RandData[,3] >68)*as.numeric(RandData[,3] <= 73)
  
  
randy <- matrix(0, NROW(RandData),1)
randy <- 94*as.numeric(RandData[,3] >=1)*as.numeric(RandData[,3] <= 8) +
         95*as.numeric(RandData[,3] >8)*as.numeric(RandData[,3] <= 60) +
         96*as.numeric(RandData[,3] >60)*as.numeric(RandData[,3] <= 73)


randframe <- cbind(RandData$mprid,randm,randy)
colnames(randframe, do.NULL = FALSE)
colnames(randframe) <- c("MPRID", "randm","randy")

# Clean First follow up interview arrest data
fu12Data <- read.dta("C:\\Users\\Stephen Kastoryano\\Dropbox\\ContDurMA\\Data\\Job Corps various stata files\\Job Corps all\\fu12_raw.dta")
# F_I3M&: Month of most recent arrest (&=A) to 5th most recent arrest (&=E)
# F_I7&B: CONvicted in most recent (&=A) arrest to 5th most recent arrest (&=E)


loopframe <- as.data.frame(select(fu12Data,contains("f_i3m"), contains("f_i3y"), f_i7ab, f_i7bb, f_i7cb, f_i7db,f_i7eb, mprid))  # Select variables indicating quarterly arrest status
loopframe <- replace(loopframe , is.na(loopframe),0 )

table(loopframe$f_i3ma) # check values all between 1-12
table(loopframe$f_i3mb)
table(loopframe$f_i3mc)
table(loopframe$f_i3md)
table(loopframe$f_i3me)
table(loopframe$f_i3ya) # check values all reasonable (above 94)
table(loopframe$f_i3yb)
table(loopframe$f_i3yc)
table(loopframe$f_i3yd)
table(loopframe$f_i3ye)


# Impute 0 on month values which make no sense (not high occurence, but still)
loopframe$f_i3ye <- loopframe$f_i3ye - loopframe$f_i3ye*as.numeric(loopframe$f_i3me >12)  
loopframe$f_i3me <- loopframe$f_i3me - loopframe$f_i3me*as.numeric(loopframe$f_i3me >12)
loopframe$f_i3yd <- loopframe$f_i3yd - loopframe$f_i3yd*as.numeric(loopframe$f_i3md >12)
loopframe$f_i3md <- loopframe$f_i3md - loopframe$f_i3md*as.numeric(loopframe$f_i3md >12)
loopframe$f_i3yc <- loopframe$f_i3yc - loopframe$f_i3yc*as.numeric(loopframe$f_i3mc >12)
loopframe$f_i3mc <- loopframe$f_i3mc - loopframe$f_i3mc*as.numeric(loopframe$f_i3mc >12)
loopframe$f_i3yb <- loopframe$f_i3yb - loopframe$f_i3yb*as.numeric(loopframe$f_i3mb >12)
loopframe$f_i3mb <- loopframe$f_i3mb - loopframe$f_i3mb*as.numeric(loopframe$f_i3mb >12)
loopframe$f_i3ya <- loopframe$f_i3ya - loopframe$f_i3ya*as.numeric(loopframe$f_i3ma >12)
loopframe$f_i3ma <- loopframe$f_i3ma - loopframe$f_i3ma*as.numeric(loopframe$f_i3ma >12)

# generate first arrest month and year
arrestm12 <- 0 + loopframe$f_i3me*as.numeric( loopframe$f_i3me != 0)*as.numeric((loopframe$f_i3ye*100 + loopframe$f_i3me) >= 9411)  + 
           loopframe$f_i3md*as.numeric( loopframe$f_i3me == 0)*as.numeric( loopframe$f_i3md != 0)*as.numeric((loopframe$f_i3yd*100 + loopframe$f_i3md) >= 9411) +
           loopframe$f_i3mc*as.numeric( loopframe$f_i3md == 0)*as.numeric( loopframe$f_i3mc != 0)*as.numeric((loopframe$f_i3yc*100 + loopframe$f_i3mc) >= 9411) +
           loopframe$f_i3mb*as.numeric( loopframe$f_i3mc == 0)*as.numeric( loopframe$f_i3mb != 0)*as.numeric((loopframe$f_i3yb*100 + loopframe$f_i3mb) >= 9411) +
           loopframe$f_i3ma*as.numeric( loopframe$f_i3mb == 0)*as.numeric( loopframe$f_i3ma != 0)*as.numeric((loopframe$f_i3ya*100 + loopframe$f_i3ma) >= 9411) 
arresty12 <-  0 + loopframe$f_i3ye*as.numeric( loopframe$f_i3ye != 0)*as.numeric((loopframe$f_i3ye*100 + loopframe$f_i3me) >= 9411)  + 
            loopframe$f_i3yd*as.numeric( loopframe$f_i3ye == 0)*as.numeric( loopframe$f_i3yd != 0)*as.numeric((loopframe$f_i3yd*100 + loopframe$f_i3md) >= 9411) +
            loopframe$f_i3yc*as.numeric( loopframe$f_i3yd == 0)*as.numeric( loopframe$f_i3yc != 0)*as.numeric((loopframe$f_i3yc*100 + loopframe$f_i3mc) >= 9411) +
            loopframe$f_i3yb*as.numeric( loopframe$f_i3yc == 0)*as.numeric( loopframe$f_i3yb != 0)*as.numeric((loopframe$f_i3yb*100 + loopframe$f_i3mb) >= 9411) +
            loopframe$f_i3ya*as.numeric( loopframe$f_i3yb == 0)*as.numeric( loopframe$f_i3ya != 0)*as.numeric((loopframe$f_i3ya*100 + loopframe$f_i3ma) >= 9411)

arrest12 <- cbind(loopframe$mprid,arrestm12,arresty12)
colnames(arrest12, do.NULL = FALSE)
colnames(arrest12) <- c("MPRID", "arrestm12","arresty12")

# Clean Second follow up interview arrest data
fu30Data <- read.dta("C:\\Users\\Stephen Kastoryano\\Dropbox\\ContDurMA\\Data\\Job Corps various stata files\\Job Corps all\\fu30_raw.dta")
# F_I18M&: Month of most recent arrest (&=A) to 5th most recent arrest (&=E)


loopframe <- as.data.frame(select(fu30Data,contains("g_i18m"), contains("g_i18y"), mprid))  # Select variables indicating quarterly arrest status
loopframe <- replace(loopframe , is.na(loopframe),0 )

loopframe$g_i18ma <- replace(loopframe$g_i18ma , as.logical(loopframe$g_i18ma < 0),0 ) # replace with 0 negativevalues of month and year
loopframe$g_i18ya <- replace(loopframe$g_i18ya , as.logical(loopframe$g_i18ya < 0),0 )
loopframe$g_i18mb <- replace(loopframe$g_i18mb , as.logical(loopframe$g_i18mb < 0),0 )
loopframe$g_i18yb <- replace(loopframe$g_i18yb , as.logical(loopframe$g_i18yb < 0),0 )
loopframe$g_i18mc <- replace(loopframe$g_i18mc , as.logical(loopframe$g_i18mc < 0),0 )
loopframe$g_i18yc <- replace(loopframe$g_i18yc , as.logical(loopframe$g_i18yc < 0),0 )
loopframe$g_i18md <- replace(loopframe$g_i18md , as.logical(loopframe$g_i18md < 0),0 )
loopframe$g_i18yd <- replace(loopframe$g_i18yd , as.logical(loopframe$g_i18yd < 0),0 )
loopframe$g_i18me <- replace(loopframe$g_i18me , as.logical(loopframe$g_i18me < 0),0 )
loopframe$g_i18ye <- replace(loopframe$g_i18ye , as.logical(loopframe$g_i18ye < 0),0 )

table(loopframe$g_i18ma) # check values all between 1-12
table(loopframe$g_i18mb)
table(loopframe$g_i18mc)
table(loopframe$g_i18md)
table(loopframe$g_i18me)
table(loopframe$g_i18ya) # check values all reasonable
table(loopframe$g_i18yb)
table(loopframe$g_i18yc)
table(loopframe$g_i18yd)
table(loopframe$g_i18ye)

# generate first arrest month and year
arrestm30 <- 0 + loopframe$g_i18me*as.numeric( loopframe$g_i18me != 0)*as.numeric((loopframe$g_i18ye*100 + loopframe$g_i18me) >= 9411)  + 
  loopframe$g_i18md*as.numeric( loopframe$g_i18me == 0)*as.numeric( loopframe$g_i18md != 0)*as.numeric((loopframe$g_i18yd*100 + loopframe$g_i18md) >= 9411) +
  loopframe$g_i18mc*as.numeric( loopframe$g_i18md == 0)*as.numeric( loopframe$g_i18mc != 0)*as.numeric((loopframe$g_i18yc*100 + loopframe$g_i18mc) >= 9411) +
  loopframe$g_i18mb*as.numeric( loopframe$g_i18mc == 0)*as.numeric( loopframe$g_i18mb != 0)*as.numeric((loopframe$g_i18yb*100 + loopframe$g_i18mb) >= 9411) +
  loopframe$g_i18ma*as.numeric( loopframe$g_i18mb == 0)*as.numeric( loopframe$g_i18ma != 0)*as.numeric((loopframe$g_i18ya*100 + loopframe$g_i18ma) >= 9411) 
arresty30 <-  0 + loopframe$g_i18ye*as.numeric( loopframe$g_i18ye != 0)*as.numeric((loopframe$g_i18ye*100 + loopframe$g_i18me) >= 9411)  + 
  loopframe$g_i18yd*as.numeric( loopframe$g_i18ye == 0)*as.numeric( loopframe$g_i18yd != 0)*as.numeric((loopframe$g_i18yd*100 + loopframe$g_i18md) >= 9411) +
  loopframe$g_i18yc*as.numeric( loopframe$g_i18yd == 0)*as.numeric( loopframe$g_i18yc != 0)*as.numeric((loopframe$g_i18yc*100 + loopframe$g_i18mc) >= 9411) +
  loopframe$g_i18yb*as.numeric( loopframe$g_i18yc == 0)*as.numeric( loopframe$g_i18yb != 0)*as.numeric((loopframe$g_i18yb*100 + loopframe$g_i18mb) >= 9411) +
  loopframe$g_i18ya*as.numeric( loopframe$g_i18yb == 0)*as.numeric( loopframe$g_i18ya != 0)*as.numeric((loopframe$g_i18ya*100 + loopframe$g_i18ma) >= 9411)


arrest30 <- cbind(loopframe$mprid,arrestm30,arresty30)
colnames(arrest30, do.NULL = FALSE)
colnames(arrest30) <- c("MPRID", "arrestm30","arresty30")

# Clean Third follow up interview arrest data
fu48Data <- read.dta("C:\\Users\\Stephen Kastoryano\\Dropbox\\ContDurMA\\Data\\Job Corps various stata files\\Job Corps all\\fu48_raw.dta")
# F_I3M&: Month of most recent arrest (&=A) to 5th most recent arrest (&=E)
# F_I7&B: CONvicted in most recent (&=A) arrest to 5th most recent arrest (&=E)


loopframe <- as.data.frame(select(fu48Data,contains("h_i18m"), contains("h_i18y"), mprid))  # Select variables indicating quarterly arrest status
loopframe <- replace(loopframe , is.na(loopframe),0 )


loopframe$h_i18ma <- replace(loopframe$h_i18ma , as.logical(loopframe$h_i18ma < 0),0 ) # replace with 0 negativevalues of month and year
loopframe$h_i18ya <- replace(loopframe$h_i18ya , as.logical(loopframe$h_i18ya < 0),0 )
loopframe$h_i18mb <- replace(loopframe$h_i18mb , as.logical(loopframe$h_i18mb < 0),0 )
loopframe$h_i18yb <- replace(loopframe$h_i18yb , as.logical(loopframe$h_i18yb < 0),0 )
loopframe$h_i18mc <- replace(loopframe$h_i18mc , as.logical(loopframe$h_i18mc < 0),0 )
loopframe$h_i18yc <- replace(loopframe$h_i18yc , as.logical(loopframe$h_i18yc < 0),0 )
loopframe$h_i18md <- replace(loopframe$h_i18md , as.logical(loopframe$h_i18md < 0),0 )
loopframe$h_i18yd <- replace(loopframe$h_i18yd , as.logical(loopframe$h_i18yd < 0),0 )
loopframe$h_i18me <- replace(loopframe$h_i18me , as.logical(loopframe$h_i18me < 0),0 )
loopframe$h_i18ye <- replace(loopframe$h_i18ye , as.logical(loopframe$h_i18ye < 0),0 )

table(loopframe$h_i18ma) # check values all between 1-12
table(loopframe$h_i18mb)
table(loopframe$h_i18mc)
table(loopframe$h_i18md)
table(loopframe$h_i18me)
table(loopframe$h_i18ya) # check values all reasonable
table(loopframe$h_i18yb)
table(loopframe$h_i18yc)
table(loopframe$h_i18yd)
table(loopframe$h_i18ye)



# generate first arrest month and year
arrestm48 <- 0 + loopframe$h_i18me*as.numeric( loopframe$h_i18me != 0)*as.numeric((loopframe$h_i18ye*100 + loopframe$h_i18me) >= 9411)  + 
  loopframe$h_i18md*as.numeric( loopframe$h_i18me == 0)*as.numeric( loopframe$h_i18md != 0)*as.numeric((loopframe$h_i18yd*100 + loopframe$h_i18md) >= 9411) +
  loopframe$h_i18mc*as.numeric( loopframe$h_i18md == 0)*as.numeric( loopframe$h_i18mc != 0)*as.numeric((loopframe$h_i18yc*100 + loopframe$h_i18mc) >= 9411) +
  loopframe$h_i18mb*as.numeric( loopframe$h_i18mc == 0)*as.numeric( loopframe$h_i18mb != 0)*as.numeric((loopframe$h_i18yb*100 + loopframe$h_i18mb) >= 9411) +
  loopframe$h_i18ma*as.numeric( loopframe$h_i18mb == 0)*as.numeric( loopframe$h_i18ma != 0)*as.numeric((loopframe$h_i18ya*100 + loopframe$h_i18ma) >= 9411) 
arresty48 <-  0 + loopframe$h_i18ye*as.numeric( loopframe$h_i18ye != 0)*as.numeric((loopframe$h_i18ye*100 + loopframe$h_i18me) >= 9411)  + 
  loopframe$h_i18yd*as.numeric( loopframe$h_i18ye == 0)*as.numeric( loopframe$h_i18yd != 0)*as.numeric((loopframe$h_i18yd*100 + loopframe$h_i18md) >= 9411) +
  loopframe$h_i18yc*as.numeric( loopframe$h_i18yd == 0)*as.numeric( loopframe$h_i18yc != 0)*as.numeric((loopframe$h_i18yc*100 + loopframe$h_i18mc) >= 9411) +
  loopframe$h_i18yb*as.numeric( loopframe$h_i18yc == 0)*as.numeric( loopframe$h_i18yb != 0)*as.numeric((loopframe$h_i18yb*100 + loopframe$h_i18mb) >= 9411) +
  loopframe$h_i18ya*as.numeric( loopframe$h_i18yb == 0)*as.numeric( loopframe$h_i18ya != 0)*as.numeric((loopframe$h_i18ya*100 + loopframe$h_i18ma) >= 9411)


arrest48 <- cbind(loopframe$mprid,arrestm48,arresty48)
colnames(arrest48, do.NULL = FALSE)
colnames(arrest48) <- c("MPRID", "arrestm48","arresty48")

arrestMframe1 <- merge(randframe, arrest12, by="MPRID")
arrestMframe2 <- merge(arrestMframe1, arrest30, by="MPRID", all= TRUE)
arrestMframe <- merge(arrestMframe2, arrest48, by="MPRID", all= TRUE)
arrestMframe <- arrestMframe[!is.na(arrestMframe[,2]),]

save(arrestMframe,file="C:\\Users\\Stephen Kastoryano\\Dropbox\\ContDurMA\\Comp code\\arrestMframe.Rda")
load("C:\\Users\\Stephen Kastoryano\\Dropbox\\ContDurMA\\Comp code\\arrestMframe.Rda")


dat <- cbind(arrestMframe)

durArr12 <-  (as.numeric(as.character(dat$arresty12))-as.numeric(as.character(dat$randy)))*12 + as.numeric(as.character(dat$arrestm12))-as.numeric(as.character(dat$randm))+1
durArr30 <-  (as.numeric(as.character(dat$arresty30))-as.numeric(as.character(dat$randy)))*12 + as.numeric(as.character(dat$arrestm30))-as.numeric(as.character(dat$randm))+1
durArr48 <-  (as.numeric(as.character(dat$arresty48))-as.numeric(as.character(dat$randy)))*12 + as.numeric(as.character(dat$arrestm48))-as.numeric(as.character(dat$randm))+1

dat <- cbind(dat,durArr12,durArr30,durArr48) 

durArrM <- durArr12*as.numeric(durArr12 >0) 
durArrMC <- as.numeric(durArrM >0)

durArr30b <- replace(durArr30,is.na(durArr30),0)
durArrM <- durArrM + durArr30b*as.numeric(durArr30b > 0)*as.numeric(durArr12 <=0) + 12*as.numeric(is.na(durArr30))*as.numeric(durArr12 <=0) 
durArrMC <- durArrMC + as.numeric(durArr30b >0)*as.numeric(durArr12 <=0)

durArr48 <- replace(durArr48,is.na(durArr30),NA)
durArr48b <- replace(durArr48,is.na(durArr48),0)
durArrM <- durArrM + durArr48b*as.numeric(durArr48b > 0)*as.numeric(durArr12 <=0)*as.numeric(durArr30b <=0) + 30*as.numeric(is.na(durArr48))*as.numeric(!is.na(durArr30))*as.numeric(durArr30b <=0)*as.numeric(durArr12 <=0) 
durArrMC <- durArrMC + as.numeric(durArr48b > 0)*as.numeric(durArr12 <=0)*as.numeric(durArr30b <=0)
durArrM <- replace(durArrM,as.logical(durArrM==0),49)

durArrMC <- durArrMC*as.numeric(durArrM <= 48)
durArrM <- durArrM*as.numeric(durArrM <= 48) + 49*as.numeric(durArrM > 48)

dat <- cbind(dat,durArrM,durArrMC) 
durArrMframe <- cbind(as.numeric(as.character(dat[,1])),durArrM,durArrMC) 
colnames(durArrMframe, do.NULL = FALSE)
colnames(durArrMframe) <- c("MPRID", "durArrM","durArrMC")

save(durArrMframe,file="C:\\Users\\Stephen Kastoryano\\Dropbox\\ContDurMA\\Comp code\\durArrMframe.Rda")
load("C:\\Users\\Stephen Kastoryano\\Dropbox\\ContDurMA\\Comp code\\durArrMframe.Rda")


# Duration until first arrest
durArrM <- matrix(durArrM, NROW(durArrM),1)
durArrMC <- matrix(durArrMC, NROW(durArrM),1)
durArrMplot <- cbind(durArrM,durArrMC)
durArrMplot <- durArrMplot[!is.na(durArrMplot[,1]),]
summary(durArrMplot)
plot(density(durArrMplot[,1]), main="Monthly Arrest Density", xlab="Time")
quantile(durArrMplot[,1], probs=c(0,0.05,0.10,0.15,0.20,0.25,0.30,0.35,0.40,0.45,0.50,0.55,0.60,0.65,0.70,0.75,0.80,0.85,0.90, 0.95, 1))

recid.surv <- survfit(Surv(time=durArrMplot[,1], event = durArrMplot[,2], type=c('right')) ~1, conf.type="none") 
plot(recid.surv, lty = 1:2, mark.time=FALSE, xlab="Time", ylab="Arrest Survival Probability") 




###  Generate MONTHLY duration until finding a job  ###
######################################################


empltlData <- read.sas7bdat("C:\\Users\\Stephen Kastoryano\\Dropbox\\ContDurMA\\Data\\original data\\empl_tl.sas7bdat")

empltlData1 <- select(empltlData,MPRID, contains("HWH"))


# Check summary statistics of hours worked per week to define cutoff for working
loopframe <- select(empltlData1, contains("HWH")) 
loopframe <- replace(loopframe , is.na(loopframe), NA )
loopframe[loopframe == 0] <- NA
denMhours <- 208-rowSums(matrix(as.numeric(is.na(loopframe)),NROW(loopframe),NCOL(loopframe)))
checkMhours <- (rowSums(loopframe,na.rm = TRUE)/denMhours)
checkMhours <- checkMhours[!is.na(checkMhours)]
summary(checkMhours)
quantile(checkMhours, probs=c(0,0.05,0.10,0.15,0.20,0.25,0.30,0.35,0.40,0.45,0.50,0.55,0.60,0.65,0.70,0.75,0.80,0.85,0.90, 0.95, 1))
plot(density(checkMhours), main="Number Hours Density")
  

loopframe <- select(empltlData1, contains("HWH"), MPRID)  # Select variables indicating quarterly education or voc. training status (Educ for short)
loopframe <- replace(loopframe , is.na(loopframe), NA )
dim(loopframe)
summary(loopframe)

Nperiods <- 208
dat <- matrix(0,NROW(loopframe),1)
loopframeb <- loopframe
loopframe[is.na(loopframe)] <- 0
for(i in seq(1,Nperiods,13)) {
  dat <- cbind(dat, apply(loopframe[,i:(i+4)], 1, max)*(1-as.numeric(as.logical(rowSums(matrix(as.numeric(is.na(loopframeb[,i:(i+4)])),NROW(loopframeb),5))==5))) +
             999*(as.numeric(as.logical(rowSums(matrix(as.numeric(is.na(loopframeb[,i:(i+4)])),NROW(loopframeb),5))==5)))) # pick maximum of weeks by month as monthly hours worked proxy
  dat <- cbind(dat, apply(loopframe[,(i+5):(i+8)], 1, max)*(1-as.numeric(as.logical(rowSums(matrix(as.numeric(is.na(loopframeb[,(i+5):(i+8)])),NROW(loopframeb),4))==4))) +
                 999*(as.numeric(as.logical(rowSums(matrix(as.numeric(is.na(loopframeb[,(i+5):(i+8)])),NROW(loopframeb),4))==4))))
  dat <- cbind(dat, apply(loopframe[,(i+9):(i+12)], 1, max)*(1-as.numeric(as.logical(rowSums(matrix(as.numeric(is.na(loopframeb[,(i+9):(i+12)])),NROW(loopframeb),4))==4))) +
                 999*(as.numeric(as.logical(rowSums(matrix(as.numeric(is.na(loopframeb[,(i+9):(i+12)])),NROW(loopframeb),4))==4))))
}
dat <- dat[,2:NCOL(dat)]
dat <- round(dat,digits=0) 
dat[dat==999] <- NA
dat1 <- dat
datJob <- cbind(as.numeric(as.character(loopframe$MPRID)),dat1)
colnames(datJob, do.NULL = FALSE)
colnames(datJob) <- c("MPRID", "Job1", "Job2", "Job3", "Job4", "Job5", "Job6", "Job7", "Job8", "Job9", "Job10", "Job11", "Job12", "Job13",
                      "Job14", "Job15", "Job16", "Job17", "Job18", "Job19", "Job20", "Job21", "Job22", "Job23", "Job24", "Job25", "Job26",
                      "Job27", "Job28", "Job29", "Job30", "Job31", "Job32", "Job33", "Job34", "Job35", "Job36", "Job37", "Job38", "Job39",
                      "Job40", "Job41", "Job42", "Job43", "Job44", "Job45", "Job46", "Job47", "Job48")




PCut <- 25   # Minimum nbr of hours in employment
dat[,1] <- as.numeric(dat[,1] >= PCut)
dat[,2] <- as.numeric(dat[,2] >= PCut)
checkNA <- dat[is.na(dat[,1]),]            
durJobM <- matrix(dat[,1], NROW(dat), 1)
durJobM <- replace(dat[,1],is.na(dat[,1]),checkNA[,2])  
dat[,1] <- replace(dat[,1],is.na(dat[,1]),0)  # Useful for the loop
durJobM <- durJobM*as.numeric(dat[,2] >= PCut)*as.numeric(dat[,3] >= PCut)

durJobMC <- matrix(durJobM, NROW(dat), 1)             

durJobMl <- durJobM
durJobMCl <- durJobMC
Nperiods <- 48
for (j in 2:(Nperiods-2)) 
{ 
  dat[,j] <- as.numeric(dat1[,j] >= PCut)*as.numeric(dat[,j+1] >= PCut)*as.numeric(dat[,j+2] >= PCut)
  durJobMCNA <- replace(dat[,j], is.na(dat[,j]),0)
  durJobMC <- durJobMCl + as.numeric(durJobMCNA == 1)*as.numeric(durJobMCl == 0)*(1-as.numeric(is.na(rowSums(dat[,1:j]))))
  durJobM <- durJobMl + j*as.numeric(durJobMCNA == 1)*as.numeric(durJobMl == 0) *(1-as.numeric(is.na(rowSums(dat[,1:j])))) +
    j*as.numeric(is.na(dat[,j]))*as.numeric(durJobMl == 0)
  
  durJobMl <- durJobM
  durJobMCl <- durJobMC
}
durJobM <- replace(durJobM, as.logical(durJobM==0), (Nperiods+1)) # For agents who never found employment 
cbind(durJobM,durJobMC,dat1[,1:17],dat[,1:17])
summary(durJobM)

durJobMframe <- cbind(as.numeric(as.character(loopframe$MPRID)),durJobM,durJobMC) 
colnames(durJobMframe, do.NULL = FALSE)
colnames(durJobMframe) <- c("MPRID", "durJobM","durJobMC")

save(durJobMframe,file="C:\\Users\\Stephen Kastoryano\\Dropbox\\ContDurMA\\Comp code\\durJobMframe.Rda")
load("C:\\Users\\Stephen Kastoryano\\Dropbox\\ContDurMA\\Comp code\\durJobMframe.Rda")

durJobM <- matrix(durJobM, NROW(loopframe),1)
durJobMC <- matrix(durJobMC, NROW(loopframe),1)
durJobMplot <- cbind(durJobM,durJobMC)
durJobMplot <- durJobMplot[!is.na(durJobMplot[,1]),]
summary(durJobMplot)
plot(density(durJobMplot[,1]), main="Employment Density", xlab="Time")
quantile(durJobMplot[,1], probs=c(0,0.05,0.10,0.15,0.20,0.25,0.30,0.35,0.40,0.45,0.50,0.55,0.60,0.65,0.70,0.75,0.80,0.85,0.90, 0.95, 1))

recid.surv <- survfit(Surv(time=durJobMplot[,1], event = durJobMplot[,2], type=c('right')) ~1, conf.type="none") 
plot(recid.surv, lty = 1:2, mark.time=FALSE, xlab="Time", ylab="Job Survival Probability") 



###  Generate MONTHLY duration until Starting education or vocational training  ###
##################################################################################

#jctlData <- read.sas7bdat("C:\\Users\\Stephen Kastoryano\\Dropbox\\ContDurMA\\Data\\original data\\jc_tl.sas7bdat")
edtrntlData <- read.sas7bdat("C:\\Users\\Stephen Kastoryano\\Dropbox\\ContDurMA\\Data\\original data\\edtrn_tl.sas7bdat")
#jctlData1 <- select(jctlData,MPRID,contains("JCHX"),contains("JCAXH"),contains("JCVOH"))
#edtrntlData1 <- select(edtrntlData,MPRID, contains("HWH"), contains("EDTH"), contains("EDAXH"), contains("EDTA"),
#                       contains("EDTV"))
#EduWklyData <- cbind(jctlData1,edtrntlData1[,2:NCOL(edtrntlData1)])

edtrntlData1 <- select(edtrntlData,MPRID, contains("EDTH"))


# Check summary statistics of hours worked per week to define cutoff for education
loopframe <- select(edtrntlData1, contains("EDTH")) 
loopframe <- replace(loopframe , is.na(loopframe), NA )
loopframe[loopframe == 0] <- NA
denMhours <- 208-rowSums(matrix(as.numeric(is.na(loopframe)),NROW(loopframe),NCOL(loopframe)))
checkMhours <- (rowSums(loopframe,na.rm = TRUE)/denMhours)
checkMhours <- checkMhours[!is.na(checkMhours)]
summary(checkMhours)
quantile(checkMhours, probs=c(0,0.05,0.10,0.15,0.20,0.25,0.30,0.35,0.40,0.45,0.50,0.55,0.60,0.65,0.70,0.75,0.80,0.85,0.90, 0.95, 1))
plot(density(checkMhours), main="Number Hours Density")


loopframe <- select(edtrntlData1, contains("EDTH"), MPRID)  # Select variables indicating quarterly education or voc. training status (Educ for short)
loopframe <- replace(loopframe , is.na(loopframe), NA )
dim(loopframe)
summary(loopframe)

Nperiods <- 208
dat <- matrix(0,NROW(loopframe),1)
loopframeb <- loopframe
loopframe[is.na(loopframe)] <- 0
for(i in seq(1,Nperiods,13)) {
  dat <- cbind(dat, apply(loopframe[,i:(i+4)], 1, max)*(1-as.numeric(as.logical(rowSums(matrix(as.numeric(is.na(loopframeb[,i:(i+4)])),NROW(loopframeb),5))==5))) +
                 999*(as.numeric(as.logical(rowSums(matrix(as.numeric(is.na(loopframeb[,i:(i+4)])),NROW(loopframeb),5))==5)))) # pick maximum of weeks by month as monthly hours education proxy
  dat <- cbind(dat, apply(loopframe[,(i+5):(i+8)], 1, max)*(1-as.numeric(as.logical(rowSums(matrix(as.numeric(is.na(loopframeb[,(i+5):(i+8)])),NROW(loopframeb),4))==4))) +
                 999*(as.numeric(as.logical(rowSums(matrix(as.numeric(is.na(loopframeb[,(i+5):(i+8)])),NROW(loopframeb),4))==4))))
  dat <- cbind(dat, apply(loopframe[,(i+9):(i+12)], 1, max)*(1-as.numeric(as.logical(rowSums(matrix(as.numeric(is.na(loopframeb[,(i+9):(i+12)])),NROW(loopframeb),4))==4))) +
                 999*(as.numeric(as.logical(rowSums(matrix(as.numeric(is.na(loopframeb[,(i+9):(i+12)])),NROW(loopframeb),4))==4))))
}
dat <- dat[,2:NCOL(dat)]
dat <- round(dat,digits=0) 
dat[dat==999] <- NA
dat1 <- dat
datEdu <- cbind(as.numeric(as.character(loopframe$MPRID)),dat1)
colnames(datEdu) <- c("MPRID", "Edu1", "Edu2", "Edu3", "Edu4", "Edu5", "Edu6", "Edu7", "Edu8", "Edu9","Edu10", "Edu11", "Edu12", "Edu13",
                       "Edu14", "Edu15", "Edu16", "Edu17", "Edu18", "Edu19", "Edu20", "Edu21", "Edu22", "Edu23", "Edu24", "Edu25", "Edu26",
                       "Edu27", "Edu28", "Edu29", "Edu30", "Edu31", "Edu32", "Edu33", "Edu34", "Edu35", "Edu36", "Edu37", "Edu38", "Edu39",
                       "Edu40", "Edu41", "Edu42", "Edu43", "Edu44", "Edu45", "Edu46", "Edu47", "Edu48")


PCut <- 10   # Minimum nbr of hours in employment
dat[,1] <- as.numeric(dat[,1] >= PCut)
dat[,2] <- as.numeric(dat[,2] >= PCut)
checkNA <- dat[is.na(dat[,1]),]            
durEduM <- matrix(dat[,1], NROW(dat), 1)
durEduM <- replace(dat[,1],is.na(dat[,1]),checkNA[,2])  
dat[,1] <- replace(dat[,1],is.na(dat[,1]),0)  # Useful for the loop

durEduMC <- matrix(durEduM, NROW(dat), 1)             

durEduMl <- durEduM
durEduMCl <- durEduMC
Nperiods <- 48
for (j in 2:Nperiods) 
{ 
  dat[,j] <- as.numeric(dat1[,j] >= PCut)
  durEduMCNA <- replace(dat[,j], is.na(dat[,j]),0)
  durEduMC <- durEduMCl + as.numeric(durEduMCNA == 1)*as.numeric(durEduMCl == 0)*(1-as.numeric(is.na(rowSums(dat[,1:j]))))
  durEduM <- durEduMl + j*as.numeric(durEduMCNA == 1)*as.numeric(durEduMl == 0) *(1-as.numeric(is.na(rowSums(dat[,1:j])))) +
    j*as.numeric(is.na(dat[,j]))*as.numeric(durEduMl == 0)
  
  durEduMl <- durEduM
  durEduMCl <- durEduMC
}
durEduM <- replace(durEduM, as.logical(durEduM==0), (Nperiods+1)) # For agents who never found employment 
cbind(durEduM,durEduMC,dat1[,1:17],dat[,1:17])
summary(durEduM)


durEduMframe <- cbind(as.numeric(as.character(loopframe$MPRID)),durEduM,durEduMC) 
colnames(durEduMframe, do.NULL = FALSE)
colnames(durEduMframe) <- c("MPRID", "durEduM","durEduMC")

save(durEduMframe,file="C:\\Users\\Stephen Kastoryano\\Dropbox\\ContDurMA\\Comp code\\durEduMframe.Rda")
load("C:\\Users\\Stephen Kastoryano\\Dropbox\\ContDurMA\\Comp code\\durEduMframe.Rda")



durEduM <- matrix(durEduM, NROW(loopframe),1)
durEduMC <- matrix(durEduMC, NROW(loopframe),1)
durEduMplot <- cbind(durEduM,durEduMC)
durEduMplot <- durEduMplot[!is.na(durEduMplot[,1]),]
summary(durEduMplot)
plot(density(durEduMplot[,1]), main="Educ & voc training Density", xlab="Time")
quantile(durEduMplot[,1], probs=c(0,0.05,0.10,0.15,0.20,0.25,0.30,0.35,0.40,0.45,0.50,0.55,0.60,0.65,0.70,0.75,0.80,0.85,0.90, 0.95, 1))

recid.surv <- survfit(Surv(time=durEduMplot[,1], event = durEduMplot[,2], type=c('right')) ~1, conf.type="none") 
plot(recid.surv, lty = 1:2, mark.time=FALSE, xlab="Time", ylab="Educ & voc Survival Probability") 





###  Generate MONTHLY duration until End of Benefits  ###
########################################################


othertlData <- read.sas7bdat("C:\\Users\\Stephen Kastoryano\\Dropbox\\ContDurMA\\Data\\original data\\other_tl.sas7bdat")
othertlData1 <- select(othertlData,MPRID, contains("ANYPH"), contains("WICH"), contains("UIH"))


###  Generate MONTHLY duration until Job and Educ/Voc clean  ###
##################################################################
#  Generate duration until Job and Educ/Voc clean of the other, so 

# For duration until (Job or Edu/Voc), censor any observation at time of other (Educ/Voc or Job)

durJobMG<- durEduM*as.numeric((durJobM-durEduM) >= 0) + durJobM*as.numeric((durJobM-durEduM) < 0)
durJobMGC<- durJobMC*as.numeric((durJobM-durEduM) < 0) 
sum(durJobMC-durJobMGC)

durEduMG<- durJobM*as.numeric((durEduM-durJobM) >= 0) + durEduM*as.numeric((durEduM-durJobM) < 0)
durEduMGC<- durEduMC*as.numeric((durEduM-durJobM) < 0) 
sum(durEduMC-durEduMGC)



###  Generate MONTHLY duration until Starting enough hours in Job or education or vocational training (JEV)  ###
##################################################################################################################
# All variables here constructed based on number of hours in total activities

DatJobEdu <- merge(datJob, datEdu, by.datJob="MPRID", by.datEdu="MPRID")

# Check summary statistics of number of hours worked per week to define cutoff for JEV (Job, or Educ or Voc. training)
loopframe <- DatJobEdu[,2:NCOL(DatJobEdu)]
loopframe <- loopframe[,1:48] + loopframe[,49:96]
loopframe <- replace(loopframe , is.na(loopframe), NA )
loopframe[loopframe == 0] <- NA
denMhours <- 48-rowSums(matrix(as.numeric(is.na(loopframe)),NROW(loopframe),NCOL(loopframe)))
checkMhours <- (rowSums(loopframe,na.rm = TRUE)/denMhours)
checkMhours <- checkMhours[!is.na(checkMhours)]
summary(checkMhours)
quantile(checkMhours, probs=c(0,0.05,0.10,0.15,0.20,0.25,0.30,0.35,0.40,0.45,0.50,0.55,0.60,0.65,0.70,0.75,0.80,0.85,0.90, 0.95, 1))
plot(density(checkMhours), main="Number Hours Density")



loopframe <- cbind(DatJobEdu[,2:NCOL(DatJobEdu)],DatJobEdu[,1]) # Select variables indicating quarterly education or voc. training status (Educ for short)
loopframe <- replace(loopframe , is.na(loopframe), NA )
dim(loopframe)
summary(loopframe)

mJEV <- matrix(0,NROW(loopframe),48)
Nperiods <- 48    # Number of time periods 
loop1 <- replace(loopframe, is.na(loopframe), 0)
for (i in 1:Nperiods) 
{ 
  mJEV[,i] <-  (loop1[,i]+loop1[,(i+48)])*as.numeric(!is.na(loopframe[,i]))*as.numeric(!is.na(loopframe[,(i+48)])) +
    loop1[,i]*as.numeric(!is.na(loopframe[,i]))*as.numeric(is.na(loopframe[,(i+48)])) +
    loop1[,(i+48)]*as.numeric(is.na(loopframe[,i]))*as.numeric(!is.na(loopframe[,(i+48)])) +
    9999*as.numeric(is.na(loopframe[,i]))*as.numeric(is.na(loopframe[,(i+48)]))
}
mJEV <- replace(mJEV , as.logical(mJEV == 9999),NA)  
mJEV1 <- mJEV


PCut <- 25   # Minimum nbr of hours in JEV
mJEV[,1] <- as.numeric(mJEV[,1] >= PCut)
mJEV[,2] <- as.numeric(mJEV[,2] >= PCut)
checkNA <- mJEV[is.na(mJEV[,1]),]            # For 1st quarter, for NA values: Take second quarter Educ status if it is not NA and 1st quarter Educ status is NA, otherwise keep as NA if both NA.
durJEV <- matrix(mJEV[,1], NROW(loopframe), 1)
durJEV <- replace(mJEV[,1],is.na(mJEV[,1]),checkNA[,2])  # Vector of 1st quarter Educ status
mJEV[,1] <- replace(mJEV[,1],is.na(mJEV[,1]),0)  # Useful for the loop

durJEVC <- matrix(durJEV, NROW(loopframe), 1)             # Vector indicator of Educ status in 1st quarter

durJEVl <- durJEV
durJEVCl <- durJEVC

for (j in 2:Nperiods) 
{ 
  mJEV[,j] <- as.numeric(mJEV1[,j] >= PCut)
  durJEVCNA <- replace(mJEV[,j], is.na(mJEV[,j]),0)
  durJEVC <- durJEVCl + as.numeric(durJEVCNA == 1)*as.numeric(durJEVCl == 0)*(1-as.numeric(is.na(rowSums(mJEV[,1:j]))))
  durJEV <- durJEVl + j*as.numeric(durJEVCNA == 1)*as.numeric(durJEVl == 0) *(1-as.numeric(is.na(rowSums(mJEV[,1:j])))) +
    j*as.numeric(is.na(mJEV[,j]))*as.numeric(durJEVl == 0)
  
  durJEVl <- durJEV
  durJEVCl <- durJEVC
}
durJEV <- replace(durJEV, as.logical(durJEV==0), (Nperiods+1)) # For agents who never found education 
cbind(durJEV,durJEVC,mJEV1[,1:6],mJEV[,1:6])
summary(durJEV)
durJEVM <- durJEV
durJEVMC <- durJEVC


durJEV <- matrix(durJEV, NROW(loopframe),1)
durJEVC <- matrix(durJEVC, NROW(loopframe),1)
durJEVplot <- cbind(durJEV,durJEVC)
durJEVplot <- durJEVplot[!is.na(durJEVplot[,1]),]
summary(durJEVplot)
plot(density(durJEVplot[,1]), main="Job or Education or Vocational Training Density", xlab="Time")
quantile(durJEVplot[,1], probs=c(0,0.05,0.10,0.15,0.20,0.25,0.30,0.35,0.40,0.45,0.50,0.55,0.60,0.65,0.70,0.75,0.80,0.85,0.90, 0.95, 1))

recid.surv <- survfit(Surv(time=durJEVplot[,1], event = durJEVplot[,2], type=c('right')) ~1, conf.type="none") 
plot(recid.surv, lty = 1:2, mark.time=FALSE, xlab="Time", ylab="JEV Survival Probability") 







###  Generate MONTHLY duration until Obtaining education or vocational degree  ###
##################################################################################

impactData <- read.sas7bdat("C:\\Users\\Stephen Kastoryano\\Dropbox\\ContDurMA\\Data\\original data\\impact.sas7bdat") 
edtrntlData <- read.sas7bdat("C:\\Users\\Stephen Kastoryano\\Dropbox\\ContDurMA\\Data\\original data\\edtrn_tl.sas7bdat")


edtrntlData2 <- select(edtrntlData,MPRID, contains("EDTH"))
impactData2 <- select(impactData,MPRID, D_HSGED, D48_VOC, D48_COLL)
degreeData1 <- merge(impactData2, edtrntlData2, by.DATAimpact="MPRID", by.DATAkey="MPRID")
dat <- degreeData1
summary(dat)


loopframe <- degreeData1[,5:NCOL(degreeData1)]  # Select variables indicating quarterly education or voc. training status (Educ for short)
loopframe <- replace(loopframe , is.na(loopframe), NA )
dim(loopframe)
summary(loopframe)

Nperiods <- 208
dat <- matrix(0,NROW(loopframe),1)
loopframeb <- loopframe
loopframe[is.na(loopframe)] <- 0
for(i in seq(1,Nperiods,13)) {
  dat <- cbind(dat, apply(loopframe[,i:(i+4)], 1, max)*(1-as.numeric(as.logical(rowSums(matrix(as.numeric(is.na(loopframeb[,i:(i+4)])),NROW(loopframeb),5))==5))) +
                 999*(as.numeric(as.logical(rowSums(matrix(as.numeric(is.na(loopframeb[,i:(i+4)])),NROW(loopframeb),5))==5)))) # pick maximum of weeks by month as monthly hours education proxy
  dat <- cbind(dat, apply(loopframe[,(i+5):(i+8)], 1, max)*(1-as.numeric(as.logical(rowSums(matrix(as.numeric(is.na(loopframeb[,(i+5):(i+8)])),NROW(loopframeb),4))==4))) +
                 999*(as.numeric(as.logical(rowSums(matrix(as.numeric(is.na(loopframeb[,(i+5):(i+8)])),NROW(loopframeb),4))==4))))
  dat <- cbind(dat, apply(loopframe[,(i+9):(i+12)], 1, max)*(1-as.numeric(as.logical(rowSums(matrix(as.numeric(is.na(loopframeb[,(i+9):(i+12)])),NROW(loopframeb),4))==4))) +
                 999*(as.numeric(as.logical(rowSums(matrix(as.numeric(is.na(loopframeb[,(i+9):(i+12)])),NROW(loopframeb),4))==4))))
}
dat <- dat[,2:NCOL(dat)]
dat <- round(dat,digits=0) 
dat[dat==999] <- NA

dat0 <- dat     # Set to 0 instances where people are in education at endof 48 months (possibly working on other degree)

for(k in 1:(NCOL(dat0)-1) ) 
  { 
  dat0[,k] <- as.numeric(as.logical(dat0[,k] > 0 ))*as.numeric(as.logical(dat0[,k+1] == 0 ))
}
dat0[,NCOL(dat0)] <- 0

dat0[is.na(dat0)] <- 0

for(j in 1:(NCOL(dat0)-2) ) 
{ 
  dat0[,j] <- dat0[,j]*as.numeric(as.logical(rowSums(dat0[,(j+1):NCOL(dat0)]) ==0))
  
}
dat0[,NCOL(dat0)] <- 0


durDegM <- 0
dat0[is.na(dat0)] <- 0

for(l in 1:(NCOL(dat0)-1) ) 
{ 
  durDegM <- durDegM + l*as.numeric(as.logical(dat0[,l] ==1))
}
durDegMC <- as.numeric(as.logical(durDegM>0))
durDegM[durDegM == 0] <- 49

dat <- cbind(durDegM,durDegMC,dat)

degree <- degreeData1[,2:4]
degree[is.na(degree)] <- 0
degree1 <- as.numeric(as.logical(rowSums(degree) > 0))

degree <- degreeData1[,2:4]
degree[is.na(degree)] <- 1
degree00 <- as.numeric(as.logical(rowSums(degree) == 0))
durDegM <- durDegM*(1-degree00) + 49*degree00
durDegMC <- durDegMC*degree1


dat1 <- cbind(degreeData1[,1:4] ,durDegM,durDegMC)




durDegMframe <- cbind(as.numeric(as.character(dat1$MPRID)),durDegM,durDegMC) 
colnames(durDegMframe, do.NULL = FALSE)
colnames(durDegMframe) <- c("MPRID", "durDegM","durDegMC")

save(durDegMframe,file="C:\\Users\\Stephen Kastoryano\\Dropbox\\ContDurMA\\Comp code\\durDegMframe.Rda")
load("C:\\Users\\Stephen Kastoryano\\Dropbox\\ContDurMA\\Comp code\\durDegMframe.Rda")



durDegM <- matrix(durDegM, NROW(loopframe),1)
durDegMC <- matrix(durDegMC, NROW(loopframe),1)
durDegMplot <- cbind(durDegM,durDegMC)
durDegMplot <- durDegMplot[!is.na(durDegMplot[,1]),]
summary(durDegMplot)
plot(density(durDegMplot[,1]), main="Degree Density", xlab="Time")
quantile(durDegMplot[,1], probs=c(0,0.05,0.10,0.15,0.20,0.25,0.30,0.35,0.40,0.45,0.50,0.55,0.60,0.65,0.70,0.75,0.80,0.85,0.90, 0.95, 1))

recid.surv <- survfit(Surv(time=durDegMplot[,1], event = durDegMplot[,2], type=c('right')) ~1, conf.type="none") 
plot(recid.surv, lty = 1:2, mark.time=FALSE, xlab="Time", ylab="Degree Survival Probability") 


durtreatMframe <- cbind(as.numeric(as.character(DatJobEdu$MPRID)),durEduM,durEduMC,durJobMG,durJobMGC,durEduMG,durEduMGC,durJEVM,durJEVMC) 
colnames(durtreatMframe, do.NULL = FALSE)
colnames(durtreatMframe) <- c("MPRID", "durEduM","durEduMC","durJobMG","durJobMGC","durEduMG","durEduMGC","durJEVM","durJEVMC")

durtreatMframe <- merge(durtreatMframe, durJobMframe, by.durtreatMframe="MPRID", by.durJobMframe="MPRID")
durtreatMframe <- merge(durtreatMframe, durDegMframe, by.durtreatMframe="MPRID", by.durDegMframe="MPRID")

save(durtreatMframe,file="C:\\Users\\Stephen Kastoryano\\Dropbox\\ContDurMA\\Comp code\\durtreatMframe.Rda")
load("C:\\Users\\Stephen Kastoryano\\Dropbox\\ContDurMA\\Comp code\\durtreatMframe.Rda")


### Select Covariates at Baseline survey  ###
#############################################

keyvarsData <- read.sas7bdat("C:\\Users\\Stephen Kastoryano\\Dropbox\\ContDurMA\\Data\\original data\\key_vars.sas7bdat")

keyvarsData1 <- select(keyvarsData,MPRID,TREATMNT,AGE_CAT,AGEGROUP,ARRST_GR,EDUC_GR,HS_GED,FEMALE,HASCHLD,RACE_ETH,NONRES,TYPEAREA)


AGE16_17 <- as.numeric(keyvarsData1$AGE_CAT <= 18)    # baseline is 19-24 year olds
AGE18_20 <- as.numeric(keyvarsData1$AGE_CAT > 18)*as.numeric(keyvarsData1$AGE_CAT <= 20)
HSdeg <- as.numeric(keyvarsData1$EDUC_GR == 3)
GEDdeg <- as.numeric(keyvarsData1$EDUC_GR == 2)
ARRESTall <-  as.numeric(keyvarsData1$ARRST_GR > 1)   # Ever arrested for a crime before JC
ARRESTseri <- as.numeric(keyvarsData1$ARRST_GR == 3)  # Arrested for serious crime
RACEblack <-  as.numeric(keyvarsData1$RACE_ETH == 2)  # baseline reference will be white, non-hispanic
RACEhisp <- as.numeric(keyvarsData1$RACE_ETH == 3)    # baseline reference will be white, non-hispanic
RACEother <-  as.numeric(keyvarsData1$RACE_ETH ==4)    # baseline reference will be white, non-hispanic
AREAdense <- as.numeric(keyvarsData1$TYPEAREA ==2)    # baseline reference will non-dense
AREAsupdense <- as.numeric(keyvarsData1$TYPEAREA ==1) # baseline reference will non-dense

DATAkey <- cbind(as.numeric(as.character(keyvarsData1$MPRID)),keyvarsData1$TREATMNT, AGE16_17,AGE18_20,HSdeg,GEDdeg, keyvarsData1$FEMALE,
                 keyvarsData1$HASCHLD,ARRESTall,ARRESTseri,RACEblack,RACEhisp,RACEother,AREAdense,AREAsupdense)
colnames(DATAkey, do.NULL = FALSE)
colnames(DATAkey) <- c("MPRID", "TREATMNT","AGE16_17","AGE18_20", "HSdeg", "GEDdeg", "FEMALE","HASCHLD",
                       "ARRESTall","ARRESTseri","RACEblack","RACEhisp","RACEother","AREAdense", "AREAsupdense")



BaseData <- read.sas7bdat("C:\\Users\\Stephen Kastoryano\\Dropbox\\ContDurMA\\Data\\original data\\baseline.sas7bdat")

BaseData1 <- select(BaseData,MPRID,YR_WORK1,MOSINJOB,CURRJOB,EARN_YR,GOT_ANYW,HH_INC,HEALTH,DRG_SUMP,HGC)
summary(BaseData1)

BaseData1$EARN_YR <- replace(BaseData1$EARN_YR , as.logical(BaseData1$EARN_YR == 0), 1 )
BaseData1$EARN_YR <- log(BaseData1$EARN_YR)

DATAbase <- cbind(as.numeric(as.character(BaseData1$MPRID)),BaseData1$YR_WORK1, BaseData1$CURRJOB, BaseData1$EARN_YR,
                  BaseData1$GOT_ANYW, BaseData1$HEALTH)
colnames(DATAbase, do.NULL = FALSE)
colnames(DATAbase) <- c("MPRID", "WORK_YR","CURRJOB","LogEARN_YR", "GOTANYW_YR", "HEALTH")


  
DataMfinal <- merge(DATAkey, DATAbase, DATAbase="MPRID", by.DATAkey="MPRID")
DataMfinal <- merge(durJobMframe, DataMfinal, durJobMframe="MPRID", by.DataMfinal="MPRID")
DataMfinalJobArr <- merge(durArrMframe, DataMfinal, durArrMframe="MPRID", DataMfinal="MPRID")
DataMfinal <- merge(DATAkey, DATAbase, DATAbase="MPRID", by.DATAkey="MPRID")
DataMfinal <- merge(durJobMframe, DataMfinal, durJobMframe="MPRID", by.DataMfinal="MPRID")
DataMfinalDegJob <- merge(durDegMframe, DataMfinal, durDegMframe="MPRID", by.DataMfinal="MPRID")
DataMfinal <- merge(DATAkey, DATAbase, DATAbase="MPRID", by.DATAkey="MPRID")
DataMfinal <- merge(durDegMframe, DataMfinal, durDegMframe="MPRID", by.DataMfinal="MPRID")
DataMfinalDegArr <- merge(durArrMframe, DataMfinal, durArrMframe="MPRID", by.DataMfinal="MPRID")
dim(DataMfinal)
dim(DataMfinalDegJob)
dim(DataMfinalJobArr)
dim(durtreatMframe)
dim(durJobMframe)
dim(durDegMframe)
dim(durArrMframe)
dim(DATAkey)
dim(DATAbase)

save(DataMfinalDegJob,file="C:\\Users\\Stephen Kastoryano\\Dropbox\\ContDurMA\\Comp code\\DataMfinalDegJob.Rda")
save(DataMfinalJobArr,file="C:\\Users\\Stephen Kastoryano\\Dropbox\\ContDurMA\\Comp code\\DataMfinalJobArr.Rda")
save(DataMfinalDegArr,file="C:\\Users\\Stephen Kastoryano\\Dropbox\\ContDurMA\\Comp code\\DataMfinalDegArr.Rda")



#baselineData <- read.sas7bdat("C:\\Users\\Stephen Kastoryano\\Dropbox\\ContDurMA\\Data\\original data\\baseline.sas7bdat")


         



Key Treatment and Outcome variables:
  <FROM KEY_VARS dataset>
  TREATMNT: 0= control, 1=program research group (num)
  <FROM IMPACT dataset>
  EDTQX1 - EDTQX16: enrolled in an education or vocational training program by quarter afer random assignment, 0= no, 1= yes
  EDHPWQ1 - EDHPWQ16: Hours per week in education or vocational training, by quarter after random assignment, 0-40 .E or .X = missing
  INACQ1 -INACQ16: Took academic classes, by quarter after..., 0=no, 1=yes, (0,1) impputed probability
  INVOCQ1 - INVOCQ16: Ever received vocational training, by quarter..., 0= no, 1= yes, (0,1) imputed probability
  WORKQ1 - WORKQ16: employed, by quarter after random assignment, 0= no, 1=yes
  PWORKQ1 - PWORKQ16: percentage of weeks employed by quarter after random assignment 0-100
  HRSWQ1 - HRSWQ16: Hours employed per week, by quarter after random assignment, 0-84
  EARNQ1 - EARNQ16: Earnings per week , by quarter after random assignment, >=0 
  AFDCQ1 - AFDCQ16: Received AFDC/TANF benefits, by quarter..., 0=no, 1=yes
  FSQ1 - FSQ16: Received food stamp (FS) benefits, by quarter after..., 0=no, 1=yes
  GAQ1 - GAQ16: Received general assistance benefits, by quarter after random assignment, 0=no, 1=yes
  SSIQ1 - SSIQ16: Received supplemental security income or social security retirement, disability, or survivors benefits (SSA), by quarter, 0=no, 1=yes
  ANYPQ1 - ANYPQ16: Received AFDC/TANF, food stamp, SSI/SSA, or general assistance (GA) benefits, by quarter..., 0=no, 1=yes
  A_ANYPEV: DOllar amount from any of abover over 48 months period 0-75,946 or .E=missing
  EVARRQ1 - EVARRQ16: Ever arrested or charged with criminal delinquency or criminal complaint, by quarter..., 0=no, 1=yes
  MU_ARR: Months after random assignment until first arrested, 1-48
  EVARRC1 - EVARRC41: Ever charged with crime (1=murder, 2=assault, 3=robbery, 4=burglary, 5=larceny, vehicle theft, or other property crime, 6=drug law violations, 7=other personal crimes, 8=other miscellaneous crimes), 0=no, 1=yes
  EVCNVC1 - EVCNVC8: Ever convicted of crime in category C1-C8 above during 48 months after ranadom assignemnt, no=0, yes=1
  SERCONV: Convicted of a serious charge (murder, assault, robbery, or burglary) during 48 moths..., no=0, yes=1
  EVERJAIL1: Served time in jail for convictions during the 48 months after random assignment, 0=no, 1=yes
  MOSJAIL1: Number of months ever in jail for convictions during the 48 months after random assignment, 0-56
  <CHECK DATASETS OF APPENDIX K>  
  If I read it correctly, you have weekly or monthly data on almost all the
  above. This should then be your main dataset for constructing duration variables
  JCHX*: participation in JC, by week after random assignment
  JCAXH*: part. in academic classes in JC, by...
  JCVOH*: Part. in vocational trainnis in JC, by...
  JCAH*: Hours in academic course in JC, by,...
  JCVH*: Hours of vocational training in JC, by...
  EDTNX*: part. in any education and training program other than JC, by...
  EDTH*: Hours in all educ and training programs (including JC), by...
  EDAXH*: part. in academic classes (other than JC), by...
  EDTA*: Hours in academic classes (other than JC), by...
  EDTV*: Hours in vocational training (other than JC), by...
  D48_GED: Received GED a GED certificate during 48 months after rand assig
  D48_HS: Received high school diploma during...
  D_HSGED: Received a high school diploma or GED during...
  D48_VOC: Recieved a vocational training degree or certificate during...
  D48_COLL: Received a two year or four year college degree during...
  WORKH*: Employed, by...  
  HWH*: Hours employed at all job, by...
  EARNH*: Earnings from all jobs, by...
  ANYPH*: Received AFDC/FS/GA/SSI benefits, by month
  WICH*: Received WIC benefits, by month
  UIH*: Received unemployment insurance benefits, by week
  
 

  

Covariate Variables
  <FROM KEY_VARS dataset>
  AGE_CAT: Age in years at application to Job Corps, 16-24 (num) or .D did not complete
  AGEGROUP: Age categories at application to JC, 1=16-17, 2=18-19, 3=20-24, .D
  ARRST_GR: Arrest experience prior to JC, 1= never arrested, 2= Arrested for non-serious crimes, 3= arrested for serious crimes
  EDUC_GR: High school credentials prior JC, 1= had no high school diploma or GED, 2= had a GED, 3= had a high school diploma
  HS_GED: Had high school or GED prior to JC, 0= no, 1= yes
  FEMALE: 0= male, 1= female
  HASCHLD: Had natural children prior to JC, 0= no, 1= yes
  RACE_ALL: 1= white, non-hisp, 2= Black, non-hisp, 3= Hispanic, 4= Native, 5= Asian or pacific Islander, 6= other
  TYPEAREA: Density of area of residence prior JC, 1=Superdense, 2= Dense, 3= nondense
  <FROM BASELINE dataset>
    Choose them directly from the dataset
  MARRIAGE: marital status, 1=never married, no cohab., 2=married, 3=cohab., 4=separated, divorced or widowed, .E=missing
  AGEPARENT: age when sample member became parent
  HGC: Highest grade completed
  DRG_SUME: summary of drugs ever used, 1=did not use, 2=used marijuana only, 3=used other drugs but not marijuana, 4=used both marijuana and other drugs
  DRG_SUMP: same as above but only in last year
  + all sorts of crime categories
  YR_WORK1: Had a job in the year prior to random assignment 1=yes, 0=no
  MOSINJOB: Months employed in year prior to random assignment
  CURRJOB: Had a job at random assignment 1=yes, 0=no
  EARN_YR: Earnings in the past year
  GOT_ANYW: Received any pubic assitance (AFDC, food stamps or other) 1=yes, 0=no
  HH_INC: Total household income 1= less than $3000, 2= 3000-6000 3=6000-9000 4=9000-18000 5=18000 or more 
  HEALTH: Health status 1=Excellent 2=good 3=fair 4=poor
  
  MOSINJOB,CURRJOB,EARN_YR,GOTANYW,HH_INC,HEALTH,DRG_SUMP,HGC
  
Other Variables:
  <FROM KEY_VARS dataset>
  MPRID: 8-digit ID (char)  (in all datasets)
  RESP_B: Completed baseline interview, 0= No, 1 = yes (num)
  RESP_12: Same 12 month interview, .D .K .R as 0 
  RESP_30: Same 30 month interview
  RESP_48: Same 48 month interview
  WGT... : These are all the weights, depending on your selection you will need to choose one or the other
  <FROM IMPACT dataset>
  EVERJCH: Ever enrolled in JC center in 48 months, 0= no, 1=yes
  
  
  
  
  
