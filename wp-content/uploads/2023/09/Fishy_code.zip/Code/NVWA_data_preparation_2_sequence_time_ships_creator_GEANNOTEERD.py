# -*- coding: utf-8 -*-
"""
Created on Mon Oct 28 16:40:11 2019

@author: jeanv
"""

import pandas as pd


#%% Paths
folder = ".\\"
#This file loads the locations of the ships and then repeats their location each 30 minutes until a new location is reported.



#%% Loading the DATA and convertime time to timestamp so python can work with it
df_ships = pd.read_csv(folder+'Output\\'+'gekoppelde_VMS_bestanden.csv')
df_ships['UTC time'] = pd.to_datetime(df_ships['UTC time'])

#sorting in UTC time so that we can use merge_asof later
df_ships.sort_values(by=['UTC time'],inplace=True)

#dropping observations where the latitude or longitude is unknown
df_ships = df_ships.dropna(subset = ['Lat.','Lon.'])

#Loading sales data - to see which ships we need data on and to see for which ships we do not observe the locations
df_verkoop = pd.read_csv(folder+'Data Visvangst\\'+'trips_sales.csv')

#Figuring out for which ships we will not observe locations
missing_set = set(df_verkoop.Vaartuig) - set(df_ships.Vaartuig)

#Setting the index on vessel, to increase the speed of the loop.
df_ships.set_index('Vaartuig',inplace=True)



#%% Generating a Grid

#Create an empty dataframe of locations, we will append locations to this dataframe
locations_grid = pd.DataFrame()

#Count the amount of times where we have sales data but no location
trips_without_vms_report = 0

#A loop which for each sales observation looks at the vessel departure and return, all VMS observations of that vessel between those time points are the reported locations
#during that trip.
for v in range(0,len(df_verkoop)):
    #defining departure, vessel and return
    vertrek             = df_verkoop.loc[v,"datumtijd_vertrek"]
    terug               = df_verkoop.loc[v,"datumtijd_terug"]
    schip               = df_verkoop.loc[v,"Vaartuig"]
    
    #if the vessel is in the set of vessels for which no vms is reported we do not need to go through the full loop.
    if (schip in missing_set): 
        trips_without_vms_report += 1
        continue
    
    
    #Creating a grid for each 30 minute starting at the departure time and ending at the return time
    grid = pd.DataFrame(pd.date_range(start=vertrek, end=terug,freq = "0.5H"),columns= ["time"]) 
    
    #putting vaartuig and time into the appropriate columns
    grid["vaartuig"] = schip
    #vertrek en terug are in local time, but we want to have UTC time because it doesnt change when moving time zones
    grid['UTC time'] = grid['time'] - pd.Timedelta('1 hours') 
    
    
    #Getting the locations of the ship
    ship_locations = df_ships.loc[schip]
    #Getting the locations of the ship during the trip and sorting on UTC time
    ship_locations_trip =  ship_locations.loc[(ship_locations['local time'] < terug ) & (ship_locations['local time'] > vertrek ),:]
    ship_locations_trip.sort_values(by=['UTC time'],inplace=True) 
    #ship_locations_trip['UTC time this'] = ship_locations_trip['UTC time']
    #ship_locations_trip['UTC time last'] = (ship_locations_trip['UTC time'].shift()).fillna(0)
    #ship_locations_trip['UTC time next'] = (ship_locations_trip['UTC time'].shift(-1)).fillna(0)
    
    #Merge the grid with the location of the closest reported UTC times.
    grid_locations_trip = pd.merge_asof(grid,ship_locations_trip,on = 'UTC time',direction = 'nearest')
    grid_locations_trip.drop(columns=['local time'],inplace=True)
    
    locations_grid = locations_grid.append(grid_locations_trip,ignore_index=True)
    if v%100 ==0:
        print(v)


#change the name of the time column 
locations_grid.rename(columns={"time":"local time"},inplace=True)

#save the file
locations_grid.to_csv(folder+'Output\\'+'locations_grid.csv',index=False)

