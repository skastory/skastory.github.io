###################################################################################################
##  Code for: Illegal Fishing Practices and Nautical Patrol  (Kastoryano & Vollaard)                  
##                                                                                                  
##  Author: Stephen Kastoryano                                      
##  Date  : 01 February 2020                                         
##                                                                   
##  Purpose: Producing Figures and Maps for paper                        
##                                                                    
##  Code input: From Cleaning1_2019_new.R
##                Data_final_1719_new.csv 
##                
##              From replicated manually from Moolenaar and Chen paper
##                MoolChen_graphs.csv 
##
##              From manual transcription based on deploymnet information (summarized in 'No_deploy_2017to2019.csv' >> only 95% sure this is correct info source),
##                deploy_2017to2019.csv
##
##              From Cleaning1_2019_new.R 
##                map_ais.csv
##
##              From 'Data Border' folder
##                'coordinates_english_border.csv', 'coordinates_dutch_belgian_border.csv','coordinates_dutch_german_border.csv','coordinates_danish_german_border.csv','coordinates_danish_norwegian_border.csv' 
##
##              From 'NVWA_data_preparation_3_inspection_location_creator_GEANNOTEERD.py'
##                'vms_combined_bb_seefalke_meerkatze_vestkysten.csv','locatiesbb.csv', 'locatie_seefalke.csv', 'locatie_meerkatze.csv', 'locatie_vestkysten.csv'
##
##                                                                    
##################################################################################################



library("foreign")
library("dplyr")
library("tidyr")
library("ggplot2")
library("reshape2")
library('rdd')



##########################################################################################
###  Generating Distributions from Moolenaar and Chen: Figure 1 and appendix Figure ??
##########################################################################################




df <- read.csv("D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Stephen files\\MoolChen_graphs.csv")



## Sole graphs ##
#################

df$sol80 = (df$sole.80mm.codend.trip1 + df$sole.80mm.codend.trip2)/2
df$sol40 = (df$sole.80mm.codend.trip1 + df$sole.80mm.codend.trip2 + df$sole.40mm.codend.cover.trip1 + df$sole.40mm.codend.cover.trip2)/2
df$sol80w = df$sol80 * df$sole.weight..gr./1000
df$sol40w = df$sol40 * df$sole.weight..gr./1000


dfsol = df[,c("sole.length..cm.","sol80","sol40")]
dfsolw = df[,c("sole.length..cm.","sol80w","sol40w")]

temp_names=c("length","80mm","40mm")
colnames(dfsol) <- temp_names
colnames(dfsolw) <- temp_names


dfsol <- melt(dfsol ,  id.vars = 'length', variable.name = 'Mesh')
dfsolw <- melt(dfsolw ,  id.vars = 'length', variable.name = 'Mesh')


ggplot(dfsol, aes(length, value)) +
  geom_line(aes(colour = Mesh),size=2) +
  geom_vline(xintercept=24, linetype="solid", color = "gray29") +
  geom_vline(xintercept=c(27,30,33,35), linetype="dashed", color = "gray62") +
  annotate('text', x = 21.5, y = 40, label = 'Undersized', angle = 90) +
  annotate('text', x = 25.5, y = 15, label = 'Small', angle = 90) +
  annotate('text', x = 28.5, y = 50, label = 'Medium-Small', angle = 90) +
  annotate('text', x = 31.5, y = 25, label = 'Medium', angle = 90) +
  annotate('text', x = 34, y = 50, label = 'Medium-Large', angle = 90) +
  annotate('text', x = 36.5, y = 15, label = 'Large', angle = 90) +
  ylab("Total number") +
  xlab("Sole length (cm)") +
  theme_bw() +
  theme_classic() +
  theme(legend.position = c(0.1, 0.85)) +
  scale_x_continuous(breaks = round(seq(min(dfsolw$length), max(dfsolw$length), by = 5),1)) 
#ggsave("D:\\Dropbox\\Fishing\\TeX file\\MC_solN.png", width = 7, height = 6)


## Figure 1 (left) ##
ggplot(dfsolw, aes(length, value)) +
  geom_line(aes(colour = Mesh),size=2) +
  geom_vline(xintercept=24, linetype="solid", color = "gray29") +
  geom_vline(xintercept=c(27,30,33,35), linetype="dashed", color = "gray62") +
  annotate('text', x = 21.5, y = 5.1, label = 'Undersized', angle = 90) +
  annotate('text', x = 25.5, y = 2, label = 'Small', angle = 90) +
  annotate('text', x = 28.5, y = 6.1, label = 'Medium-Small', angle = 90) +
  annotate('text', x = 31.5, y = 3.2, label = 'Medium', angle = 90) +
  annotate('text', x = 34, y = 6.6, label = 'Medium-Large', angle = 90) +
  annotate('text', x = 36.5, y = 2.1, label = 'Large', angle = 90) +
  ylab("Weight (kg)") +
  xlab("Length of fish (cm)") +
  theme_bw() +
  theme_classic() +
  theme(legend.position = c(0.15, 0.8)) +
  theme(legend.text = element_text(size=15)) +
  theme(legend.title = element_text(size=15)) +
  theme(legend.key.height= unit(1.1, 'cm'),legend.key.width= unit(1.5, 'cm')) +
  scale_x_continuous(breaks = round(seq(min(dfsolw$length), max(dfsolw$length), by = 5),1)) 
#ggsave("D:\\Dropbox\\Fishing\\TeX file\\MC_solW.png", width = 7, height = 6)




## Plaice graphs ##
#################

df$ple80 = (df$plaice.80mm.codend.trip1 + df$plaice.80mm.codend.trip2)/2
df$ple40 = (df$plaice.80mm.codend.trip1 + df$plaice.80mm.codend.trip2 + df$plaice.40mm.codend.cover.trip1 + df$plaice.40mm.codend.cover.trip2)/2
df$ple80w = df$ple80 * df$plaice.weight..gr./1000
df$ple40w = df$ple40 * df$plaice.weight..gr./1000


dfple = df[,c("plaice.length..cm.","ple80","ple40")]
dfple = dfple[!is.na(dfple$plaice.length..cm.),]
dfplew = df[,c("plaice.length..cm.","ple80w","ple40w")]
dfplew = dfplew[!is.na(dfplew$plaice.length..cm.),]


temp_names=c("length","80mm","40mm")
colnames(dfple) <- temp_names
colnames(dfplew) <- temp_names


dfple <- melt(dfple ,  id.vars = 'length', variable.name = 'Mesh')
dfplew <- melt(dfplew ,  id.vars = 'length', variable.name = 'Mesh')


ggplot(dfple, aes(length, value)) +
  geom_line(aes(colour = Mesh),size=2) +
  geom_vline(xintercept=27, linetype="solid", color = "gray29") +
  geom_vline(xintercept=c(30,33,35), linetype="dashed", color = "gray62") +
  annotate('text', x = 28.5, y = 100, label = 'Medium-Small', angle = 90) +
  annotate('text', x = 31.5, y = 55, label = 'Medium', angle = 90) +
  annotate('text', x = 34, y = 100, label = 'Medium-Large', angle = 90) +
  annotate('text', x = 36.5, y = 40, label = 'Large', angle = 90) +
  ylab("Total number caught") +
  xlab("Plaice length (cm)") +
  theme_bw() +
  theme_classic() +
  theme(legend.position = c(0.1, 0.85)) +
  scale_x_continuous(breaks = round(seq(10, 35, by = 5),1)) 
ggsave("D:\\Dropbox\\Fishing\\TeX file\\MC_pleN.png", width = 7, height = 6)


## Figure 1 (right) ##
ggplot(dfplew, aes(length, value)) +
  geom_line(aes(colour = Mesh),size=2) +
  geom_vline(xintercept=27, linetype="solid", color = "gray29") +
  geom_vline(xintercept=c(30,33,35), linetype="dashed", color = "gray62") +
  annotate('text', x = 24.5, y = 8, label = 'Undersized', angle = 90) +
  annotate('text', x = 28.5, y = 10, label = 'Medium-Small', angle = 90) +
  annotate('text', x = 31.5, y = 5, label = 'Medium', angle = 90) +
  annotate('text', x = 34, y = 9.5, label = 'Medium-Large', angle = 90) +
  annotate('text', x = 36.5, y = 3.5, label = 'Large', angle = 90) +
  ylab("Weight (kg)") +
  xlab("Length of fish (cm)") +
  theme_bw() +
  theme_classic() +
  theme(legend.position = c(0.15, 0.8)) +
  theme(legend.text = element_text(size=15)) +
  theme(legend.title = element_text(size=15)) +
  theme(legend.key.height= unit(1.1, 'cm'),legend.key.width= unit(1.5, 'cm')) +
  scale_x_continuous(breaks = round(seq(10, 35, by = 5),1)) 
ggsave("D:\\Dropbox\\Fishing\\TeX file\\MC_pleW.png", width = 7, height = 6)





##  Produce rotation graphs for explanation in section Patrolled vs. Non-patrolled weekdays  ##
###############################################################################################


df <- read.csv("D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Stephen files\\MoolChen_graphs.csv")


## Sole graphs ##
#################

df$sol80 = (df$sole.80mm.codend.trip1 + df$sole.80mm.codend.trip2)/2
df$sol40 = (df$sole.80mm.codend.trip1 + df$sole.80mm.codend.trip2 + df$sole.40mm.codend.cover.trip1 + df$sole.40mm.codend.cover.trip2)/2
df$sol80w = df$sol80 * df$sole.weight..gr./1000
df$sol40w = df$sol40 * df$sole.weight..gr./1000


dfsol = df[,c("sole.length..cm.","sol80","sol40")]
dfsolw = df[,c("sole.length..cm.","sol80w","sol40w")]

temp_names=c("length","mm80","mm40")
colnames(dfsol) <- temp_names
colnames(dfsolw) <- temp_names


# Rescale 40mm distribution to have 'above 24 weight total 40mm' = 'above 24 weight total 80mm'
kern = kernelwts(dfsolw$length[1:25], median(dfsolw$length), 20, kernel = "gaussian")*length(dfsolw$length)  # You can play around with kernel to get the figure you want
length(dfsolw$length[1:25])
scale= sum(dfsolw$mm80*(dfsolw$length >= 24)*(dfsolw$length < 35))/sum(dfsolw$mm40[1:25]*(dfsolw$length[1:25] >= 24)*(dfsolw$length[1:25] < 35)* kern)   # scaled with gaussian kernel weighting to emulate real life shift in distribution in which tails of length distribution less sensitive than center of distribution to changes in mesh size (seems like the right assumption to me)
mm40scaled1 = dfsolw$mm40[1:25] * scale  * kern
#mm40scaled1 = dfsolw$mm40[1:25]     # Unscaled version. Uncomment this to produce
dfsolw$mm40scaled = c(mm40scaled1,dfsolw$mm80[26:33])



# Check these two sums are equal
sum(dfsolw$mm80*(dfsolw$length >= 24))
sum(dfsolw$mm40scaled*(dfsolw$length >= 24))


# Check shares and 'effect' of using illegal small mesh
share40_Small = sum(dfsolw$mm40scaled * (dfsolw$length >= 24) * (dfsolw$length < 27))/sum(dfsolw$mm40scaled*(dfsolw$length >= 24))
share40_MSmall = sum(dfsolw$mm40scaled * (dfsolw$length >= 27) * (dfsolw$length < 30))/sum(dfsolw$mm40scaled*(dfsolw$length >= 24))
share40_Med = sum(dfsolw$mm40scaled * (dfsolw$length >= 30) * (dfsolw$length < 33))/sum(dfsolw$mm40scaled*(dfsolw$length >= 24))
share40_MLarge= sum(dfsolw$mm40scaled * (dfsolw$length >= 33) * (dfsolw$length < 35))/sum(dfsolw$mm40scaled*(dfsolw$length >= 24))
share40_Large = sum(dfsolw$mm40scaled * (dfsolw$length >= 35))/sum(dfsolw$mm40scaled*(dfsolw$length >= 24))

share80_Small = sum(dfsolw$mm80 * (dfsolw$length >= 24) * (dfsolw$length < 27))/sum(dfsolw$mm80*(dfsolw$length >= 24))
share80_MSmall = sum(dfsolw$mm80 * (dfsolw$length >= 27) * (dfsolw$length < 30))/sum(dfsolw$mm80*(dfsolw$length >= 24))
share80_Med = sum(dfsolw$mm80 * (dfsolw$length >= 30) * (dfsolw$length < 33))/sum(dfsolw$mm80*(dfsolw$length >= 24))
share80_MLarge= sum(dfsolw$mm80 * (dfsolw$length >= 33) * (dfsolw$length < 35))/sum(dfsolw$mm80*(dfsolw$length >= 24))
share80_Large = sum(dfsolw$mm80 * (dfsolw$length >= 35))/sum(dfsolw$mm80*(dfsolw$length >= 24))

# These shares are close enough to the tradeoffs we see 
share80_Small-share40_Small
share80_MSmall-share40_MSmall
share80_Med-share40_Med
share80_MLarge-share40_MLarge
share80_Large-share40_Large


# LATE Denominator calculation for share of illegal fishing vessel 'compliers'
LATEden_Small = 0.0056/(share80_Small-share40_Small)
LATEden_Med = 0.0043/(share80_Med-share40_Med)
LATEden_MLarge = 0.0023/(share80_MLarge-share40_MLarge)

LATEden = abs(LATEden_Small) 
LATEden

LATEden = (abs(LATEden_Small) + abs(LATEden_Med) + abs(LATEden_MLarge))/3
LATEden

# Check implied difference in juvenile fish weight caught
sum(dfsolw$mm80)
sum(dfsolw$mm40scaled)


dfsolw = dfsolw[,c("length","mm80","mm40scaled" )]
temp_names=c("length","80mm","40mm scaled")
colnames(dfsolw) <- temp_names




dfsolw <- melt(dfsolw ,  id.vars = 'length', variable.name = 'Mesh')




## Figure 10 ##
ggplot(dfsolw, aes(length, value)) +
  geom_line(aes(colour = Mesh),size=2) +
  geom_vline(xintercept=24, linetype="solid", color = "gray29") +
  geom_vline(xintercept=c(27,30,33,35), linetype="dashed", color = "gray62") +
  annotate('text', x = 21.5, y = 5.1, label = 'Undersized', angle = 90) +
  annotate('text', x = 25.5, y = 2, label = 'Small', angle = 90) +
  annotate('text', x = 28.5, y = 6.1, label = 'Medium-Small', angle = 90) +
  annotate('text', x = 31.5, y = 3.2, label = 'Medium', angle = 90) +
  annotate('text', x = 34, y = 6.6, label = 'Medium-Large', angle = 90) +
  annotate('text', x = 36.5, y = 2.1, label = 'Large', angle = 90) +
  ylab("Weight (kg)") +
  xlab("Length of fish (cm)") +
  theme_bw() +
  theme_classic() +
  theme(legend.position = c(0.20, 0.8)) +
  theme(legend.text = element_text(size=15)) +
  theme(legend.title = element_text(size=15)) +
  theme(legend.key.height= unit(1.1, 'cm'),legend.key.width= unit(1.5, 'cm')) +
  scale_x_continuous(breaks = round(seq(min(dfsolw$length), max(dfsolw$length), by = 5),1)) +
  ggsave("D:\\Dropbox\\Fishing\\TeX file\\GraphMC_scaled.png", width = 7, height = 6)





##  Produce rotation graphs for reconstruction of juvenile excess mortality   ##
################################################################################


df <- read.csv("D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Stephen files\\MoolChen_graphs.csv")



## Sole graphs ##
#################


df$sol80 = (df$sole.80mm.codend.trip1 + df$sole.80mm.codend.trip2)/2
df$sol40 = (df$sole.80mm.codend.trip1 + df$sole.80mm.codend.trip2 + df$sole.40mm.codend.cover.trip1 + df$sole.40mm.codend.cover.trip2)/2
df$sol80w = df$sol80 * df$sole.weight..gr./1000
df$sol40w = df$sol40 * df$sole.weight..gr./1000


dfsol = df[,c("sole.length..cm.","sol80","sol40")]
dfsolw = df[,c("sole.length..cm.","sol80w","sol40w")]

temp_names=c("length","mm80","mm40")
colnames(dfsol) <- temp_names
colnames(dfsolw) <- temp_names


# Rescale 40mm distribution to have 'above 24 weight total 40mm' = 'above 24 weight total 80mm'
kern = kernelwts(dfsolw$length[1:25], median(dfsolw$length), 15, kernel = "gaussian")*length(dfsolw$length)  # You can play around with kernel to get the figure you want
length(dfsolw$length[1:25])
scale= sum(dfsolw$mm80*(dfsolw$length >= 24)*(dfsolw$length < 35))/sum(dfsolw$mm40[1:25]*(dfsolw$length[1:25] >= 24)*(dfsolw$length[1:25] < 35)* kern)   # scaled with gaussian kernel weighting to emulate real life shift in distribution in which tails of length distribution less sensitive than center of distribution to changes in mesh size (seems like the right assumption to me)
mm40scaled1 = dfsolw$mm40[1:25] * scale  * kern
dfsolw$mm40scaled = c(mm40scaled1,dfsolw$mm80[26:33])



# Scale such that quantities reflect average total landed weight in data (mean = 1698.739kg)
rescale= (1698.739/sum(dfsolw$mm80*(dfsolw$length >= 24)))
dfsolw$mm80 = dfsolw$mm80*rescale 
dfsolw$mm40scaled = dfsolw$mm40scaled*rescale 

# Check these two sums are equal
sum(dfsolw$mm80*(dfsolw$length >= 24))
sum(dfsolw$mm40scaled*(dfsolw$length >= 24))


# Check shares and 'effect' of using illegal small mesh
share40_Small = sum(dfsolw$mm40scaled * (dfsolw$length >= 24) * (dfsolw$length <= 27))/(sum(dfsolw$mm40scaled*(dfsolw$length >= 24)) + sum(dfsolw$mm40scaled*(dfsolw$length == 27)) + sum(dfsolw$mm40scaled*(dfsolw$length == 30)) +  sum(dfsolw$mm40scaled*(dfsolw$length == 33)) + sum(dfsolw$mm40scaled*(dfsolw$length == 35)))
share40_MSmall = sum(dfsolw$mm40scaled * (dfsolw$length >= 27) * (dfsolw$length <= 30))/(sum(dfsolw$mm40scaled*(dfsolw$length >= 24)) + sum(dfsolw$mm40scaled*(dfsolw$length == 27)) + sum(dfsolw$mm40scaled*(dfsolw$length == 30)) +  sum(dfsolw$mm40scaled*(dfsolw$length == 33)) + sum(dfsolw$mm40scaled*(dfsolw$length == 35)))
share40_Med = sum(dfsolw$mm40scaled * (dfsolw$length >= 30) * (dfsolw$length <= 33))/(sum(dfsolw$mm40scaled*(dfsolw$length >= 24)) + sum(dfsolw$mm40scaled*(dfsolw$length == 27)) + sum(dfsolw$mm40scaled*(dfsolw$length == 30)) +  sum(dfsolw$mm40scaled*(dfsolw$length == 33)) + sum(dfsolw$mm40scaled*(dfsolw$length == 35)))
share40_MLarge= sum(dfsolw$mm40scaled * (dfsolw$length >= 33) * (dfsolw$length <= 35))/(sum(dfsolw$mm40scaled*(dfsolw$length >= 24)) + sum(dfsolw$mm40scaled*(dfsolw$length == 27)) + sum(dfsolw$mm40scaled*(dfsolw$length == 30)) +  sum(dfsolw$mm40scaled*(dfsolw$length == 33)) + sum(dfsolw$mm40scaled*(dfsolw$length == 35)))
share40_Large = sum(dfsolw$mm40scaled * (dfsolw$length >= 35))/(sum(dfsolw$mm40scaled*(dfsolw$length >= 24)) + sum(dfsolw$mm40scaled*(dfsolw$length == 27)) + sum(dfsolw$mm40scaled*(dfsolw$length == 30)) +  sum(dfsolw$mm40scaled*(dfsolw$length == 33)) + sum(dfsolw$mm40scaled*(dfsolw$length == 35)))

share80_Small = sum(dfsolw$mm80 * (dfsolw$length >= 24) * (dfsolw$length <= 27))/(sum(dfsolw$mm80*(dfsolw$length >= 24)) + sum(dfsolw$mm40scaled*(dfsolw$length == 27)) + sum(dfsolw$mm40scaled*(dfsolw$length == 30)) +  sum(dfsolw$mm40scaled*(dfsolw$length == 33)) + sum(dfsolw$mm40scaled*(dfsolw$length == 35)))
share80_MSmall = sum(dfsolw$mm80 * (dfsolw$length >= 27) * (dfsolw$length <= 30))/(sum(dfsolw$mm80*(dfsolw$length >= 24)) + sum(dfsolw$mm40scaled*(dfsolw$length == 27)) + sum(dfsolw$mm40scaled*(dfsolw$length == 30)) +  sum(dfsolw$mm40scaled*(dfsolw$length == 33)) + sum(dfsolw$mm40scaled*(dfsolw$length == 35)))
share80_Med = sum(dfsolw$mm80 * (dfsolw$length >= 30) * (dfsolw$length <= 33))/(sum(dfsolw$mm80*(dfsolw$length >= 24)) + sum(dfsolw$mm40scaled*(dfsolw$length == 27)) + sum(dfsolw$mm40scaled*(dfsolw$length == 30)) +  sum(dfsolw$mm40scaled*(dfsolw$length == 33)) + sum(dfsolw$mm40scaled*(dfsolw$length == 35)))
share80_MLarge= sum(dfsolw$mm80 * (dfsolw$length >= 33) * (dfsolw$length <= 35))/(sum(dfsolw$mm80*(dfsolw$length >= 24)) + sum(dfsolw$mm40scaled*(dfsolw$length == 27)) + sum(dfsolw$mm40scaled*(dfsolw$length == 30)) +  sum(dfsolw$mm40scaled*(dfsolw$length == 33)) + sum(dfsolw$mm40scaled*(dfsolw$length == 35)))
share80_Large = sum(dfsolw$mm80 * (dfsolw$length >= 35))/(sum(dfsolw$mm80*(dfsolw$length >= 24)) + sum(dfsolw$mm40scaled*(dfsolw$length == 27)) + sum(dfsolw$mm40scaled*(dfsolw$length == 30)) +  sum(dfsolw$mm40scaled*(dfsolw$length == 33)) + sum(dfsolw$mm40scaled*(dfsolw$length == 35)))


# These shares keep the similar proportions from effects found in paper but are scaled to be 5 times larger.
# All reconstruction results must therefore be divided by 5
share40_Small- share80_Small
share40_MSmall-share80_MSmall
share40_Med-share80_Med
share40_MLarge-share80_MLarge
share40_Large-share80_Large

# Check implied difference in juvenile fish weight caught
sum(dfsolw$mm80)
sum(dfsolw$mm40scaled)


dfsolwN = dfsolw[,c("length","mm80","mm40scaled" )]
temp_names=c("length","80mm","40mm scaled")
colnames(dfsolwN) <- temp_names


dfsolw_fig <- melt(dfsolwN ,  id.vars = 'length', variable.name = 'Mesh')


## Figure 36a appendix ##
ggplot(dfsolw_fig, aes(length, value)) +
  geom_line(aes(colour = Mesh),size=2) +
  geom_vline(xintercept=24, linetype="solid", color = "gray29") +
  geom_vline(xintercept=c(27,30,33,35), linetype="dashed", color = "gray62") +
  annotate('text', x = 21.5, y = 20, label = 'Undersized', angle = 90) +
  annotate('text', x = 25.5, y = 12, label = 'Small', angle = 90) +
  annotate('text', x = 28.5, y = 24, label = 'Medium-Small', angle = 90) +
  annotate('text', x = 31.5, y = 15, label = 'Medium', angle = 90) +
  annotate('text', x = 34, y = 24, label = 'Medium-Large', angle = 90) +
  annotate('text', x = 36.5, y = 12, label = 'Large', angle = 90) +
  ylab("Weight (kg)") +
  xlab("Length of fish (cm)") +
  theme_bw() +
  theme_classic() +
  theme(legend.position = c(0.20, 0.8)) +
  theme(legend.text = element_text(size=15)) +
  theme(legend.title = element_text(size=15)) +
  theme(legend.key.height= unit(1.1, 'cm'),legend.key.width= unit(1.5, 'cm')) +
  scale_x_continuous(breaks = round(seq(min(dfsolw$length), max(dfsolw$length), by = 5),1)) +
 ggsave("D:\\Dropbox\\Fishing\\TeX file\\GraphMC_recon.png", width = 7, height = 6)


# Calculate areas under curve to left of 24cm from above graph
dfsolw$length[1:14]
# In terms of weight
weight80 = sum(dfsolw$mm80[1:14]) # number of weight 80mm mesh under 24cm in length  (remember df[1:16,2] in grams which is why you divide by 1000)
weight40 = sum(dfsolw$mm40scaled[1:14])   # number of weight 80mm mesh under 24cm in length
(weight40-weight80)/5  # difference in area under curve for one vessel-trip. This is the excess mortality of juvenile sole for one vessel-trip in our data. 
(weight40-weight80)*1523*0.82/5
# We divide by 5 to reflect the accurate proportion of the effect given our Figure ( You can think of this as 2 ships fishing according to the above graph and 8 fishing with 0 effect)

weight80*1523*0.82 # total weight juvenile sole bycatch with 80mm mesh
(sum(dfsolw$mm80)-weight80)*1523*0.82  # total weight adult sole with 80mm mesh

# In terms of units
units80 = sum(dfsolw$mm80[1:14]/(df[1:14,2]/1000)) # number of units 80mm mesh under 24cm in length  (remember df[1:16,2] in grams which is why you divide by 1000)
units40 = sum(dfsolw$mm40scaled[1:14]/(df[1:14,2]/1000))   # number of units 80mm mesh under 24cm in length
(units40-units80)/5  # difference in area under curve for one vessel-trip. This is the excess mortality of juvenile sole for one vessel-trip in our data.
(units40-units80)*1523*0.82/5 # Total yearly effect for 13 non-patrolled weeks
# We divide by 5 to reflect the accurate proportion of the effect given our Figure ( You can think of this as 2 ships fshing accoring to the above graph and 8 fishing with 0 effect)

units80*1523*0.82 # total juvenile sole bycatch with 80mm mesh
(sum(dfsolw$mm80/(df[,2]/1000))-units80)*1523*0.82  # total adult sole with 80mm mesh






##  Produce rotation graphs for reconstruction of juvenile excess mortality   ##
################################################################################


df <- read.csv("D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Stephen files\\MoolChen_graphs.csv")


## Plaice graphs rescaled by sole rescaling (since sole is target) ##
####################################################################



df$ple80 = (df$plaice.80mm.codend.trip1 + df$plaice.80mm.codend.trip2)/2
df$ple40 = (df$plaice.80mm.codend.trip1 + df$plaice.80mm.codend.trip2 + df$plaice.40mm.codend.cover.trip1 + df$plaice.40mm.codend.cover.trip2)/2
df$ple80w = df$ple80 * df$plaice.weight..gr./1000
df$ple40w = df$ple40 * df$plaice.weight..gr./1000


dfple = df[,c("plaice.length..cm.","ple80","ple40")]
dfple = dfple[!is.na(dfple$plaice.length..cm.),]
dfplew = df[,c("plaice.length..cm.","ple80w","ple40w")]
dfplew = dfple[!is.na(dfplew$plaice.length..cm.),]


temp_names=c("length","mm80","mm40")
colnames(dfple) <- temp_names
colnames(dfplew) <- temp_names


df$sol80 = (df$sole.80mm.codend.trip1 + df$sole.80mm.codend.trip2)/2
df$sol40 = (df$sole.80mm.codend.trip1 + df$sole.80mm.codend.trip2 + df$sole.40mm.codend.cover.trip1 + df$sole.40mm.codend.cover.trip2)/2
df$sol80w = df$sol80 * df$sole.weight..gr./1000
df$sol40w = df$sol40 * df$sole.weight..gr./1000


dfsol = df[,c("sole.length..cm.","sol80","sol40")]
dfsolw = df[,c("sole.length..cm.","sol80w","sol40w")]

temp_names=c("length","mm80","mm40")
colnames(dfsol) <- temp_names
colnames(dfsolw) <- temp_names


# Rescale 40mm distribution to have 'above 24 weight total 40mm' = 'above 24 weight total 80mm'
kern = kernelwts(dfsolw$length[1:25], median(dfsolw$length),15, kernel = "gaussian")*length(dfsolw$length)  # You can play around with kernel to get the figure you want
length(dfsolw$length[1:25])
scale= sum(dfsolw$mm80*(dfsolw$length >= 24)*(dfsolw$length < 35))/sum(dfsolw$mm40[1:25]*(dfsolw$length[1:25] >= 24)*(dfsolw$length[1:25] < 35)* kern)   # scaled with gaussian kernel weighting to emulate real life shift in distribution in which tails of length distribution less sensitive than center of distribution to changes in mesh size (seems like the right assumption to me)
mm40scaled1 = dfplew$mm40[3:23] * scale  * kern[1:21] 
dfplew$mm40scaled = c(dfplew$mm80[1:2],mm40scaled1)



# Scale such that quantities reflect average total landed weight in data (mean = 4451.721kg)
rescale = (4451.721/sum(dfplew$mm80*(dfplew$length >= 27)))
dfplew$mm80 = dfplew$mm80*rescale
dfplew$mm40scaled = dfplew$mm40scaled*rescale




# Check shares and 'effect' of using illegal small mesh
share40_MSmall = sum(dfplew$mm40scaled * (dfplew$length >= 27) * (dfplew$length < 30))/sum(dfplew$mm40scaled*(dfplew$length >= 24))
share40_Med = sum(dfplew$mm40scaled * (dfplew$length >= 30) * (dfplew$length < 33))/sum(dfplew$mm40scaled*(dfplew$length >= 24))
share40_MLarge= sum(dfplew$mm40scaled * (dfplew$length >= 33) * (dfplew$length < 35))/sum(dfplew$mm40scaled*(dfplew$length >= 24))
share40_Large = sum(dfplew$mm40scaled * (dfplew$length >= 35))/sum(dfplew$mm40scaled*(dfplew$length >= 24))

share80_MSmall = sum(dfplew$mm80 * (dfplew$length >= 27) * (dfplew$length < 30))/sum(dfplew$mm80*(dfplew$length >= 24))
share80_Med = sum(dfplew$mm80 * (dfplew$length >= 30) * (dfplew$length < 33))/sum(dfplew$mm80*(dfplew$length >= 24))
share80_MLarge= sum(dfplew$mm80 * (dfplew$length >= 33) * (dfplew$length < 35))/sum(dfplew$mm80*(dfplew$length >= 24))
share80_Large = sum(dfplew$mm80 * (dfplew$length >= 35))/sum(dfplew$mm80*(dfplew$length >= 24))

share40_MSmall-share80_MSmall
share40_Med-share80_Med
share40_MLarge-share80_MLarge
share40_Large-share80_Large

# Check implied difference in juvenile fish weight caught
sum(dfplew$mm80)
sum(dfplew$mm40scaled)


dfplewN = dfplew[,c("length","mm80","mm40scaled" )]
temp_names=c("length","80mm","40mm scaled")
colnames(dfplewN) <- temp_names






dfplew_fig <- melt(dfplewN ,  id.vars = 'length', variable.name = 'Mesh')


## Figure 36b appendix ##
ggplot(dfplew_fig, aes(length, value)) +
  geom_line(aes(colour = Mesh),size=2) +
  geom_vline(xintercept=27, linetype="solid", color = "gray29") +
  geom_vline(xintercept=c(30,33,35), linetype="dashed", color = "gray62") +
  annotate('text', x = 24.5, y = 8100, label = 'Undersized', angle = 90) +
  annotate('text', x = 28.5, y = 8900, label = 'Medium-Small', angle = 90) +
  annotate('text', x = 31.5, y = 6000, label = 'Medium', angle = 90) +
  annotate('text', x = 34, y = 8500, label = 'Medium-Large', angle = 90) +
  annotate('text', x = 36.5, y = 4700, label = 'Large', angle = 90) +
  ylab("Weight (kg)") +
  xlab("Length of fish (cm)") +
  theme_bw() +
  theme_classic() +
  theme(legend.position = c(0.20, 0.87)) +
  theme(legend.text = element_text(size=15)) +
  theme(legend.title = element_text(size=15)) +
  theme(legend.key.height= unit(1.1, 'cm'),legend.key.width= unit(1.5, 'cm')) +
  scale_x_continuous(breaks = round(seq(10, 35, by = 5),1)) +
 ggsave("D:\\Dropbox\\Fishing\\TeX file\\GraphMC_recon_ple.png", width = 7, height = 6)
 





dfplew$length[1:20]
# Calculate areas under curve to left of 27cm from above graph
weight80 = sum(dfplew$mm80[1:19]) # number of weight 80mm mesh under 27cm in length  (remember df[1:20,2] in grams which is why you divide by 1000)
weight40 = sum(dfplew$mm40scaled[1:19])   # number of weight 80mm mesh under 24cm in length
(weight40-weight80)/5  # difference in area under curve for one vessel-trip. This is the excess mortality of juvenile plaice for one vessel-trip in our data.
(weight40-weight80)*1523*0.76/5
# We divide by 5 to reflect the accurate proportion of the effect given our Figure ( You can think of this as 2 ships fshing accoring to the above graph and 8 fishing with 0 effect)

weight80*1523*0.76 # total weight juvenile plaice bycatch with 80mm mesh
(sum(dfplew$mm80)-weight80)*1523*0.76  # total weight adult plaice with 80mm mesh

units80 = sum(dfplew$mm80[1:19]/(df[1:19,8]/1000)) # number of units 80mm mesh under 24cm in length  (remember df[1:20,2] in grams which is why you divide by 1000)
units40 = sum(dfplew$mm40scaled[1:19]/(df[1:19,8]/1000))   # number of units 80mm mesh under 24cm in length
(units40-units80)/5  # difference in area under curve for one vessel-trip. This is the excess mortality of juvenile plaice for one vessel-trip in our data.
(units40-units80)*1523*0.76/5 # Total yearly effect for 13 non-patrolled weeks
# We divide by 5 to reflect the accurate proportion of the effect given our Figure ( You can think of this as 2 ships fshing accoring to the above graph and 8 fishing with 0 effect)

units80*1523*0.76 # total juvenile plaice bycatch with 80mm mesh
(sum(dfplew$mm80/(df[1:23,8]/1000))-units80)*1523*0.76  # total adult plaice with 80mm mesh














##########################################################################################
###  Generating trends graphs: Figure 2 and appendix Figure ??
##########################################################################################


###  SOLE ANALYSIS
####################

dataset <- read.csv("D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Stephen files\\Data_final_1719_new.csv")
dataset = dataset[,-1]
#data = read.csv(file,colClasses = c("character", "numeric",rep("character",5),rep("numeric",49),'character',
#                                        rep("numeric",6),'character',rep("numeric",6), rep("numeric",116)), na.strings=c(""," ","NA"))
dat_list = cbind(dataset$week_index,dataset$verkoop_sol_levend_1,dataset$verkoop_sol_levend_2,dataset$verkoop_sol_levend_3,dataset$verkoop_sol_levend_4,dataset$verkoop_sol_levend_5,dataset$verkoop_sol_levend_7)
data_mean = aggregate(dat_list, list(dat_list[,1]), mean)
data_mean = data_mean[,2:ncol(data_mean)]
temp_names=c("week_index","Large","Medium-Large","Medium", "Medium-Small", "Small", "Undersized")
temp_names=c("week_index","Large","Med.-Large","Medium", "Med.-Small", "Small", "Undersized")
colnames(data_mean) <- temp_names



data_mean <- melt(data_mean ,  id.vars = 'week_index', variable.name = 'Size_Category')

# Below are all full weeks during which BB was not patrolling
# 2017: 1 10 11 17 21 22 27 28 29 30 31 32 33 42 50 52 
# 2018: 53 58 59 61 62 70 73 74 82 83 84 85 86 87 94 96 97 104
# 2019: 105 114 115 116 124 125 128 131 132 133 134 135 136 137 140 141 146 147 148 149 153 155 156


No_BB = c( 1,10, 11, 17,21,22, 27,28, 29, 30, 31, 32, 33, 42,50, 52, 53,58,59, 61,62,70,73,74, 82,83, 84, 85, 86, 87, 94, 96, 97,104,105, 114,115, 116, 124, 125, 128,  131,132, 133, 134, 135, 136, 137, 140, 141, 146,147, 148 , 149, 153, 155,156 )
All = seq(1,156)
BB_depl = All[!(All  %in% No_BB)]



## Figure 2 ##
ggplot(data_mean, aes(week_index, value)) +
  geom_line(aes(colour = Size_Category)) +
  geom_vline(xintercept=No_BB, linetype="dashed", color = "gray73") +
  ylab("Average Catch (kg)") +
  xlab("Date (Year-week)") +
  scale_x_continuous(breaks=c(1, 53, 105,157),labels=c("1" = "2017-1", "53" = "2018-1", "105" = "2019-1",  "157" = "2020-01")) +
  theme_bw() +
  theme_classic() +
  theme(legend.position = c(0.27, 0.95), legend.direction = "horizontal") +
  theme(legend.text = element_text(size=13)) +
  theme(legend.title = element_text(size=13)) +
ggsave("D:\\Dropbox\\Fishing\\TeX file\\trend_sol.png", width = 11, height = 6)





# Creating a histogram that shows the average catch per trip per fishing vessel
hist(dataset$avg_catch_per_trip,breaks=100,xlim=c(0,4000),xlab="Average Landed Sole per Trip for Fishing Vessels (in kg)",main="", col=c("#0099FF"))

hist(dataset$kg_totaal,breaks=200,xlim=c(0,10000),xlab="Total Landed Sole per Trip (in kg)",main="", col=c("#0099FF"))

hist(dataset$lengte_over_alles,breaks=60,xlim=c(0,50),xlab="Ship Length",main="", col=c("#0099FF"))
hist(dataset$tonnage,breaks=60,xlim=c(0,600),xlab="Tons",main="", col=c("#0099FF"))
hist(dataset$vermogen,breaks=60,xlim=c(0,1500),xlab="Power",main="", col=c("#0099FF"))


dataset <- read.csv("D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Data Visvangst\\VIS_KUB_Dagvangsten.csv")
table(dataset$VISTUIG_FAO_CODE)
table(dataset$VISTUIG_MAASWIJDTE)






###  PLAICE ANALYSIS
######################




dataset <- read.csv("D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Stephen files\\Data_final_1719_new.csv")
dataset = dataset[,-1]
#data = read.csv(file,colClasses = c("character", "numeric",rep("character",5),rep("numeric",49),'character',
#                                        rep("numeric",6),'character',rep("numeric",6), rep("numeric",116)), na.strings=c(""," ","NA"))
dat_list = cbind(dataset$week_index,dataset$verkoop_ple_levend_1,dataset$verkoop_ple_levend_2,dataset$verkoop_ple_levend_3,dataset$verkoop_ple_levend_4,dataset$verkoop_ple_levend_7)
data_mean = aggregate(dat_list, list(dat_list[,1]), mean)
data_mean = data_mean[,2:ncol(data_mean)]
temp_names=c("week_index","Large","Medium-Large","Medium", "Medium-Small", "Undersized")
temp_names=c("week_index","Large","Medium-Large","Medium", "Medium-Small",  "Undersized")
colnames(data_mean) <- temp_names


data_mean <- melt(data_mean ,  id.vars = 'week_index', variable.name = 'Size_Category')

# Below are all full weeks during which BB was not patrolling
# 2017: 1 10 11 17 21 22 27 28 29 30 31 32 33 42 50 52 
# 2018: 53 58 59 61 62 70 73 74 82 83 84 85 86 87 94 96 97 104
# 2019: 105 114 115 116 124 125 128 131 132 133 134 135 136 137 140 141 146 147 148 149 153 155 156

No_BB = c( 1,10, 11, 17,21,22, 27,28, 29, 30, 31, 32, 33, 42,50, 52, 53,58,59, 61,62,70,73,74, 82,83, 84, 85, 86, 87, 94, 96, 97,104,105, 114,115, 116, 124, 125, 128,  131,132, 133, 134, 135, 136, 137, 140, 141, 146,147, 148 , 149, 153, 155,156 )
All = seq(1,156)
BB_depl = All[!(All  %in% No_BB)]



## Figure 34 appendix ##
ggplot(data_mean, aes(week_index, value)) +
  geom_line(aes(colour = Size_Category)) +
  geom_vline(xintercept=No_BB, linetype="dashed", color = "gray73") +
  ylab("Average Catch (kg)") +
  xlab("Date (Year-week)") +
  scale_x_continuous(breaks=c(1, 53, 105,157),labels=c("1" = "2017-1", "53" = "2018-1", "105" = "2019-1",  "157" = "2020-01")) +
  theme_bw() +
  theme_classic() +
  theme(legend.position = c(0.58, 0.97), legend.direction = "horizontal") +
  theme(legend.text = element_text(size=13)) +
  theme(legend.title = element_text(size=13)) +
  ggsave("D:\\Dropbox\\Fishing\\TeX file\\trend_ple.png", width = 11, height = 6)







##########################################################################################
###  Generating outcome and other statistics: Figure 3 and appendix Figure ??
##########################################################################################





library("dplyr")
library("tidyr")
library("ggplot2")


df <- read.csv( "D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Stephen files\\Data_final_1719_new.csv")
df = df[,-1]
## Selection and scaling on dependent variables ##
#################################################



low_landing = 50   # set equal shares and lower bound quantities if total kg landed is below low_share



# Define length of fishing trip
df$vertrek = as.Date(df$vertrek,format="%Y-%m-%d")
df$terugkeer = as.Date(df$terugkeer,format="%Y-%m-%d")

df$length_trip = (as.numeric(df$terugkeer)-as.numeric(df$vertrek))+1
table(df$length_trip)
df$log_length_trip = log(df$length_trip)


vesselID = unique(df$vaartuig)  #Obtain unique vessel ids to find overlap with daily data

table(df$length_trip)   # distribution of trip length
sum(as.numeric(df$length_trip<7))/nrow(df) # fraction of trips 6 days or under
table(df$day_dep)       # distribution of departure day
(sum(as.numeric(df$day_dep=="Monday"))+ sum(as.numeric(df$day_dep=="Sunday")))/nrow(df) # share of trips departing Sunday or Monday
table(df$day_return)    # distribution of return day
(sum(as.numeric(df$day_return=="Friday"))+ sum(as.numeric(df$day_dep=="Thursday")))/nrow(df) # share of trips departing Sunday or Monday


# Define dummy for whether vessel fished in a given week
df$fished_sol1 = as.numeric(df$kg_totaal>low_landing)


## Sole ##
##########

###  Figure 3 (left)  ###
hist(df$kg_totaal,breaks=200,xlim=c(0,8000),ylab="Number of trips",xlab="Total weight of landed sole in a single trip (in kg)",main="", col=c("#0099FF"))

###  Figure 3 (right)  ###
avg_catch_per_trip = aggregate(x=df$kg_totaal, by=list(df$vaartuig),FUN=mean)
hist(avg_catch_per_trip[,2],breaks=50,xlim=c(0,5000),ylab="Number of vessels",xlab="Average weight of landed sole per trip (in kg)",main="", col=c("#0099FF"))

## Plaice ##
############

###  Appendix ?? (left)  ###
hist(df$kg_totaal_ple,breaks=200,xlim=c(0,35000),ylab="Number of trips",xlab="Total weight of landed plaice in a single trip (in kg)",main="", col=c("#0099FF"))

###  Appendix ?? (right)  ###
avg_catch_per_trip_ple = aggregate(x=df$kg_totaal_ple, by=list(df$vaartuig),FUN=mean)
hist(avg_catch_per_trip_ple[,2],breaks=50,xlim=c(0,21000),ylab="Number of vessels",xlab="Average weight of landed plaice per trip (in kg)",main="", col=c("#0099FF"))
table(df$avg_catch_per_trip)



###  Appendix Figures  ###
##########################

# Plot number of vessels at sea for each week #
df_weekly = filter(df, (df$week_index==1))
vessels_by_week = c(length(unique(df_weekly$vaartuig)),1)
for (i in seq(2,156)) {
  df_weekly = filter(df, (df$week_index==i))
  vessels_by_week = rbind(vessels_by_week,c(length(unique(df_weekly$vaartuig)),i))
}
vessels_by_week = as.data.frame(vessels_by_week)
colnames(vessels_by_week) <-  c("vessels", "week")
ggplot(vessels_by_week, aes(x=week, y=vessels))  +
  geom_point() + 
  geom_segment( aes(x=week, xend=week, y=0, yend=vessels)) +
  ylab("Number of vessels at sea") +
  xlab("Date (Year-week)") +
  scale_x_continuous(breaks=c(1, 53, 105,157),labels=c("1" = "2017-1", "53" = "2018-1", "105" = "2019-1",  "157" = "2020-01")) +
  theme_bw() +
  theme_classic()   


# trip length #
hist(df$length_trip,breaks=10,xlim=c(0,16),ylab="Number of trips",xlab="Trip duration",main="", col=c("#0099FF"))


# vessel length #
table(df$lengte_over_alles)


df_mean = aggregate(df$lengte_over_alles, list(df$vaartuig), median)

hist(df_mean[,2],breaks=nrow(df_mean),xlim=c(0,55),ylab="number of vessels",xlab="vessel length (m)",main="", col=c("#0099FF"))

df_mean = aggregate(df$vermogen, list(df$vaartuig), median)

hist(df_mean[,2] ,breaks=nrow(df_mean),xlim=c(0,1600),ylab="number of vessels",xlab="vessel power (Kw)",main="", col=c("#0099FF"))

df_mean = aggregate(df$tonnage, list(df$vaartuig), median)

hist(df_mean[,2],breaks=nrow(df_mean),xlim=c(0,600),ylab="number of vessels",xlab="vessel weight (tonnes)",main="", col=c("#0099FF"))














##########################################################################################
###  Generating maps: Figure 4-6 and 8-9, appendix Figure ??
##########################################################################################





#install.packages("ggmap")
library(ggmap)
library(dplyr)

#Set your API Key
ggmap::register_google(key = "AIzaSyAs66RTIY9wtRtAZXe29wiUc0gsth4Kus8")



file = "D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Stephen files\\map_ais.csv"
file2   = "D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Output\\vms_combined_bb_seefalke_meerkatze_vestkysten.csv"    # Don't use this, there are added rows
filebb = "D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Output\\locatiesbb.csv"
fileseefalke = "D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Output\\locatie_seefalke.csv"
filemeerkatze= "D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Output\\locatie_meerkatze.csv"
filevestkysten= "D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Output\\locatie_vestkysten.csv"
register_google(key = "AIzaSyBx6Qy_cO3RoHGD9feVRTEHKk7JjWy5WPs")

fileborder_eng   = 'D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Data Border\\coordinates_english_border.csv'
fileborder_nl_be = 'D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Data Border\\coordinates_dutch_belgian_border.csv'
fileborder_nl_ge = 'D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Data Border\\coordinates_dutch_german_border.csv'
fileborder_da_ge = 'D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Data Border\\coordinates_danish_german_border.csv'
fileborder_da_nw = 'D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Data Border\\coordinates_danish_norwegian_border.csv'


fishdata2   = read.csv(file2,na.strings=c(""," ","NA"),header=TRUE)
fishdata2 = fishdata2[,2:7]

typeof(fishdata2[,6])

fishdata1   = read.csv(file,na.strings=c(""," ","NA"),header=TRUE)
fishdata1 = fishdata1[,-1]

fishdata1$Lat = as.numeric(sub(",", ".", fishdata1$Lat, fixed = TRUE))
fishdata1$Lat = as.double(fishdata1$Lat)
fishdata1$Lon = as.numeric(sub(",", ".", fishdata1$Lon, fixed = TRUE))
fishdata1$Lon = as.double(fishdata1$Lon)


names(fishdata1)[names(fishdata1) == "Lat"] <- "lat"
names(fishdata1)[names(fishdata1) == "Lon"] <- "lon"

fishdata =  fishdata1


dim(fishdata)

bbdata   = read.csv(filebb,colClasses = c("character","character","numeric","numeric","numeric","numeric","character"), na.strings=c(""," ","NA"),header=TRUE)
seefalke = read.csv(fileseefalke,colClasses = c("character","character","character","numeric","numeric","character"), na.strings=c(""," ","NA"),header=TRUE)
meerkatze= read.csv(filemeerkatze,colClasses = c("character","character","character","numeric","numeric","character"), na.strings=c(""," ","NA"),header=TRUE)
vestkysten= read.csv(filevestkysten,colClasses = c(rep("character",4),"numeric","numeric","character","character"), na.strings=c(""," ","NA"),header=TRUE)

border_eng   = read.csv(fileborder_eng,colClasses = c("numeric","numeric"), na.strings=c(""," ","NA"),header=TRUE)
border_nl_be = read.csv(fileborder_nl_be,colClasses = c("numeric","numeric"), na.strings=c(""," ","NA"),header=TRUE)
border_nl_ge = read.csv(fileborder_nl_ge,colClasses = c("numeric","numeric"), na.strings=c(""," ","NA"),header=TRUE)
border_da_ge = read.csv(fileborder_da_ge,colClasses = c("numeric","numeric"), na.strings=c(""," ","NA"),header=TRUE)
border_da_nw = read.csv(fileborder_da_nw,colClasses = c("numeric","numeric"), na.strings=c(""," ","NA"),header=TRUE)

names(bbdata)[names(bbdata) == "Lat..BB"] <- "lat"
names(bbdata)[names(bbdata) == "Lon..BB"] <- "lon"

names(seefalke)[names(seefalke) == "Lat..SF"] <- "lat"
names(seefalke)[names(seefalke) == "Lon..SF"] <- "lon"

names(meerkatze)[names(meerkatze) == "Lat..MK"] <- "lat"
names(meerkatze)[names(meerkatze) == "Lon..MK"] <- "lon"

names(vestkysten)[names(vestkysten) == "Lat..VK"] <- "lat"
names(vestkysten)[names(vestkysten) == "Lon..VK"] <- "lon"




## Figure 4 (left) ##
fishdata =  fishdata1
sort(unique(fishdata$week_index))
fishdata = sample_n(fishdata, (nrow(fishdata)/24))  # take random one month sample

border_eng_2 = filter(border_eng,(border_eng$lat <55.75))
border_eng_2 = filter(border_eng_2,(border_eng_2$lon >2.53))
p <- ggmap(get_googlemap(center =c(5,54.55), zoom = 6, scale = 2,  maptype ='terrain',color = 'color',,style = 'feature:administrative|element:labels|visibility:off'))
p + geom_point(aes(x = lon, y = lat), data = fishdata, size = 0.05,colour = "blue", alpha = 0.1) +
  geom_point(aes(x = lon, y = lat), data = border_eng_2, size=1,colour = "black",shape=".") +
  geom_point(aes(x = lon, y = lat), data = border_nl_be, alpha = 1,size=1,colour = "black",shape=".") +
  geom_point(aes(x = lon, y = lat), data = border_nl_ge, alpha = 1,size=1,colour = "black",shape=".") 

# Graph of random sample of all fishing vessels in dataset (registered in the Netherlands). 9083 geolocation random sample of 944721 geolocations. 


## Figure 4 (right) ##
# Plot of patrol vessels by country (Zoomed in)
p <- ggmap(get_googlemap(center =c(3.5,54.5), zoom = 6, scale = 2,  maptype ='terrain',color = 'color',style = 'feature:administrative|element:labels|visibility:off'))
p + geom_point(aes(x = lon, y = lat), data = bbdata, size = 0.05,colour = "orange", alpha = 0.1) +
  geom_point(aes(x = lon, y = lat), data = seefalke,size=0.050,colour = "#CC99FF", alpha = 0.1) +
  geom_point(aes(x = lon, y = lat), data = meerkatze, size=0.050,colour = "#CC99FF", alpha = 0.1) +
  geom_point(aes(x = lon, y = lat), data = vestkysten, size=0.050,colour = "#FF3333", alpha = 0.1) +
  geom_point(aes(x = lon, y = lat), data = border_eng, size=1,colour = "black",shape=".") +
  geom_point(aes(x = lon, y = lat), data = border_nl_be, alpha = 1,size=1,colour = "black",shape=".") +
  geom_point(aes(x = lon, y = lat), data = border_nl_ge, alpha = 1,size=1,colour = "black",shape=".") +
  geom_point(aes(x = lon, y = lat), data = border_da_ge, alpha = 1,size=1,colour = "black",shape=".") +
  geom_point(aes(x = lon, y = lat), data = border_da_nw, alpha = 1,size=1,colour = "black",shape=".") 




## Appendix plot: all Dutch Coast guard signals over 2017-2018 ##
# Plot of BB  (Zoomed out)
border_eng_2 = filter(border_eng,(border_eng$lat <55.75))
border_eng_2 = filter(border_eng_2,(border_eng_2$lon >2.53))
# Plot of all patrol vessels (Zoomed out)
p <- ggmap(get_googlemap(center =c(-2,63), zoom = 4, scale = 2,  maptype ='terrain',color = 'color',style = 'feature:administrative|element:labels|visibility:off'))
p + geom_point(aes(x = lon, y = lat), data = bbdata, size = 0.05,colour = "#333333", alpha = 0.1) +
  geom_point(aes(x = lon, y = lat), data = border_eng_2, size=1,colour = "black",shape=".") +
  geom_point(aes(x = lon, y = lat), data = border_nl_be, alpha = 1,size=1,colour = "black",shape=".") +
  geom_point(aes(x = lon, y = lat), data = border_nl_ge, alpha = 1,size=1,colour = "black",shape=".") 




### Preparing data for figure 8  ####
########################################################

library("dplyr")
library("tidyr")
library("ggplot2")
library("plm")
library("lmtest")
library("sandwich")
library("clubSandwich")
library("lfe")


df <- read.csv( "D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Stephen files\\Data_final_1719_new.csv")
df = df[,-1]



## Defining treatment and restricting analysis sample ##

# Below are all full weeks during which BB was not patrolling
# 2017: 1 10 11 17 21 22 27 28 29 30 31 32 33 42 50 52 
# 2018: 53 58 59 61 62 70 73 74 82 83 84 85 86 87 94 96 97 104
# 2019: 105 114 115 116 124 125 128 131 132 133 134 135 136 137 140 141 146 147 148 149 153 155 156

NT_week = c( 1,10, 11, 17,21,22, 27,28, 29, 30, 31, 32, 33, 42,50, 52, 53,58,59, 61,62,70,73,74, 82,83, 84, 85, 86, 87, 94, 96, 97,104,105, 114,115, 116, 124, 125, 128,  131,132, 133, 134, 135, 136, 137, 140, 141, 146,147, 148 , 149, 153, 155,156 )  # Non-Treated weeks (no patrolling)
All = seq(1,156)
T_week = All[!(All  %in% NT_week)] # Treated weeks (patrolling)
mAnalysis_weeks = rbind(cbind(NT_week,0),cbind(T_week,1))
mA_w = mAnalysis_weeks[order(mAnalysis_weeks[,1]),2]

analysis_weeks = 1
for (i in seq(2,104)) {
  analysis_weeks = cbind(analysis_weeks,i*as.numeric(mA_w[i] != mA_w[(i-1)]) + i*as.numeric(mA_w[i] != mA_w[(i+1)])* (1-as.numeric(mA_w[i] != mA_w[(i-1)])*as.numeric(mA_w[i] != mA_w[(i+1)])))
}
analysis_weeks
analysis_weeks = analysis_weeks[analysis_weeks!=0]  # Weeks to be included in sample
analysis_weeks
All[!(All  %in% analysis_weeks)]    # Weeks to be excluded from sample

# Keep only relevant adjacant weeks
nrow(df)
df = filter(df, (df$week_index %in% analysis_weeks))
nrow(df)
table(df$week_index)


# Given the resulting dataset, these will be the weeks with no treatment (BB not deployed)
NT_week = c( 1,10, 11, 17,21,22, 27, 33, 42,50, 52, 53,58,59, 61,62,70,73,74, 82, 87, 94, 96, 97,104,105, 114, 116, 124, 125, 128,  131, 137, 140, 141, 146, 149, 153, 155 )
df$treat = 1-as.numeric(df$week_index %in% NT_week)


# Dropping Christmas weeks which skews analysis of probability of fishing 
# -> fishing vessels and coast guard are almost all on vacation which means these are not comparable weeks to adjacent patrolling weeks
nrow(df)
df = filter(df, !(df$week_index %in% c(52,103,104)))  # drop Christmas weeks and their comparisons when relevant
nrow(df)
table(df$week_index)


df = filter(df, (df$week_index < 103))

# Expand df to have a single row for each day vessel was at sea
df$vertrek = as.Date(df$vertrek,format="%Y-%m-%d")
df$terugkeer = as.Date(df$terugkeer,format="%Y-%m-%d")
df$length_trip = (as.numeric(df$terugkeer)-as.numeric(df$vertrek))+1

dfmerge = cbind(df$vaartuig[1],df$vertrek[1],df$treat[1] )
for (i in 1:nrow(df)) {
  j=0
  while (j < df$length_trip[i]){
    dfmerge = rbind(dfmerge,cbind(df$vaartuig[i],(df$vertrek[i]+j),df$treat[i] ))
    j = j+1
  }
}
dfmerge = as.data.frame(dfmerge[-1,])
names(dfmerge) <- c("vaartuig","date","treat")
dfmerge$date = as.Date(dfmerge$date,format="%Y-%m-%d")

fishdata =  fishdata1

# Prepare geocoded data for merging
fishdata$date = as.Date(fishdata$UTC.time,format="%Y-%m-%d")
fishdata$weekday = weekdays(as.Date(fishdata$UTC.time,format="%Y-%m-%d"))

Data_map_T <- merge(fishdata, dfmerge, by=c("vaartuig","date"))  # Data_map_T is merged data of geocode and treatment status
Data_map_T0 = filter(Data_map_T, (Data_map_T$treat == 0))
nrow(Data_map_T0)
Data_map_T1 = filter(Data_map_T, (Data_map_T$treat == 1))
Data_map_T1 = sample_n(Data_map_T1, nrow(Data_map_T0))  # randomly sample to have the same number on map of treated and non treated observations
nrow(Data_map_T1)

# sum((Data_map_T1$weekday == "Saturday") + (Data_map_T1$weekday == "Sunday") >0)
# sum((Data_map_T0$weekday == "Saturday") + (Data_map_T0$weekday == "Sunday") >0)
# Data_map_T1 = filter(Data_map_T1, ((Data_map_T1$weekday == "Saturday") + (Data_map_T1$weekday == "Sunday") ==0))
# Data_map_T0 = filter(Data_map_T0, ((Data_map_T0$weekday == "Saturday") + (Data_map_T0$weekday == "Sunday") ==0))


###################
#### PLOT 7-10 ####
###################

# Note that you randomly sample treated GPS observations, of which there are more than non-treated ones, to have 
# fixed number of GPS points in treated ad non-treated map

Data_map_T1 = sample_n(Data_map_T1, round(nrow(Data_map_T1)/24))  # randomly sample to have the same number on map of treated and non treated observations
Data_map_T0 = sample_n(Data_map_T0, round(nrow(Data_map_T0)/24))  # randomly sample to have the same number on map of treated and non treated observations


##  Figure 8 left ##
# Plot fishing vessels TREATED WEEKS (Zoomed in)
p <- ggmap(get_googlemap(center =c(5,54.55), zoom = 6, scale = 2,  maptype ='terrain',color = 'color',,style = 'feature:administrative|element:labels|visibility:off'))
p + geom_point(aes(x = lon, y = lat), data = Data_map_T1, size = 0.05,colour = "blue", alpha = 0.1)  


## This possibly for appendix  ##
p <- ggmap(get_googlemap(center =c(5,54.55), zoom = 6, scale = 2,  maptype ='terrain',color = 'color',,style = 'feature:administrative|element:labels|visibility:off'))
p + stat_density2d(
  aes(x = lon, y = lat, fill = ..level.., alpha =..level..),
  size = 0.2, bins = 30, data = Data_map_T1,
  geom = "polygon"
) +
  geom_density2d(data = Data_map_T1, 
                 aes(x = lon, y = lat), size = 0.3) 


##  Figure 8 right ##
# Plot fishing vessels NON-TREATED WEEKS (Zoomed in)
p <- ggmap(get_googlemap(center =c(5,54.55), zoom = 6, scale = 2,  maptype ='terrain',color = 'color',,style = 'feature:administrative|element:labels|visibility:off'))
p + geom_point(aes(x = lon, y = lat), data = Data_map_T0, size = 0.05,colour = "blue", alpha = 0.1) 


## This possibly for appendix  ##
p <- ggmap(get_googlemap(center =c(5,54.55), zoom = 6, scale = 2,  maptype ='terrain',color = 'color',,style = 'feature:administrative|element:labels|visibility:off'))
p + stat_density2d(
  aes(x = lon, y = lat, fill = ..level.., alpha =..level..),
  size = 0.2, bins = 30, data = Data_map_T0,
  geom = "polygon"
) +
  geom_density2d(data = Data_map_T0, 
                 aes(x = lon, y = lat), size = 0.3) 






### Preparing data for figures 6  ####
######################################


### Different maps for patrol vessels of other countries depending on whether BB was deployed ##


file_BB = "D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Stephen files\\deploy_2017to2019.csv"

# Import the data and set the appropriate column types to numeric
data_BBdep = read.csv(file_BB)
colnames(data_BBdep) <- c("start","end")
data_BBdep$start = as.Date(data_BBdep$start ,format="%d/%m/%Y")
data_BBdep$end = as.Date(data_BBdep$end ,format="%d/%m/%Y")

first_day=as.numeric( as.Date("2017-01-01",format="%Y-%m-%d"))  # first day of time period
last_day=as.numeric( as.Date("2018-12-31",format="%Y-%m-%d"))

dfmerge1 = as.data.frame(matrix(seq(as.Date("2017-01-01"), as.Date("2018-12-31"), by="days"),length(seq(as.Date("2017-01-01"), as.Date("2018-12-31"), by="days")),1))
names(dfmerge1) <- "date"
dfmerge1$date = as.Date(dfmerge1$date,format="%Y-%m-%d")


dfmerge2 = data_BBdep$start[1] 
for (i in 1:nrow(data_BBdep)) {
  j=0
  while (j < (data_BBdep$end[i]- data_BBdep$start[i] +1)){
    dfmerge2 = rbind(dfmerge2,(data_BBdep$start[i]+j))
    j = j+1
  }
}
dfmerge2 = as.data.frame(dfmerge2[-1,])
names(dfmerge2) <- "date"
dfmerge2$date = as.Date(dfmerge2$date,format="%Y-%m-%d")
dfmerge2 = cbind(dfmerge2,1)



dfmerge = merge(dfmerge1, dfmerge2, by="date",all.x=TRUE)

dfmerge[,2] = 1-as.numeric(is.na(dfmerge[,2]))
names(dfmerge) <- c("date","BBdeployed")



# Prepare geocoded data for merging
bbdata$date = as.Date(bbdata$local.time,format="%Y-%m-%d")
bbdata$weekday = weekdays(as.Date(bbdata$local.time,format="%Y-%m-%d"))
seefalke$date = as.Date(seefalke$UTC.time,format="%Y-%m-%d")
seefalke$weekday = weekdays(as.Date(seefalke$UTC.time,format="%Y-%m-%d"))
meerkatze$date = as.Date(meerkatze$UTC.time,format="%Y-%m-%d")
meerkatze$weekday = weekdays(as.Date(meerkatze$UTC.time,format="%Y-%m-%d"))
vestkysten$date = as.Date(vestkysten$local.time,format="%Y-%m-%d")
vestkysten$weekday = weekdays(as.Date(vestkysten$local.time,format="%Y-%m-%d"))


Data_map_BB <- merge(bbdata, dfmerge, by="date")  # Data_map_BB is merged data of geocode and treatment status of BB deployment
Data_map_SF <- merge(seefalke, dfmerge, by="date")  # Data_map_BB is merged data of geocode and treatment status of BB deployment
Data_map_MK <- merge(meerkatze, dfmerge, by="date")  # Data_map_BB is merged data of geocode and treatment status of BB deployment
Data_map_VK <- merge(vestkysten, dfmerge, by="date")  # Data_map_BB is merged data of geocode and treatment status of BB deployment




Data_map_BB0 = filter(Data_map_BB, (Data_map_BB$BBdeployed  == 0)) # BB not deployed
nrow(Data_map_BB0)
Data_map_BB1 = filter(Data_map_BB, (Data_map_BB$BBdeployed == 1))   # BB  deployed
nrow(Data_map_BB1)

Data_map_SF0 = filter(Data_map_SF, (Data_map_SF$BBdeployed  == 0)) # BB not deployed
nrow(Data_map_SF0)
Data_map_SF1 = filter(Data_map_SF, (Data_map_SF$BBdeployed == 1))   # BB  deployed
nrow(Data_map_SF1)

Data_map_MK0 = filter(Data_map_MK, (Data_map_MK$BBdeployed  == 0)) # BB not deployed
nrow(Data_map_MK0)
Data_map_MK1 = filter(Data_map_MK, (Data_map_MK$BBdeployed == 1))   # BB  deployed
nrow(Data_map_MK1)


Data_map_VK0 = filter(Data_map_VK, (Data_map_VK$BBdeployed  == 0)) # BB not deployed
nrow(Data_map_VK0)
Data_map_VK1 = filter(Data_map_VK, (Data_map_VK$BBdeployed == 1))   # BB  deployed
nrow(Data_map_VK1)


# Reviewer pointless test request: Statistical test of frequency of presence of foreign vessels in Dutch EEZ in treated vs. control weeks
####################################################


# Generate east and west borders
border_eng_2 = filter(border_eng,(border_eng$lat <55.75))
border_eng_2 = filter(border_eng_2,(border_eng_2$lon >2.53))
border_west = rbind(border_eng_2, border_eng_2)
border_west = border_west[order(border_west$lat), ]
border_east = border_nl_ge[order(border_nl_ge$lat), ]

### Generate Data_map_foreign0$insideEEZ_NL=1 if foreign vessels inside Dutch EEZ and  BB not deployed week
Data_map_foreign0 =rbind(Data_map_SF0[,c("date","UTC.time", "lat","lon")], Data_map_MK0[,c("date","UTC.time", "lat","lon")], Data_map_VK0[,c("date","UTC.time", "lat","lon")])

# Create a new column 'insideEEZ_NL' and initialize with 0
Data_map_foreign0$insideEEZ_NL <- 0

# Iterate through each row and update 'insideEEZ_NL' based on conditions
for (i in 1:nrow(Data_map_foreign0)) {
  la = Data_map_foreign0$lat[i]
  lo = Data_map_foreign0$lon[i]
  if (la < max(border_west$lat) & la > min(border_west$lat) &  #if inside max east/west/north/south polygon
      lo > min(border_west$lon) & lo < max(border_east$lon) ){
    
    closest_rowW <- which.min(abs(border_west$lat - la))  
    closest_lonW <- border_west$lon[closest_rowW]      # take longit value of closest latitude point on west border
    closest_rowE <- which.min(abs(border_east$lat - la))  
    closest_lonE <- border_east$lon[closest_rowE]     # take longit value of closest latitude point on east border
    if (lo > closest_lonW & lo < closest_lonE){
      Data_map_foreign0$insideEEZ_NL[i]=1       # takes value 1 if within lon values of east and west borders
    }
  }
}

Data_reviewer <- cbind(0, 0 , Data_map_foreign0$insideEEZ_NL)
colnames(Data_reviewer) <- c("BBvessel", "BBinsp", "insideEEZ_NL")

table(Data_map_foreign0$insideEEZ_NL)
# Print the updated dataframe
print(Data_map_foreign0)
sum(Data_map_foreign0$insideEEZ_NL)/nrow(Data_map_foreign0)


### Generate Data_map_foreign1$insideEEZ_NL=1 if foreign vessels inside Dutch EEZ and BB deployed week
Data_map_foreign1 =rbind(Data_map_SF1[,c("date","UTC.time", "lat","lon")], Data_map_MK1[,c("date","UTC.time", "lat","lon")], Data_map_VK1[,c("date","UTC.time", "lat","lon")])

# Create a new column 'insideEEZ_NL' and initialize with 0
Data_map_foreign1$insideEEZ_NL <- 0

# Iterate through each row and update 'insideEEZ_NL' based on conditions
for (i in 1:nrow(Data_map_foreign1)) {
  la = Data_map_foreign1$lat[i]
  lo = Data_map_foreign1$lon[i]
  if (la < max(border_west$lat) & la > min(border_west$lat) &  #if inside max east/west/north/south polygon
      lo > min(border_west$lon) & lo < max(border_east$lon) ){
    
    closest_rowW <- which.min(abs(border_west$lat - la))  
    closest_lonW <- border_west$lon[closest_rowW]      # take longit value of closest latitude point on west border
    closest_rowE <- which.min(abs(border_east$lat - la))  
    closest_lonE <- border_east$lon[closest_rowE]     # take longit value of closest latitude point on east border
    if (lo > closest_lonW & lo < closest_lonE){
      Data_map_foreign1$insideEEZ_NL[i]=1       # takes value 1 if within lon values of east and west borders
    }
  }
}

Data_reviewer <- rbind(Data_reviewer,cbind(0, 1 , Data_map_foreign1$insideEEZ_NL))

table(Data_map_foreign1$insideEEZ_NL)
table(Data_map_foreign0$insideEEZ_NL)
# Print the updated dataframe
print(Data_map_foreign0)
sum(Data_map_foreign0$insideEEZ_NL)/nrow(Data_map_foreign0)
sum(Data_map_foreign1$insideEEZ_NL)/nrow(Data_map_foreign1)





### Generate Data_map_foreign0$insideEEZ_NL=1 if BB vessel inside Dutch EEZ and BB not deployed week
Data_map_BBn0 =Data_map_BB0[,c("date","UTC.time", "lat","lon")] 

# Create a new column 'insideEEZ_NL' and initialize with 0
Data_map_BBn0$insideEEZ_NL <- 0

# Iterate through each row and update 'insideEEZ_NL' based on conditions
for (i in 1:nrow(Data_map_BBn0)) {
  la = Data_map_BBn0$lat[i]
  lo = Data_map_BBn0$lon[i]
  if (la < max(border_west$lat) & la > min(border_west$lat) &  #if inside max east/west/north/south polygon
      lo > min(border_west$lon) & lo < max(border_east$lon) ){
    
    closest_rowW <- which.min(abs(border_west$lat - la))  
    closest_lonW <- border_west$lon[closest_rowW]      # take longit value of closest latitude point on west border
    closest_rowE <- which.min(abs(border_east$lat - la))  
    closest_lonE <- border_east$lon[closest_rowE]     # take longit value of closest latitude point on east border
    if (lo > closest_lonW & lo < closest_lonE){
      Data_map_BBn0$insideEEZ_NL[i]=1       # takes value 1 if within lon values of east and west borders
    }
  }
}

Data_reviewer <- rbind(Data_reviewer,cbind(1, 0 , Data_map_BBn0$insideEEZ_NL))
colnames(Data_reviewer) <- c("BBvessel", "BBinsp", "insideEEZ_NL")

table(Data_map_BBn0$insideEEZ_NL)
# Print the updated dataframe
print(Data_map_BBn0)
sum(Data_map_BBn0$insideEEZ_NL)/nrow(Data_map_BBn0)


### Generate Data_map_foreign1$insideEEZ_NL=1 if BB vessel inside Dutch EEZ and BB deployed week
Data_map_BBn1 =Data_map_BB1[,c("date","UTC.time", "lat","lon")] 

# Create a new column 'insideEEZ_NL' and initialize with 0
Data_map_BBn1$insideEEZ_NL <- 0

# Iterate through each row and update 'insideEEZ_NL' based on conditions
for (i in 1:nrow(Data_map_BBn1)) {
  la = Data_map_BBn1$lat[i]
  lo = Data_map_BBn1$lon[i]
  if (la < max(border_west$lat) & la > min(border_west$lat) &  #if inside max east/west/north/south polygon
      lo > min(border_west$lon) & lo < max(border_east$lon) ){
    
    closest_rowW <- which.min(abs(border_west$lat - la))  
    closest_lonW <- border_west$lon[closest_rowW]      # take longit value of closest latitude point on west border
    closest_rowE <- which.min(abs(border_east$lat - la))  
    closest_lonE <- border_east$lon[closest_rowE]     # take longit value of closest latitude point on east border
    if (lo > closest_lonW & lo < closest_lonE){
      Data_map_BBn1$insideEEZ_NL[i]=1       # takes value 1 if within lon values of east and west borders
    }
  }
}

Data_reviewer <- rbind(Data_reviewer,cbind(1, 1 , Data_map_BBn1$insideEEZ_NL))




table(Data_map_BBn1$insideEEZ_NL)
table(Data_map_BBn0$insideEEZ_NL)
table(Data_map_foreign1$insideEEZ_NL)
table(Data_map_foreign0$insideEEZ_NL)
# Print the updated dataframe
sum(Data_map_BBn0$insideEEZ_NL)/nrow(Data_map_BBn0)
sum(Data_map_BBn1$insideEEZ_NL)/nrow(Data_map_BBn1)
sum(Data_map_foreign0$insideEEZ_NL)/nrow(Data_map_foreign0)
sum(Data_map_foreign1$insideEEZ_NL)/nrow(Data_map_foreign1)


DFr = data.frame(Data_reviewer)
DFr = DFr[(DFr$BBvessel==0),]
colnames(Data_reviewer)

Lfe <- lm(insideEEZ_NL ~ BBinsp  ,  data = DFr)
coeftest(Lfe, vcov = vcovHC(Lfe))

DFr = DFr[(DFr$BBinsp==1),]
sum(DFr$insideEEZ_NL)/nrow(DFr)
sum(DFr$insideEEZ_NL*(1-DFr$BBinsp))



########################
###  FIGURE 6  #####
########################

## Figure 6 (left) ##
p <- ggmap(get_googlemap(center =c(3.5,54.5), zoom = 6, scale = 2,  maptype ='terrain',color = 'color',style = 'feature:administrative|element:labels|visibility:off'))
p + geom_point(aes(x = lon, y = lat), data = Data_map_BB1, size = 0.05,colour = "blue", alpha = 0.1) +
  geom_point(aes(x = lon, y = lat), data = border_eng_2, size=1,colour = "black",shape=".") +
  geom_point(aes(x = lon, y = lat), data = border_nl_be, alpha = 1,size=1,colour = "black",shape=".") +
  geom_point(aes(x = lon, y = lat), data = border_nl_ge, alpha = 1,size=1,colour = "black",shape=".") 


## Figure 6 (right) ##
border_eng_2 = filter(border_eng,(border_eng$lat <55.75))
border_eng_2 = filter(border_eng_2,(border_eng_2$lon >2.53))
# Plot of patrol vessels by country (Zoomed in)
p <- ggmap(get_googlemap(center =c(3.5,54.5), zoom = 6, scale = 2,  maptype ='terrain',color = 'color',style = 'feature:administrative|element:labels|visibility:off'))
p + geom_point(aes(x = lon, y = lat), data = Data_map_BB0, size = 0.05,colour = "blue", alpha = 0.1) +
  geom_point(aes(x = lon, y = lat), data = border_eng_2, size=1,colour = "black",shape=".") +
  geom_point(aes(x = lon, y = lat), data = border_nl_be, alpha = 1,size=1,colour = "black",shape=".") +
  geom_point(aes(x = lon, y = lat), data = border_nl_ge, alpha = 1,size=1,colour = "black",shape=".") 



#### SPILLOVER: PLOTS ARE USEFUL FOR APPENDIX  ####


# Plot of patrol vessels by country (Zoomed in)
p <- ggmap(get_googlemap(center =c(3.5,54.5), zoom = 6, scale = 2,  maptype ='terrain',color = 'color',style = 'feature:administrative|element:labels|visibility:off'))
p + geom_point(aes(x = lon, y = lat), data = Data_map_BB0, size = 0.05,colour = "blue", alpha = 0.1) +
  geom_point(aes(x = lon, y = lat), data = Data_map_SF0,size=0.050,colour = "blue", alpha = 0.1) +
  geom_point(aes(x = lon, y = lat), data = Data_map_MK0, size=0.050,colour = "blue", alpha = 0.1) +
  geom_point(aes(x = lon, y = lat), data = Data_map_VK0, size=0.050,colour = "blue", alpha = 0.1) +
  geom_point(aes(x = lon, y = lat), data = border_eng, size=1,colour = "black",shape=".") +
  geom_point(aes(x = lon, y = lat), data = border_nl_be, alpha = 1,size=1,colour = "black",shape=".") +
  geom_point(aes(x = lon, y = lat), data = border_nl_ge, alpha = 1,size=1,colour = "black",shape=".") +
  geom_point(aes(x = lon, y = lat), data = border_da_ge, alpha = 1,size=1,colour = "black",shape=".") +
  geom_point(aes(x = lon, y = lat), data = border_da_nw, alpha = 1,size=1,colour = "black",shape=".") 


p <- ggmap(get_googlemap(center =c(3.5,54.5), zoom = 6, scale = 2,  maptype ='terrain',color = 'color',style = 'feature:administrative|element:labels|visibility:off'))
p + geom_point(aes(x = lon, y = lat), data = Data_map_BB1, size = 0.05,colour = "blue", alpha = 0.1) +
  geom_point(aes(x = lon, y = lat), data = Data_map_SF1,size=0.050,colour = "blue", alpha = 0.1) +
  geom_point(aes(x = lon, y = lat), data = Data_map_MK1, size=0.050,colour = "blue", alpha = 0.1) +
  geom_point(aes(x = lon, y = lat), data = Data_map_VK1, size=0.050,colour = "blue", alpha = 0.1) +
  geom_point(aes(x = lon, y = lat), data = border_eng, size=1,colour = "black",shape=".") +
  geom_point(aes(x = lon, y = lat), data = border_nl_be, alpha = 1,size=1,colour = "black",shape=".") +
  geom_point(aes(x = lon, y = lat), data = border_nl_ge, alpha = 1,size=1,colour = "black",shape=".") +
  geom_point(aes(x = lon, y = lat), data = border_da_ge, alpha = 1,size=1,colour = "black",shape=".") +
  geom_point(aes(x = lon, y = lat), data = border_da_nw, alpha = 1,size=1,colour = "black",shape=".") 








