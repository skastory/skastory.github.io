# -*- coding: utf-8 -*-
"""
@author: shocuk & jvh & skastoryano
date: Dec 2020

"""


#%% # Importing all the libraries
import numpy as np
import pandas as pd
import time
pd.options.mode.chained_assignment = None



#%% # Presetting environment
from IPython.core.interactiveshell import InteractiveShell
InteractiveShell.ast_node_interactivity = "all"
pd.set_option("max_row",90)
pd.set_option("max_column",10)



#%% # Functions
def month_to_num(string):
    m = {'jan':1,'feb':2,'mar':3,'apr':4,'may':5,'jun':6,'jul':7,'aug':8,'sep':9,'oct':10,'nov':11,'dec':12}
    s = string.strip()[:3].lower()
    try:
        out = m[s]
        return out
    except:
        raise ValueError('Not a month')



#%% # Paths and Files
folder    = 'D:\\Dropbox\\vis\\New data per Nov 2020\\'


#%% (1) Reading

# Reading the file with debarkation data
df_aanland = pd.read_csv(folder+'VIS_KUB_Aanlandingen_va_nov2018.csv', encoding='iso-8859-1') #,converters= {'DatumTijd_Vertrek': pd.to_datetime})
# Reading Daily Catches Data
df_dagvang = pd.read_csv(folder+'VIS_KUB_Dagvangsten_va_nov2018.csv', encoding='iso-8859-1')
# Reading Data on inspections in the harbour
df_inspect = pd.read_csv(folder+'VIS_KUB_Inspecties_va_nov2018.csv', encoding='iso-8859-1')
# Reading vessel data
df_vaartui = pd.read_csv(folder+'VIS_KUB_Vaartuigen_va_nov2018.csv')
# Reading Sales Data
df_verkoop = pd.read_csv(folder+'VIS_KUB_Verkopen_va_nov2018.csv', encoding='iso-8859-1')

# Reading Data on when the BB is absent
df_verlofbb = pd.read_csv(folder+'Data Inspectieschepen\\'+'verlof_bb.csv',index_col = 0)

# %% (2) Initial pre-processing

# Lowering Harbor names so they are easy to compare
df_aanland.Haven_Terugkeer = df_aanland.Haven_Terugkeer.str.lower()
df_inspect.Haven = df_inspect.Haven.str.lower()

# Renaming
torename = {'Lengte_Over_Alles': 'VAARTUIG_Lengte_Over_Alles', 'Tonnage': 'VAARTUIG_Tonnage',
            'Vermogen': 'VAARTUIG_Vermogen', 'WIJZIGINGS_DATUM_VANAF': 'VAARTUIG_WIJZIGINGS_DATUM_VANAF'}
df_vaartui.rename(columns=torename, inplace=True)

torename = {'GROOTTEKLASSE': 'VERKOOP_GROOTTEKLASSE', 'hoeveelheid_levend_vdt': 'VERKOOP_hoeveelheid_levend_vdt'}
df_verkoop.rename(columns=torename, inplace=True)

# renaming harbors in df_inspect so that they match with aanlandingen.
df_inspect['Haven'].replace(
    {'den oever': 'wieringen/den oever', 'wieringen': 'wieringen/den oever', 'wrg': 'wieringen/den oever',
     'nl-wrg': 'wieringen/den oever', 'nl ijm': 'ijmuiden/velsen', 'ijm': 'ijmuiden/velsen', 'ijmuiden': 'ijmuiden/velsen', 'vli': 'vlissingen',
     'vlisisngen': 'vlissingen', 'visafslag hollands noorden in den helder': 'den helder', 'nl-dhr': 'den helder',
     'dhr': 'den helder', 'nl sce': 'scheveningen', 'sce': 'scheveningen', 'brs': 'breskens', 'std': 'stellendam', 'clp': 'colijnsplaat',
     'har': 'harlingen', 'nlijm': 'ijmuiden/velsen', 'wieringen (den oever)': 'wieringen/den oever'},
    inplace=True)
set(df_inspect.Haven) - set(df_aanland.Haven_Terugkeer)  # no match={'amsterdam', 'schore', 'tholen', 'yerseke'}

# %% # Datetime conversion
df_inspect['Inspectie_Datum'] = pd.to_datetime(df_inspect['Inspectie_Datum'])

# Datetime conversion by Decomposing
df_aanland['datumtijd_vertrek_jaar'] = df_aanland['DatumTijd_Vertrek'].str.findall('(\d{4})').str[0].astype(int)
df_aanland['datumtijd_vertrek_maand'] = df_aanland['DatumTijd_Vertrek'].str.findall('([a-zA-Z]{3})').str[0]
df_aanland['datumtijd_vertrek_maand'] = df_aanland['datumtijd_vertrek_maand'].apply(month_to_num)
df_aanland['datumtijd_vertrek_dag'] = df_aanland['DatumTijd_Vertrek'].str.findall('(\d{2})').str[0].astype(int)
df_aanland['datumtijd_vertrek_tijd'] = df_aanland['DatumTijd_Vertrek'].str.findall(':(\d{2}:\d{2}:\d{2})').str[0]

df_aanland['datumtijd_terug_jaar'] = df_aanland['DatumTijd_Terugkeer'].str.findall('(\d{4})').str[0].astype(int)
df_aanland['datumtijd_terug_maand'] = df_aanland['DatumTijd_Terugkeer'].str.findall('([a-zA-Z]{3})').str[0]
df_aanland['datumtijd_terug_maand'] = df_aanland['datumtijd_terug_maand'].apply(month_to_num)
df_aanland['datumtijd_terug_dag'] = df_aanland['DatumTijd_Terugkeer'].str.findall('(\d{2})').str[0].astype(int)
df_aanland['datumtijd_terug_tijd'] = df_aanland['DatumTijd_Terugkeer'].str.findall(':(\d{2}:\d{2}:\d{2})').str[0]

datumtijd_vertrek = df_aanland['datumtijd_vertrek_jaar'].apply(np.str) + '-' + df_aanland[
    'datumtijd_vertrek_maand'].apply(np.str) + '-' + df_aanland['datumtijd_vertrek_dag'].apply(np.str) + ' ' + \
                    df_aanland['datumtijd_vertrek_tijd']
df_aanland['datumtijd_vertrek'] = pd.to_datetime(datumtijd_vertrek)
datumtijd_terug = df_aanland['datumtijd_terug_jaar'].apply(np.str) + '-' + df_aanland['datumtijd_terug_maand'].apply(
    np.str) + '-' + df_aanland['datumtijd_terug_dag'].apply(np.str) + ' ' + df_aanland['datumtijd_terug_tijd']
df_aanland['datumtijd_terug'] = pd.to_datetime(datumtijd_terug)

# %% # Dropping columns that are obsolete
todrop2 = ['datumtijd_vertrek_jaar', 'datumtijd_vertrek_maand', 'datumtijd_vertrek_dag', 'datumtijd_vertrek_tijd',
           'datumtijd_terug_jaar', 'datumtijd_terug_maand', 'datumtijd_terug_dag', 'datumtijd_terug_tijd']
df_aanland.drop(columns=todrop2, inplace=True)

todrop5 = ['Haven_Vertrek', 'Haven_Terugkeer', 'FGE_FAO_GEBIED_CODE']
df_verkoop.drop(todrop5, axis=1, inplace=True)

# %% (3) Processing aanland data - Jean 15/05/2019

# replacing nan for ondermaats with an N (as Henk said I could)-Jean
df_aanland['ONDERMAATS_IND'].fillna("N", inplace=True)

# dropping dve_nr
df_aanland.drop(columns=['dve_nr'], inplace=True)

# aggregate over visreis - we have dat per dve_nr, which gives data per size category and type (dead, alive). We will need the data to be per fishing trip however
df_aanland["aggregate_hoeveelheid_dood"] = \
df_aanland.groupby(['Vaartuig', 'Visreis_Nr', 'visbestand_fao_code', 'ONDERMAATS_IND'])['HOEVEELHEID_DOOD'].transform(
    'sum')
df_aanland["aggregate_hoeveelheid_levend"] = \
df_aanland.groupby(['Vaartuig', 'Visreis_Nr', 'visbestand_fao_code', 'ONDERMAATS_IND'])[
    'hoeveelheid_levend_dve'].transform('sum')
df_aanland.drop(columns=['HOEVEELHEID_DOOD', 'hoeveelheid_levend_dve'], inplace=True)
df_aanland.rename(index=str, columns={"aggregate_hoeveelheid_dood": "HOEVEELHEID_DOOD",
                                      "aggregate_hoeveelheid_levend": "hoeveelheid_levend"}, inplace=True)

# dropping duplicates
df_aanland.drop_duplicates(inplace=True)  # SH: 8567 rows (of 36387) are grouped into 27820

# %% # Processing aanland data - trying to get each visreis into one row. First step is putting ondermaats and bovenmaats in one row, then putting PLE and SOL in one row.

# Splitting aanlanding in 2 df's, then merging those. So that for each trip we get catch ondermaats as a separate column
df_ondermaats = df_aanland.loc[df_aanland['ONDERMAATS_IND'] == "J", :]
df_ondermaats.rename(index=str, columns={"HOEVEELHEID_DOOD": "ONDERMAATS_HOEVEELHEID_DOOD",
                                         "hoeveelheid_levend": "ONDERMAATS_HOEVEELHEID_LEVEND"}, inplace=True)
df_ondermaats.drop(columns=['ONDERMAATS_IND'], inplace=True)

df_bovenmaats = df_aanland.loc[df_aanland['ONDERMAATS_IND'] == "N", :]
df_bovenmaats.rename(index=str, columns={"HOEVEELHEID_DOOD": "BOVENMAATS_HOEVEELHEID_DOOD",
                                         "hoeveelheid_levend": "BOVENMAATS_HOEVEELHEID_LEVEND"}, inplace=True)
df_bovenmaats.drop(columns=['ONDERMAATS_IND'], inplace=True)

# merging the two dataframes (ondermaats and bovenmaats) back together. Outer merge so that if only bovenmaats or ondermaats is landed we will keep the observation. One of the merge characteristics is visbestand_fao_code so that we do still differentiate between sole and plaice
df_aanland_mergedsizes = pd.merge(df_ondermaats, df_bovenmaats, how='outer',
                                  on=['Vaartuig', 'FGE_FAO_GEBIED_CODE', 'Visreis_Nr', 'DatumTijd_Vertrek',
                                      'DatumTijd_Terugkeer', 'datumtijd_vertrek', 'datumtijd_terug', 'Haven_Vertrek',
                                      'Haven_Terugkeer', 'HavenCode_Vertrek', 'HavenCode_Terugkeer',
                                      'visbestand_fao_code'])

# repeating the same procedure to get both fish species into one row for each visreis.
df_SOL = df_aanland_mergedsizes.loc[df_aanland_mergedsizes['visbestand_fao_code'] == "SOL", :]
df_SOL.rename(index=str, columns={"ONDERMAATS_HOEVEELHEID_DOOD": "AANLANDING_SOL_ONDERMAATS_DOOD",
                                  "ONDERMAATS_HOEVEELHEID_LEVEND": "AANLANDING_SOL_ONDERMAATS_LEVEND",
                                  "BOVENMAATS_HOEVEELHEID_DOOD": "AANLANDING_SOL_BOVENMAATS_DOOD",
                                  "BOVENMAATS_HOEVEELHEID_LEVEND": "AANLANDING_SOL_BOVENMAATS_LEVEND"}, inplace=True)
df_SOL.drop(columns=['visbestand_fao_code'], inplace=True)

df_PLE = df_aanland_mergedsizes.loc[df_aanland_mergedsizes['visbestand_fao_code'] == "PLE", :]
df_PLE.rename(index=str, columns={"ONDERMAATS_HOEVEELHEID_DOOD": "AANLANDING_PLE_ONDERMAATS_DOOD",
                                  "ONDERMAATS_HOEVEELHEID_LEVEND": "AANLANDING_PLE_ONDERMAATS_LEVEND",
                                  "BOVENMAATS_HOEVEELHEID_DOOD": "AANLANDING_PLE_BOVENMAATS_DOOD",
                                  "BOVENMAATS_HOEVEELHEID_LEVEND": "AANLANDING_PLE_BOVENMAATS_LEVEND"}, inplace=True)
df_PLE.drop(columns=['visbestand_fao_code'], inplace=True)

df_aanland_improved = pd.merge(df_SOL, df_PLE, how='outer',
                               on=['Vaartuig', 'FGE_FAO_GEBIED_CODE', 'Visreis_Nr', 'DatumTijd_Vertrek',
                                   'DatumTijd_Terugkeer', 'datumtijd_vertrek', 'datumtijd_terug', 'Haven_Vertrek',
                                   'Haven_Terugkeer', 'HavenCode_Vertrek', 'HavenCode_Terugkeer'])

# Now sometimes I will have two observations where only the fge_fao_gebied_code is different. I will set those fge_fao_gebied code's to changed and drop duplicates later.
df_aanland_improved['FGE_FAO_GEBIED_CODE'] = df_aanland_improved['FGE_FAO_GEBIED_CODE'].where(
    ~df_aanland_improved.duplicated(subset='Visreis_Nr', keep=False), "Changed")

# Some observations will have duplicates where catch is different. Then the maximum of these two is correct. The reason is that we have one row with the catch ondermaats and another with the catch bovenmaats, the other one will be zero.
df_aanland_improved['AANLANDING_SOL_ONDERMAATS_DOOD'] = df_aanland_improved.groupby(['Visreis_Nr'])[
    'AANLANDING_SOL_ONDERMAATS_DOOD'].transform('max')
df_aanland_improved['AANLANDING_SOL_BOVENMAATS_DOOD'] = df_aanland_improved.groupby(['Visreis_Nr'])[
    'AANLANDING_SOL_BOVENMAATS_DOOD'].transform('max')
df_aanland_improved['AANLANDING_SOL_ONDERMAATS_LEVEND'] = df_aanland_improved.groupby(['Visreis_Nr'])[
    'AANLANDING_SOL_ONDERMAATS_LEVEND'].transform('max')
df_aanland_improved['AANLANDING_SOL_BOVENMAATS_LEVEND'] = df_aanland_improved.groupby(['Visreis_Nr'])[
    'AANLANDING_SOL_BOVENMAATS_LEVEND'].transform('max')
df_aanland_improved['AANLANDING_PLE_ONDERMAATS_DOOD'] = df_aanland_improved.groupby(['Visreis_Nr'])[
    'AANLANDING_PLE_ONDERMAATS_DOOD'].transform('max')
df_aanland_improved['AANLANDING_PLE_BOVENMAATS_DOOD'] = df_aanland_improved.groupby(['Visreis_Nr'])[
    'AANLANDING_PLE_BOVENMAATS_DOOD'].transform('max')
df_aanland_improved['AANLANDING_PLE_ONDERMAATS_LEVEND'] = df_aanland_improved.groupby(['Visreis_Nr'])[
    'AANLANDING_PLE_ONDERMAATS_LEVEND'].transform('max')
df_aanland_improved['AANLANDING_PLE_BOVENMAATS_LEVEND'] = df_aanland_improved.groupby(['Visreis_Nr'])[
    'AANLANDING_PLE_BOVENMAATS_LEVEND'].transform('max')

df_aanland_improved = df_aanland_improved.drop_duplicates(keep='first')

# %% (4) Processing df_verkoop zodat alle data per visreis in een rij komt

# lets first take care of that sometime fish are sold in different batches while they are from the same trip.
df_verkoop["verkoop_categorie_dood"] = \
df_verkoop.groupby(['Visreis_Nr', 'VERKOOP_GROOTTEKLASSE', 'visbestand_fao_code'])[
    'VERKOOP_HOEVEELHEID_DOOD'].transform('sum')
df_verkoop["verkoop_categorie_levend"] = \
df_verkoop.groupby(['Visreis_Nr', 'VERKOOP_GROOTTEKLASSE', 'visbestand_fao_code'])[
    'VERKOOP_hoeveelheid_levend_vdt'].transform('sum')

# Deleting obsolete columns
df_verkoop.drop(columns=['verkoopdocument_nr', 'VERKOOP_HOEVEELHEID_DOOD', 'VERKOOP_hoeveelheid_levend_vdt'],
                inplace=True)
# dropping duplicates
df_verkoop.drop_duplicates(inplace=True)

# splitting based on fish species, to merge later. Split into dataframes for different species, then we merge them in order to have different columns for different species.
# First getting a df with only PLE
df_verkoop_PLE = df_verkoop.loc[df_verkoop['visbestand_fao_code'] == "PLE", :]
df_verkoop_PLE.rename(index=str, columns={"verkoop_categorie_dood": "verkoop_PLE_dood",
                                          "verkoop_categorie_levend": "verkoop_PLE_levend"}, inplace=True)
df_verkoop_PLE.drop(columns=['visbestand_fao_code'], inplace=True)

# now creating df's for all sizes of the fish PLE. Renaming columns. Dropping grootteklasse column. Then I can merge them together so it's all in one line.
# I need to write a loop because there are 10 size classes
df_verkoop_PLE1 = df_verkoop_PLE.loc[df_verkoop_PLE['VERKOOP_GROOTTEKLASSE'] == 1, :]
df_verkoop_PLE1.rename(index=str,
                       columns={'verkoop_PLE_dood': 'verkoop_PLE_dood_1', "verkoop_PLE_levend": 'verkoop_PLE_levend_1'},
                       inplace=True)
df_verkoop_PLE1.drop(columns=['VERKOOP_GROOTTEKLASSE'], inplace=True)

df_v_PLE = df_verkoop_PLE1.copy()
for a in range(2, 10):
    df_verkoop_PLE_a = df_verkoop_PLE.loc[df_verkoop_PLE['VERKOOP_GROOTTEKLASSE'] == a, :]
    df_verkoop_PLE_a.rename(index=str, columns={'verkoop_PLE_dood': 'verkoop_PLE_dood_' + str(a),
                                                "verkoop_PLE_levend": 'verkoop_PLE_levend_' + str(a)}, inplace=True)
    df_verkoop_PLE_a.drop(columns=['VERKOOP_GROOTTEKLASSE'], inplace=True)
    df_v_PLE = pd.merge(df_v_PLE, df_verkoop_PLE_a,
                        on=['Vaartuig', 'Visreis_Nr', 'DatumTijd_Vertrek', 'DatumTijd_Terugkeer', 'HavenCode_Vertrek',
                            'HavenCode_Terugkeer'], how='outer')

# Secondly getting a df with only fish SOL
df_verkoop_SOL = df_verkoop.loc[df_verkoop['visbestand_fao_code'] == "SOL", :]
df_verkoop_SOL.rename(index=str, columns={"verkoop_categorie_dood": "verkoop_SOL_dood",
                                          "verkoop_categorie_levend": "verkoop_SOL_levend"}, inplace=True)
df_verkoop_SOL.drop(columns=['visbestand_fao_code'], inplace=True)

# Repeat the procedure we used for PLE. Now creating df's for all sizes of the fish SOL. Renaming columns. Dropping grootteklasse column. Then I can merge them together so it's all in one line.
df_verkoop_SOL1 = df_verkoop_SOL.loc[df_verkoop_SOL['VERKOOP_GROOTTEKLASSE'] == 1, :]
df_verkoop_SOL1.rename(index=str,
                       columns={'verkoop_SOL_dood': 'verkoop_SOL_dood_1', "verkoop_SOL_levend": 'verkoop_SOL_levend_1'},
                       inplace=True)
df_verkoop_SOL1.drop(columns=['VERKOOP_GROOTTEKLASSE'], inplace=True)

df_v_SOL = df_verkoop_SOL1.copy()
for a in range(2, 10):
    df_verkoop_SOL_a = df_verkoop_SOL.loc[df_verkoop_SOL['VERKOOP_GROOTTEKLASSE'] == a, :]
    df_verkoop_SOL_a.rename(index=str, columns={'verkoop_SOL_dood': 'verkoop_SOL_dood_' + str(a),
                                                "verkoop_SOL_levend": 'verkoop_SOL_levend_' + str(a)}, inplace=True)
    df_verkoop_SOL_a.drop(columns=['VERKOOP_GROOTTEKLASSE'], inplace=True)
    df_v_SOL = pd.merge(df_v_SOL, df_verkoop_SOL_a,
                        on=['Vaartuig', 'Visreis_Nr', 'DatumTijd_Vertrek', 'DatumTijd_Terugkeer', 'HavenCode_Vertrek',
                            'HavenCode_Terugkeer'], how='outer')

# merging it all back into one large verkoop dataframe
df_verkoop_improved = pd.merge(df_v_SOL, df_v_PLE,
                               on=['Vaartuig', 'Visreis_Nr', 'DatumTijd_Vertrek', 'DatumTijd_Terugkeer',
                                   'HavenCode_Vertrek', 'HavenCode_Terugkeer'], how='outer')

# %% # Merging
# Aanland + Verkoop

dfx = pd.merge(df_aanland_improved, df_verkoop_improved, how='left',
               on=['Vaartuig', 'Visreis_Nr', 'DatumTijd_Vertrek', 'DatumTijd_Terugkeer', 'HavenCode_Vertrek',
                   'HavenCode_Terugkeer'])

# %% # Clearing some variables since it's become messy

del a, datumtijd_terug, datumtijd_vertrek, df_PLE, df_SOL, df_aanland_mergedsizes, df_bovenmaats, df_v_PLE, df_v_SOL, df_verkoop_PLE1, df_verkoop_PLE_a, df_verkoop_SOL, df_verkoop_SOL1, df_verkoop_SOL_a, todrop2, todrop5, torename
df_final = dfx.copy()

# Dropped a part where we calculated the sum of dagvangsten as well- which we used before for the difference in debarkation kilo's and sum of dagvangsten sales
df_final.to_csv(folder + 'Output\\' + 'trips_sales_2019.csv', index=False)



