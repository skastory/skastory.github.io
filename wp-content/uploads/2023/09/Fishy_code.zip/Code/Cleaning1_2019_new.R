########################################################################
##  Code for: Fishing fraud  (Kastoryano & Vollaard)                  ##
##                                                                    ##
##  Author: Stephen Kastoryano & Jean van Haperen                     ##
##  Date  : 01 September 2020                                         ##
##                                                                    ##
##  Purpose: Cleaning data for analysis                               ##
##                                                                    ##
##  Code input: trips_sales.csv from old file generation 'NVWA_data_preparation_4_Weekvangst_Simplified_GEANNOTEERD.py'
##              trips_sales_2019.csv from 'NVWA_data_preparation_4_2019data.py'
##              VIS_KUB_VTG_Old_VTG_va_nov2018.csv gives key for vessel id changes (source data)
##              deploy_2017to2019.csv based on deploymnet information (summarized in 'No_deploy_2017to2019.csv' >> only 95% sure this is correct info source),
##              kenmerken vaartuigen.csv, weather_data_1718.csv, fuel_pricesNL.csv in 'Final preparation and estimation in STATA'
##  Code output: For Tables_and_Figures.R
##                Data_final_1719.csv
##                Data_final_1719_newProb.csv  
##               For Figures_Final.R
##                map_ais.csv
##
##
##                                                                    ##
########################################################################


rm(list=ls())

pacman::p_load(data.table, plm,plyr,stargazer,ggplot2,foreign,tidyverse,rccmisc) # Loading packages

file = "D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Output\\trips_sales.csv"
file_2019 = "D:\\Dropbox\\vis\\New data per Nov 2020\\trips_sales_2019.csv"

# Import the data and set the appropriate column types to numeric
# 2017-2018 data
fishdata_1718 = read.csv(file,colClasses = c("character", "numeric",rep("character",9),rep("numeric",44)), na.strings=c(""," ","NA"))
Vaartuig_1920 =matrix("NA", NROW(fishdata_1718),1)
Vaartuig_1718 = fishdata_1718$Vaartuig
fishdata_1718 =cbind(fishdata_1718, Vaartuig_1920, Vaartuig_1718)
fishdata_1718 = fishdata_1718[(as.Date(fishdata_1718$datumtijd_vertrek,format="%Y-%m-%d") <"2018-11-01"),]  # drop observations after 01.11.2018 as these are duplicated in 2019-2020 dataset (and more complete in the 2019-2020 dataset)
fishdata_1718 <- fishdata_1718[order(fishdata_1718$datumtijd_vertrek ),]

# 2019-2020 data
fishdata_1920 = read.csv(file_2019,colClasses = c("character", "numeric",rep("character",9),rep("numeric",44)), na.strings=c(""," ","NA"))
colnames(fishdata_1920)[1] <- c("Vaartuig_1920")




file_IDchange = "D:\\Dropbox\\vis\\New data per Nov 2020\\VIS_KUB_VTG_Old_VTG_va_nov2018.csv"

# Import the data and set the appropriate column types to numeric
data_IDchange = read.csv(file_IDchange,colClasses = c(rep("character",2)))
colnames(data_IDchange) <- c("Vaartuig_1920", "Vaartuig")
data_IDchange$Vaartuig = data_IDchange$Vaartuig
data_IDchange$Vaartuig[is.na(data_IDchange$Vaartuig)] <- data_IDchange$Vaartuig_1920[is.na(data_IDchange$Vaartuig)] 

fishdata_1920 <- merge(fishdata_1920, data_IDchange, by.fishdata_1920="Vaartuig_1920")
Vaartuig_1718 =matrix("NA", NROW(fishdata_1920),1)
fishdata_1920 =cbind(fishdata_1920, Vaartuig_1718)

# bind 2017-2018 and 2018-2019 datasets
fishdata = rbind(fishdata_1718, fishdata_1920)
#fishdata = fishdata_1718




dim(fishdata)
fishdata <- fishdata[, -c(3:5,7)] # drop redundent variables
fishdata = lownames(fishdata)  # make all column names lower case to be consistent with old code



# Converting dates
fishdata$datumtijd_terug_time  = as.POSIXct(fishdata$datumtijd_terug)
fishdata$datumtijd_vertrek_time  = as.POSIXct(fishdata$datumtijd_vertrek)
fishdata$length_trip_hr = (fishdata$datumtijd_terug_time-fishdata$datumtijd_vertrek_time)/60  # number of hours at sea

fishdata$datumtijd_terug = as.Date(fishdata$datumtijd_terug,format="%Y-%m-%d")
fishdata$datumtijd_vertrek = as.Date(fishdata$datumtijd_vertrek,format="%Y-%m-%d")
fishdata$time_index_dep = strftime(fishdata$datumtijd_vertrek,format= "%Y-%U")
fishdata$time_index_return = strftime(fishdata$datumtijd_terug,format= "%Y-%U")


fishdata$day_return = strftime(fishdata$datumtijd_terug,'%A')
fishdata$day_dep = strftime(fishdata$datumtijd_vertrek,'%A')
fishdata$year_return = strftime(fishdata$datumtijd_terug,'%Y')
fishdata$week_return = strftime(fishdata$datumtijd_terug,format= "%U")
fishdata$week_return =  as.numeric(fishdata$week_return) * as.numeric(fishdata$year_return == "2017") + ( as.numeric(fishdata$week_return)+52) * as.numeric(fishdata$year_return == "2018") 


names(fishdata)[names(fishdata) == "datumtijd_vertrek"] <- "vertrek"  # Changing names of columns
names(fishdata)[names(fishdata) == "datumtijd_terug"] <- "terugkeer"  # Changing names of columns



# Dropping superfluous columns
drops_dood = c("verkoop_sol_dood_1","verkoop_sol_dood_2","verkoop_sol_dood_3","verkoop_sol_dood_4","verkoop_sol_dood_5",
               "verkoop_sol_dood_6","verkoop_sol_dood_7","verkoop_sol_dood_8","verkoop_sol_dood_9","verkoop_ple_dood_1","verkoop_ple_dood_2",
               "verkoop_ple_dood_3","verkoop_ple_dood_4","verkoop_ple_dood_5","verkoop_ple_dood_6","verkoop_ple_dood_7","verkoop_ple_dood_8",
               "verkoop_ple_dood_9","aanlanding_ple_ondermaats_dood","aanlanding_sol_ondermaats_dood","aanlanding_ple_bovenmaats_dood","aanlanding_sol_bovenmaats_dood")

# verkoop_sol_levend_1: largest fish: tong groot: >35cm and >500 gr , verkoop_sol_levend_2: large fish: tong groot middel: 33-35 cm and 300-500 gr 
# verkoop_sol_levend_3: med sized fish: tong klein middel: 30-33 cm and 230-300 gr ,  verkoop_sol_levend_4: small fish: tong 1: 27-30 cm and 180-230 gr 
# verkoop_sol_levend_5: smallest legally saleable fish: tong 2: 24-27 cm and 120-180 gr , verkoop_sol_levend_7: below minimum size fish: ondermaats

drops_levend = c("verkoop_sol_levend_6","verkoop_sol_levend_8","verkoop_sol_levend_9","verkoop_ple_levend_6","verkoop_ple_levend_8","verkoop_ple_levend_9")  #For Sole: leven_6 has 140 entries although it is not clear why. These do not seem to relfect mistakes in data entries in other size categories. Given the relatively small frequencies we also delete this column as well.
fishdata = fishdata[,!(names(fishdata) %in% drops_dood)]
fishdata = fishdata[,!(names(fishdata) %in% drops_levend)] #dropping columns of data that don't represent anything. category 7 is ondermaats

# Replacing NA's in some columns with zero's
col_na_tozero = c( "verkoop_sol_levend_1","verkoop_sol_levend_2", "verkoop_sol_levend_3","verkoop_sol_levend_4","verkoop_sol_levend_5","verkoop_sol_levend_7")
fishdata[col_na_tozero][is.na(fishdata[col_na_tozero])] <- 0
col_na_tozero = c( "verkoop_ple_levend_1","verkoop_ple_levend_2", "verkoop_ple_levend_3","verkoop_ple_levend_4","verkoop_ple_levend_7")
fishdata[col_na_tozero][is.na(fishdata[col_na_tozero])] <- 0

# Determining the total catch of sole, category 1 is largest category 5 is smallest legal, category 7 is illegally small.
fishdata$kg_totaal = fishdata$verkoop_sol_levend_1 + fishdata$verkoop_sol_levend_2 + fishdata$verkoop_sol_levend_3 + fishdata$verkoop_sol_levend_4 + fishdata$verkoop_sol_levend_5 + fishdata$verkoop_sol_levend_7
fishdata$kg_totaal_ple = fishdata$verkoop_ple_levend_1 + fishdata$verkoop_ple_levend_2 + fishdata$verkoop_ple_levend_3 + fishdata$verkoop_ple_levend_4  + fishdata$verkoop_ple_levend_7


# Calculating catch per trip for fishing vessels and merging this information back in. In order to determine which vessels have the minimum average catch per trip.
id_catch = fishdata[,c("vaartuig","kg_totaal")]
catch_per_boat = aggregate(. ~vaartuig, data=id_catch, sum, na.rm=TRUE)
occurances = as.data.frame(table(id_catch$vaartuig))
occurances["catch_total"] = catch_per_boat[,"kg_totaal"]
occurances["avg_catch_per_trip"] = occurances["catch_total"] / occurances["Freq"]
fishdata = merge(fishdata,occurances,by.x = "vaartuig",by.y = "Var1")


# Creating a histogram that shows the average catch per trip per fishing vessel
hist(occurances$avg_catch_per_trip,breaks=80,xlim=c(0,4000),xlab="Average Catch of Sole per Trip for Fishing Vessels",main="", col=c("#0099FF"))
hist(occurances$avg_catch_per_trip,breaks=2000,xlim=c(0,100),xlab="Average Catch of Sole per Trip for Fishing Vessels",main="", col=c("#0099FF"))


# Setting some parameters and generating minimum amount caught dataframes. I'm leaving out observations where weekvangst is zero (afwijking = -1) or the amount landed is zero (afwijking is infinite)
dim(fishdata)
minkgsol    = 50   # set minimum average kg of sol caught per trip to minkgsol
fish_bb_sol = fishdata[which((fishdata$avg_catch_per_trip > minkgsol )),]  # Dropped 3490 observations
dim(fish_bb_sol)



# Select relevant variables for analysis
myvars <- c("vaartuig","vaartuig_1920","vaartuig_1718","vertrek","terugkeer","length_trip_hr","time_index_dep","time_index_return","year_return","day_dep","day_return","kg_totaal","catch_total","avg_catch_per_trip", "Freq" , 
            "verkoop_sol_levend_1","verkoop_sol_levend_2","verkoop_sol_levend_3","verkoop_sol_levend_4","verkoop_sol_levend_5","verkoop_sol_levend_7","aanlanding_sol_ondermaats_levend", "aanlanding_sol_bovenmaats_levend",
            "verkoop_ple_levend_1","verkoop_ple_levend_2","verkoop_ple_levend_3","verkoop_ple_levend_4","verkoop_ple_levend_7","aanlanding_ple_ondermaats_levend","aanlanding_ple_bovenmaats_levend", "kg_totaal_ple",       
            "haven_vertrek","fge_fao_gebied_code","haven_terugkeer","visreis_nr")
fish_bb_sol = fish_bb_sol[,myvars]
table(fish_bb_sol$terugkeer-fish_bb_sol$vertrek)
fish_bb_sol = fish_bb_sol[(fish_bb_sol$terugkeer-fish_bb_sol$vertrek  <14),]   # drop 4 observations with trips above 14 days

# Defining the week at sea for each ship
fish_bb_sol$week_index <- 0
first_day=as.numeric( as.Date("2017-01-01",format="%Y-%m-%d"))  # first day of time period
last_day=as.numeric( as.Date("2020-09-27",format="%Y-%m-%d"))  # last day of time period !! last_day minus first_day needs to be divisible by 7  !!
(last_day-first_day)/7
dim(fish_bb_sol)
fish_bb_sol = fish_bb_sol[(fish_bb_sol$terugkeer<=last_day),]   # drop 9 observations with returns after "2020-09-27" 
dim(fish_bb_sol)

i = first_day
for (i in seq(from=first_day, to=last_day , by=7)) {
  
  fish_bb_sol$week_index = fish_bb_sol$week_index  +  
    ((i-first_day+7)/7)* as.numeric(fish_bb_sol$vertrek >= i)*as.numeric(fish_bb_sol$terugkeer < (i+7)) +   # if depart and return in same week
    ((i-first_day+7)/7)* as.numeric(fish_bb_sol$vertrek >= i)*as.numeric(fish_bb_sol$vertrek < (i+7))* as.numeric(fish_bb_sol$terugkeer >= (i+7)) * as.numeric(i+7-as.numeric(fish_bb_sol$vertrek) > as.numeric(fish_bb_sol$terugkeer) -i -6) + # spent more days in this week than next week
    ((i-first_day+14)/7)* as.numeric(fish_bb_sol$vertrek >= i)*as.numeric(fish_bb_sol$vertrek < (i+7))* as.numeric(fish_bb_sol$terugkeer >= (i+7)) * as.numeric(i+7-as.numeric(fish_bb_sol$vertrek) <= as.numeric(fish_bb_sol$terugkeer) -i -6)   # spent more or equal days in next week than this week
}

# check = fish_bb_sol[(fish_bb_sol$week_index != fish_bb_sol$time_index_return ),]
# check = cbind(check$vaartuig , as.character(check$vertrek),as.character(check$terugkeer),check$week_index,check$week_return)
# 
fish_bb_sol <- fish_bb_sol[order(fish_bb_sol$terugkeer),]
table(fish_bb_sol$week_index )
hist(fish_bb_sol$week_index ,breaks=100,xlim=c(0,195),xlab="Average Landed Sole per Trip for Fishing Vessels",main="", col=c("#0099FF"))


### DEALING WITH DUPLICATES  ###
################################

# We need unique vessel - date combinations. I will split the duplicates out and combine them.
fish_bb_sol <- fish_bb_sol[order(fish_bb_sol$vaartuig,fish_bb_sol$week_index,fish_bb_sol$vertrek ),] # sort variables
dim(fish_bb_sol)
fish_bb_sol = fish_bb_sol[!(duplicated(fish_bb_sol[,c("vaartuig","week_index","vertrek")])),]  # delete 671 observations which are repeated
dim(fish_bb_sol)
dupl = fish_bb_sol[(duplicated(fish_bb_sol[,c("vaartuig","week_index")])|duplicated(fish_bb_sol[,c("vaartuig","week_index")],fromLast=TRUE)),]



dupl1 = dupl[,c("vaartuig","vaartuig_1920","vaartuig_1718","vertrek","length_trip_hr","time_index_dep","day_dep","catch_total","avg_catch_per_trip", "Freq" , "haven_vertrek","fge_fao_gebied_code","visreis_nr", "week_index")]
col_dupl2 = c("kg_totaal","verkoop_sol_levend_1","verkoop_sol_levend_2","verkoop_sol_levend_3","verkoop_sol_levend_4","verkoop_sol_levend_5","verkoop_sol_levend_7","aanlanding_sol_ondermaats_levend", "aanlanding_sol_bovenmaats_levend",
              "verkoop_ple_levend_1","verkoop_ple_levend_2","verkoop_ple_levend_3","verkoop_ple_levend_4","verkoop_ple_levend_7","aanlanding_ple_ondermaats_levend","aanlanding_ple_bovenmaats_levend","kg_totaal_ple")
dupl2 = dupl[,col_dupl2]
dupl2[is.na(dupl2)] <- 0
dupl4 = dupl[,c("terugkeer","time_index_return","year_return","day_return","haven_terugkeer")]

temp_names = c("vaartuig","vaartuig_1920","vaartuig_1718","vertrek","length_trip_hr","time_index_dep","day_dep","catch_total","avg_catch_per_trip", "Freq" , "haven_vertrek","fge_fao_gebied_code","visreis_nr", "week_index",
               "kg_totaal","verkoop_sol_levend_1","verkoop_sol_levend_2","verkoop_sol_levend_3","verkoop_sol_levend_4","verkoop_sol_levend_5","verkoop_sol_levend_7","aanlanding_sol_ondermaats_levend", "aanlanding_sol_bovenmaats_levend",
               "verkoop_ple_levend_1","verkoop_ple_levend_2","verkoop_ple_levend_3","verkoop_ple_levend_4","verkoop_ple_levend_7","aanlanding_ple_ondermaats_levend","aanlanding_ple_bovenmaats_levend", "kg_totaal_ple",
               "terugkeer","time_index_return","year_return","day_return","haven_terugkeer")
mdupl = data.frame(matrix(NA, nrow = 1, ncol = ncol(dupl)))
colnames(mdupl) <- temp_names

j=1
while (j < nrow(dupl)) {
  dup1 = dupl1[j,]    # keep first dates, etc. 
  dup2 = dupl2[j,]
  i=1
  while (as.numeric(dupl$vaartuig[j] ==dupl$vaartuig[j+i])*as.numeric(dupl$week_index[j] ==dupl$week_index[(j+i)])){  
    dup2 = dup2 + dupl2[j+i,]     # sum fish catch variables
    i=i+1
    if (j+i > nrow(dupl)) {
      break
    }
  }
  j=j+i-1
  dup4 = dupl4[j,]    # keep last dates, etc. from last of duplicates
  
  mdupl = rbind(mdupl, cbind(dup1,dup2,dup4))
  j=j+1
  
}


final_var = c("vaartuig","vaartuig_1920","vaartuig_1718","vertrek","terugkeer","length_trip_hr","week_index","time_index_dep","time_index_return","day_dep","day_return","kg_totaal", "catch_total","avg_catch_per_trip", "Freq",
              "verkoop_sol_levend_1","verkoop_sol_levend_2","verkoop_sol_levend_3","verkoop_sol_levend_4","verkoop_sol_levend_5","verkoop_sol_levend_7","aanlanding_sol_ondermaats_levend", "aanlanding_sol_bovenmaats_levend",
              "verkoop_ple_levend_1","verkoop_ple_levend_2","verkoop_ple_levend_3","verkoop_ple_levend_4","verkoop_ple_levend_7","aanlanding_ple_ondermaats_levend","aanlanding_ple_bovenmaats_levend", "kg_totaal_ple",       
              "haven_vertrek","fge_fao_gebied_code","haven_terugkeer","visreis_nr")
dupl = mdupl[2:nrow(mdupl),final_var]

dupl$vertrek <- as.Date(dupl$vertrek, origin = "1970-01-01")
dupl$terugkeer <- as.Date(dupl$terugkeer, origin = "1970-01-01")


# extract entries which were not same week (non-duplicates)
fish_bb_sol <- fish_bb_sol[order(fish_bb_sol$vaartuig,fish_bb_sol$week_index,fish_bb_sol$vertrek ),] # sort variables
nondupl =fish_bb_sol[!(duplicated(fish_bb_sol[,c("vaartuig","week_index")])|duplicated(fish_bb_sol[,c("vaartuig","week_index")],fromLast=TRUE)),]
nondupl = nondupl[,final_var]

# combine and order the full data
fish_sol = rbind(dupl,nondupl)
fish_sol <- fish_sol[order(fish_sol$vaartuig,fish_sol$week_index),]  
dim(fish_sol)



## Dropping observations in 2020
last_day=as.numeric( as.Date("2019-12-29",format="%Y-%m-%d"))  # last day of time period !! last_day minus first_day needs to be divisible by 7  !!
(last_day-first_day)/7
dim(fish_sol)
fish_sol = fish_sol[(fish_sol$terugkeer<=last_day),]   # drop 2932 observations with returns after "2019-12-29" 
dim(fish_sol)


### Constructing the inspection ship (Barend Biesheuvel) treatment variable  ###
################################################################################


file_BB = "D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Stephen files\\deploy_2017to2019.csv"
# This file includes the dates, Monday to Thursday for the weeks in which the BB was deployed. We assume that the BB was deployed 
# during weeks of bad weather since they almost always still patrol the coastline during the bad weather days

# Import the data and set the appropriate column types to numeric
data_BBdep = read.csv(file_BB)
colnames(data_BBdep) <- c("start","end")

data_BBdep$start = as.Date(data_BBdep$start ,format="%d/%m/%Y")
data_BBdep$end = as.Date(data_BBdep$end ,format="%d/%m/%Y")



fish_sol$BB_patrol_frac = matrix(0,nrow(fish_sol), 1)  # Numeric Variable for fraction of days BB was patrolling while vessel was at sea fishing
fish_sol$BB_patrol_Dnot0 = matrix(0,nrow(fish_sol), 1)  # Indicator Variable =1 if fish_sol$BB_patrol_frac > 0
fish_sol$BB_patrol_D25 = matrix(0,nrow(fish_sol), 1)  # Indicator Variable =1 if fish_sol$BB_patrol_frac >= 25
fish_sol$BB_patrol_D50 = matrix(0,nrow(fish_sol), 1)  # Indicator Variable =1 if fish_sol$BB_patrol_frac >= 50
fish_sol$BB_patrol_D75 = matrix(0,nrow(fish_sol), 1)  # Indicator Variable =1 if fish_sol$BB_patrol_frac >= 75
fish_sol$BB_patrol_D1 = matrix(0,nrow(fish_sol), 1)  # Indicator Variable =1 if fish_sol$BB_patrol_frac == 1


for (i in 1:nrow(fish_sol)) {
  frac1 = 0;frac2 = 0;frac3 = 0;frac4 = 0; frac1ind = 0;frac2ind = 0;frac3ind = 0; frac4ind = 0;
  for (j in 1:nrow(data_BBdep)) {
    frac1 = frac1 + ((as.numeric(data_BBdep$end[j]) - as.numeric(data_BBdep$start[j])+1)/(as.numeric(fish_sol$terugkeer[i])-as.numeric(fish_sol$vertrek[i])+1))*
      as.numeric(data_BBdep$start[j] >= fish_sol$vertrek[i])*as.numeric(data_BBdep$end[j] <= fish_sol$terugkeer[i])  # if BB deployed between duration of fishing trip 

    frac2 = frac2 + ((as.numeric(data_BBdep$end[j]) - as.numeric(fish_sol$vertrek[i])+1)/(as.numeric(fish_sol$terugkeer[i])-as.numeric(fish_sol$vertrek[i])+1))*
      as.numeric(data_BBdep$start[j] < fish_sol$vertrek[i])*as.numeric(data_BBdep$end[j] >= fish_sol$vertrek[i])*as.numeric(data_BBdep$end[j] <= fish_sol$terugkeer[i])  # if BB deployed before start but returns before end of fishing trip 

    frac3 = frac3 + ((as.numeric(fish_sol$terugkeer[i]) - as.numeric(data_BBdep$start[j])+1)/(as.numeric(fish_sol$terugkeer[i])-as.numeric(fish_sol$vertrek[i])+1))*
      as.numeric(data_BBdep$start[j] >= fish_sol$vertrek[i])*as.numeric(data_BBdep$start[j] <= fish_sol$terugkeer[i])*as.numeric(data_BBdep$end[j] > fish_sol$terugkeer[i])  # if BB deployed after start but returns after end of fishing trip 

    frac4 = frac4 + 1*as.numeric(data_BBdep$start[j] < fish_sol$vertrek[i])*as.numeric(data_BBdep$end[j] > fish_sol$terugkeer[i])  # 1 if BB deployed entire duration of fishing trip

  }
  
  fish_sol$BB_patrol_frac[i] = frac1 + frac2 + frac3 + frac4
  
  
  fish_sol$BB_patrol_Dnot0[i] = as.numeric( fish_sol$BB_patrol_frac[i] > 0) 
  fish_sol$BB_patrol_D25[i] = as.numeric( fish_sol$BB_patrol_frac[i] >= 0.25) 
  fish_sol$BB_patrol_D50[i] = as.numeric( fish_sol$BB_patrol_frac[i] >= 0.50) 
  fish_sol$BB_patrol_D75[i] = as.numeric( fish_sol$BB_patrol_frac[i] >= 0.75) 
  fish_sol$BB_patrol_D1[i] = as.numeric( fish_sol$BB_patrol_frac[i] == 1) 
}






### Merge data on fishing ship characteristics ###
##################################################

file_char = "D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Final preparation and estimation in STATA\\kenmerken vaartuigen.csv"

# Import the data and set the appropriate column types to numeric
data_char = read.csv(file_char,colClasses = c("character",rep("numeric",4)))

data_char <- data_char[seq(2,nrow(data_char),2),1:4]  # select only even rows. All but 4 entries all replicated in 2017 and 2018

Data_final <- merge(fish_sol, data_char, by.data_char="vaartuig")


### Merge data on weekly weather ###
####################################

file_weather = "D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Final preparation and estimation in STATA\\weather_data_1718.csv"

# Import the data and set the appropriate column types to numeric
data_weather = read.csv(file_weather,colClasses = c(rep("numeric",12)))
colnames(data_weather)[1] <- "year"
colnames(data_weather)[2] <- "week"
colnames(data_weather)
data_weather$week_index = data_weather$week*as.numeric(data_weather$year == 2017) + (data_weather$week + 52)*as.numeric(data_weather$year == 2018) + (data_weather$week + 104)*as.numeric(data_weather$year == 2019)
data_weather = data_weather[,3:ncol(data_weather)]


Data_final <- merge(Data_final, data_weather, by.data_weather="week_index")  

Data_final <- Data_final[order(Data_final$vaartuig,Data_final$week_index,Data_final$vertrek ),] # sort variables


# Split string of Vaartuig in Data_final to merge properly
vaartuig = Data_final$vaartuig
vaartuig_split = strsplit(vaartuig, "Vaartuig_")
vaartuig_split = matrix(unlist(vaartuig_split), ncol=2, byrow=TRUE)
Data_final$vaartuig <- as.numeric(vaartuig_split[,2])


# ### Merge data on weekly vessel inspections ###
# ###############################################
# 
# library("openxlsx","strsplit")
# file_insp = "D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Final preparation and estimation in STATA\\inspecties.xlsx"
# 
# # Import the data and set the appropriate column types to numeric
# data_insp = read.xlsx(file_insp, sheet = 1,colNames = TRUE)
# data_insp$week_index = data_insp$week*as.numeric(data_insp$jaar == 2017) + (data_insp$week + 52)*as.numeric(data_insp$jaar == 2018)
# data_insp = data_insp[,3:ncol(data_insp)]
# 
# 
# 
# 
# # Split string of Vaartuig in Data_final to merge properly
# vaartuig = Data_final$vaartuig
# vaartuig_split = strsplit(vaartuig, "Vaartuig_")
# vaartuig_split = matrix(unlist(vaartuig_split), ncol=2, byrow=TRUE)
# Data_final$vaartuig <- as.numeric(vaartuig_split[,2])
# 
# Data_final <- Data_final[order(Data_final$vaartuig,Data_final$week_index,Data_final$vertrek ),] # sort variables
# data_insp <- data_insp[order(data_insp$vaartuig,data_insp$week_index ),] # sort variables
# 
# Data_final <- merge(Data_final, data_insp, by=c("vaartuig","week_index"), all=T)
# 
# Data_final <- Data_final[!is.na(Data_final$vertrek),]  # remove inspection of ships which are not in sole dataset
# Data_final$inspectie[is.na(Data_final$inspectie)] <- 0
# 



### Merge data on fuel prices    ###
####################################  

file_fuel = "D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Final preparation and estimation in STATA\\fuel_pricesNL.csv"

data_fuel = read.csv(file_fuel,colClasses = c("numeric","character","numeric","numeric"))[,-1]
data_fuel$Date =as.Date(data_fuel$Perioden,format="%Y%m%d")
data_fuel = as.data.frame(data_fuel[,-1])

plot(data_fuel$Date,data_fuel$BenzineEuro95_1) 
plot(data_fuel$Date,data_fuel$Diesel_2) 
plot(data_fuel$Date,data_fuel$LPG_3) 

# # Matching on the day of vessel departure for each ship
names(data_fuel)[names(data_fuel) == "BenzineEuro95_1"] <- "BenzineEuro95"
names(data_fuel)[names(data_fuel) == "Diesel_2"] <- "Diesel"
names(data_fuel)[names(data_fuel) == "LPG_3"] <- "LPG"
names(data_fuel)[names(data_fuel) == "Date"] <- "vertrek"

Data_final <- merge(Data_final, data_fuel, by.data_fuel="vertrek")


# # Matching on the week at sea for each ship
# data_fuel$week_index <- 0
# first_day=as.numeric( as.Date("2017-01-01",format="%Y-%m-%d"))  # first day of time period
# last_day=as.numeric( as.Date("2020-09-27",format="%Y-%m-%d"))  # last day of time period !! last_day minus first_day needs to be divisible by 7  !!
# (last_day-first_day)/7
# dim(data_fuel)
# data_fuel = data_fuel[(data_fuel$Date<=last_day),]   # drop 5 observations with returns after "2020-09-27" 
# dim(data_fuel)
# 
# i = first_day
# for (i in seq(from=first_day, to=last_day , by=7)) {
#   data_fuel$week_index = data_fuel$week_index  +  (as.numeric(data_fuel$Date) >= i)
#   }
# 
# library("doBy")
# data_fuel = summaryBy(BenzineEuro95_1+Diesel_2+LPG_3 ~ week_index , data=data_fuel)
# names(data_fuel)[names(data_fuel) == "BenzineEuro95_1.mean"] <- "BenzineEuro95"
# names(data_fuel)[names(data_fuel) == "Diesel_2.mean"] <- "Diesel"
# names(data_fuel)[names(data_fuel) == "LPG_3.mean"] <- "LPG"
# 
# Data_final <- merge(Data_final, data_fuel, by.data_fuel="week_index")





## Final variable selection  ##
###############################
ls(Data_final)

final_var = c("vaartuig","vaartuig_1920","vaartuig_1718","week_index", "vertrek","terugkeer","length_trip_hr","time_index_dep","time_index_return","day_dep","day_return","kg_totaal", 
              "verkoop_sol_levend_1","verkoop_sol_levend_2","verkoop_sol_levend_3","verkoop_sol_levend_4","verkoop_sol_levend_5","verkoop_sol_levend_7",
              "aanlanding_sol_ondermaats_levend", "aanlanding_sol_bovenmaats_levend", "verkoop_ple_levend_1","verkoop_ple_levend_2","verkoop_ple_levend_3","verkoop_ple_levend_4","verkoop_ple_levend_7",
              "aanlanding_ple_ondermaats_levend", "aanlanding_ple_bovenmaats_levend", "kg_totaal_ple",
              "catch_total","avg_catch_per_trip", "Freq" , "windnoord", "windzuid", "windwest", "windoost", "windsnelheid", "temp", "watertemp", "golfhoogte", "maxdaggolfhoogte", "luchtdruk_k13_k14",
              "haven_vertrek","fge_fao_gebied_code","haven_terugkeer","visreis_nr","BB_patrol_frac" , "BB_patrol_Dnot0", "BB_patrol_D25", 
              "BB_patrol_D50","BB_patrol_D75","BB_patrol_D1", "vermogen","lengte_over_alles","tonnage", "BenzineEuro95","Diesel","LPG")
Data_final_1719 = Data_final[,final_var]

#names(Data_final)
#dim(Data_final)

#check = Data_final[,c("vaartuig","week_index","vertrek","terugkeer","BB_patrol_frac" ,"BB_patrol_reas","BB_patrol_D25", 
#                      "BB_patrol_D50","BB_patrol_D75","BB_patrol_D1","BB_patrol_longtrip" ,"BB_patrol_badweather", "BB_patrol_vacation")]


#Data_final =nondupl
write.csv(Data_final_1719,  "D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Stephen files\\Data_final_1719_new.csv")

write.dta(Data_final_1719,  "D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Stephen files\\Data_final_1719_new.dta")





















############################################################################################################
####   Prepare data for analysing probability of vessel fishing 
####################################################################






df <- read.csv( "D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Stephen files\\Data_final_1719_new.csv")
df = df[,-1]




# Defining the week at sea for each ship

first_day=as.Date("2017-01-01",format="%Y-%m-%d")  # first day of time period
last_day=as.Date("2019-12-28",format="%Y-%m-%d")  # last day of time period !! last_day minus first_day needs to be divisible by 7  !!
(last_day-first_day+1)/7

dfp =as.data.frame(1)
names(dfp) <- "week_index"
dfp$vaartuig = "Vaartuig_0"
dfp$kg_totaal = 0
dfp$kg_totaal_ple = 0

dfp$verkoop_sol_levend_1 = 0
dfp$verkoop_sol_levend_2 = 0
dfp$verkoop_sol_levend_3 = 0
dfp$verkoop_sol_levend_4 = 0
dfp$verkoop_sol_levend_5 = 0
dfp$verkoop_sol_levend_7 = 0
dfp$verkoop_ple_levend_1 = 0
dfp$verkoop_ple_levend_2 = 0
dfp$verkoop_ple_levend_3 = 0
dfp$verkoop_ple_levend_4 = 0
dfp$verkoop_ple_levend_7 = 0


for (p in unique(df$vaartuig)) {
  
  dfp1 =as.data.frame(seq(1,156,1))
  names(dfp1) <- "week_index"
  dfp1$vaartuig = matrix(p,156,1)
  dfp1$kg_totaal = 0
  dfp1$kg_totaal_ple = 0
  
  dfp1$verkoop_sol_levend_1 = 0
  dfp1$verkoop_sol_levend_2 = 0
  dfp1$verkoop_sol_levend_3 = 0
  dfp1$verkoop_sol_levend_4 = 0
  dfp1$verkoop_sol_levend_5 = 0
  dfp1$verkoop_sol_levend_7 = 0
  dfp1$verkoop_ple_levend_1 = 0
  dfp1$verkoop_ple_levend_2 = 0
  dfp1$verkoop_ple_levend_3 = 0
  dfp1$verkoop_ple_levend_4 = 0
  dfp1$verkoop_ple_levend_7 = 0
  
  dfp =rbind(dfp,dfp1)
  
  
}
dfp =dfp[-1,]






### Merge data on fishing ship characteristics ###
##################################################

file_char = "D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Final preparation and estimation in STATA\\kenmerken vaartuigen.csv"

# Import the data and set the appropriate column types to numeric
data_char = read.csv(file_char,colClasses = c("character",rep("numeric",4)))

data_char <- data_char[seq(2,nrow(data_char),2),1:4]  # select only even rows. All but 4 entries all replicated in 2017 and 2018

# Split string of Vaartuig in Data_final to merge properly
vaartuig = data_char$vaartuig
vaartuig_split = strsplit(vaartuig, "Vaartuig_")
vaartuig_split = matrix(unlist(vaartuig_split), ncol=2, byrow=TRUE)
data_char$vaartuig <- as.numeric(vaartuig_split[,2])


dfp <- merge(dfp, data_char, by="vaartuig")





### Merge data on weekly weather ###
####################################

file_weather = "D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Final preparation and estimation in STATA\\weather_data_1718.csv"

# Import the data and set the appropriate column types to numeric
data_weather = read.csv(file_weather,colClasses = c(rep("numeric",12)))
colnames(data_weather)[1] <- "year"
colnames(data_weather)[2] <- "week"
colnames(data_weather)
data_weather$week_index = data_weather$week*as.numeric(data_weather$year == 2017) + (data_weather$week + 52)*as.numeric(data_weather$year == 2018) + (data_weather$week + 104)*as.numeric(data_weather$year == 2019)
data_weather = data_weather[,3:ncol(data_weather)]


dfp <- merge(dfp, data_weather, by="week_index")

dfp <- dfp[order(dfp$vaartuig,dfp$week_index ),] # sort variables



### Merge data on fuel prices    ###
####################################

file_fuel = "D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Final preparation and estimation in STATA\\fuel_pricesNL.csv"

data_fuel = read.csv(file_fuel,colClasses = c("numeric","character","numeric","numeric"))[,-1]
data_fuel$Date =as.Date(data_fuel$Perioden,format="%Y%m%d")
data_fuel = as.data.frame(data_fuel[,-1])

plot(data_fuel$Date,data_fuel$BenzineEuro95_1) 
plot(data_fuel$Date,data_fuel$Diesel_2) 
plot(data_fuel$Date,data_fuel$LPG_3) 


colnames(dfp)
names(dfp)

# Matching on the week at sea for each ship
data_fuel$week_index <- 0
first_day=as.numeric( as.Date("2017-01-01",format="%Y-%m-%d"))  # first day of time period
last_day=as.numeric( as.Date("2020-09-27",format="%Y-%m-%d"))  # last day of time period !! last_day minus first_day needs to be divisible by 7  !!
(last_day-first_day)/7
dim(data_fuel)
data_fuel = data_fuel[(data_fuel$Date<=last_day),]   # drop 5 observations with returns after "2020-09-27"
dim(data_fuel)

i = first_day
for (i in seq(from=first_day, to=last_day , by=7)) {
  data_fuel$week_index = data_fuel$week_index  +  (as.numeric(data_fuel$Date) >= i)
  }

library("doBy")
data_fuel = summaryBy(BenzineEuro95_1+Diesel_2+LPG_3 ~ week_index , data=data_fuel)
names(data_fuel)[names(data_fuel) == "BenzineEuro95_1.mean"] <- "BenzineEuro95"
names(data_fuel)[names(data_fuel) == "Diesel_2.mean"] <- "Diesel"
names(data_fuel)[names(data_fuel) == "LPG_3.mean"] <- "LPG"

dfp <- merge(dfp, data_fuel, by.data_fuel="week_index")

dfp <- dfp[order(dfp$vaartuig,dfp$week_index ),] # sort variables


dfp$BB_patrol_frac = 0

# Save file
write.csv(dfp,  "D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Stephen files\\Data_final_1719_newProb0.csv")












##################################################################################################
### Analysis Using vessel landing data  ###
##################################################

dfp <- read.csv( "D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Stephen files\\Data_final_1719_newProb0.csv")
dfp = dfp[,-1]
df <- read.csv( "D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Stephen files\\Data_final_1719_new.csv")
df = df[,-1]
df <- df[order(df$vaartuig,df$week_index),]

   
names(df)


df = df[,names(dfp)]
df2 = df[,c("vaartuig","week_index")]
df2$check = 1

#aggregate(df$week_index, list(df$vaartuig), length)


nrow(dfp)
dfp =  merge(dfp, df2, by.dfp=c("vaartuig","week_index"),all.x =TRUE)
nrow(dfp)
dfp$check = 1- as.numeric(is.na(dfp$check))
dfp = filter(dfp, (dfp$check == 0))
dfp = dfp[,-ncol(dfp)]


df <- rbind(df, dfp)
df <- df[order(df$vaartuig,df$week_index),]

write.csv(df,  "D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Stephen files\\Data_final_1719_newProb.csv")



















####################################################################
####################################################################
####   Prepare data for analysing of ais data
####################################################################
####################################################################



library("dplyr")
library("tidyr")
library("ggplot2")
library("plm")
library("lmtest")
library("sandwich")
library("clubSandwich")
library("lfe")
library("fixest")
library("missForest")
library("fs")
library("readxl")

df <- read.csv( "D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Stephen files\\Data_final_1719_new.csv")
df = df[,-1]

nrow(df)
df = filter(df, (df$week_index<105))  #keep only years 2017-2018 to match with vms
nrow(df)


## create data frame with one week for each day at sea of each vessel ##
atsea = cbind(df$vaartuig[1], df$week_index[1], as.Date(df$vertrek[1]),seq(as.Date(df$vertrek[1]), as.Date(df$terugkeer[1]), by = "day"))
for (i in 2:nrow(df)) {
  atsea = rbind(atsea,cbind(df$vaartuig[i],df$week_index[i], as.Date(df$vertrek[i]),seq(as.Date(df$vertrek[i]), as.Date(df$terugkeer[i]), by = "day")))
  
}

atsea = as.data.frame(atsea)
atsea[,3] = as.Date(as.numeric(atsea[,3])) 
atsea[,4] = as.Date(as.numeric(atsea[,4])) 
colnames(atsea) <- c("vaartuig", "week_index", "vertrek", "date")
sort(unique(atsea$vaartuig))


## Load all GIS datasets for each ship and put them in one readable file  ##
file_paths <- fs::dir_ls("D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Data VMS\\")
file_paths=  file_paths[-1]
file_paths=  file_paths[-NROW(file_paths)]

file_paths_split = strsplit(file_paths, "_")
file_paths_split = matrix(unlist(file_paths_split), ncol=4, byrow=TRUE)
vaartuig = strsplit(file_paths_split[,4], ".x") 
vaartuig = matrix(unlist(vaartuig), ncol=2, byrow=TRUE)
vaartuig = as.numeric(vaartuig[,1])

length(unique(vaartuig))
prep = cbind(read_excel( file_paths[1])[1,2:6])
prep$vaartuig = 0
for (i in seq_along(file_paths)){
  print(i)
  print(vaartuig[i])
  load_ais = read_excel( file_paths[i])[,2:6]
  load_ais$vaartuig = vaartuig[i]
  prep = rbind(prep, load_ais)
}
prep = prep[-1,]
colnames(prep) <- c("UTC.time", "Course",   "Speed","Lat", "Lon", "vaartuig")
prep$date = as.Date(prep$UTC.time,format="%Y-%m-%d")

prep1 = prep
nrow(prep1)
typeof(prep1$Speed)
prep1$Speed = as.numeric(sub(",", ".", prep1$Speed, fixed = TRUE))
prep1$speed_0 = as.numeric(prep1$Speed==0)
prep1$ais = 1

# impute values for NA in Speed as the lagged last seen value
sum(is.na(prep1$speed_0))
for (i in 2:nrow(prep1)){
  if (is.na(prep1$speed_0[i])*(prep1$vaartuig[i] ==prep1$vaartuig[i-1]))
  { 
    prep1$speed_0[i]= prep1$speed_0[i-1]
  }
}
sum(is.na(prep1$speed_0))

sum(is.na(prep1$Lat))

sum(is.na(prep2$speed_0))

prep2=prep1

# Drop incomplete and irretrieavable data 
nrow(prep2)
sum(is.na(prep2$date))
prep2 = prep2[!is.na(prep2$speed_0),] # 23 observations dropped
nrow(prep2)
prep2 = prep2[!is.na(prep2$date),]  # All of these pertain to one vessel. The data for vaartuig == 388 is just a complete mess. It is useless.


# Save data for plotting on maps
map_ais = full_join(prep2, atsea, by = c("vaartuig", "date"))
map_ais = map_ais[!is.na(map_ais$vertrek),]
map_ais = map_ais[!is.na(map_ais$Lat),]
# Save data for maps analysis
write.csv(map_ais,  "D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Stephen files\\map_ais.csv")

prep2$trawl_speed_D = as.numeric(prep2$Speed >5)    # Equal to 1 if vessel navigating at trawling speed
table(prep2$Speed)

prep3 =prep2[(prep2$Speed <20),]

hist(prep3$Speed,breaks=200,xlim=c(0,20),main="", col=c("#0099FF"))


df_aisnbr = aggregate(x=prep2$ais, by=list(prep2$vaartuig,prep2$date),FUN=sum)
df_aisnbr0 = aggregate(x=prep2$speed_0, by=list(prep2$vaartuig,prep2$date),FUN=sum)
df_trawl_speed = aggregate(x=prep2$trawl_speed_D, by=list(prep2$vaartuig,prep2$date),FUN=sum)
nrow(df_aisnbr)
nrow(df_aisnbr0)
nrow(df_trawl_speed)



df_aisnbr1 = as.data.frame(cbind(df_aisnbr, df_aisnbr0[,3],df_trawl_speed[,3]))
colnames(df_aisnbr1) <- c("vaartuig", "date", "ais_nbr", "ais_speed0","ais_trawl_speed")

## THE PROBLEM IS HERE. THE BASE YEAR IS DIFFERENT FOR DIFFERENT DATES

df_ais = full_join(df_aisnbr1, atsea, by = c("vaartuig", "date"))
nrow(df_ais)
df_ais = df_ais[!is.na(df_ais$vertrek),]  # drop non-matched
nrow(df_ais)
df_ais = df_ais[!is.na(df_ais$ais_nbr),]
nrow(df_ais)


sum(is.na(df_ais$ais_nbr))
df_aisnbr = aggregate(x=df_ais$ais_nbr, by=list(df_ais$vaartuig,df_ais$vertrek),FUN=sum)
df_aisnbr0 = aggregate(x=df_ais$ais_speed0, by=list(df_ais$vaartuig,df_ais$vertrek),FUN=sum)
df_trawl_speed = aggregate(x=df_ais$ais_trawl_speed, by=list(df_ais$vaartuig,df_ais$vertrek),FUN=sum)
Tot_ais = cbind(df_aisnbr, df_aisnbr0[,3],df_trawl_speed[,3])
colnames(Tot_ais) <- c("vaartuig", "vertrek", "ais_nbr", "ais_speed0","ais_trawl_speed")


sort(Tot_ais$vertrek)
sort(df$vertrek)

Tot_ais$vaartuig = as.integer(Tot_ais$vaartuig)
df$vertrek = as.character(df$vertrek)
Tot_ais$vertrek = as.character(Tot_ais$vertrek)


df_ais = full_join(df, Tot_ais, by = c("vaartuig", "vertrek"))
nrow(df_ais)
df_ais$vertrek = as.Date(df_ais$vertrek)
nrow(df_ais)
df_ais = df_ais[!(is.na(df_ais$ais_nbr)),]
nrow(df_ais)

# Save dataset to study ais effects
write.csv(df_ais,  "D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Stephen files\\df_ais.csv")




















