Project: Data preparation for "Unseen Annihilation: Illegal Fishing Practices and Nautical Patrol" Kastoryano & Vollaard

Code Author: Stephen Kastoryano, Seyit Hocuk & Jean van Haperen                                       
Date  : 30 June 2023  



1. "NVWA_data_preparation_1_vms_creator_GEANNOTEERD.py" in Python3
	INPUTS: all 'Vaartuig_###.xlsx' files in 'Data VMS' folder
	OUTPUT: "gekoppelde_VMS_bestanden.csv"

2. "NVWA_data_preparation_2_sequence_time_ships_creator_GEANNOTEERD.py" in Python3
	INPUTS: "gekoppelde_VMS_bestanden.csv" from above 1.; 'trips_sales.csv' in 'Data Visvangst' folder 
	OUTPUT: "locations_grid.csv"

3. "NVWA_data_preparation_3_inspection_location_creator_GEANNOTEERD.py" in Python3
	INPUTS: "locations_grid.csv" from above 2.; "Meerkatze-2017.tsv","Meerkatze-2018.tsv","Seefalke-2017.tsv", "Seefalke-2018.tsv" from 'Data Inspectieschepen' folder;
		'Vaartuig_BB_2017.xlsx', 'Vaartuig_BB_2018.xlsx' from 'Data Inspectieschepen' folder; 
		'coordinates_english_border.csv', 'coordinates_dutch_belgian_border.csv','coordinates_dutch_german_border.csv','coordinates_danish_german_border.csv','coordinates_danish_norwegian_border.csv' from 'Data Border' folder
	OUTPUT: "vms_combined_bb_seefalke_meerkatze_vestkysten.csv"

4. "NVWA_data_preparation_4_2019data.py" in Python3
	INPUTS: 'VIS_KUB_Aanlandingen_va_nov2018.csv','VIS_KUB_Dagvangsten_va_nov2018.csv','VIS_KUB_Inspecties_va_nov2018.csv', 'VIS_KUB_Vaartuigen_va_nov2018.csv', 'VIS_KUB_Verkopen_va_nov2018.csv' in 'New data per Nov 2020' folder;
		'verlof_bb.csv' in 'Data Inspectieschepen' folder
	OUTPUT: 'trips_sales_2019.csv'

5. 'Cleaning_2019_new.R' 
	INPUTS: trips_sales.csv from old file generation 'NVWA_data_preparation_4_Weekvangst_Simplified_GEANNOTEERD.py'
                trips_sales_2019.csv from 'NVWA_data_preparation_4_2019data.py'
                VIS_KUB_VTG_Old_VTG_va_nov2018.csv gives key for vessel id changes (source data)
                deploy_2017to2019.csv based on deploymnet information (summarized in 'No_deploy_2017to2019.csv' >> only 95% sure this is correct info source),
                kenmerken vaartuigen.csv, weather_data_1718.csv, fuel_pricesNL.csv in 'Final preparation and estimation in STATA'
	OUTPUT: For Tables_and_Figures.R
                  Data_final_1719.csv
                  Data_final_1719_newProb.csv  
                For Figures_Final.R
                  map_ais.csv

6. 'Tables and figures.R' produces Table results and results in figures
	INPUTS: From Cleaning1_2019_new.R
                  Data_final_1719_new.csv
                  Data_final_1719_newProb.csv 
                From Cleaning1_2019_new.R
                  df_ais.csv 

7. 'Figures_Final.R' produces all other maps and figures
	INPUTS: From Cleaning1_2019_new.R
                  Data_final_1719_new.csv 
                
                From replicated manually from Moolenaar and Chen paper
                  MoolChen_graphs.csv 
 
                From manual transcription based on deploymnet information (summarized in 'No_deploy_2017to2019.csv' >> only 95% sure this is correct info source),
                  deploy_2017to2019.csv
  
                From Cleaning1_2019_new.R 
                  map_ais.csv
 
                From 'Data Border' folder
                  'coordinates_english_border.csv', 'coordinates_dutch_belgian_border.csv','coordinates_dutch_german_border.csv','coordinates_danish_german_border.csv','coordinates_danish_norwegian_border.csv' 
 
                From 'NVWA_data_preparation_3_inspection_location_creator_GEANNOTEERD.py'
                  'vms_combined_bb_seefalke_meerkatze_vestkysten.csv','locatiesbb.csv', 'locatie_seefalke.csv', 'locatie_meerkatze.csv', 'locatie_vestkysten.csv'
 
