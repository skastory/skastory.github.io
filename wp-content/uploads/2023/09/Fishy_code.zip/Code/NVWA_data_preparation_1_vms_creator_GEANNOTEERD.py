# -*- coding: utf-8 -*-
"""
@author: shocuk & jvh
date: May 2019

"""


#%% # Importing all the libraries
import pandas as pd
import os
pd.options.mode.chained_assignment = None



#%% # Presetting environment
from IPython.core.interactiveshell import InteractiveShell
InteractiveShell.ast_node_interactivity = "all" 
pd.set_option("max_row",90)
pd.set_option("max_column",10)



#%% # Functions
def find_csv_filenames( path_to_dir, suffix=".csv" ):
    filenames = os.listdir(path_to_dir)
    return [ filename for filename in filenames if filename.endswith( suffix ) ]



#%% # Paths and Files
pathtodir  = '.\\'
pathtodir1 = '.\\Data VMS\\'



#%% # Initializations
do_merge_VMS = 1



#%% # Reading

# Reading VMS
files      = find_csv_filenames(pathtodir1,".xlsx")
skipfiles  = ['Vaartuig_171.xlsx','Vaartuig_388.xlsx'] # 171=[no local time], 388=[Error data at end]

if do_merge_VMS==1:
    df_VMS = pd.DataFrame()
    for ii in range(len(files)):    
        filenames = files[ii]
        print('File name is :', filenames)
        
        if filenames in skipfiles:
            print('   ... skipping this file')
            # 171 unsure if name 'UTC time' wrongly labeled or 'local time' is missing. So, drop this!
            # 388 contains too many errors
            continue
        
        df_VMSi = pd.read_excel(pathtodir1+filenames)
        
        # Correcting small errors        
        if filenames=='Vaartuig_187.xlsx':
            df_VMSi.drop(columns=['Harbour'],inplace=True)
        
        if filenames=='Vaartuig_439.xlsx':
            df_VMSi.rename(columns={'Created UTC time':'UTC time'},inplace=True)
        
        # Precleaning and Preparing
        df_VMSi.replace(r',',r'.',regex=True,inplace=True) # decimal separator 
        df_VMSi.iloc[:,2:6] = df_VMSi.iloc[:,2:6].astype(float) # conversion to floating point
        
        df_VMSi['local time'] = pd.to_datetime(df_VMSi['local time'])
        df_VMSi['UTC time']   = pd.to_datetime(df_VMSi['UTC time'])
        
        # Selecting variables & Dropping
        df_VMSi.insert(0, 'Vaartuig', filenames.strip('.xlsx')) # get the name and number of the ship
        df_VMSi.drop(['Lat..1','Lon..1'],axis=1,inplace=True)
        
        print('File shape is:', df_VMSi.shape)
        
        df_VMS = df_VMS.append(df_VMSi, sort=False)
        
    outfilename1 = 'gekoppelde_VMS_bestanden.csv' # any name is fine
    df_VMS.to_csv(pathtodir+'Output\\'+outfilename1, index=False)

 
