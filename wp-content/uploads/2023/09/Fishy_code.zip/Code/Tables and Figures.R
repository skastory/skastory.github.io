###################################################################################################
##  Code for: Illegal Fishing Practices and Nautical Patrol  (Kastoryano & Vollaard)                  
##                                                                                                  
##  Author: Stephen Kastoryano                                      
##  Date  : 01 February 2020                                         
##                                                                                   
##  Purpose: Analysis of effect of patrolling                         
##                                                                    
##  Code input: From Cleaning1_2019_new.R
##                Data_final_1719_new.csv
##                Data_final_1719_newProb.csv 
##              From Cleaning1_2019_new.R
##                df_ais.csv 
##
##
##
##
##
##
##
##
##                                                                    
####################################################################################################

rm(list=ls())

library("dplyr")
library("tidyr")
library("ggplot2")
library("plm")
library("lmtest")
library("sandwich")
library("clubSandwich")
library("lfe")
library("fixest")
library("missForest")
library("xtable")
library("vtable")


df <- read.csv( "D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Stephen files\\Data_final_1719_new.csv")
#df <- read.csv( "D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Stephen files\\Data_final_1719_corr.csv")
df = df[,-1]
dim(df)

## Appendix result: FIGURE 24: Effets when imputing zeros for weeks when vessel not at sea ##
## Comment in the following section:

 # dfp <- read.csv( "D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Stephen files\\Data_final_1719_newProb.csv")  # this file already made the selection of weeks for sample
 # df = dfp[,-1]
####

## Selection and scaling on dependent variables ##
#################################################


# Define lower baseline to not have results overly influenced by changes close to 0
# Generate shares of fish sizes. For small total landings keep shares equal to mean shares (reduces influence of changes close to 0)

# Redefine total kg landed to exclude below minimum size fish
df$kg_totaal = df$verkoop_sol_levend_1 + df$verkoop_sol_levend_2 + df$verkoop_sol_levend_3 + df$verkoop_sol_levend_4 + df$verkoop_sol_levend_5
df$kg_totaal_ple = df$verkoop_ple_levend_1 + df$verkoop_ple_levend_2 + df$verkoop_ple_levend_3 + df$verkoop_ple_levend_4



# We impute values of no-effect
impute5 = 0.2
impute4 = 0.2
impute3 = 0.2
impute2 = 0.2
impute1 = 0.2

low_landing = 50   # set equal shares and lower bound quantities if total kg landed is below low_share
df$perc_sol5 = (df$verkoop_sol_levend_5/df$kg_totaal)
df$perc_sol5[is.na(df$perc_sol5)] <- 0
df$perc_sol5[df$kg_totaal<=low_landing] <- impute5
df$perc_sol4 = df$verkoop_sol_levend_4/df$kg_totaal
df$perc_sol4[is.na(df$perc_sol4)] <- 0
df$perc_sol4[df$kg_totaal<=low_landing] <- impute4
df$perc_sol3 = df$verkoop_sol_levend_3/df$kg_totaal
df$perc_sol3[is.na(df$perc_sol3)] <- 0
df$perc_sol3[df$kg_totaal<=low_landing] <- impute3
df$perc_sol2 = df$verkoop_sol_levend_2/df$kg_totaal
df$perc_sol2[is.na(df$perc_sol2)] <- 0
df$perc_sol2[df$kg_totaal<=low_landing] <- impute2
df$perc_sol1 = df$verkoop_sol_levend_1/df$kg_totaal
df$perc_sol1[is.na(df$perc_sol1)] <- 0
df$perc_sol1[df$kg_totaal<=low_landing] <- impute1



# Define length of fishing trip
df$vertrek = as.Date(df$vertrek,format="%Y-%m-%d")
df$terugkeer = as.Date(df$terugkeer,format="%Y-%m-%d")

df$length_trip = (as.numeric(df$terugkeer)-as.numeric(df$vertrek))+1
table(df$length_trip)
df$log_length_trip = log(df$length_trip)


vesselID = unique(df$vaartuig)  #Obtain unique vessel ids to find overlap with daily data

table(df$length_trip)   # distribution of trip length
sum(as.numeric(df$length_trip<7))/nrow(df) # fraction of trips 6 days or under
table(df$day_dep)       # distribution of departure day
(sum(as.numeric(df$day_dep=="Monday"))+ sum(as.numeric(df$day_dep=="Sunday")))/nrow(df) # share of trips departing Sunday or Monday
table(df$day_return)    # distribution of return day
(sum(as.numeric(df$day_return=="Friday"))+ sum(as.numeric(df$day_dep=="Thursday")))/nrow(df) # share of trips departing Sunday or Monday


# Define dummy for whether vessel fished in a given week
df$fished_sol1 = as.numeric(df$kg_totaal>low_landing)


############
## Impute value for missing values in "luchtdruk_k13_k14" ##
# replace missing air pressure values with values from nearby station
df$luchtdruk_k13_k14[(df$week_index == 128)] <- 1013.1857
df$luchtdruk_k13_k14[(df$week_index == 129)] <- 1015.9572
df$luchtdruk_k13_k14[(df$week_index == 130)] <- 1021.2286
df$luchtdruk_k13_k14[(df$week_index == 131)] <- 1020.0714


# Generate higher order polynomials
df$golfhoogtesq = df$golfhoogte^2
df$golfhoogtecb = df$golfhoogte^3
df$windnoordsq = df$windnoord^2
df$windnoordcb = df$windnoord^3
df$windzuidsq = df$windzuid^2
df$windzuidcb = df$windzuid^3
df$windwestsq = df$windwest^2
df$windwestcb = df$windwest^3
df$windoostsq = df$windoost^2
df$windoostcb = df$windoost^3
df$windsnelheidsq = df$windsnelheid^2
df$windsnelheidcb = df$windsnelheid^3
df$tempsq = df$temp^2
df$tempcb = df$temp^3
df$maxdaggolfhoogtesq = df$maxdaggolfhoogte^2
df$maxdaggolfhoogtecb = df$maxdaggolfhoogte^3
df$luchtdruk_k13_k14sq = df$luchtdruk_k13_k14^2
df$luchtdruk_k13_k14cb = df$luchtdruk_k13_k14^3
df$BenzineEuro95sq = df$BenzineEuro95^2
df$BenzineEuro95cb = df$BenzineEuro95^3
df$Dieselsq = df$Diesel^2
df$Dieselcb = df$Diesel^3
df$Diesel4 = df$Diesel^4

df$length_tripsq = df$length_trip^2
df$length_tripcb = df$length_trip^3


#df$ones = 1
#aggregate(x=df$ones, by=list(df$vaartuig),FUN=sum)  # weeks of observation by fishing vessel
# nrow(df)
# df = df[(df$kg_totaal> 50),]
# nrow(df)

dfa = df






df = dfa
## Defining treatment and restricting analysis sample ##
########################################################

# Ben's selection
# This makes no sense
NT_week = c( 1,2,9,10, 11, 17,21,22,23, 27,28, 29, 30, 31, 32, 33, 42,43,50, 52, 53,57,58,59, 61,62,70,73,74, 82,83, 84, 85, 86, 87, 94, 96, 97,104,105, 114,115, 116, 124, 125, 128,  131,132, 133, 134, 135, 136, 137, 140, 141, 146,147, 148 , 149, 153, 155,156 )  # Non-Treated weeks (no patrolling)

# Leaving weeks of bad weather as part of controls
# 2017: 1 2* 9* 10 11 17 19* 21 22 23* 25* 27 28 29 30 31 32 33 36* 37* 40* 42 50 51* 52 
# 2018: 53 55* 57* 58 59 61 62 70 73 74 82 83 84 85 86 87 94 96 97 104
# 2019: 105 114 115 116 124 125 128 131 132 133 134 135 136 137 140 141 144* 146 147 148 149 150* 152* 153 154* 155 156

NT_week = c( 1,2,9,10, 11, 17,19,21,22,23,25, 27,28, 29, 30, 31, 32, 33,36,37,40, 42,50,51, 52, 53,55,57,58,59, 61,62,70,73,74, 82,83, 84, 85, 86, 87, 94, 96, 97,104,  105, 114,115, 116, 124, 125, 128,  131,132, 133, 134, 135, 136, 137, 140, 141, 144, 146,147, 148 , 149,150,152, 153,154, 155,156 )  # Non-Treated weeks (no patrolling)



# Below are all full weeks during which BB was not patrolling
# 2017: 1 10 11 17 21 22 27 28 29 30 31 32 33 42 50 52 
# 2018: 53 58 59 61 62 70 73 74 82 83 84 85 86 87 94 96 97 104
# 2019: 105 114 115 116 124 125 128 131 132 133 134 135 136 137 140 141 146 147 148 149 153 155 156
length(NT_week)
NT_week = c( 1,10, 11, 17,21,22, 27,28, 29, 30, 31, 32, 33, 42,50, 52, 53,58,59, 61,62,70,73,74, 82,83, 84, 85, 86, 87, 94, 96, 97,104,105, 114,115, 116, 124, 125, 128,  131,132, 133, 134, 135, 136, 137, 140, 141, 146,147, 148 , 149, 153, 155,156 )  # Non-Treated weeks (no patrolling)
All = seq(1,156)
nrow(df[(df$week_index %in% NT_week),])
nrow(df)
T_week = All[!(All  %in% NT_week)] # Treated weeks (patrolling)
mAnalysis_weeks = rbind(cbind(NT_week,0),cbind(T_week,1))
mA_w = mAnalysis_weeks[order(mAnalysis_weeks[,1]),2]

analysis_weeks = 1
for (i in seq(2,155)) {
       analysis_weeks = cbind(analysis_weeks,i*as.numeric(mA_w[i] != mA_w[(i-1)]) + i*as.numeric(mA_w[i] != mA_w[(i+1)])* (1-as.numeric(mA_w[i] != mA_w[(i-1)])*as.numeric(mA_w[i] != mA_w[(i+1)])))
}
analysis_weeks
analysis_weeks = analysis_weeks[analysis_weeks!=0]  # Weeks to be included in sample
analysis_weeks
All[!(All  %in% analysis_weeks)]    # Weeks to be excluded from sample


# Keep only relevant adjacent weeks
nrow(df)
df = filter(df, (df$week_index %in% analysis_weeks))
nrow(df)
table(df$week_index)


# Given the resulting dataset, these will be the weeks with no treatment (BB not deployed)
NT_week = unique(df$week_index[(df$week_index %in% NT_week)])
#NT_week = c( 1,10, 11, 17,21,22, 27, 33, 42,50, 52, 53,58,59, 61,62,70,73,74, 82, 87, 94, 96, 97,104,105, 114, 116, 124, 125, 128,  131, 137, 140, 141, 146, 149, 153, 155 )
df$treat = 1-as.numeric(df$week_index %in% NT_week)



# Dropping Christmas weeks which skews analysis of probability of fishing 
# -> fishing vessels and coast guard are almost all on vacation which means these are not comparable weeks to adjacent patrolling weeks
nrow(df)
df = filter(df, !(df$week_index %in% c(52,103,104)))  # drop Christmas weeks and their comparisons when relevant
# df = filter(df, !(df$week_index %in% c(2,9,19,23,25,36,37,40,51,55,57,144,150,152,154)))  # drop any bad-weather week
# df = filter(df, !(df$week_index %in% c(1,2,9,10,19,22,23,25,36,37,40,51,55,57,58,144,149,150,152,153,154,155)))  # drop any additional week depending on bad-weather week for identification
# df = filter(df, !(df$week_index %in% c(59,71,154)))  # these weeks have relatively low numbers of vessels at sea so could arguably be dropped

nrow(df)
table(df$week_index)




table(df$treat) # Number of treated vs non-treated
sum(as.numeric(df$length_trip <8))/nrow(df)   # fraction of trips lasting less than 7 days
sum(as.numeric(df$day_dep == "Monday") * as.numeric(df$day_return == "Thursday") + as.numeric(df$day_dep == "Sunday") * as.numeric(df$day_return == "Thursday") +
      as.numeric(df$day_dep == "Monday") * as.numeric(df$day_return == "Friday") + as.numeric(df$day_dep == "Sunday") * as.numeric(df$day_return == "Friday"))/nrow(df)  
# Fraction of trips within usual Sunday night / Monday morning to Thursday night/Friday 

nrow(df)


# Show treated vs. non-treated weeks
df_weekly = filter(df, (df$week_index==1))
vessels_by_week = c(length(unique(df_weekly$vaartuig)),1)
for (i in seq(2,156)) {
  df_weekly = filter(df, (df$week_index==i))
  vessels_by_week = rbind(vessels_by_week,c(length(unique(df_weekly$vaartuig)),i))
}
vessels_by_week = as.data.frame(vessels_by_week)
vessels_by_week = vessels_by_week[(vessels_by_week[,1]>0),]
colnames(vessels_by_week) <-  c("vessels", "week")
vessels_by_week$treat = as.factor(!(vessels_by_week$week %in% NT_week))

typeof(vessels_by_week$treat)
# Grouped

### The following graph is for Figure 'Weekly fishing trips in baseline analysis sample'  ##
ggplot(vessels_by_week, aes(fill=treat, y=vessels, x=week)) + 
  geom_bar(position="dodge", stat="identity") +
  scale_color_grey() +
  scale_fill_discrete(name = "Treatment", labels = c("Non-patrolled", "Patrolled")) +
  ylab("Number of vessels at sea") +
  theme(text = element_text(size=20)) +
  theme(legend.background = element_rect(fill="white",
                                         size=0.5, linetype="solid", 
                                         colour ="black"))  +
  theme(legend.title = element_blank()) +
  scale_x_continuous(breaks=c(1, 53, 105,157),labels=c("1" = "2017-1", "53" = "2018-1", "105" = "2019-1",  "157" = "2020-01")) +
  theme_bw() +
  theme(axis.line = element_line(colour = "black"),
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        panel.border = element_blank(),
        panel.background = element_blank()) +
  theme(legend.position = c(0.5, 0.9)) 



#cbind(vessels_by_week$week,vessels_by_week$treat)


##############################################
### Descriptive Statistics/ Balance table
##############################################

# Top part of descriptive statistics table
df_bal = df[,c("treat","kg_totaal","verkoop_sol_levend_7","verkoop_sol_levend_5","verkoop_sol_levend_4","verkoop_sol_levend_3","verkoop_sol_levend_2","verkoop_sol_levend_1","perc_sol5","perc_sol4","perc_sol3","perc_sol2","perc_sol1","kg_totaal_ple", "lengte_over_alles","tonnage","vermogen", "length_trip_hr")]
df_bal0= df_bal[(df_bal$treat==0),]
colnames(df_bal0) <- c("Non-Patrolled", "weight: Total","weight: Undersized", "weight: Small", "weight: M.-Small", "weight: Medium", "weight: M.-Large","weight: Large", "share: Small", "share: M.-Small", "share: Medium", "share: M.-Large","share: Large","weight: Total plaice","Ship length (m)","Ship weight (tonnes)","Power (Kw)", "Trip length (hr)")
df_bal1= df_bal[(df_bal$treat==1),]
colnames(df_bal1) <- c("Patrolled", "weight: Total","weight: Undersized", "weight: Small", "weight: M.-Small", "weight: Medium", "weight: M.-Large","weight: Large", "share: Small", "share: M.-Small", "share: Medium", "share: M.-Large","share: Large","weight: Total plaice","Ship length (m)","Ship weight (tonnes)","Power (Kw)", "Trip length (hr)")


# Generate descriptice statistics table
teXtable = cbind(mean(df_bal0[,2]),sd(df_bal0[,2]), mean(df_bal1[,2]),sd(df_bal1[,2]),(mean(df_bal1[,2])-mean(df_bal0[,2])) )

for (i in 3:ncol(df_bal)) {
  print(i)
  teXtable = rbind(teXtable,  cbind(mean(df_bal0[,i]),sd(df_bal0[,i]), mean(df_bal1[,i]),sd(df_bal1[,i]),(mean(df_bal1[,i])-mean(df_bal0[,i])) ) )
}

options(scipen=999)
teXtable =cbind(c("weight: Total","weight: Undersized", "weight: Small", "weight: M.-Small", "weight: Medium", "weight: M.-Large","weight: Large", "share: Small", "share: M.-Small", "share: Medium", "share: M.-Large","share: Large","weight: Total plaice","Ship length (m)","Ship weight (tonnes)","Power (Kw)", "Trip length (hr)"),teXtable)
xtable(teXtable)


sumtable(df_bal, group = 'treat', group.test = TRUE)

#
#
sX=c("windnoord","windwest","windsnelheid","temp","golfhoogte","luchtdruk_k13_k14","Diesel")
df_bal = df[,c("week_index","treat",sX)]
df_bal0= df_bal[(df_bal$treat==0),]
df_bal0= aggregate(df_bal0, list(df_bal0$week_index), FUN=mean)[,3:(ncol(df_bal)+1)]
colnames(df_bal0) <- c("Non-Patrolled",  "North wind","West wind", "Wind speed", "Temperature", "Wave height", "Air pressure", "Price Diesel")
df_bal1= df_bal[(df_bal$treat==1),]
df_bal1= aggregate(df_bal1, list(df_bal1$week_index), FUN=mean)[,3:(ncol(df_bal)+1)]
colnames(df_bal1) <- c("Patrolled",  "North wind","West wind", "Wind speed", "Temperature", "Wave height", "Air pressure", "Price Diesel")


# Generate descriptice statistics table
teXtable = cbind(mean(df_bal0[,2]),sd(df_bal0[,2]), mean(df_bal1[,2]),sd(df_bal1[,2]),(mean(df_bal1[,2])-mean(df_bal0[,2])) )

for (i in 3:ncol(df_bal0)) {
  print(i)
  teXtable = rbind(teXtable,  cbind(mean(df_bal0[,i]),sd(df_bal0[,i]), mean(df_bal1[,i]),sd(df_bal1[,i]),(mean(df_bal1[,i])-mean(df_bal0[,i])) ) )
}

options(scipen=999)
teXtable =cbind(c("North wind","West wind", "Wind speed", "Temperature", "Wave height", "Air pressure", "Price Diesel"),teXtable)
xtable(teXtable)


colnames(df_bal0) <- c("Patrolled",  "North wind","West wind", "Wind speed", "Temperature", "Wave height", "Air pressure", "Price Diesel")
df_bal = rbind(df_bal0, df_bal1)
sumtable(df_bal, group = 'Patrolled', group.test = TRUE)


###############




dfb = df

### The following snip of code should be commented in for Figure 'Weekly fishing trips in baseline analysis sample'  ##
### and robustness check analysis when restricting sample  ##

# You can play around with which vessels are included in analysis based on how many weeks each vessel is observed (max is 78)
# Results are very robust changes in the sample

## Appendix result: FIGURE 4b and FIGURE 25: Effets when keeping only vessels with at least 60 comparison weeks ##
## Comment in the following section:
# df =dfb
# length(unique(df$week_index))
# df$ones = 1
# weeks_sample = aggregate(x=df$ones, by=list(df$vaartuig),sum)  # weeks of observation by fishing vessel
# colnames(weeks_sample) = c("vaartuig","weeks_in_sample")
# hist(weeks_sample$weeks_in_sample,breaks=length(unique(weeks_sample$vaartuig)),xlim=c(0,80),ylab="Number of vessels", xlab="Number of weeks observed in sample of baseline patrolling results",main="", col=c("#0099FF"))
# 
# 
# plot(ecdf(weeks_sample$weeks_in_sample))
# df <- merge(df, weeks_sample, by="vaartuig")
# 
# ############
# ## Figure 4b
# ############
# hist(df$weeks_in_sample,breaks=length(unique(df$vaartuig)),xlim=c(0,80), ylab="Number of vessel-trip observations",xlab="Number of weeks observed in baseline analysis sample",main="", col=c("#0099FF"))
# check = nrow(df)
# 
# ## Appendix result: FIGURE 25: Effets when dropping vessels with fewer than 60 observed weeks ##
# df = df[(df$weeks_in_sample >60),]
# nrow(df)/check
###############



## Appendix result: FIGURE 23: Effets when dropping 400 observations for vessel with no comparison week ##
## Comment in the following section:

# df = df[order(df$vaartuig,df$week_index ),]
# dfs = df[1,]
# for (i in 2:(nrow(df)-1)) {
#   if (  (df$vaartuig[i]==df$vaartuig[i-1])*(df$week_index[i]==df$week_index[i-1]+1) + (df$vaartuig[i]==df$vaartuig[i+1])*(df$week_index[i]==df$week_index[i+1]-1) >0 ) {
#     dfs = rbind(dfs,df[i,])
#   }
# }
# dfs = rbind(dfs,df[nrow(df),])
# nrow(dfs)
# df=dfs
############


## Appendix result: FIGURE 21: Effets when restricting sample to only vessels at sea Sunday-Monday to Thursday-Friday ##
## Comment in the following section:

# df$start_day = weekdays(as.Date(df$vertrek,format="%Y-%m-%d"))
# table(df$start_day)
# df$start_sel = as.numeric(df$start_day == "Sunday")*as.numeric(df$length_trip <= 6) + as.numeric(df$start_day == "Monday")*as.numeric(df$length_trip <= 5) + as.numeric(df$start_day == "Tuesday")*as.numeric(df$length_trip <= 4) + as.numeric(df$start_day == "Wednesday")*as.numeric(df$length_trip <= 3) + as.numeric(df$start_day == "Thursday")*as.numeric(df$length_trip == 1)
# nrow(df)
# df = filter(df, (df$start_sel == 1)) # Sunday-Monday to Sunday-Monday to Thursday-Friday trip
# nrow(df)
#########


## Appendix result: FIGURE 28: Effets when dropping all vessel-trip observations with below 50kg of sole fished ##
## Comment in the following section:

#df =df[(df$kg_totaal>low_landing),]
##########


## Appendix result: FIGURE 29: Effets when keeping only  vessel with above 1000kg average sole landings per trip ##
## Comment in the following section:
# df =df[(df$avg_catch_per_trip>1000),]
##########


## Appendix result: Effets for vessels above 40m in length ##
## Comment in the following section:
# df =df[(df$lengte_over_alles>40),]
##########


## Appendix result: Effets for vessels above 1000Kw in power ##
## Comment in the following section:
#df =df[(df$vermogen>1000),]
##########


nrow(df) # number of observations
sum(df$treat) # number of treated observations
### Shares of different sole depending on patrolled/non-patrolled weeks
# Patrolled weeks
raw5_pat = sum(df$treat*df$perc_sol5)/sum(df$treat)
raw4_pat = sum(df$treat*df$perc_sol4)/sum(df$treat)
raw3_pat = sum(df$treat*df$perc_sol3)/sum(df$treat)
raw2_pat = sum(df$treat*df$perc_sol2)/sum(df$treat)
raw1_pat = sum(df$treat*df$perc_sol1)/sum(df$treat)

# Non-patrolled
raw5_npat = sum((1-df$treat)*df$perc_sol5)/sum(1-df$treat)
raw4_npat = sum((1-df$treat)*df$perc_sol4)/sum(1-df$treat)
raw3_npat = sum((1-df$treat)*df$perc_sol3)/sum(1-df$treat)
raw2_npat = sum((1-df$treat)*df$perc_sol2)/sum(1-df$treat)
raw1_npat = sum((1-df$treat)*df$perc_sol1)/sum(1-df$treat)

# Difference in effect
raw5_pat - raw5_npat   
raw4_pat - raw4_npat 
raw3_pat - raw3_npat 
raw2_pat - raw2_npat 
raw1_pat - raw1_npat 
  



sX=c("windnoord","windwest","windsnelheid","temp","golfhoogte","luchtdruk_k13_k14","Diesel")
sTreat <- "treat"

## Appendix result: FIGURE 22: Effets when including up to 3rd degree polynomial terms for covariates##
## Comment in the following section:

#sX=c("windnoord","windnoordsq","windnoordcb","windwest","windwestsq","windwestcb","windsnelheid","windsnelheidsq","windsnelheidcb","temp","tempsq","tempcb","golfhoogte","golfhoogtesq","golfhoogtecb", "luchtdruk_k13_k14","luchtdruk_k13_k14sq","luchtdruk_k13_k14cb","Diesel","Dieselsq","Dieselcb")
##########

## Appendix result referee comment: Effects when including up to 3rd degree polynomial terms for covariates##
## Comment in the following section:

sX=c("windnoord","windwest","windsnelheid","temp","golfhoogte","maxdaggolfhoogte", "luchtdruk_k13_k14","Diesel")
##########




##############################################
### EFFECTS ON SOLE SHARES  ####
##############################################

streatX = c(sTreat)
panel_share5 <- plm(as.formula(paste("perc_sol5 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share4 <- plm(as.formula(paste("perc_sol4 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share3 <- plm(as.formula(paste("perc_sol3 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share2 <- plm(as.formula(paste("perc_sol2 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share1 <- plm(as.formula(paste("perc_sol1 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
res5 = coef_test(panel_share5, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
res4 = coef_test(panel_share4, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
res3 = coef_test(panel_share3, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
res2 = coef_test(panel_share2, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
res1 = coef_test(panel_share1, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]

res = rbind(res5,res4,res3,res2,res1)
res_df = as.data.frame(res[,1:2])


## The following lines are to build LaTeX table
summary(panel_share5)

tabl = cbind(rbind(res5[1,1],res5[1,2]),rbind(res4[1,1],res4[1,2]),rbind(res3[1,1],res3[1,2]),
             rbind(res2[1,1],res2[1,2]),rbind(res1[1,1],res1[1,2]))  
#### 

streatX = c(sTreat,sX)
panel_share5 <- plm(as.formula(paste("perc_sol5 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share4 <- plm(as.formula(paste("perc_sol4 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share3 <- plm(as.formula(paste("perc_sol3 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share2 <- plm(as.formula(paste("perc_sol2 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share1 <- plm(as.formula(paste("perc_sol1 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
res5 = coef_test(panel_share5, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
res4 = coef_test(panel_share4, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
res3 = coef_test(panel_share3, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
res2 = coef_test(panel_share2, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
res1 = coef_test(panel_share1, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]



## The following lines are to build LaTeX table
tabl5 = coef_test(panel_share5, vcov = "CR1", cluster = "individual", test = "naive-t")
tabl4 = coef_test(panel_share4, vcov = "CR1", cluster = "individual", test = "naive-t")
tabl3 = coef_test(panel_share3, vcov = "CR1", cluster = "individual", test = "naive-t")
tabl2 = coef_test(panel_share2, vcov = "CR1", cluster = "individual", test = "naive-t")
tabl1 = coef_test(panel_share1, vcov = "CR1", cluster = "individual", test = "naive-t")


for (i in 1:(length(sX)+1)) {
  tabl = rbind(tabl, cbind(rbind(tabl5[i,1],tabl5[i,2]),rbind(tabl4[i,1],tabl4[i,2]),rbind(tabl3[i,1],tabl3[i,2]),
                           rbind(tabl2[i,1],tabl2[i,2]),rbind(tabl1[i,1],tabl1[i,2]))  )
}
tablshare =tabl
##

res = rbind(res5,res4,res3,res2,res1)

res_df = rbind(res_df,res[,1:2])
res_df$covar = c(rep("without covariates",5),rep("with covariates",5))
res_df$size =   c("Small", "Medium-Small", "Medium", "Medium-Large", "Large","Small", "Medium-Small", "Medium", "Medium-Large", "Large")
rownames(res_df) <- NULL
colnames(res_df) <-  c("effect", "effect_se", "specification", "size")
res_df = rbind(res_df[1,],res_df[6,],res_df[2,],res_df[7,],res_df[3,],res_df[8,],res_df[4,],res_df[9,],res_df[5,],res_df[10,])
res_df$size <- as.character(res_df$size)
res_df$size <- factor(res_df$size, levels=unique(res_df$size))

####################
## Figure 9a, 21a, 22a, 23a, 24a, 25a, 26a, 27a, 28a, 29a, 30a, 31a
####################
pd = position_dodge(.2)    ### How much to jitter the points on the plot

print(ggplot(res_df,                ### The data frame to use.
             aes(x     = size,
                 y     = effect,
                 color = specification)) +
        geom_point(shape = 15,
                   size  = 4,
                   position = pd) +
        geom_errorbar(aes(ymin  = effect - 1.96*effect_se,
                          ymax  = effect + 1.96*effect_se),
                      width = 0.2,
                      size  = 1,
                      position = pd) +
        theme_bw() +
        theme(text = element_text(size=20)) +
        theme(legend.title = element_blank()) +
        theme(legend.position = c(0.85, 0.08)) +
        theme(legend.background = element_rect(fill="white",
                                               size=0.5, linetype="solid", 
                                               colour ="black")) +
        scale_color_grey() +
        geom_hline(yintercept=0, linetype="dotted") +
        ylab("Change in share") +
        xlab("Size category"))
#ggsave("D:\\Dropbox\\Fishing\\TeX file\\eff_share.png", width = 9.5, height = 6.5)   ## Figure 9a
#ggsave("D:\\Dropbox\\Fishing\\TeX file\\eff_share400.png", width = 9.5, height = 6.5) ## Figure 23a
#ggsave("D:\\Dropbox\\Fishing\\TeX file\\eff_shareWith0.png", width = 9.5, height = 6.5) ## Figure 24a
#ggsave("D:\\Dropbox\\Fishing\\TeX file\\eff_shareMonThu.png", width = 9.5, height = 6.5)  ## Figure 21a
#ggsave("D:\\Dropbox\\Fishing\\TeX file\\eff_share60.png", width = 9.5, height = 6.5) ## Figure 25a
#ggsave("D:\\Dropbox\\Fishing\\TeX file\\eff_share50drop.png", width = 9.5, height = 6.5) ## Figure 28a
#ggsave("D:\\Dropbox\\Fishing\\TeX file\\eff_share1000avg.png", width = 9.5, height = 6.5) ## Figure 29a
#ggsave("D:\\Dropbox\\Fishing\\TeX file\\eff_sharePoly.png", width = 9.5, height = 6.5)  ## Figure 22a
#ggsave("D:\\Dropbox\\Fishing\\TeX file\\eff_shareMaxwave.png", width = 9.5, height = 6.5)  ## referee request
#ggsave("D:\\Dropbox\\Fishing\\TeX file\\eff_shareLengthabove40.png", width = 9.5, height = 6.5) ## Figure 30a
#ggsave("D:\\Dropbox\\Fishing\\TeX file\\eff_sharePowerabove1000.png", width = 9.5, height = 6.5) ## Figure 31a
#ggsave("D:\\Dropbox\\Fishing\\TeX file\\eff_share_corr.png", width = 9.5, height = 6.5) ## Figure 26a
#ggsave("D:\\Dropbox\\Fishing\\TeX file\\eff_share_corr2.png", width = 9.5, height = 6.5) ## Figure 27a


##############################################
### EFFECTS ON SOLE WEIGHT - poisson model ###
##############################################

panel_land_tot = fepois(kg_totaal ~ treat   | vaartuig, df)
panel_land5 = fepois(verkoop_sol_levend_5 ~ treat  | vaartuig, df)
panel_land4 = fepois(verkoop_sol_levend_4 ~ treat   | vaartuig, df)
panel_land3 = fepois(verkoop_sol_levend_3 ~ treat   | vaartuig, df)
panel_land2 = fepois(verkoop_sol_levend_2 ~ treat   | vaartuig, df)
panel_land1 = fepois(verkoop_sol_levend_1 ~ treat   | vaartuig, df)
print(panel_land_tot) 
print(panel_land5) 
print(panel_land4) 
print(panel_land3) 
print(panel_land2)
print(panel_land1) 
summary(panel_land_tot, cluster = "vaartuig")


res = cbind(c(summary(panel_land_tot)$coefficients,summary(panel_land5)$coefficients,summary(panel_land4)$coefficients,summary(panel_land3)$coefficients,summary(panel_land2)$coefficients,summary(panel_land1)$coefficients),c(summary(panel_land_tot)$se[1],summary(panel_land5)$se[1],summary(panel_land4)$se[1],summary(panel_land3)$se[1],summary(panel_land2)$se[1],summary(panel_land1)$se[1]))
res_df = as.data.frame(res)

panel_land_tot = fepois(kg_totaal ~ treat +    windnoord  +  windwest  +  windsnelheid +  temp    + golfhoogte  +  luchtdruk_k13_k14 + Diesel  | vaartuig, df)
panel_land5 = fepois(verkoop_sol_levend_5 ~ treat +   windnoord  +  windwest  +   windsnelheid +  temp   + golfhoogte  +  luchtdruk_k13_k14 + Diesel | vaartuig, df)
panel_land4 = fepois(verkoop_sol_levend_4 ~ treat +   windnoord  +  windwest  +   windsnelheid +  temp   + golfhoogte  +  luchtdruk_k13_k14 + Diesel  | vaartuig, df)
panel_land3 = fepois(verkoop_sol_levend_3 ~ treat +   windnoord  +  windwest  +   windsnelheid +  temp   + golfhoogte +  luchtdruk_k13_k14 + Diesel  | vaartuig, df)
panel_land2 = fepois(verkoop_sol_levend_2 ~ treat +   windnoord  +  windwest  +   windsnelheid +  temp    + golfhoogte  +  luchtdruk_k13_k14 + Diesel  | vaartuig, df)
panel_land1 = fepois(verkoop_sol_levend_1 ~ treat +   windnoord  +  windwest  +   windsnelheid +  temp    + golfhoogte  +  luchtdruk_k13_k14 + Diesel  | vaartuig, df)
print(panel_land_tot) 
print(panel_land5) 
print(panel_land4) 
print(panel_land3) 
print(panel_land2) 
print(panel_land1)

## Appendix result: Figure 22b: Effets when including up to 3rd degree polynomial terms for covariates##
## Comment in the following section:

# panel_land5 = fepois(verkoop_sol_levend_5 ~ treat +  windnoord + windnoordsq + windnoordcb  +  windwest + windwestsq + windwestcb +  windsnelheid + windsnelheidsq + windsnelheidcb +  temp  + tempsq + tempcb  + golfhoogte + golfhoogtesq + golfhoogtecb +    luchtdruk_k13_k14 + luchtdruk_k13_k14sq + luchtdruk_k13_k14cb + Diesel + Dieselsq + Dieselcb  | vaartuig, df)
# panel_land4 = fepois(verkoop_sol_levend_4 ~ treat + windnoord + windnoordsq + windnoordcb +  windwest + windwestsq + windwestcb +  windsnelheid + windsnelheidsq + windsnelheidcb +  temp  + tempsq + tempcb  + golfhoogte + golfhoogtesq + golfhoogtecb +    luchtdruk_k13_k14 + luchtdruk_k13_k14sq + luchtdruk_k13_k14cb + Diesel + Dieselsq + Dieselcb | vaartuig, df)
# panel_land3 = fepois(verkoop_sol_levend_3 ~ treat + windnoord + windnoordsq + windnoordcb  +  windwest + windwestsq + windwestcb +  windsnelheid + windsnelheidsq + windsnelheidcb +  temp  + tempsq + tempcb  + golfhoogte + golfhoogtesq + golfhoogtecb +  luchtdruk_k13_k14 + luchtdruk_k13_k14sq + luchtdruk_k13_k14cb + Diesel + Dieselsq + Dieselcb | vaartuig, df)
# panel_land2 = fepois(verkoop_sol_levend_2 ~ treat + windnoord + windnoordsq + windnoordcb  +  windwest + windwestsq + windwestcb +  windsnelheid + windsnelheidsq + windsnelheidcb +  temp  + tempsq + tempcb  + golfhoogte + golfhoogtesq + golfhoogtecb +  luchtdruk_k13_k14 + luchtdruk_k13_k14sq + luchtdruk_k13_k14cb + Diesel + Dieselsq + Dieselcb | vaartuig, df)
# panel_land1 = fepois(verkoop_sol_levend_1 ~ treat + windnoord + windnoordsq + windnoordcb  +  windwest + windwestsq + windwestcb +  windsnelheid + windsnelheidsq + windsnelheidcb +  temp  + tempsq + tempcb  + golfhoogte + golfhoogtesq + golfhoogtecb +   luchtdruk_k13_k14 + luchtdruk_k13_k14sq + luchtdruk_k13_k14cb + Diesel + Dieselsq + Dieselcb | vaartuig, df)
# panel_land_tot = fepois(kg_totaal ~ treat + windnoord + windnoordsq + windnoordcb  +  windwest + windwestsq + windwestcb +  windsnelheid + windsnelheidsq + windsnelheidcb +  temp  + tempsq + tempcb  + golfhoogte + golfhoogtesq + golfhoogtecb +   luchtdruk_k13_k14 + luchtdruk_k13_k14sq + luchtdruk_k13_k14cb + Diesel + Dieselsq + Dieselcb | vaartuig, df)
# print(panel_land_tot)
# print(panel_land5)
# print(panel_land4)
# print(panel_land3)
# print(panel_land2)
# print(panel_land1)
###############



res = cbind(c(summary(panel_land_tot)$coefficients[1],summary(panel_land5)$coefficients[1],summary(panel_land4)$coefficients[1],summary(panel_land3)$coefficients[1],summary(panel_land2)$coefficients[1],summary(panel_land1)$coefficients[1]),c(summary(panel_land_tot)$se[1],summary(panel_land5)$se[1],summary(panel_land4)$se[1],summary(panel_land3)$se[1],summary(panel_land2)$se[1],summary(panel_land1)$se[1]))
res_df = rbind(res_df,res) 

res_df$covar = c(rep("without covariates",6),rep("with covariates",6))
res_df$size =   c("All","Small", "Medium-Small", "Medium", "Medium-Large", "Large","All","Small", "Medium-Small", "Medium", "Medium-Large", "Large")
rownames(res_df) <- NULL
colnames(res_df) <-  c("effect", "effect_se", "specification", "size")
res_df = rbind(res_df[1,],res_df[7,],res_df[2,],res_df[8,],res_df[3,],res_df[9,],res_df[4,],res_df[10,],res_df[5,],res_df[11,],res_df[6,],res_df[12,])
res_df$size <- as.character(res_df$size)
res_df$size <- factor(res_df$size, levels=unique(res_df$size))

####################
## Figure 9b,  21b, 22b, 23b, 24b, 25b, 26b, 27b, 28b, 29b, 30b, 31b
####################
pd = position_dodge(.2)    ### How much to jitter the points on the plot

print(ggplot(res_df,               
             aes(x     = size,
                 y     = effect,
                 color = specification)) +
        geom_point(shape = 15,
                   size  = 4,
                   position = pd) +
        geom_errorbar(aes(ymin  = effect - 1.96*effect_se,
                          ymax  = effect + 1.96*effect_se),
                      width = 0.2,
                      size  = 1,
                      position = pd) +
        theme_bw() +
        theme(text = element_text(size=20)) +
        theme(legend.title = element_blank()) +
        theme(legend.position = c(0.85, 0.08)) +
        theme(legend.background = element_rect(fill="white",
                                               size=0.5, linetype="solid", 
                                               colour ="black")) +
        scale_color_grey() +
        geom_hline(yintercept=0, linetype="dotted") +
        ylab("Approx. % change in weight (kg)") +
        xlab("Size category"))
#ggsave("D:\\Dropbox\\Fishing\\TeX file\\eff_weightPO.png", width = 9.5, height = 6.5)  ## Figure 9b
#ggsave("D:\\Dropbox\\Fishing\\TeX file\\eff_weightPO400.png", width = 9.5, height = 6.5)  ## Figure 23b
#ggsave("D:\\Dropbox\\Fishing\\TeX file\\eff_weightPOWith0.png", width = 9.5, height = 6.5) ## Figure 24b
#ggsave("D:\\Dropbox\\Fishing\\TeX file\\eff_weightPOMonThu.png", width = 9.5, height = 6.5)  ## Figure 21b
#ggsave("D:\\Dropbox\\Fishing\\TeX file\\eff_weightPO60.png", width = 9.5, height = 6.5) ## Figure 25b
#ggsave("D:\\Dropbox\\Fishing\\TeX file\\eff_weightPO50drop.png", width = 9.5, height = 6.5) ## Figure 28b
#ggsave("D:\\Dropbox\\Fishing\\TeX file\\eff_weightPO1000avg.png", width = 9.5, height = 6.5) ## Figure 29b
#ggsave("D:\\Dropbox\\Fishing\\TeX file\\eff_weightPOPoly.png", width = 9.5, height = 6.5)  ## Figure 22b
#ggsave("D:\\Dropbox\\Fishing\\TeX file\\eff_weightPOMaxwave.png", width = 9.5, height = 6.5)  ## referee request
#ggsave("D:\\Dropbox\\Fishing\\TeX file\\eff_weightPOLengthabove40.png", width = 9.5, height = 6.5) ## Figure 30b
#ggsave("D:\\Dropbox\\Fishing\\TeX file\\eff_weightPOPowerabove1000.png", width = 9.5, height = 6.5)  ## Figure 31b
#ggsave("D:\\Dropbox\\Fishing\\TeX file\\eff_weightPO_corr.png", width = 9.5, height = 6.5) ## Figure 26b
#ggsave("D:\\Dropbox\\Fishing\\TeX file\\eff_weightPO_corr2.png", width = 9.5, height = 6.5) ## Figure 27b

##############################################
### EFFECTS ON SOLE WEIGHT (kg)  ####
##############################################

streatX = c(sTreat)
panel_land5 <- plm(as.formula(paste("verkoop_sol_levend_5 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_land4 <- plm(as.formula(paste("verkoop_sol_levend_4 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_land3 <- plm(as.formula(paste("verkoop_sol_levend_3 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_land2 <- plm(as.formula(paste("verkoop_sol_levend_2 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_land1 <- plm(as.formula(paste("verkoop_sol_levend_1 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_land_tot <- plm(as.formula(paste("kg_totaal ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
res5 = coef_test(panel_land5, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
res4 = coef_test(panel_land4, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
res3 = coef_test(panel_land3, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
res2 = coef_test(panel_land2, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
res1 = coef_test(panel_land1, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
resAll = coef_test(panel_land_tot, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]

res = rbind(resAll,res5,res4,res3,res2,res1)
res_df = as.data.frame(res[,1:2])


streatX = c(sTreat,sX)
panel_land5 <- plm(as.formula(paste("verkoop_sol_levend_5 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_land4 <- plm(as.formula(paste("verkoop_sol_levend_4 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_land3 <- plm(as.formula(paste("verkoop_sol_levend_3 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_land2 <- plm(as.formula(paste("verkoop_sol_levend_2 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_land1 <- plm(as.formula(paste("verkoop_sol_levend_1 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_land_tot <- plm(as.formula(paste("kg_totaal ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
res5 = coef_test(panel_land5, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
res4 = coef_test(panel_land4, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
res3 = coef_test(panel_land3, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
res2 = coef_test(panel_land2, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
res1 = coef_test(panel_land1, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
resAll = coef_test(panel_land_tot, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]


res = rbind(resAll,res5,res4,res3,res2,res1)

res_df = rbind(res_df,res[,1:2])
res_df$covar = c(rep("without covariates",6),rep("with covariates",6))
res_df$size =   c("All","Small", "Medium-Small", "Medium", "Medium-Large", "Large","All","Small", "Medium-Small", "Medium", "Medium-Large", "Large")
rownames(res_df) <- NULL
colnames(res_df) <-  c("effect", "effect_se", "specification", "size")
res_df = rbind(res_df[1,],res_df[7,],res_df[2,],res_df[8,],res_df[3,],res_df[9,],res_df[4,],res_df[10,],res_df[5,],res_df[11,],res_df[6,],res_df[12,])
res_df$size <- as.character(res_df$size)
res_df$size <- factor(res_df$size, levels=unique(res_df$size))

## Figure 1 ##
pd = position_dodge(.2)    ### How much to jitter the points on the plot

print(ggplot(res_df,                ### The data frame to use.
             aes(x     = size,
                 y     = effect,
                 color = specification)) +
        geom_point(shape = 15,
                   size  = 4,
                   position = pd) +
        geom_errorbar(aes(ymin  = effect - 1.96*effect_se,
                          ymax  = effect + 1.96*effect_se),
                      width = 0.2,
                      size  = 1,
                      position = pd) +
        theme_bw() +
        theme(text = element_text(size=20)) +
        theme(legend.title = element_blank()) +
        theme(legend.position = c(0.85, 0.08)) +
        theme(legend.background = element_rect(fill="white",
                                               size=0.5, linetype="solid", 
                                               colour ="black")) +
        scale_color_grey() +
        geom_hline(yintercept=0, linetype="dotted") +
        ylab("Change in weight (kg)") +
        xlab("Size category"))





## Calculating share of vessels engaged in illegal fishing practices
####################################################################

# Dropping observations for each of 4 vessels which are either always patrolled or always non-patrolled (4 observations dropped total)
df =dfb 
df1 = df[!(df$vaartuig %in% c(243,64,394)),]
nrow(df1) 


df1$perc_sol5T1 = df1$perc_sol5*df1$treat
df1$perc_sol5T0 = df1$perc_sol5*(1-df1$treat)
perc_sol5T1_df1 = df1[(df1$treat ==1),]
perc_sol5T0_df1 = df1[(df1$treat ==0),]
AggrT1_prec5 = aggregate(perc_sol5T1_df1$perc_sol5T1, by=list(perc_sol5T1_df1$vaartuig), mean)
AggrT0_prec5 = aggregate(perc_sol5T0_df1$perc_sol5T0, by=list(perc_sol5T0_df1$vaartuig), mean)
Dperc_sol5 = AggrT1_prec5[,2]- AggrT0_prec5[,2]

df1$perc_sol4T1 = df1$perc_sol4*df1$treat
df1$perc_sol4T0 = df1$perc_sol4*(1-df1$treat)
perc_sol4T1_df1 = df1[(df1$treat ==1),]
perc_sol4T0_df1 = df1[(df1$treat ==0),]
AggrT1_prec4 = aggregate(perc_sol4T1_df1$perc_sol4T1, by=list(perc_sol4T1_df1$vaartuig), mean)
AggrT0_prec4 = aggregate(perc_sol4T0_df1$perc_sol4T0, by=list(perc_sol4T0_df1$vaartuig), mean)
Dperc_sol4 = AggrT1_prec4[,2]- AggrT0_prec4[,2]

df1$perc_sol3T1 = df1$perc_sol3*df1$treat
df1$perc_sol3T0 = df1$perc_sol3*(1-df1$treat)
perc_sol3T1_df1 = df1[(df1$treat ==1),]
perc_sol3T0_df1 = df1[(df1$treat ==0),]
AggrT1_prec3 = aggregate(perc_sol3T1_df1$perc_sol3T1, by=list(perc_sol3T1_df1$vaartuig), mean)
AggrT0_prec3 = aggregate(perc_sol3T0_df1$perc_sol3T0, by=list(perc_sol3T0_df1$vaartuig), mean)
Dperc_sol3 = AggrT1_prec3[,2]- AggrT0_prec3[,2]

df1$perc_sol2T1 = df1$perc_sol2*df1$treat
df1$perc_sol2T0 = df1$perc_sol2*(1-df1$treat)
perc_sol2T1_df1 = df1[(df1$treat ==1),]
perc_sol2T0_df1 = df1[(df1$treat ==0),]
AggrT1_prec2 = aggregate(perc_sol2T1_df1$perc_sol2T1, by=list(perc_sol2T1_df1$vaartuig), mean)
AggrT0_prec2 = aggregate(perc_sol2T0_df1$perc_sol2T0, by=list(perc_sol2T0_df1$vaartuig), mean)
Dperc_sol2 = AggrT1_prec2[,2]- AggrT0_prec2[,2]


df1$perc_sol1T1 = df1$perc_sol1*df1$treat
df1$perc_sol1T0 = df1$perc_sol1*(1-df1$treat)
perc_sol1T1_df1 = df1[(df1$treat ==1),]
perc_sol1T0_df1 = df1[(df1$treat ==0),]
AggrT1_prec1 = aggregate(perc_sol1T1_df1$perc_sol1T1, by=list(perc_sol1T1_df1$vaartuig), mean)
AggrT0_prec1 = aggregate(perc_sol1T0_df1$perc_sol1T0, by=list(perc_sol1T0_df1$vaartuig), mean)
Dperc_sol1 = AggrT1_prec1[,2]- AggrT0_prec1[,2]



# Full distribution by vessel of changes in shares by fish size category
options("scipen"=100, "digits"=4)
cbind(Dperc_sol5, Dperc_sol4, Dperc_sol3, Dperc_sol2, Dperc_sol1)

# Difference in number of times there is increase/decrease in share for patrolled vs. non-patrolled weeks
# In expectation, with no treatment effects, the following two columns should be equal
rbind(c(sum(Dperc_sol5 <0),sum(Dperc_sol5 >=0)),c(sum(Dperc_sol4 <0),sum(Dperc_sol4 >=0)),c(sum(Dperc_sol3 <0),sum(Dperc_sol3 >=0)),c(sum(Dperc_sol2 <0),sum(Dperc_sol2 >=0)),c(sum(Dperc_sol1 <0),sum(Dperc_sol1 >=0)))

# Percentage of vessels engaged in illegal fishing practices given by difference in Small, Medium or Medium-Large categories 
Mean_shareS =(sum(Dperc_sol5 <0)-(length(Dperc_sol5)/2))/length(Dperc_sol5)  # If you use Small category
Mean_shareS
Mean_shareM = (sum(Dperc_sol3 <0)-(length(Dperc_sol5)/2))/length(Dperc_sol3)  # If you use Medium category
Mean_shareM
Mean_shareML = (sum(Dperc_sol2 <0)-(length(Dperc_sol5)/2))/length(Dperc_sol2)  # If you use Medium-Large category
Mean_shareML

# Now look at pattern of simultaneous decrease in Small sole AND increase in Medium sole AND increase in Medium-Large Sole
(sum((Dperc_sol5 <0)*(Dperc_sol3 >0)*(Dperc_sol2 >0))-sum((Dperc_sol5 >0)*(Dperc_sol3 <0)*(Dperc_sol2 <0)))/(2*length(Dperc_sol2))

(sum((Dperc_sol5 <0)*(Dperc_sol3 >0)*(Dperc_sol2 >0))-35.5)/(length(Dperc_sol2))

# Now look at pattern of simultaneous decrease in Small sole AND increase in Medium sole
(sum((Dperc_sol5 <0)*(Dperc_sol3 >0))-sum((Dperc_sol5 >0)*(Dperc_sol3 <0)))/(2*length(Dperc_sol3))

(sum((Dperc_sol5 <0)*(Dperc_sol3 >0))-35.5)/(length(Dperc_sol3))

# Calculating average of all approximations:
(0.144+0.152+0.144+0.131)/4

#####################
### Boostrap the above for Mean_share


# Set the number of bootstrap iterations
n_boot <- 399

# Create an empty vector to store the bootstrap values
bootstrap_valuesS <- numeric(n_boot)
bootstrap_valuesM <- numeric(n_boot)
bootstrap_valuesML <- numeric(n_boot)

i=1
# Perform bootstrap iterations
for (i in 1:n_boot) {
  # Bootstrap sampling with replacement of vessels
  dfboot = df[!(df$vaartuig %in% c(243,64,394)),]
  uni_vaartuig = unique(dfboot$vaartuig)
  boot_vaartuig = uni_vaartuig[sample(length(uni_vaartuig), replace = TRUE) ]

  df1 = dfboot[(dfboot$vaartuig %in% boot_vaartuig), ]

  df1$perc_sol5T1 = df1$perc_sol5*df1$treat
  df1$perc_sol5T0 = df1$perc_sol5*(1-df1$treat)
  perc_sol5T1_df1 = df1[(df1$treat ==1),]
  perc_sol5T0_df1 = df1[(df1$treat ==0),]
  AggrT1_prec5 = aggregate(perc_sol5T1_df1$perc_sol5T1, by=list(perc_sol5T1_df1$vaartuig), mean)
  AggrT0_prec5 = aggregate(perc_sol5T0_df1$perc_sol5T0, by=list(perc_sol5T0_df1$vaartuig), mean)
  Dperc_sol5 = AggrT1_prec5[,2]- AggrT0_prec5[,2]
  
  df1$perc_sol4T1 = df1$perc_sol4*df1$treat
  df1$perc_sol4T0 = df1$perc_sol4*(1-df1$treat)
  perc_sol4T1_df1 = df1[(df1$treat ==1),]
  perc_sol4T0_df1 = df1[(df1$treat ==0),]
  AggrT1_prec4 = aggregate(perc_sol4T1_df1$perc_sol4T1, by=list(perc_sol4T1_df1$vaartuig), mean)
  AggrT0_prec4 = aggregate(perc_sol4T0_df1$perc_sol4T0, by=list(perc_sol4T0_df1$vaartuig), mean)
  Dperc_sol4 = AggrT1_prec4[,2]- AggrT0_prec4[,2]
  
  df1$perc_sol3T1 = df1$perc_sol3*df1$treat
  df1$perc_sol3T0 = df1$perc_sol3*(1-df1$treat)
  perc_sol3T1_df1 = df1[(df1$treat ==1),]
  perc_sol3T0_df1 = df1[(df1$treat ==0),]
  AggrT1_prec3 = aggregate(perc_sol3T1_df1$perc_sol3T1, by=list(perc_sol3T1_df1$vaartuig), mean)
  AggrT0_prec3 = aggregate(perc_sol3T0_df1$perc_sol3T0, by=list(perc_sol3T0_df1$vaartuig), mean)
  Dperc_sol3 = AggrT1_prec3[,2]- AggrT0_prec3[,2]
  
  df1$perc_sol2T1 = df1$perc_sol2*df1$treat
  df1$perc_sol2T0 = df1$perc_sol2*(1-df1$treat)
  perc_sol2T1_df1 = df1[(df1$treat ==1),]
  perc_sol2T0_df1 = df1[(df1$treat ==0),]
  AggrT1_prec2 = aggregate(perc_sol2T1_df1$perc_sol2T1, by=list(perc_sol2T1_df1$vaartuig), mean)
  AggrT0_prec2 = aggregate(perc_sol2T0_df1$perc_sol2T0, by=list(perc_sol2T0_df1$vaartuig), mean)
  Dperc_sol2 = AggrT1_prec2[,2]- AggrT0_prec2[,2]
  
  
  df1$perc_sol1T1 = df1$perc_sol1*df1$treat
  df1$perc_sol1T0 = df1$perc_sol1*(1-df1$treat)
  perc_sol1T1_df1 = df1[(df1$treat ==1),]
  perc_sol1T0_df1 = df1[(df1$treat ==0),]
  AggrT1_prec1 = aggregate(perc_sol1T1_df1$perc_sol1T1, by=list(perc_sol1T1_df1$vaartuig), mean)
  AggrT0_prec1 = aggregate(perc_sol1T0_df1$perc_sol1T0, by=list(perc_sol1T0_df1$vaartuig), mean)
  Dperc_sol1 = AggrT1_prec1[,2]- AggrT0_prec1[,2]
  
  
  

  # Full distribution by vessel of changes in shares by fish size category
  options("scipen"=100, "digits"=4)
 
  # Percentage of vessels engaged in illegal fishing practices given by difference in Small, Medium or Medium-Large categories 
  Mean_share_bootstrapS =(sum(Dperc_sol5 <0)-(length(Dperc_sol5)/2))/length(Dperc_sol5)  # If you use Small category
  Mean_share_bootstrapM = (sum(Dperc_sol3 <0)-(length(Dperc_sol5)/2))/length(Dperc_sol3)  # If you use Medium category
  Mean_share_bootstrapML = (sum(Dperc_sol2 <0)-(length(Dperc_sol5)/2))/length(Dperc_sol2)  # If you use Medium-Large category

  
  # Store the bootstrap value
  bootstrap_valuesS[i] <- Mean_share_bootstrapS
  bootstrap_valuesM[i] <- Mean_share_bootstrapM
  bootstrap_valuesML[i] <- Mean_share_bootstrapML
}

# Print the bootstrap 95 percent confidence intervals
alpha =0.05
low95S = sort(bootstrap_valuesS)[round(alpha *(n_boot+1)/2)]
high95S = sort(bootstrap_valuesS)[((n_boot+1)-round(alpha *(n_boot+1)/2))]
low95M = sort(bootstrap_valuesM)[round(alpha *(n_boot+1)/2)]
high95M = sort(bootstrap_valuesM)[((n_boot+1)-round(alpha *(n_boot+1)/2))]
low95ML = sort(bootstrap_valuesML)[round(alpha *(n_boot+1)/2)]
high95ML = sort(bootstrap_valuesML)[((n_boot+1)-round(alpha *(n_boot+1)/2))]

Mean_shareS
low95S
high95S
Mean_shareM
low95M
high95M
Mean_shareML
low95ML
high95ML


##############################################
# Effects on length of fishing trip
###############################################

df = dfb



table(df$length_trip)

sum(df$treat*df$length_trip)/sum(df$treat) - sum((1-df$treat)*df$length_trip)/sum(1-df$treat)  # Difference in means of trip length

table(df$treat)
sX=c("windnoord","windwest","windsnelheid","temp","golfhoogte","luchtdruk_k13_k14","Diesel")
sTreat <- "treat"
streatX = c(sTreat)
panel_length1 <- plm(as.formula(paste("length_trip ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_length3 <- plm(as.formula(paste("length_trip_hr ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
streatX = c(sTreat,sX)
panel_length2 <- plm(as.formula(paste("length_trip ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_length4 <- plm(as.formula(paste("length_trip_hr ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
coef_test(panel_length1, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
coef_test(panel_length2, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
coef_test(panel_length3, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
coef_test(panel_length4, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]  # this is the one in the paper
#summary(panel_length1)
summary(panel_length4)  # This is 


### Reviewer comment about obtaining the above effect for 76 affected vessels:

# Dropping observations for each of 4 vessels which are either always patrolled or always non-patrolled (4 observations dropped total)
df = dfb
df1 = df[!(df$vaartuig %in% c(243,64,394)),]
nrow(df1)

df1$perc_sol5T1 = df1$perc_sol5*df1$treat
df1$perc_sol5T0 = df1$perc_sol5*(1-df1$treat)
perc_sol5T1_df1 = df1[(df1$treat ==1),]
perc_sol5T0_df1 = df1[(df1$treat ==0),]
AggrT1_prec5 = aggregate(perc_sol5T1_df1$perc_sol5T1, by=list(perc_sol5T1_df1$vaartuig), mean)
AggrT0_prec5 = aggregate(perc_sol5T0_df1$perc_sol5T0, by=list(perc_sol5T0_df1$vaartuig), mean)
Dperc_sol5 = AggrT1_prec5[,2]- AggrT0_prec5[,2] # If this is positive, it is one of 76 vessel
negSvaartuig = as.numeric(AggrT1_prec5[,2]- AggrT0_prec5[,2] < 0)*AggrT1_prec5[,1]
negSvaartuig = sort(unique(negSvaartuig))[-1]

# Effect for 76 vessels compliers
df = dfb
df = df[!(df$vaartuig %in% c(243,64,394)),]
df = df[(df$vaartuig %in% negSvaartuig),]

sX=c("windnoord","windwest","windsnelheid","temp","golfhoogte","luchtdruk_k13_k14","Diesel")
sTreat <- "treat"
streatX = c(sTreat,sX)
panel_length4 <- plm(as.formula(paste("length_trip_hr ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
coef_test(panel_length4, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]  # this is the one in the paper
summary(panel_length4)  # This is 
nrow(df)
sum(df$treat)
length(unique(df$vaartuig))

# Effect for 42 vessels non-compliers
df = dfb
df = df[!(df$vaartuig %in% c(243,64,394)),]
df = df[!(df$vaartuig %in% negSvaartuig),]

sX=c("windnoord","windwest","windsnelheid","temp","golfhoogte","luchtdruk_k13_k14","Diesel")
sTreat <- "treat"
streatX = c(sTreat,sX)
panel_length4 <- plm(as.formula(paste("length_trip_hr ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
coef_test(panel_length4, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]  # this is the one in the paper
summary(panel_length4)  
nrow(df)
sum(df$treat)
length(unique(df$vaartuig))


# If we restict sample to only vessels at sea Sunday-Monday to Thursday-Friday
df$start_day = weekdays(as.Date(df$vertrek,format="%Y-%m-%d"))
table(df$start_day)
df$start_sel = as.numeric(df$start_day == "Sunday")*as.numeric(df$length_trip <= 6) + as.numeric(df$start_day == "Monday")*as.numeric(df$length_trip <= 5) + as.numeric(df$start_day == "Tuesday")*as.numeric(df$length_trip <= 4) + as.numeric(df$start_day == "Wednesday")*as.numeric(df$length_trip <= 3) + as.numeric(df$start_day == "Thursday")*as.numeric(df$length_trip == 1)
nrow(df)
df = filter(df, (df$start_sel == 1)) # Sunday-Monday to Sunday-Monday to Thursday-Friday trip
nrow(df)


sum(df$treat*df$length_trip)/sum(df$treat) - sum((1-df$treat)*df$length_trip)/sum(1-df$treat)  # Difference in means of trip length
table(df$treat)
streatX = c(sTreat)
panel_length1 <- plm(as.formula(paste("length_trip ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_length3 <- plm(as.formula(paste("length_trip_hr ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
streatX = c(sTreat,sX)
panel_length2 <- plm(as.formula(paste("length_trip ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_length4 <- plm(as.formula(paste("length_trip_hr ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
coef_test(panel_length1, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
coef_test(panel_length2, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
coef_test(panel_length3, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
coef_test(panel_length4, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
#summary(panel_length2)

aggregate(df$length_trip, list(df$treat), mean)
aggregate(df$length_trip, list(df$treat), median)



# Dropping observations for each of 4 vessels which are either always patrolled or always non-patrolled (4 observations dropped total)
df1 = df[!(df$vaartuig %in% c(243,64,394)),]
nrow(df1)

df1$perc_sol5T1 = df1$perc_sol5*df1$treat
df1$perc_sol5T0 = df1$perc_sol5*(1-df1$treat)
perc_sol5T1_df1 = df1[(df1$treat ==1),]
perc_sol5T0_df1 = df1[(df1$treat ==0),]
AggrT1_prec5 = aggregate(perc_sol5T1_df1$perc_sol5T1, by=list(perc_sol5T1_df1$vaartuig), mean)
AggrT0_prec5 = aggregate(perc_sol5T0_df1$perc_sol5T0, by=list(perc_sol5T0_df1$vaartuig), mean)
Dperc_sol5 = AggrT1_prec5[,2]- AggrT0_prec5[,2]




 
##############################################
# Effects on probability of vessel out at sea
###############################################

df = dfb

sum(df$kg_totaal==0)
sum((df$kg_totaal<=20)*(df$kg_totaal>0))
sum((df$kg_totaal<=50)*(df$kg_totaal>0))
sum((df$kg_totaal<=100)*(df$kg_totaal>0))
sum((df$kg_totaal<=200)*(df$kg_totaal>0))
sum(df$kg_totaal>=0)

length(unique(df$week_index))  # Check total number of weeks in sample  #81
sort(aggregate(df$week_index, list(df$vaartuig), length)[,2]) # Check how many weeks each vessel is fishing # no fishing vessel is at sea all of the weeks

table(df$treat)
df$fished_sol1 = as.numeric(df$kg_totaal>50) 
table(df$fished_sol1)  # This is set at df$fished_sol1 = as.numeric(dfp$kg_totaal>low_landing) 


sX=c("windnoord","windwest","windsnelheid","temp","golfhoogte","luchtdruk_k13_k14","Diesel")
sTreat <- "treat"
streatX = c(sTreat)
panel_fished_sol1 <- plm(as.formula(paste("fished_sol1 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
streatX = c(sTreat,sX)
panel_fished_sol2 <- plm(as.formula(paste("fished_sol1 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
coef_test(panel_fished_sol1, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
coef_test(panel_fished_sol2, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
summary(panel_fished_sol2)

mean_by_week <- aggregate(df[,c("week_index","treat","windnoord","windwest","windsnelheid","temp","golfhoogte","luchtdruk_k13_k14","Diesel")], by = list(df$week_index), FUN = mean)
mean_by_week =mean_by_week[,-1]
df <- df[order(df$vaartuig, df$week_index), ] # sort df for loop

sort_week <- sort(unique(df$week_index))

dfv <- expand.grid(vaartuig = unique(df$vaartuig), week_index = sort_week)
dfv$vaar_week= 1000*dfv$vaartuig+ dfv$week_index
df$vaar_week= 1000*df$vaartuig+ df$week_index
dfv$atsee <- ifelse((dfv$vaar_week %in% df$vaar_week), 1, 0)  # Generate variable equal to 1 if vessel out at see
dfv <- merge(dfv, mean_by_week, by = "week_index") # Merge back weekly weather data and treatment 

sX=c("windnoord","windwest","windsnelheid","temp","golfhoogte","luchtdruk_k13_k14","Diesel")
sTreat <- "treat"
streatX = c(sTreat)
panel_fished_sol1 <- plm(as.formula(paste("atsee ~ ", paste(streatX, collapse= "+"))), data = dfv,index = c("vaartuig"), model = "within")
streatX = c(sTreat,sX)
panel_fished_sol2 <- plm(as.formula(paste("atsee ~ ", paste(streatX, collapse= "+"))), data = dfv,index = c("vaartuig"), model = "within")
coef_test(panel_fished_sol1, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
coef_test(panel_fished_sol2, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
summary(panel_fished_sol2)
sum(dfv$treat)


## In the following code we add 0 entries for weeks in which vessels did not go out at sea ##
dfp <- read.csv( "D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Stephen files\\Data_final_1719_newProb.csv")  # this file already made the selection of weeks for sample
#dfp <- read.csv( "D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Stephen files\\Data_final_1719_newProb_corr.csv")  # this file already made the selection of weeks for sample
dfp = dfp[,-1]


# Below are all full weeks during which BB was not patrolling
# 2017: 1 10 11 17 21 22 27 28 29 30 31 32 33 42 50 52 
# 2018: 53 58 59 61 62 70 73 74 82 83 84 85 86 87 94 96 97 104
# 2019: 105 114 115 116 124 125 128 131 132 133 134 135 136 137 140 141 146 147 148 149 153 155 156

NT_week = c( 1,10, 11, 17,21,22, 27,28, 29, 30, 31, 32, 33, 42,50, 52, 53,58,59, 61,62,70,73,74, 82,83, 84, 85, 86, 87, 94, 96, 97,104,105, 114,115, 116, 124, 125, 128,  131,132, 133, 134, 135, 136, 137, 140, 141, 146,147, 148 , 149, 153, 155,156 )  # Non-Treated weeks (no patrolling)
All = seq(1,156)
T_week = All[!(All  %in% NT_week)] # Treated weeks (patrolling)
mAnalysis_weeks = rbind(cbind(NT_week,0),cbind(T_week,1))
mA_w = mAnalysis_weeks[order(mAnalysis_weeks[,1]),2]

analysis_weeks = 1
for (i in seq(2,155)) {
  analysis_weeks = cbind(analysis_weeks,i*as.numeric(mA_w[i] != mA_w[(i-1)]) + i*as.numeric(mA_w[i] != mA_w[(i+1)])* (1-as.numeric(mA_w[i] != mA_w[(i-1)])*as.numeric(mA_w[i] != mA_w[(i+1)])))
}
analysis_weeks
analysis_weeks = analysis_weeks[analysis_weeks!=0]  # Weeks to be included in sample
analysis_weeks
All[!(All  %in% analysis_weeks)]    # Weeks to be excluded from sample

df_weekly = filter(dfp, (dfp$week_index==1))
vessels_by_week = c(length(unique(df_weekly$vaartuig)),1)
for (i in seq(2,156)) {
  df_weekly = filter(dfp, (dfp$week_index==i))
  vessels_by_week = rbind(vessels_by_week,c(length(unique(df_weekly$vaartuig)),i))
}

# Plot number of vessels at sea for each week
plot(x=vessels_by_week[,2], y=vessels_by_week[,1])


nrow(dfp)
dfp = filter(dfp, (dfp$week_index %in% analysis_weeks))
nrow(dfp)
table(dfp$week_index)

# Plot number of vessels at sea for each week
vessels_by_week =vessels_by_week[(vessels_by_week[,2] %in% analysis_weeks),]
plot(x=vessels_by_week[,2], y=vessels_by_week[,1])

# Given the resulting dataset, these will be the weeks with no treatment (BB not deployed)
NT_week = unique(df$week_index[(df$week_index %in% NT_week)])
dfp$treat = 1-as.numeric(dfp$week_index %in% NT_week)


# Dropping Christmas weeks which skews analysis of probability of fishing 
# -> fishing vessels and coast guard are almost all on vacation which means these are not comparable weeks to adjacent patrolling weeks
nrow(dfp)
dfp = filter(dfp, !(dfp$week_index %in% c(52,103,104)))  # drop Christmas weeks and their comparisons when relevant
nrow(dfp)
table(dfp$week_index)



dfp$fished_sol1 = as.numeric(dfp$kg_totaal>50) 
table(dfp$fished_sol1)  

sX=c("windnoord","windwest","windsnelheid","temp","golfhoogte","luchtdruk_k13_k14","Diesel")

## Impute value for missing values in "luchtdruk_k13_k14" ##
# replace missing air pressure values with values from nearby station
dfp$luchtdruk_k13_k14[(dfp$week_index == 128)] <- 1013.1857
dfp$luchtdruk_k13_k14[(dfp$week_index == 129)] <- 1015.9572
dfp$luchtdruk_k13_k14[(dfp$week_index == 130)] <- 1021.2286
dfp$luchtdruk_k13_k14[(dfp$week_index == 131)] <- 1020.0714

sum(dfp$treat*dfp$fished_sol1)/sum(dfp$treat) - sum((1-dfp$treat)*dfp$fished_sol1)/sum(1-dfp$treat) # Difference in means of probability of fishing

sum(dfp$treat*dfp$fished_sol1)*length(unique(dfp$vaartuig)) /sum(dfp$treat)
sum((1-dfp$treat)*dfp$fished_sol1)*length(unique(dfp$vaartuig))/sum(1-dfp$treat)
length(unique(dfp$vaartuig)) 
table(dfp$treat)

sTreat <- "treat"
streatX = c(sTreat)
panel_fished_sol1 <- plm(as.formula(paste("fished_sol1 ~ ", paste(streatX, collapse= "+"))), data = dfp,index = c("vaartuig"), model = "within")
streatX = c(sTreat,sX)
panel_fished_sol2 <- plm(as.formula(paste("fished_sol1 ~ ", paste(streatX, collapse= "+"))), data = dfp,index = c("vaartuig"), model = "within")
coef_test(panel_fished_sol1, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
coef_test(panel_fished_sol2, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
summary(panel_fished_sol2)








##############################################
# Effects on GIS location declaration by vessels out at sea
###############################################

df <- read.csv("D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Stephen files\\df_ais.csv")
#df <- read.csv("D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Stephen files\\df_ais_corr.csv")
df = df[,-1]



df$ais_nbr_not0 = df$ais_nbr-df$ais_speed0


# Define length of fishing trip
df$vertrek = as.Date(df$vertrek,format="%Y-%m-%d")
df$terugkeer = as.Date(df$terugkeer,format="%Y-%m-%d")

df$length_trip = (as.numeric(df$terugkeer)-as.numeric(df$vertrek))+1


## Defining treatment and restricting analysis sample ##
########################################################



# Below are all full weeks during which BB was not patrolling
# 2017: 1 10 11 17 21 22 27 28 29 30 31 32 33 42 50 52 
# 2018: 53 58 59 61 62 70 73 74 82 83 84 85 86 87 94 96 97 104
# 2019: 105 114 115 116 124 125 128 131 132 133 134 135 136 137 140 141 146 147 148 149 153 155 156

NT_week = c( 1,10, 11, 17,21,22, 27,28, 29, 30, 31, 32, 33, 42,50, 52, 53,58,59, 61,62,70,73,74, 82,83, 84, 85, 86, 87, 94, 96, 97,104,105, 114,115, 116, 124, 125, 128,  131,132, 133, 134, 135, 136, 137, 140, 141, 146,147, 148 , 149, 153, 155,156 )  # Non-Treated weeks (no patrolling)
All = seq(1,156)
T_week = All[!(All  %in% NT_week)] # Treated weeks (patrolling)
mAnalysis_weeks = rbind(cbind(NT_week,0),cbind(T_week,1))
mA_w = mAnalysis_weeks[order(mAnalysis_weeks[,1]),2]

analysis_weeks = 1
for (i in seq(2,104)) {
  analysis_weeks = cbind(analysis_weeks,i*as.numeric(mA_w[i] != mA_w[(i-1)]) + i*as.numeric(mA_w[i] != mA_w[(i+1)])* (1-as.numeric(mA_w[i] != mA_w[(i-1)])*as.numeric(mA_w[i] != mA_w[(i+1)])))
}
analysis_weeks
analysis_weeks = analysis_weeks[analysis_weeks!=0]  # Weeks to be included in sample
analysis_weeks
All[!(All  %in% analysis_weeks)]    # Weeks to be excluded from sample

# Keep only relevant adjacant weeks
nrow(df)
df = filter(df, (df$week_index %in% analysis_weeks))
nrow(df)
table(df$week_index)


# Given the resulting dataset, these will be the weeks with no treatment (BB not deployed)
NT_week = c( 1,10, 11, 17,21,22, 27, 33, 42,50, 52, 53,58,59, 61,62,70,73,74, 82, 87, 94, 96, 97,104,105, 114, 116, 124, 125, 128,  131, 137, 140, 141, 146, 149, 153, 155 )
df$treat = 1-as.numeric(df$week_index %in% NT_week)


# Dropping Christmas weeks which skews analysis of probability of fishing 
# -> fishing vessels and coast guard are almost all on vacation which means these are not comparable weeks to adjacent patrolling weeks
nrow(df)
df = filter(df, !(df$week_index %in% c(52,103,104)))  # drop Christmas weeks and their comparisons when relevant
nrow(df)
table(df$week_index)





length(unique(df$vaartuig)) 
table(df$vaartuig)




# Effects on shares of fish category landed
sX=c("windnoord","windwest","windsnelheid","temp","golfhoogte","luchtdruk_k13_k14","Diesel")


## Impute value for missing values in "luchtdruk_k13_k14" ##
# replace missing air pressure values with values from nearby station
df$luchtdruk_k13_k14[(df$week_index == 128)] <- 1013.1857
df$luchtdruk_k13_k14[(df$week_index == 129)] <- 1015.9572
df$luchtdruk_k13_k14[(df$week_index == 130)] <- 1021.2286
df$luchtdruk_k13_k14[(df$week_index == 131)] <- 1020.0714

# SHOW THE FIRST TWO OF THESE HISTOGRAMS IN APPENDIX 
hist(df$ais_nbr,breaks=200,xlim=c(0,800),xlab="Total GPS signals sent",main="", col=c("#0099FF"))   #This is the one in the paper
hist(df$ais_nbr_not0,breaks=200,xlim=c(0,600),xlab="Total GPS non 0 Speed signals sent",main="", col=c("#0099FF"))
hist(df$ais_speed0,breaks=200,xlim=c(0,400),xlab="Total GPS Speed=0 signals sent",main="", col=c("#0099FF"))
hist(df$ais_trawl_speed,breaks=200,xlim=c(0,400),xlab="Total GPS signals sent at Tralwing speed",main="", col=c("#0099FF"))


# For descriptive statistics table:
df_ais_nbr1= df$ais_nbr[(df$treat ==1)]   # treated ais observations
df_ais_nbr0= df$ais_nbr[(df$treat ==0)]   # untreated ais observations
mean(df_ais_nbr1)
sd(df_ais_nbr1)
mean(df_ais_nbr0)
sd(df_ais_nbr0)

nrow(df)
table(df$treat)
sX=c("windnoord","windwest","windsnelheid","temp","golfhoogte","luchtdruk_k13_k14","Diesel")
sTreat <- "treat"
streatX = c(sTreat)
panel_gps1 <- plm(as.formula(paste("ais_nbr ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_gps3 <- plm(as.formula(paste("ais_speed0 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_gps5 <- plm(as.formula(paste("ais_nbr_not0 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_gps7 <- plm(as.formula(paste("ais_trawl_speed ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
streatX = c(sTreat,sX)
panel_gps2 <- plm(as.formula(paste("ais_nbr ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_gps4 <- plm(as.formula(paste("ais_speed0 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_gps6 <- plm(as.formula(paste("ais_nbr_not0 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_gps8 <- plm(as.formula(paste("ais_trawl_speed ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
coef_test(panel_gps1, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
coef_test(panel_gps2, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]   #This is the one in the paper
coef_test(panel_gps3, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
coef_test(panel_gps4, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
coef_test(panel_gps5, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
coef_test(panel_gps6, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
coef_test(panel_gps7, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
coef_test(panel_gps8, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]

summary(panel_gps2)
sum(sTreat)

# If we restict sample to only vessels at sea Sunday-Monday to Thursday-Friday
df$start_day = weekdays(as.Date(df$vertrek,format="%Y-%m-%d"))
table(df$start_day)
df$start_sel = as.numeric(df$start_day == "Sunday")*as.numeric(df$length_trip <= 6) + as.numeric(df$start_day == "Monday")*as.numeric(df$length_trip <= 5) + as.numeric(df$start_day == "Tuesday")*as.numeric(df$length_trip <= 4) + as.numeric(df$start_day == "Wednesday")*as.numeric(df$length_trip <= 3) + as.numeric(df$start_day == "Thursday")*as.numeric(df$length_trip == 1)
nrow(df)
df = filter(df, (df$start_sel == 1)) # Sunday-Monday trip start days observations

# SHOW THE FIRST TWO OF THESE HISTOGRAMS IN APPENDIX
hist(df$ais_nbr,breaks=200,xlim=c(0,800),xlab="Total GPS signals sent",main="", col=c("#0099FF"))
hist(df$ais_nbr_not0,breaks=200,xlim=c(0,600),xlab="Total GPS non 0 Speed signals sent",main="", col=c("#0099FF"))
hist(df$ais_speed0,breaks=200,xlim=c(0,400),xlab="Total GPS Speed=0 signals sent",main="", col=c("#0099FF"))
hist(df$ais_trawl_speed,breaks=200,xlim=c(0,400),xlab="Total GPS signals sent at Tralwing speed",main="", col=c("#0099FF"))



nrow(df)
table(df$treat)
streatX = c(sTreat)
panel_gps1 <- plm(as.formula(paste("ais_nbr ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_gps3 <- plm(as.formula(paste("ais_speed0 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_gps5 <- plm(as.formula(paste("ais_nbr_not0 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_gps7 <- plm(as.formula(paste("ais_trawl_speed ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
streatX = c(sTreat,sX)
panel_gps2 <- plm(as.formula(paste("ais_nbr ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_gps4 <- plm(as.formula(paste("ais_speed0 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_gps6 <- plm(as.formula(paste("ais_nbr_not0 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_gps8 <- plm(as.formula(paste("ais_trawl_speed ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
coef_test(panel_gps1, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
coef_test(panel_gps2, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
coef_test(panel_gps3, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
coef_test(panel_gps4, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]  
coef_test(panel_gps5, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
coef_test(panel_gps6, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
coef_test(panel_gps7, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
coef_test(panel_gps8, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
summary(panel_gps2)
summary(panel_gps4)
summary(panel_gps6)


panel_gps1 = fepois(ais_nbr ~ treat +    windnoord  +  windwest  +  windsnelheid +  temp    + golfhoogte  +  luchtdruk_k13_k14 + Diesel  | vaartuig, df)
panel_gps2 = fepois(ais_speed0 ~ treat +   windnoord  +  windwest  +   windsnelheid +  temp   + golfhoogte  +  luchtdruk_k13_k14 + Diesel | vaartuig, df)
panel_gps3 = fepois(ais_nbr_not0 ~ treat +   windnoord  +  windwest  +   windsnelheid +  temp   + golfhoogte  +  luchtdruk_k13_k14 + Diesel  | vaartuig, df)
print(panel_gps1) 
print(panel_gps2) 
print(panel_gps3) 





























#########################################################################################################
## WEEKEND EFFECTS ##
#########################################################################################################



df = dfa


# We assume that there is never any patrolling between Friday and Sunday to construct treatment variable
#  df$frac_wd is fraction of days over total days at sea that vessel was at sea on friday, Saturday, or Sunday
df$frac_wd =   (1/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Monday")*(df$length_trip==5) + (2/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Monday")*(df$length_trip==6) +  (3/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Monday")*(df$length_trip>6)*(df$length_trip <= 11) + (4/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Monday")*(df$length_trip == 12) + (5/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Monday")*(df$length_trip == 13) + (6/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Monday")*(df$length_trip == 14) +
  (1/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Tuesday")*(df$length_trip==4) + (2/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Tuesday")*(df$length_trip==5) +  (3/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Tuesday")*(df$length_trip>5)*(df$length_trip <= 10) + (4/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Tuesday")*(df$length_trip == 11) + (5/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Tuesday")*(df$length_trip == 12) + (6/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Tuesday")*(df$length_trip >= 13) +
  (1/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Wednesday")*(df$length_trip==3) + (2/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Wednesday")*(df$length_trip==4) + (3/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Wednesday")*(df$length_trip>4)*(df$length_trip <= 9) + (4/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Wednesday")*(df$length_trip == 10) + (5/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Wednesday")*(df$length_trip == 11) + (6/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Wednesday")*(df$length_trip >= 12) +
  (1/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Thursday")*(df$length_trip==2) + (2/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Thursday")*(df$length_trip==3) +   (3/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Thursday")*(df$length_trip>3)*(df$length_trip <= 8) + (4/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Thursday")*(df$length_trip == 9) + (5/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Thursday")*(df$length_trip == 10) + (6/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Thursday")*(df$length_trip >= 11) +
  (weekdays(as.Date(df$vertrek))=="Friday")*(df$length_trip<4) + (3/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Friday")*(df$length_trip>=4)*(df$length_trip<=7) + (4/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Friday")*(df$length_trip==8)  + (5/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Friday")*(df$length_trip ==9) + (6/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Friday")*(df$length_trip >= 10) +
  (weekdays(as.Date(df$vertrek))=="Saturday")*(df$length_trip<3) + (2/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Saturday")*(df$length_trip>=3)*(df$length_trip<=6) + (3/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Saturday")*(df$length_trip==7)  + (4/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Saturday")*(df$length_trip ==8) + (5/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Saturday")*(df$length_trip >= 9)*(df$length_trip <= 13) + (6/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Saturday")*(df$length_trip == 14) +
  (weekdays(as.Date(df$vertrek))=="Sunday")*(df$length_trip == 1) + (1/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Sunday")*(df$length_trip>=2)*(df$length_trip<=5) + (2/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Sunday")*(df$length_trip==6)  + (3/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Sunday")*(df$length_trip ==7) + (4/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Sunday")*(df$length_trip >= 8)*(df$length_trip <= 12)  + (5/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Sunday")*(df$length_trip == 13) + (6/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Sunday")*(df$length_trip ==14) 


table(df$frac_wd) 
table(df$length_trip)  # check return days

frac =  0.5
df$treat_we = as.numeric(df$frac_wd < frac) # Treated if fraction of weekend days fishing is below frac (this allows for vessels leaving on sunday night and returning Friday morning to be counted as during the week trips)
table(df$treat_we)                
nrow(df)

## Appendix result: Robustness check notexcluding semi-treated ##
## Comment out the following section:
df = filter(df, ((df$frac_wd > 0.334)*(df$frac_wd <frac ) !=1)) # df$frac_wd > 0.334 allows for vessels leaving on sunday night and returning Friday morning to be counted as during the week trips)
##########



##Difference in difference to remove confounding effect due to supply restrictions ###

# Weeks in which BB was not patrolling
# 2017: 1 10 11 17 21 22 27 28 29 30 31 32 33 42 50 52
# 2018: 53 58 59 61 62 70 73 74 82 83 84 85 86 87 94 96 97 104
# 2019: 105 114 115 116 124 125 128 131 132 133 134 135 136 137 140 141 146 147 148 149 153 155 156
noBB_weeks = c(1, 10, 11, 17, 21, 22, 27, 28, 29, 30, 31, 32, 33, 42, 50, 52,53, 58, 59, 61, 62, 70, 73, 74, 82, 83, 84, 85, 86, 87, 94, 96, 97, 104,105, 114, 115, 116, 124, 125, 128, 131, 132, 133, 134, 135, 136, 137, 140, 141, 146, 147, 148, 149, 153, 155, 156)

df$off_week = matrix(0,nrow(df),1)
for (i in 1:nrow(df)) {
  for (j in 1:length(noBB_weeks)) {
    if (df$week_index[i] == noBB_weeks[j]) {
      df$off_week[i] = 1
    }
  }
}

# Dropping Christmas weeks which skews analysis of probability of fishing 
# -> fishing vessels and coast guard are almost all on vacation which means these are not comparable weeks to adjacent patrolling weeks
nrow(df)
df = filter(df, !(df$week_index %in% c(52,104,156)))  # drop Christmas weeks and their comparisons when relevant
nrow(df)
table(df$week_index)

# Construct weekend effect
df$BB_week = 1-df$off_week  # weeks in which there was patrolling
df$BB_week_treat = df$BB_week * df$treat_we  # weekdays in weeks in which there was patrolling
nrow(df)
table(df$treat_we) 
sum((1-df$treat_we)*df$BB_week)
sum((1-df$treat_we)*(1-df$BB_week))


table(df$treat_we)

# Effects on shares of fish category landed
sX=c("windnoord","windwest","windsnelheid","temp","golfhoogte","luchtdruk_k13_k14","Diesel")

# Most balanced specification is one with algorithm imputed values on NA and using
# covariates without higher order values sX=c("windnoord","windwest","windsnelheid","temp","golfhoogte","luchtdruk_k13_k14","Diesel")

############
## Impute value for missing values in "luchtdruk_k13_k14" ##
# replace missing air pressure values with values from nearby station
df$luchtdruk_k13_k14[(df$week_index == 128)] <- 1013.1857
df$luchtdruk_k13_k14[(df$week_index == 129)] <- 1015.9572
df$luchtdruk_k13_k14[(df$week_index == 130)] <- 1021.2286
df$luchtdruk_k13_k14[(df$week_index == 131)] <- 1020.0714


sTreat <- c("treat_we","BB_week_treat")
# B_treat_we = effect of weekdays relative to weekends in non patrolling weeks
# B_BB_week_treat = effect of weekdays vs weekends in weeks in which there is patrolling




##############################################
### EFFECTS ON SOLE SHARE                  ###
##############################################


streatX = c(sTreat)
panel_share5 <- plm(as.formula(paste("perc_sol5 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig","week_index"), model = "within", effect = "twoways")
panel_share4 <- plm(as.formula(paste("perc_sol4 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig","week_index"), model = "within", effect = "twoways")
panel_share3 <- plm(as.formula(paste("perc_sol3 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig","week_index"), model = "within", effect = "twoways")
panel_share2 <- plm(as.formula(paste("perc_sol2 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig","week_index"), model = "within", effect = "twoways")
panel_share1 <- plm(as.formula(paste("perc_sol1 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig","week_index"), model = "within", effect = "twoways")
res5 = coef_test(panel_share5, vcov = "CR1", cluster = "individual", test = "naive-t")[2,]
res4 = coef_test(panel_share4, vcov = "CR1", cluster = "individual", test = "naive-t")[2,]
res3 = coef_test(panel_share3, vcov = "CR1", cluster = "individual", test = "naive-t")[2,]
res2 = coef_test(panel_share2, vcov = "CR1", cluster = "individual", test = "naive-t")[2,]
res1 = coef_test(panel_share1, vcov = "CR1", cluster = "individual", test = "naive-t")[2,]

res = rbind(res5,res4,res3,res2,res1)
res_df = as.data.frame(res[,1:2])

## The following lines are to build LaTeX table
summary(panel_share5)
tabl5 = coef_test(panel_share5, vcov = "CR1", cluster = "individual", test = "naive-t")
tabl4 = coef_test(panel_share4, vcov = "CR1", cluster = "individual", test = "naive-t")
tabl3 = coef_test(panel_share3, vcov = "CR1", cluster = "individual", test = "naive-t")
tabl2 = coef_test(panel_share2, vcov = "CR1", cluster = "individual", test = "naive-t")
tabl1 = coef_test(panel_share1, vcov = "CR1", cluster = "individual", test = "naive-t")

tabl = cbind(rbind(tabl5[1,1],tabl5[1,2],tabl5[2,1],tabl5[2,2]),
             rbind(tabl4[1,1],tabl4[1,2],tabl4[2,1],tabl4[2,2]),
             rbind(tabl3[1,1],tabl3[1,2],tabl3[2,1],tabl3[2,2]),
             rbind(tabl2[1,1],tabl2[1,2],tabl2[2,1],tabl2[2,2]),
             rbind(tabl1[1,1],tabl1[1,2],tabl1[2,1],tabl1[2,2]))  
####



streatX = c(sTreat,sX)
panel_share5 <- plm(as.formula(paste("perc_sol5 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig","week_index"), model = "within", effect = "twoways")
panel_share4 <- plm(as.formula(paste("perc_sol4 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig","week_index"), model = "within", effect = "twoways")
panel_share3 <- plm(as.formula(paste("perc_sol3 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig","week_index"), model = "within", effect = "twoways")
panel_share2 <- plm(as.formula(paste("perc_sol2 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig","week_index"), model = "within", effect = "twoways")
panel_share1 <- plm(as.formula(paste("perc_sol1 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig","week_index"), model = "within", effect = "twoways")
res5 = coef_test(panel_share5, vcov = "CR1", cluster = "individual", test = "naive-t")[2,]
res4 = coef_test(panel_share4, vcov = "CR1", cluster = "individual", test = "naive-t")[2,]
res3 = coef_test(panel_share3, vcov = "CR1", cluster = "individual", test = "naive-t")[2,]
res2 = coef_test(panel_share2, vcov = "CR1", cluster = "individual", test = "naive-t")[2,]
res1 = coef_test(panel_share1, vcov = "CR1", cluster = "individual", test = "naive-t")[2,]


## The following lines are to build LaTeX table
tabl5 = coef_test(panel_share5, vcov = "CR1", cluster = "individual", test = "naive-t")
tabl4 = coef_test(panel_share4, vcov = "CR1", cluster = "individual", test = "naive-t")
tabl3 = coef_test(panel_share3, vcov = "CR1", cluster = "individual", test = "naive-t")
tabl2 = coef_test(panel_share2, vcov = "CR1", cluster = "individual", test = "naive-t")
tabl1 = coef_test(panel_share1, vcov = "CR1", cluster = "individual", test = "naive-t")


for (i in 1:(length(sX)+1)) {
  tabl = rbind(tabl, cbind(rbind(tabl5[i,1],tabl5[i,2]),rbind(tabl4[i,1],tabl4[i,2]),rbind(tabl3[i,1],tabl3[i,2]),
                           rbind(tabl2[i,1],tabl2[i,2]),rbind(tabl1[i,1],tabl1[i,2]))  )
}
tablshare =tabl
##

res = rbind(res5,res4,res3,res2,res1)

res_df = rbind(res_df,res[,1:2])
res_df$covar = c(rep("without covariates",5),rep("with covariates",5))
res_df$size =   c("Small", "Medium-Small", "Medium", "Medium-Large", "Large","Small", "Medium-Small", "Medium", "Medium-Large", "Large")
rownames(res_df) <- NULL
colnames(res_df) <-  c("effect", "effect_se", "specification", "size")
res_df = rbind(res_df[1,],res_df[6,],res_df[2,],res_df[7,],res_df[3,],res_df[8,],res_df[4,],res_df[9,],res_df[5,],res_df[10,])
res_df$size <- as.character(res_df$size)
res_df$size <- factor(res_df$size, levels=unique(res_df$size))

####################
## Figure 13a
####################
pd = position_dodge(.2)    ### How much to jitter the points on the plot

print(ggplot(res_df,                ### The data frame to use.
             aes(x     = size,
                 y     = effect,
                 color = specification)) +
        geom_point(shape = 15,
                   size  = 4,
                   position = pd) +
        geom_errorbar(aes(ymin  = effect - 1.96*effect_se,
                          ymax  = effect + 1.96*effect_se),
                      width = 0.2,
                      size  = 1,
                      position = pd) +
        theme_bw() +
        theme(text = element_text(size=20)) +
        theme(legend.title = element_blank()) +
        theme(legend.position = c(0.85, 0.08)) +
        theme(legend.background = element_rect(fill="white",
                                               size=0.5, linetype="solid", 
                                               colour ="black")) +
        scale_color_grey() +
        geom_hline(yintercept=0, linetype="dotted") +
        ylab("Change in share") +
        xlab("Size category"))
#ggsave("D:\\Dropbox\\Fishing\\TeX file\\eff_shareWE.png", width = 9.5, height = 6.5)   ## Figure 13a
#ggsave("D:\\Dropbox\\Fishing\\TeX file\\eff_shareWEall.png", width = 9.5, height = 6.5)



##############################################
### EFFECTS ON SOLE WEIGHT - poisson model ###
##############################################



panel_land_tot = fepois(kg_totaal ~ treat_we + BB_week_treat   | vaartuig + week_index, df)
panel_land5 = fepois(verkoop_sol_levend_4 ~ treat_we + BB_week_treat   | vaartuig + week_index, df)
panel_land4 = fepois(verkoop_sol_levend_4 ~ treat_we + BB_week_treat   | vaartuig + week_index, df)
panel_land3 = fepois(verkoop_sol_levend_3 ~ treat_we + BB_week_treat   | vaartuig + week_index, df)
panel_land2 = fepois(verkoop_sol_levend_2 ~ treat_we + BB_week_treat   | vaartuig + week_index, df)
panel_land1 = fepois(verkoop_sol_levend_1 ~ treat_we + BB_week_treat   | vaartuig + week_index, df)
print(panel_land_tot) 
print(panel_land5) 
print(panel_land4) 
print(panel_land3) 
print(panel_land2)
print(panel_land1) 



res = cbind(c(summary(panel_land_tot)$coefficients[2],summary(panel_land5)$coefficients[2],summary(panel_land4)$coefficients[2],summary(panel_land3)$coefficients[2],summary(panel_land2)$coefficients[2],summary(panel_land1)$coefficients[2]),c(summary(panel_land_tot)$se[2],summary(panel_land5)$se[2],summary(panel_land4)$se[2],summary(panel_land3)$se[2],summary(panel_land2)$se[2],summary(panel_land1)$se[2]))
res_df = as.data.frame(res)


panel_land_tot = fepois(kg_totaal ~ treat_we + BB_week_treat +    windnoord  +  windwest  +  windsnelheid +  temp    + golfhoogte  +  luchtdruk_k13_k14 + Diesel  | vaartuig + week_index, df)
panel_land5 = fepois(verkoop_sol_levend_5 ~ treat_we + BB_week_treat +   windnoord  +  windwest  +   windsnelheid +  temp   + golfhoogte  +  luchtdruk_k13_k14 + Diesel  | vaartuig + week_index, df)
panel_land4 = fepois(verkoop_sol_levend_4 ~ treat_we + BB_week_treat +   windnoord  +  windwest  +   windsnelheid +  temp   + golfhoogte  +  luchtdruk_k13_k14 + Diesel  | vaartuig + week_index, df)
panel_land3 = fepois(verkoop_sol_levend_3 ~ treat_we + BB_week_treat +   windnoord  +  windwest  +   windsnelheid +  temp   + golfhoogte +  luchtdruk_k13_k14 + Diesel  | vaartuig + week_index, df)
panel_land2 = fepois(verkoop_sol_levend_2 ~ treat_we + BB_week_treat +   windnoord  +  windwest  +   windsnelheid +  temp    + golfhoogte  +  luchtdruk_k13_k14 + Diesel  | vaartuig + week_index, df)
panel_land1 = fepois(verkoop_sol_levend_1 ~ treat_we + BB_week_treat +   windnoord  +  windwest  +   windsnelheid +  temp    + golfhoogte  +  luchtdruk_k13_k14 + Diesel  | vaartuig + week_index, df)
print(panel_land_tot) 
print(panel_land5) 
print(panel_land4) 
print(panel_land3) 
print(panel_land2) 
print(panel_land1)



res = cbind(c(summary(panel_land_tot)$coefficients[2],summary(panel_land5)$coefficients[2],summary(panel_land4)$coefficients[2],summary(panel_land3)$coefficients[2],summary(panel_land2)$coefficients[2],summary(panel_land1)$coefficients[2]),c(summary(panel_land_tot)$se[2],summary(panel_land5)$se[2],summary(panel_land4)$se[2],summary(panel_land3)$se[2],summary(panel_land2)$se[2],summary(panel_land1)$se[2]))
res_df = rbind(res_df,res) 

res_df$covar = c(rep("without covariates",6),rep("with covariates",6))
res_df$size =   c("All","Small", "Medium-Small", "Medium", "Medium-Large", "Large","All","Small", "Medium-Small", "Medium", "Medium-Large", "Large")
rownames(res_df) <- NULL
colnames(res_df) <-  c("effect", "effect_se", "specification", "size")
res_df = rbind(res_df[1,],res_df[7,],res_df[2,],res_df[8,],res_df[3,],res_df[9,],res_df[4,],res_df[10,],res_df[5,],res_df[11,],res_df[6,],res_df[12,])
res_df$size <- as.character(res_df$size)
res_df$size <- factor(res_df$size, levels=unique(res_df$size))

####################
## Figure 13b
####################
pd = position_dodge(.2)    ### How much to jitter the points on the plot

print(ggplot(res_df,               
             aes(x     = size,
                 y     = effect,
                 color = specification)) +
        geom_point(shape = 15,
                   size  = 4,
                   position = pd) +
        geom_errorbar(aes(ymin  = effect - 1.96*effect_se,
                          ymax  = effect + 1.96*effect_se),
                      width = 0.2,
                      size  = 1,
                      position = pd) +
        theme_bw() +
        theme(text = element_text(size=20)) +
        theme(legend.title = element_blank()) +
        theme(legend.position = c(0.85, 0.08)) +
        theme(legend.background = element_rect(fill="white",
                                               size=0.5, linetype="solid", 
                                               colour ="black")) +
        scale_color_grey() +
        geom_hline(yintercept=0, linetype="dotted") +
        ylab("Approx. % change in weight (kg)") +
        xlab("Size category"))
ggsave("D:\\Dropbox\\Fishing\\TeX file\\eff_weightPO_WE.png", width = 9.5, height = 6.5)   ## Figure 13b
#ggsave("D:\\Dropbox\\Fishing\\TeX file\\eff_weightPO_WEall.png", width = 9.5, height = 6.5)



# Effects on length of fishing trip and probability of fishing



sX=c("windnoord","windwest","windsnelheid","temp","golfhoogte","luchtdruk_k13_k14","Diesel")
sTreat <- c("treat_we","BB_week_treat")
streatX = c(sTreat)
panel_length1 <- plm(as.formula(paste("length_trip ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig","week_index"), model = "within", effect = "twoways")
panel_length3 <- plm(as.formula(paste("length_trip_hr ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig","week_index"), model = "within", effect = "twoways")
streatX = c(sTreat,sX)
panel_length2 <- plm(as.formula(paste("length_trip ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig","week_index"), model = "within", effect = "twoways")
panel_length4 <- plm(as.formula(paste("length_trip_hr ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig","week_index"), model = "within", effect = "twoways")
coef_test(panel_length1, vcov = "CR1", cluster = "individual", test = "naive-t")[1:2,]
coef_test(panel_length2, vcov = "CR1", cluster = "individual", test = "naive-t")[1:2,]
coef_test(panel_length3, vcov = "CR1", cluster = "individual", test = "naive-t")[1:2,]
coef_test(panel_length4, vcov = "CR1", cluster = "individual", test = "naive-t")[1:2,]  # coefficient in same direction but not enough power
#summary(panel_length1)
summary(panel_length4)







######################################################
### FUEL EFFECTS                                  ####
######################################################


df = dfa

summary(df$Diesel)
table(df$Diesel)


# 
# # Plot number of vessels at sea for each week
# df_weekly = filter(df, (df$week_index==1))
# vessels_by_week = c(length(unique(df_weekly$vaartuig)),1)
# for (i in seq(2,156)) {
#   df_weekly = filter(df, (df$week_index==i))
#   vessels_by_week = rbind(vessels_by_week,c(length(unique(df_weekly$vaartuig)),i))
# }
# vessels_by_week
# 
# # Plot number of vessels at sea for each week
# plot(x=vessels_by_week[,2], y=vessels_by_week[,1])
# 
# plot_Dieseldur = as.data.frame(cbind(vessels_by_week[,2],vessels_by_week[,1],aggregate(df[, "Diesel"], list(df$week_index), mean)[,2],aggregate(df[, "length_trip"], list(df$week_index), mean)[,2])) 
# plot_Dieseldur = filter(plot_Dieseldur, !(plot_Dieseldur[,1] %in% c(52,104,156))) 
# colnames(plot_Dieseldur) <- c("week_index","nbr_vessels","Diesel", "avgDuration")
# 
# 
# # DieselVSvessels =  cbind(vessels_by_week[,1],aggregate(df[, "Diesel"], list(df$week_index), mean)[,2])
# # plot(x=DieselVSvessels[,1], y=DieselVSvessels[,2])
# plot(x=plot_Dieseldur[,1], y=plot_Dieseldur[,3])
# plot(x=plot_Dieseldur[,3], y=plot_Dieseldur[,2])
# 
# abline(lm(plot_Dieseldur[,2] ~ plot_Dieseldur[,3]))
# 
# plot_Dieseldur
# plot_Dieseldur = filter(plot_Dieseldur, !(plot_Dieseldur$avgDuration<4.9))
# plot_Dieseldur = filter(plot_Dieseldur, !(plot_Dieseldur$avgDuration>6.3))
# plot(x=plot_Dieseldur[,4], y=plot_Dieseldur[,2])
# abline(lm(plot_Dieseldur[,2] ~ plot_Dieseldur[,4]))
# summary(lm(plot_Dieseldur[,2] ~ plot_Dieseldur[,4]))
# 


#Dropping weeks in which coast guard was not patrolling
# NT_week = c( 1,10, 11, 17,21,22, 27,28, 29, 30, 31, 32, 33, 42,50, 52, 53,58,59, 61,62,70,73,74, 82,83, 84, 85, 86, 87, 94, 96, 97,104,105, 114,115, 116, 124, 125, 128,  131,132, 133, 134, 135, 136, 137, 140, 141, 146,147, 148 , 149, 153, 155,156 )  # Non-Treated weeks (no patrolling)
# nrow(df)
# df = filter(df, !(df$week_index %in% NT_week))  
# nrow(df)

# Dropping Christmas weeks which skews analysis of probability of fishing 
# -> fishing vessels and coast guard are almost all on vacation which means these are not comparable weeks to adjacent patrolling weeks
table(df$week_index)
nrow(df)
df = filter(df, !(df$week_index %in% c(52,104,156)))  # drop Christmas weeks and their comparisons when relevant
nrow(df)
table(df$week_index)


# Effects on shares of fish category landed
sX=c("windnoord","windwest","windsnelheid","temp","golfhoogte","luchtdruk_k13_k14")

# Most balanced specification is one with algorithm imputed values on NA and using
# covariates without higher order values sX=c("windnoord","windwest","windsnelheid","temp","golfhoogte","luchtdruk_k13_k14","Diesel")

############
## Impute value for missing values in "luchtdruk_k13_k14" ##
# replace missing air pressure values with values from nearby station
df$luchtdruk_k13_k14[(df$week_index == 128)] <- 1013.1857
df$luchtdruk_k13_k14[(df$week_index == 129)] <- 1015.9572
df$luchtdruk_k13_k14[(df$week_index == 130)] <- 1021.2286
df$luchtdruk_k13_k14[(df$week_index == 131)] <- 1020.0714

###############

length(unique(df$week_index))
length(unique(df$Diesel))


# # If you want to take fuel price as a binary variable include the following 3 lines of
hist(df$Diesel,breaks=80,xlim=c(1.1,1.5),xlab="Diesel prices",main="", col=c("#0099FF"))  # Take cutoff price of 1.3 for binary outcome
#df$Diesel = as.numeric(df$Diesel >median(df$Diesel))
df$Diesel = -df$Diesel
#table(df$Diesel)


df$DieselD = as.numeric(df$Diesel >median(df$Diesel))

sX=c("windnoord","windwest","windsnelheid","temp","golfhoogte","luchtdruk_k13_k14")

sTreat <- "Diesel"

streatX = c(sTreat,sX)
# Effects on shares of fish category landed
panel_share5 <- plm(as.formula(paste("perc_sol5 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share4 <- plm(as.formula(paste("perc_sol4 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share3 <- plm(as.formula(paste("perc_sol3 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share2 <- plm(as.formula(paste("perc_sol2 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share1 <- plm(as.formula(paste("perc_sol1 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_land_tot <- plm(as.formula(paste("kg_totaal ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
coef_test(panel_share5, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
coef_test(panel_share4, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
coef_test(panel_share3, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
coef_test(panel_share2, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
coef_test(panel_share1, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
coef_test(panel_land_tot, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]

streatX = c(sTreat)
panel_share5 <- plm(as.formula(paste("perc_sol5 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share4 <- plm(as.formula(paste("perc_sol4 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share3 <- plm(as.formula(paste("perc_sol3 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share2 <- plm(as.formula(paste("perc_sol2 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share1 <- plm(as.formula(paste("perc_sol1 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
res5 = coef_test(panel_share5, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
res4 = coef_test(panel_share4, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
res3 = coef_test(panel_share3, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
res2 = coef_test(panel_share2, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
res1 = coef_test(panel_share1, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]




res = rbind(res5,res4,res3,res2,res1)
res_df = as.data.frame(res[,1:2])


## The following lines are to build LaTeX table
summary(panel_share5)

tabl = cbind(rbind(res5[1,1],res5[1,2]),rbind(res4[1,1],res4[1,2]),rbind(res3[1,1],res3[1,2]),
             rbind(res2[1,1],res2[1,2]),rbind(res1[1,1],res1[1,2]))  
#### 




streatX = c(sTreat,sX)
panel_share5 <- plm(as.formula(paste("perc_sol5 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share4 <- plm(as.formula(paste("perc_sol4 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share3 <- plm(as.formula(paste("perc_sol3 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share2 <- plm(as.formula(paste("perc_sol2 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share1 <- plm(as.formula(paste("perc_sol1 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
res5 = coef_test(panel_share5, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
res4 = coef_test(panel_share4, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
res3 = coef_test(panel_share3, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
res2 = coef_test(panel_share2, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
res1 = coef_test(panel_share1, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]



## The following lines are to build LaTeX table
tabl5 = coef_test(panel_share5, vcov = "CR1", cluster = "individual", test = "naive-t")
tabl4 = coef_test(panel_share4, vcov = "CR1", cluster = "individual", test = "naive-t")
tabl3 = coef_test(panel_share3, vcov = "CR1", cluster = "individual", test = "naive-t")
tabl2 = coef_test(panel_share2, vcov = "CR1", cluster = "individual", test = "naive-t")
tabl1 = coef_test(panel_share1, vcov = "CR1", cluster = "individual", test = "naive-t")


for (i in 1:(length(sX)+1)) {
  tabl = rbind(tabl, cbind(rbind(tabl5[i,1],tabl5[i,2]),rbind(tabl4[i,1],tabl4[i,2]),rbind(tabl3[i,1],tabl3[i,2]),
                           rbind(tabl2[i,1],tabl2[i,2]),rbind(tabl1[i,1],tabl1[i,2]))  )
}
tablshare =tabl
##

res = rbind(res5,res4,res3,res2,res1)

res_df = rbind(res_df,res[,1:2])
res_df$covar = c(rep("without covariates",5),rep("with covariates",5))
res_df$size =   c("Small", "Medium-Small", "Medium", "Medium-Large", "Large","Small", "Medium-Small", "Medium", "Medium-Large", "Large")
rownames(res_df) <- NULL
colnames(res_df) <-  c("effect", "effect_se", "specification", "size")
res_df = rbind(res_df[1,],res_df[6,],res_df[2,],res_df[7,],res_df[3,],res_df[8,],res_df[4,],res_df[9,],res_df[5,],res_df[10,])
res_df$size <- as.character(res_df$size)
res_df$size <- factor(res_df$size, levels=unique(res_df$size))

####################
## Figure 14a
####################
pd = position_dodge(.2)    ### How much to jitter the points on the plot

print(ggplot(res_df,                ### The data frame to use.
             aes(x     = size,
                 y     = effect,
                 color = specification)) +
        geom_point(shape = 15,
                   size  = 4,
                   position = pd) +
        geom_errorbar(aes(ymin  = effect - 1.96*effect_se,
                          ymax  = effect + 1.96*effect_se),
                      width = 0.2,
                      size  = 1,
                      position = pd) +
        theme_bw() +
        theme(text = element_text(size=20)) +
        theme(legend.title = element_blank()) +
        theme(legend.position = c(0.85, 0.08)) +
        theme(legend.background = element_rect(fill="white",
                                               size=0.5, linetype="solid", 
                                               colour ="black")) +
        scale_color_grey() +
        geom_hline(yintercept=0, linetype="dotted") +
        ylab("Change in share") +
        xlab("Size category"))
ggsave("D:\\Dropbox\\Fishing\\TeX file\\eff_shareFUEL.png", width = 9.5, height = 6.5)   ## Figure 14a


##############################################
### EFFECTS ON SOLE WEIGHT - poisson model ###
##############################################

panel_land_tot = fepois(kg_totaal ~ Diesel   | vaartuig, df)
panel_land5 = fepois(verkoop_sol_levend_5 ~ Diesel  | vaartuig, df)
panel_land4 = fepois(verkoop_sol_levend_4 ~ Diesel   | vaartuig, df)
panel_land3 = fepois(verkoop_sol_levend_3 ~ Diesel   | vaartuig, df)
panel_land2 = fepois(verkoop_sol_levend_2 ~ Diesel   | vaartuig, df)
panel_land1 = fepois(verkoop_sol_levend_1 ~ Diesel   | vaartuig, df)
print(panel_land_tot) 
print(panel_land5) 
print(panel_land4) 
print(panel_land3) 
print(panel_land2)
print(panel_land1) 



res = cbind(c(summary(panel_land_tot)$coefficients,summary(panel_land5)$coefficients,summary(panel_land4)$coefficients,summary(panel_land3)$coefficients,summary(panel_land2)$coefficients,summary(panel_land1)$coefficients),c(summary(panel_land_tot)$se[1],summary(panel_land5)$se[1],summary(panel_land4)$se[1],summary(panel_land3)$se[1],summary(panel_land2)$se[1],summary(panel_land1)$se[1]))
res_df = as.data.frame(res)


panel_land_tot = fepois(kg_totaal ~ Diesel +    windnoord  +  windwest  +  windsnelheid +  temp    + golfhoogte  +  luchtdruk_k13_k14   | vaartuig, df)
panel_land5 = fepois(verkoop_sol_levend_5 ~ Diesel +   windnoord  +  windwest  +   windsnelheid +  temp   + golfhoogte  +  luchtdruk_k13_k14  | vaartuig, df)
panel_land4 = fepois(verkoop_sol_levend_4 ~ Diesel +   windnoord  +  windwest  +   windsnelheid +  temp   + golfhoogte  +  luchtdruk_k13_k14   | vaartuig, df)
panel_land3 = fepois(verkoop_sol_levend_3 ~ Diesel +   windnoord  +  windwest  +   windsnelheid +  temp   + golfhoogte +  luchtdruk_k13_k14   | vaartuig, df)
panel_land2 = fepois(verkoop_sol_levend_2 ~ Diesel +   windnoord  +  windwest  +   windsnelheid +  temp    + golfhoogte  +  luchtdruk_k13_k14   | vaartuig, df)
panel_land1 = fepois(verkoop_sol_levend_1 ~ Diesel +   windnoord  +  windwest  +   windsnelheid +  temp    + golfhoogte  +  luchtdruk_k13_k14   | vaartuig, df)
print(panel_land_tot) 
print(panel_land5) 
print(panel_land4) 
print(panel_land3) 
print(panel_land2) 
print(panel_land1)



res = cbind(c(summary(panel_land_tot)$coefficients[1],summary(panel_land5)$coefficients[1],summary(panel_land4)$coefficients[1],summary(panel_land3)$coefficients[1],summary(panel_land2)$coefficients[1],summary(panel_land1)$coefficients[1]),c(summary(panel_land_tot)$se[1],summary(panel_land5)$se[1],summary(panel_land4)$se[1],summary(panel_land3)$se[1],summary(panel_land2)$se[1],summary(panel_land1)$se[1]))
res_df = rbind(res_df,res) 

res_df$covar = c(rep("without covariates",6),rep("with covariates",6))
res_df$size =   c("All","Small", "Medium-Small", "Medium", "Medium-Large", "Large","All","Small", "Medium-Small", "Medium", "Medium-Large", "Large")
rownames(res_df) <- NULL
colnames(res_df) <-  c("effect", "effect_se", "specification", "size")
res_df = rbind(res_df[1,],res_df[7,],res_df[2,],res_df[8,],res_df[3,],res_df[9,],res_df[4,],res_df[10,],res_df[5,],res_df[11,],res_df[6,],res_df[12,])
res_df$size <- as.character(res_df$size)
res_df$size <- factor(res_df$size, levels=unique(res_df$size))

####################
## Figure 14b
####################
pd = position_dodge(.2)    ### How much to jitter the points on the plot

print(ggplot(res_df,               
             aes(x     = size,
                 y     = effect,
                 color = specification)) +
        geom_point(shape = 15,
                   size  = 4,
                   position = pd) +
        geom_errorbar(aes(ymin  = effect - 1.96*effect_se,
                          ymax  = effect + 1.96*effect_se),
                      width = 0.2,
                      size  = 1,
                      position = pd) +
        theme_bw() +
        theme(text = element_text(size=20)) +
        theme(legend.title = element_blank()) +
        theme(legend.position = c(0.85, 0.08)) +
        theme(legend.background = element_rect(fill="white",
                                               size=0.5, linetype="solid", 
                                               colour ="black")) +
        scale_color_grey() +
        geom_hline(yintercept=0, linetype="dotted") +
        ylab("Approx. % change in weight (kg)") +
        xlab("Size category"))
ggsave("D:\\Dropbox\\Fishing\\TeX file\\eff_weightPO_FUEL.png", width = 9.5, height = 6.5)  ## Figure 14b


# ##############################################
# # Effects on length of fishing trip
# ###############################################
#
#
#

sX=c("windnoord","windwest","windsnelheid","temp","golfhoogte","luchtdruk_k13_k14")
sTreat <- "Diesel"
streatX = c(sTreat)
panel_length1 <- plm(as.formula(paste("length_trip_hr ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
streatX = c(sTreat,sX)
panel_length2 <- plm(as.formula(paste("length_trip_hr ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
coef_test(panel_length1, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
coef_test(panel_length2, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]  # Note that there are effects on trip length, but these can not be directly compared due to selection of vessels as seen in probability estimates which follow

mean(df$length_trip_hr)



##############################################
# Effects on probability of vessel out at sea
###############################################

## In the following code we add 0 entries for weeks in which vessels did not go out at sea ##
dfp <- read.csv( "D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Stephen files\\Data_final_1719_newProb.csv")  # this file already made the selection of weeks for sample
#dfp <- read.csv( "D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Stephen files\\Data_final_1719_newProb_corr.csv")  # this file already made the selection of weeks for sample
dfp = dfp[,-1]

length(unique(dfp$week_index))

#Dropping weeks in which coast guard was not patrolling
NT_week = c( 1,10, 11, 17,21,22, 27,28, 29, 30, 31, 32, 33, 42,50, 52, 53,58,59, 61,62,70,73,74, 82,83, 84, 85, 86, 87, 94, 96, 97,104,105, 114,115, 116, 124, 125, 128,  131,132, 133, 134, 135, 136, 137, 140, 141, 146,147, 148 , 149, 153, 155,156 )  # Non-Treated weeks (no patrolling)
nrow(df)
dfp = filter(dfp, !(dfp$week_index %in% NT_week))
nrow(dfp)

# Dropping Christmas weeks which skews analysis of probability of fishing
# -> fishing vessels and coast guard are almost all on vacation which means these are not comparable weeks to adjacent patrolling weeks
nrow(dfp)
dfp = filter(dfp, !(dfp$week_index %in% c(52,104,156)))  # drop Christmas weeks and their comparisons when relevant
nrow(dfp)
table(dfp$week_index)




dfp$fished_sol1 = as.numeric(dfp$kg_totaal>50)
table(dfp$fished_sol1)

sX=c("windnoord","windwest","windsnelheid","temp","golfhoogte","luchtdruk_k13_k14","Diesel")

## Impute value for missing values in "luchtdruk_k13_k14" ##
# replace missing air pressure values with values from nearby station
df$luchtdruk_k13_k14[(df$week_index == 128)] <- 1013.1857
df$luchtdruk_k13_k14[(df$week_index == 129)] <- 1015.9572
df$luchtdruk_k13_k14[(df$week_index == 130)] <- 1021.2286
df$luchtdruk_k13_k14[(df$week_index == 131)] <- 1020.0714



sum(dfp$treat*dfp$fished_sol1)/sum(dfp$treat) - sum((1-dfp$treat)*dfp$fished_sol1)/sum(1-dfp$treat) # Difference in means of probability of fishing

sum(dfp$treat*dfp$fished_sol1)*length(unique(dfp$vaartuig)) /sum(dfp$treat)
sum((1-dfp$treat)*dfp$fished_sol1)*length(unique(dfp$vaartuig))/sum(1-dfp$treat)
length(unique(dfp$vaartuig))
table(dfp$treat)

dfp$Diesel = -dfp$Diesel

sTreat <- "Diesel"
streatX = c(sTreat)
panel_fished_sol1 <- plm(as.formula(paste("fished_sol1 ~ ", paste(streatX, collapse= "+"))), data = dfp,index = c("vaartuig"), model = "within")
streatX = c(sTreat,sX)
panel_fished_sol2 <- plm(as.formula(paste("fished_sol1 ~ ", paste(streatX, collapse= "+"))), data = dfp,index = c("vaartuig"), model = "within")
coef_test(panel_fished_sol1, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
coef_test(panel_fished_sol2, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
summary(panel_fished_sol2)
















###########################################################################################################
###########################################################################################################
###    SAME ANALYSIS ON PLAICE
###########################################################################################################
###########################################################################################################







df <- read.csv( "D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Stephen files\\Data_final_1719_new.csv")
#df <- read.csv( "D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Stephen files\\Data_final_1719_corr.csv")
df = df[,-1]
## Selection and scaling on dependent variables ##
#################################################

# Redefine total kg landed to exclude below minimum size fish
df$kg_totaal = df$verkoop_sol_levend_1 + df$verkoop_sol_levend_2 + df$verkoop_sol_levend_3 + df$verkoop_sol_levend_4 + df$verkoop_sol_levend_5 
df$kg_totaal_ple = df$verkoop_ple_levend_1 + df$verkoop_ple_levend_2 + df$verkoop_ple_levend_3 + df$verkoop_ple_levend_4  



# Define lower baseline to not have results overly influenced by changes close to 0
# Generate shares of fish sizes. For small total landings keep shares equal (reduces influence of changes close to 0)



low_landing = 50   # set equal shares and lower bound quantities if total kg landed is below low_share
df$perc_ple4 = df$verkoop_ple_levend_4/df$kg_totaal_ple
df$perc_ple4[is.na(df$perc_ple4)] <- 0
df$perc_ple4[df$kg_totaal_ple<=low_landing] <- 0.25
df$perc_ple3 = df$verkoop_ple_levend_3/df$kg_totaal_ple
df$perc_ple3[is.na(df$perc_ple3)] <- 0
df$perc_ple3[df$kg_totaal_ple<=low_landing] <- 0.25
df$perc_ple2 = df$verkoop_ple_levend_2/df$kg_totaal_ple
df$perc_ple2[is.na(df$perc_ple2)] <- 0
df$perc_ple2[df$kg_totaal_ple<=low_landing] <- 0.25
df$perc_ple1 = df$verkoop_ple_levend_1/df$kg_totaal_ple
df$perc_ple1[is.na(df$perc_ple1)] <- 0
df$perc_ple1[df$kg_totaal_ple<=low_landing] <- 0.25








# Define length of fishing trip
df$vertrek = as.Date(df$vertrek,format="%Y-%m-%d")
df$terugkeer = as.Date(df$terugkeer,format="%Y-%m-%d")

df$length_trip = (as.numeric(df$terugkeer)-as.numeric(df$vertrek))+1
table(df$length_trip)
hist(df$length_trip,breaks=10,xlim=c(0,16),xlab="Trip length",main="", col=c("#0099FF"))
df$log_length_trip = log(df$length_trip)

table(df$length_trip)   # distribution of trip length
sum(as.numeric(df$length_trip<7))/nrow(df) # fraction of trips 6 days or under
table(df$day_dep)       # distribution of departure day
(sum(as.numeric(df$day_dep=="Monday"))+ sum(as.numeric(df$day_dep=="Sunday")))/nrow(df) # share of trips departing Sunday or Monday
table(df$day_return)    # distribution of return day
(sum(as.numeric(df$day_return=="Friday"))+ sum(as.numeric(df$day_dep=="Thursday")))/nrow(df) # share of trips departing Sunday or Monday


# Define dummy for whether vessel fished in a given week
df$fished_sol1 = as.numeric(df$kg_totaal_ple>low_landing)

# Generate higher order polynomials
df$golfhoogtesq = df$golfhoogte^2
df$golfhoogtecb = df$golfhoogte^3
df$windnoordsq = df$windnoord^2
df$windnoordcb = df$windnoord^3
df$windzuidsq = df$windzuid^2
df$windzuidcb = df$windzuid^3
df$windwestsq = df$windwest^2
df$windwestcb = df$windwest^3
df$windoostsq = df$windoost^2
df$windoostcb = df$windoost^3
df$windsnelheidsq = df$windsnelheid^2
df$windsnelheidcb = df$windsnelheid^3
df$tempsq = df$temp^2
df$tempcb = df$temp^3
df$maxdaggolfhoogtesq = df$maxdaggolfhoogte^2
df$maxdaggolfhoogtecb = df$maxdaggolfhoogte^3
df$luchtdruk_k13_k14sq = df$luchtdruk_k13_k14^2
df$luchtdruk_k13_k14cb = df$luchtdruk_k13_k14^3
df$BenzineEuro95sq = df$BenzineEuro95^2
df$BenzineEuro95cb = df$BenzineEuro95^3
df$Dieselsq = df$Diesel^2
df$Dieselcb = df$Diesel^3
df$Diesel4 = df$Diesel^4

df$length_tripsq = df$length_trip^2
df$length_tripcb = df$length_trip^3



dfa = df
## Defining treatment and restricting analysis sample ##
########################################################



# Below are all full weeks during which BB was not patrolling
# 2017: 1 10 11 17 21 22 27 28 29 30 31 32 33 42 50 52 
# 2018: 53 58 59 61 62 70 73 74 82 83 84 85 86 87 94 96 97 104
# 2019: 105 114 115 116 124 125 128 131 132 133 134 135 136 137 140 141 146 147 148 149 153 155 156

NT_week = c( 1,10, 11, 17,21,22, 27,28, 29, 30, 31, 32, 33, 42,50, 52, 53,58,59, 61,62,70,73,74, 82,83, 84, 85, 86, 87, 94, 96, 97,104,105, 114,115, 116, 124, 125, 128,  131,132, 133, 134, 135, 136, 137, 140, 141, 146,147, 148 , 149, 153, 155,156 )  # Non-Treated weeks (no patrolling)
All = seq(1,156)
T_week = All[!(All  %in% NT_week)] # Treated weeks (patrolling)
mAnalysis_weeks = rbind(cbind(NT_week,0),cbind(T_week,1))
mA_w = mAnalysis_weeks[order(mAnalysis_weeks[,1]),2]

analysis_weeks = 1
for (i in seq(2,155)) {
  analysis_weeks = cbind(analysis_weeks,i*as.numeric(mA_w[i] != mA_w[(i-1)]) + i*as.numeric(mA_w[i] != mA_w[(i+1)])* (1-as.numeric(mA_w[i] != mA_w[(i-1)])*as.numeric(mA_w[i] != mA_w[(i+1)])))
}
analysis_weeks
analysis_weeks = analysis_weeks[analysis_weeks!=0]  # Weeks to be included in sample
analysis_weeks
All[!(All  %in% analysis_weeks)]    # Weeks to be excluded from sample

# Plot number of vessels at sea for each week
df_weekly = filter(df, (df$week_index==1))
vessels_by_week = c(length(unique(df_weekly$vaartuig)),1)
for (i in seq(2,156)) {
  df_weekly = filter(df, (df$week_index==i))
  vessels_by_week = rbind(vessels_by_week,c(length(unique(df_weekly$vaartuig)),i))
}

# Plot number of vessels at sea for each week
plot(x=vessels_by_week[,2], y=vessels_by_week[,1])




# Keep only relevant adjacant weeks
nrow(df)
df = filter(df, (df$week_index %in% analysis_weeks))
nrow(df)
table(df$week_index)

# Plot number of vessels at sea for each week
vessels_by_week =vessels_by_week[(vessels_by_week[,2] %in% analysis_weeks),]
plot(x=vessels_by_week[,2], y=vessels_by_week[,1])

# Given the resulting dataset, these will be the weeks with no treatment (BB not deployed)
NT_week = c( 1,10, 11, 17,21,22, 27, 33, 42,50, 52, 53,58,59, 61,62,70,73,74, 82, 87, 94, 96, 97,104,105, 114, 116, 124, 125, 128,  131, 137, 140, 141, 146, 149, 153, 155 )
df$treat = 1-as.numeric(df$week_index %in% NT_week)


# Dropping Christmas weeks which skews analysis of probability of fishing 
# -> fishing vessels and coast guard are almost all on vacation which means these are not comparable weeks to adjacent patrolling weeks
nrow(df)
df = filter(df, !(df$week_index %in% c(52,103,104)))  # drop Christmas weeks and their comparisons when relevant
nrow(df)
table(df$week_index)


table(df$treat) # Number of treated vs non-treated
sum(as.numeric(df$length_trip <8))/nrow(df)   # fraction of trips lasting less than 7 days
sum(as.numeric(df$day_dep == "Monday") * as.numeric(df$day_return == "Thursday") + as.numeric(df$day_dep == "Sunday") * as.numeric(df$day_return == "Thursday") +
      as.numeric(df$day_dep == "Monday") * as.numeric(df$day_return == "Friday") + as.numeric(df$day_dep == "Sunday") * as.numeric(df$day_return == "Friday"))/nrow(df)  
# Fraction of trips within usual Sunday night / Monday morning to Thursday night/Friday 

nrow(df)


length(unique(df$vaartuig)) 
table(df$vaartuig)



##############################################
### Balancing table
##############################################

# sX=c("windnoord","windzuid","windwest","windoost","windsnelheid","temp","golfhoogte","luchtdruk_k13_k14","Diesel")
# sTreat <- "treat"
# streatX = c(sTreat,sX)
# 
# 
# library("tidyverse")
# library("vtable")
# sumtable(df[,streatX], group = "treat", add.median=TRUE, group.test = TRUE)
# sumtable(df[,c("verkoop_ple_levend_7","verkoop_ple_levend_5","verkoop_ple_levend_4","verkoop_ple_levend_3","verkoop_ple_levend_2","verkoop_ple_levend_1","perc_ple5","perc_ple4","perc_ple3","perc_ple2","perc_ple1", streatX)], group = "treat",add.median=TRUE, group.test = TRUE)
# 





# Effects on shares of fish category landed
sX=c("windnoord","windwest","windsnelheid","temp","golfhoogte","luchtdruk_k13_k14","Diesel")

# Most balanced specification is one with algorithm imputed values on NA and using
# covariates without higher order values sX=c("windnoord","windwest","windsnelheid","temp","golfhoogte","luchtdruk_k13_k14","Diesel")

############
## Impute value for missing values in "luchtdruk_k13_k14" ##
# replace missing air pressure values with values from nearby station
df$luchtdruk_k13_k14[(df$week_index == 128)] <- 1013.1857
df$luchtdruk_k13_k14[(df$week_index == 129)] <- 1015.9572
df$luchtdruk_k13_k14[(df$week_index == 130)] <- 1021.2286
df$luchtdruk_k13_k14[(df$week_index == 131)] <- 1020.0714

dfb = df





### Shares of different plaice depending on treatment/non-treatment weeks
sum(df$treat*df$perc_ple4)/sum(df$treat)
sum(df$treat*df$perc_ple3)/sum(df$treat)
sum(df$treat*df$perc_ple2)/sum(df$treat)
sum(df$treat*df$perc_ple1)/sum(df$treat)


sum((1-df$treat)*df$perc_ple4)/sum(1-df$treat)
sum((1-df$treat)*df$perc_ple3)/sum(1-df$treat)
sum((1-df$treat)*df$perc_ple2)/sum(1-df$treat)
sum((1-df$treat)*df$perc_ple1)/sum(1-df$treat)



sTreat <- "treat"


##############################################
### EFFECTS ON PLAICE SHARES  ####
##############################################

streatX = c(sTreat)

panel_share4 <- plm(as.formula(paste("perc_ple4 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share3 <- plm(as.formula(paste("perc_ple3 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share2 <- plm(as.formula(paste("perc_ple2 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share1 <- plm(as.formula(paste("perc_ple1 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
res4 = coef_test(panel_share4, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
res3 = coef_test(panel_share3, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
res2 = coef_test(panel_share2, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
res1 = coef_test(panel_share1, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]

res = rbind(res4,res3,res2,res1)
res_df = as.data.frame(res[,1:2])


streatX = c(sTreat,sX)
panel_share4 <- plm(as.formula(paste("perc_ple4 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share3 <- plm(as.formula(paste("perc_ple3 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share2 <- plm(as.formula(paste("perc_ple2 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share1 <- plm(as.formula(paste("perc_ple1 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
res4 = coef_test(panel_share4, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
res3 = coef_test(panel_share3, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
res2 = coef_test(panel_share2, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
res1 = coef_test(panel_share1, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]

res = rbind(res4,res3,res2,res1)

res_df = rbind(res_df,res[,1:2])
res_df$covar = c(rep("without covariates",4),rep("with covariates",4))
res_df$size =   c("Medium-Small", "Medium", "Medium-Large", "Large","Medium-Small", "Medium", "Medium-Large", "Large")
rownames(res_df) <- NULL
colnames(res_df) <-  c("effect", "effect_se", "specification", "size")
res_df = rbind(res_df[1,],res_df[5,],res_df[2,],res_df[6,],res_df[3,],res_df[7,],res_df[4,],res_df[8,])
res_df$size <- as.character(res_df$size)
res_df$size <- factor(res_df$size, levels=unique(res_df$size))

####################
## Figure 12a
####################
pd = position_dodge(.2)    ### How much to jitter the points on the plot

print(ggplot(res_df,                ### The data frame to use.
             aes(x     = size,
                 y     = effect,
                 color = specification)) +
        geom_point(shape = 15,
                   size  = 4,
                   position = pd) +
        geom_errorbar(aes(ymin  = effect - 1.96*effect_se,
                          ymax  = effect + 1.96*effect_se),
                      width = 0.2,
                      size  = 1,
                      position = pd) +
        theme_bw() +
        theme(text = element_text(size=20)) +
        theme(legend.title = element_blank()) +
        theme(legend.position = c(0.85, 0.92)) +
        theme(legend.background = element_rect(fill="white",
                                               size=0.5, linetype="solid", 
                                               colour ="black")) +
        scale_color_grey() +
        geom_hline(yintercept=0, linetype="dotted") +
        ylab("Change in share") +
        xlab("Size category"))
ggsave("D:\\Dropbox\\Fishing\\TeX file\\Peff_share.png", width = 9.5, height = 6.5)



##############################################
### EFFECTS ON PLAICE WEIGHT (kg)  ####
##############################################

streatX = c(sTreat)
panel_land4 <- plm(as.formula(paste("verkoop_ple_levend_4 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_land3 <- plm(as.formula(paste("verkoop_ple_levend_3 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_land2 <- plm(as.formula(paste("verkoop_ple_levend_2 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_land1 <- plm(as.formula(paste("verkoop_ple_levend_1 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_land_tot <- plm(as.formula(paste("kg_totaal_ple ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
res4 = coef_test(panel_land4, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
res3 = coef_test(panel_land3, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
res2 = coef_test(panel_land2, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
res1 = coef_test(panel_land1, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
resAll = coef_test(panel_land_tot, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]

res = rbind(resAll,res4,res3,res2,res1)
res_df = as.data.frame(res[,1:2])


streatX = c(sTreat,sX)
panel_land4 <- plm(as.formula(paste("verkoop_ple_levend_4 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_land3 <- plm(as.formula(paste("verkoop_ple_levend_3 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_land2 <- plm(as.formula(paste("verkoop_ple_levend_2 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_land1 <- plm(as.formula(paste("verkoop_ple_levend_1 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_land_tot <- plm(as.formula(paste("kg_totaal_ple ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
res4 = coef_test(panel_land4, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
res3 = coef_test(panel_land3, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
res2 = coef_test(panel_land2, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
res1 = coef_test(panel_land1, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
resAll = coef_test(panel_land_tot, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]


res = rbind(resAll,res4,res3,res2,res1)

res_df = rbind(res_df,res[,1:2])
res_df$covar = c(rep("without covariates",5),rep("with covariates",5))
res_df$size =   c("All", "Medium-Small", "Medium", "Medium-Large", "Large","All","Medium-Small", "Medium", "Medium-Large", "Large")
rownames(res_df) <- NULL
colnames(res_df) <-  c("effect", "effect_se", "specification", "size")
res_df = rbind(res_df[1,],res_df[6,],res_df[2,],res_df[7,],res_df[3,],res_df[8,],res_df[4,],res_df[9,],res_df[5,],res_df[10,])
res_df$size <- as.character(res_df$size)
res_df$size <- factor(res_df$size, levels=unique(res_df$size))


pd = position_dodge(.2)    ### How much to jitter the points on the plot

print(ggplot(res_df,                ### The data frame to use.
             aes(x     = size,
                 y     = effect,
                 color = specification)) +
        geom_point(shape = 15,
                   size  = 4,
                   position = pd) +
        geom_errorbar(aes(ymin  = effect - 1.96*effect_se,
                          ymax  = effect + 1.96*effect_se),
                      width = 0.2,
                      size  = 1,
                      position = pd) +
        theme_bw() +
        theme(text = element_text(size=20)) +
        theme(legend.title = element_blank()) +
        theme(legend.position = c(0.85, 0.08)) +
        theme(legend.background = element_rect(fill="white",
                                               size=0.5, linetype="solid", 
                                               colour ="black")) +
        scale_color_grey() +
        geom_hline(yintercept=0, linetype="dotted") +
        ylab("Change in weight (kg)") +
        xlab("Size category"))



##############################################
### EFFECTS ON PLAICE WEIGHT - poisson model ###
##############################################

panel_land_tot = fepois(kg_totaal_ple ~ treat   | vaartuig, df)
panel_land4 = fepois(verkoop_ple_levend_4 ~ treat   | vaartuig, df)
panel_land3 = fepois(verkoop_ple_levend_3 ~ treat   | vaartuig, df)
panel_land2 = fepois(verkoop_ple_levend_2 ~ treat   | vaartuig, df)
panel_land1 = fepois(verkoop_ple_levend_1 ~ treat   | vaartuig, df)
print(panel_land_tot) 
print(panel_land4) 
print(panel_land3) 
print(panel_land2)
print(panel_land1) 



res = cbind(c(summary(panel_land_tot)$coefficients,summary(panel_land4)$coefficients,summary(panel_land3)$coefficients,summary(panel_land2)$coefficients,summary(panel_land1)$coefficients),c(summary(panel_land_tot)$se[1],summary(panel_land4)$se[1],summary(panel_land3)$se[1],summary(panel_land2)$se[1],summary(panel_land1)$se[1]))
res_df = as.data.frame(res)


panel_land_tot = fepois(kg_totaal_ple ~ treat +    windnoord  +  windwest  +  windsnelheid +  temp    + golfhoogte  +  luchtdruk_k13_k14 + Diesel  | vaartuig, df)
panel_land4 = fepois(verkoop_ple_levend_4 ~ treat +   windnoord  +  windwest  +   windsnelheid +  temp   + golfhoogte  +  luchtdruk_k13_k14 + Diesel  | vaartuig, df)
panel_land3 = fepois(verkoop_ple_levend_3 ~ treat +   windnoord  +  windwest  +   windsnelheid +  temp   + golfhoogte +  luchtdruk_k13_k14 + Diesel  | vaartuig, df)
panel_land2 = fepois(verkoop_ple_levend_2 ~ treat +   windnoord  +  windwest  +   windsnelheid +  temp    + golfhoogte  +  luchtdruk_k13_k14 + Diesel  | vaartuig, df)
panel_land1 = fepois(verkoop_ple_levend_1 ~ treat +   windnoord  +  windwest  +   windsnelheid +  temp    + golfhoogte  +  luchtdruk_k13_k14 + Diesel  | vaartuig, df)
print(panel_land_tot) 
print(panel_land4) 
print(panel_land3) 
print(panel_land2) 
print(panel_land1)


res = cbind(c(summary(panel_land_tot)$coefficients[1],summary(panel_land4)$coefficients[1],summary(panel_land3)$coefficients[1],summary(panel_land2)$coefficients[1],summary(panel_land1)$coefficients[1]),c(summary(panel_land_tot)$se[1],summary(panel_land4)$se[1],summary(panel_land3)$se[1],summary(panel_land2)$se[1],summary(panel_land1)$se[1]))
res_df = rbind(res_df,res) 

res_df$covar = c(rep("without covariates",5),rep("with covariates",5))
res_df$size =   c("All", "Medium-Small", "Medium", "Medium-Large", "Large","All","Medium-Small", "Medium", "Medium-Large", "Large")
rownames(res_df) <- NULL
colnames(res_df) <-  c("effect", "effect_se", "specification", "size")
res_df = rbind(res_df[1,],res_df[6,],res_df[2,],res_df[7,],res_df[3,],res_df[8,],res_df[4,],res_df[9,],res_df[5,],res_df[10,])
res_df$size <- as.character(res_df$size)
res_df$size <- factor(res_df$size, levels=unique(res_df$size))

####################
## Figure 12b
####################
pd = position_dodge(.2)    ### How much to jitter the points on the plot

print(ggplot(res_df,               
             aes(x     = size,
                 y     = effect,
                 color = specification)) +
        geom_point(shape = 15,
                   size  = 4,
                   position = pd) +
        geom_errorbar(aes(ymin  = effect - 1.96*effect_se,
                          ymax  = effect + 1.96*effect_se),
                      width = 0.2,
                      size  = 1,
                      position = pd) +
        theme_bw() +
        theme(text = element_text(size=20)) +
        theme(legend.title = element_blank()) +
        theme(legend.position = c(0.85, 0.92)) +
        theme(legend.background = element_rect(fill="white",
                                               size=0.5, linetype="solid", 
                                               colour ="black")) +
        scale_color_grey() +
        geom_hline(yintercept=0, linetype="dotted") +
        ylab("Approx. % change in weight (kg)") +
        xlab("Size category"))
ggsave("D:\\Dropbox\\Fishing\\TeX file\\Peff_weightPO.png", width = 9.5, height = 6.5)







#########################################################################################################
## WEEKEND EFFECTS ##
#########################################################################################################



df = dfa

# We assume that there is never any patrolling between Friday and Sunday to construct treatment variable
#  df$frac_wd is fraction of days over total days at sea that vessel was at sea on friday, Saturday, or Sunday
df$frac_wd =   (1/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Monday")*(df$length_trip==5) + (2/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Monday")*(df$length_trip==6) +  (3/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Monday")*(df$length_trip>6)*(df$length_trip <= 11) + (4/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Monday")*(df$length_trip == 12) + (5/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Monday")*(df$length_trip == 13) + (6/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Monday")*(df$length_trip == 14) +
  (1/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Tuesday")*(df$length_trip==4) + (2/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Tuesday")*(df$length_trip==5) +  (3/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Tuesday")*(df$length_trip>5)*(df$length_trip <= 10) + (4/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Tuesday")*(df$length_trip == 11) + (5/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Tuesday")*(df$length_trip == 12) + (6/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Tuesday")*(df$length_trip >= 13) +
  (1/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Wednesday")*(df$length_trip==3) + (2/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Wednesday")*(df$length_trip==4) + (3/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Wednesday")*(df$length_trip>4)*(df$length_trip <= 9) + (4/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Wednesday")*(df$length_trip == 10) + (5/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Wednesday")*(df$length_trip == 11) + (6/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Wednesday")*(df$length_trip >= 12) +
  (1/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Thursday")*(df$length_trip==2) + (2/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Thursday")*(df$length_trip==3) +   (3/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Thursday")*(df$length_trip>3)*(df$length_trip <= 8) + (4/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Thursday")*(df$length_trip == 9) + (5/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Thursday")*(df$length_trip == 10) + (6/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Thursday")*(df$length_trip >= 11) +
  (weekdays(as.Date(df$vertrek))=="Friday")*(df$length_trip<4) + (3/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Friday")*(df$length_trip>=4)*(df$length_trip<=7) + (4/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Friday")*(df$length_trip==8)  + (5/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Friday")*(df$length_trip ==9) + (6/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Friday")*(df$length_trip >= 10) +
  (weekdays(as.Date(df$vertrek))=="Saturday")*(df$length_trip<3) + (2/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Saturday")*(df$length_trip>=3)*(df$length_trip<=6) + (3/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Saturday")*(df$length_trip==7)  + (4/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Saturday")*(df$length_trip ==8) + (5/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Saturday")*(df$length_trip >= 9)*(df$length_trip <= 13) + (6/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Saturday")*(df$length_trip == 14) +
  (weekdays(as.Date(df$vertrek))=="Sunday")*(df$length_trip == 1) + (1/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Sunday")*(df$length_trip>=2)*(df$length_trip<=5) + (2/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Sunday")*(df$length_trip==6)  + (3/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Sunday")*(df$length_trip ==7) + (4/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Sunday")*(df$length_trip >= 8)*(df$length_trip <= 12)  + (5/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Sunday")*(df$length_trip == 13) + (6/df$length_trip)*(weekdays(as.Date(df$vertrek))=="Sunday")*(df$length_trip ==14) 


table(df$frac_wd) 
table(df$length_trip)  # check return days

frac =  0.5
df$treat_we = as.numeric(df$frac_wd < frac) # Treated if fraction of weekend days fishing is below frac (this allows for vessels leaving on sunday night and returning Friday morning to be counted as during the week trips)
table(df$treat_we)                
nrow(df)
df = filter(df, ((df$frac_wd > 0.334)*(df$frac_wd <frac ) !=1)) # df$frac_wd > 0.334 allows for vessels leaving on sunday night and returning Friday morning to be counted as during the week trips)



##Difference in difference to remove confounding effect due to supply restrictions ###

# Weeks in which BB was not patrolling
# 2017: 1 10 11 17 21 22 27 28 29 30 31 32 33 42 50 52
# 2018: 53 58 59 61 62 70 73 74 82 83 84 85 86 87 94 96 97 104
# 2019: 105 114 115 116 124 125 128 131 132 133 134 135 136 137 140 141 146 147 148 149 153 155 156
noBB_weeks = c(1, 10, 11, 17, 21, 22, 27, 28, 29, 30, 31, 32, 33, 42, 50, 52,53, 58, 59, 61, 62, 70, 73, 74, 82, 83, 84, 85, 86, 87, 94, 96, 97, 104,105, 114, 115, 116, 124, 125, 128, 131, 132, 133, 134, 135, 136, 137, 140, 141, 146, 147, 148, 149, 153, 155, 156)

df$off_week = matrix(0,nrow(df),1)
for (i in 1:nrow(df)) {
  for (j in 1:length(noBB_weeks)) {
    if (df$week_index[i] == noBB_weeks[j]) {
      df$off_week[i] = 1
    }
  }
}

# Dropping Christmas weeks which skews analysis of probability of fishing 
# -> fishing vessels and coast guard are almost all on vacation which means these are not comparable weeks to adjacent patrolling weeks
nrow(df)
df = filter(df, !(df$week_index %in% c(52,104,156)))  # drop Christmas weeks and their comparisons when relevant
nrow(df)
table(df$week_index)

# Construct weekend effect
df$BB_week = 1-df$off_week  # weeks in which there was patrolling
df$BB_week_treat = df$BB_week * df$treat_we  # weekdays in weeks in which there was patrolling
nrow(df)
table(df$treat_we) 




# Effects on shares of fish category landed
sX=c("windnoord","windwest","windsnelheid","temp","golfhoogte","luchtdruk_k13_k14","Diesel")

# Most balanced specification is one with algorithm imputed values on NA and using
# covariates without higher order values sX=c("windnoord","windwest","windsnelheid","temp","golfhoogte","luchtdruk_k13_k14","Diesel")

############
## Impute value for missing values in "luchtdruk_k13_k14" ##
# replace missing air pressure values with values from nearby station
df$luchtdruk_k13_k14[(df$week_index == 128)] <- 1013.1857
df$luchtdruk_k13_k14[(df$week_index == 129)] <- 1015.9572
df$luchtdruk_k13_k14[(df$week_index == 130)] <- 1021.2286
df$luchtdruk_k13_k14[(df$week_index == 131)] <- 1020.0714


sTreat <- c("treat_we","BB_week_treat")
# B_treat_we = effect of weekdays relative to weekends in non patrolling weeks
# B_BB_week_treat = effect of weekdays vs weekends in weeks in which there is patrolling



##############################################
### EFFECTS ON PLAICE SHARES  ####
##############################################

streatX = c(sTreat,sX)
# Effects on shares of fish category landed

panel_share4 <- plm(as.formula(paste("perc_ple4 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig","week_index"), model = "within", effect = "twoways")
panel_share3 <- plm(as.formula(paste("perc_ple3 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig","week_index"), model = "within", effect = "twoways")
panel_share2 <- plm(as.formula(paste("perc_ple2 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig","week_index"), model = "within", effect = "twoways")
panel_share1 <- plm(as.formula(paste("perc_ple1 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig","week_index"), model = "within", effect = "twoways")
res4 = coef_test(panel_share4, vcov = "CR1", cluster = "individual", test = "naive-t")[2,]
res3 = coef_test(panel_share3, vcov = "CR1", cluster = "individual", test = "naive-t")[2,]
res2 = coef_test(panel_share2, vcov = "CR1", cluster = "individual", test = "naive-t")[2,]
res1 = coef_test(panel_share1, vcov = "CR1", cluster = "individual", test = "naive-t")[2,]

res = rbind(res4,res3,res2,res1)
res_df = as.data.frame(res[,1:2])


streatX = c(sTreat,sX)
panel_share4 <- plm(as.formula(paste("perc_ple4 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig","week_index"), model = "within", effect = "twoways")
panel_share3 <- plm(as.formula(paste("perc_ple3 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig","week_index"), model = "within", effect = "twoways")
panel_share2 <- plm(as.formula(paste("perc_ple2 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig","week_index"), model = "within", effect = "twoways")
panel_share1 <- plm(as.formula(paste("perc_ple1 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig","week_index"), model = "within", effect = "twoways")
res4 = coef_test(panel_share4, vcov = "CR1", cluster = "individual", test = "naive-t")[2,]
res3 = coef_test(panel_share3, vcov = "CR1", cluster = "individual", test = "naive-t")[2,]
res2 = coef_test(panel_share2, vcov = "CR1", cluster = "individual", test = "naive-t")[2,]
res1 = coef_test(panel_share1, vcov = "CR1", cluster = "individual", test = "naive-t")[2,]



res = rbind(res4,res3,res2,res1)

res_df = rbind(res_df,res[,1:2])
res_df$covar = c(rep("without covariates",4),rep("with covariates",4))
res_df$size =   c("Medium-Small", "Medium", "Medium-Large", "Large","Medium-Small", "Medium", "Medium-Large", "Large")
rownames(res_df) <- NULL
colnames(res_df) <-  c("effect", "effect_se", "specification", "size")
res_df = rbind(res_df[1,],res_df[5,],res_df[2,],res_df[6,],res_df[3,],res_df[7,],res_df[4,],res_df[8,])
res_df$size <- as.character(res_df$size)
res_df$size <- factor(res_df$size, levels=unique(res_df$size))

## Figure 1 ##
pd = position_dodge(.2)    ### How much to jitter the points on the plot

print(ggplot(res_df,                ### The data frame to use.
             aes(x     = size,
                 y     = effect,
                 color = specification)) +
        geom_point(shape = 15,
                   size  = 4,
                   position = pd) +
        geom_errorbar(aes(ymin  = effect - 1.96*effect_se,
                          ymax  = effect + 1.96*effect_se),
                      width = 0.2,
                      size  = 1,
                      position = pd) +
        theme_bw() +
        theme(text = element_text(size=20)) +
        theme(legend.title = element_blank()) +
        theme(legend.position = c(0.85, 0.08)) +
        theme(legend.background = element_rect(fill="white",
                                               size=0.5, linetype="solid", 
                                               colour ="black")) +
        scale_color_grey() +
        geom_hline(yintercept=0, linetype="dotted") +
        ylab("Change in share") +
        xlab("Size category"))



##############################################
### EFFECTS ON PLAICE WEIGHT - poisson model ###
##############################################



panel_land_tot = fepois(kg_totaal_ple ~ treat_we + BB_week_treat   | vaartuig + week_index, df)
panel_land4 = fepois(verkoop_ple_levend_4 ~ treat_we + BB_week_treat   | vaartuig + week_index, df)
panel_land3 = fepois(verkoop_ple_levend_3 ~ treat_we + BB_week_treat   | vaartuig + week_index, df)
panel_land2 = fepois(verkoop_ple_levend_2 ~ treat_we + BB_week_treat   | vaartuig + week_index, df)
panel_land1 = fepois(verkoop_ple_levend_1 ~ treat_we + BB_week_treat   | vaartuig + week_index, df)
print(panel_land_tot) 
print(panel_land4) 
print(panel_land3) 
print(panel_land2)
print(panel_land1) 



res = cbind(c(summary(panel_land_tot)$coefficients[2],summary(panel_land4)$coefficients[2],summary(panel_land3)$coefficients[2],summary(panel_land2)$coefficients[2],summary(panel_land1)$coefficients[2]),c(summary(panel_land_tot)$se[2],summary(panel_land4)$se[2],summary(panel_land3)$se[2],summary(panel_land2)$se[2],summary(panel_land1)$se[2]))
res_df = as.data.frame(res)


panel_land_tot = fepois(kg_totaal_ple ~ treat_we + BB_week_treat +    windnoord  +  windwest  +  windsnelheid +  temp    + golfhoogte  +  luchtdruk_k13_k14 + Diesel  | vaartuig + week_index, df)
panel_land4 = fepois(verkoop_ple_levend_4 ~ treat_we + BB_week_treat +   windnoord  +  windwest  +   windsnelheid +  temp   + golfhoogte  +  luchtdruk_k13_k14 + Diesel  | vaartuig + week_index, df)
panel_land3 = fepois(verkoop_ple_levend_3 ~ treat_we + BB_week_treat +   windnoord  +  windwest  +   windsnelheid +  temp   + golfhoogte +  luchtdruk_k13_k14 + Diesel  | vaartuig + week_index, df)
panel_land2 = fepois(verkoop_ple_levend_2 ~ treat_we + BB_week_treat +   windnoord  +  windwest  +   windsnelheid +  temp    + golfhoogte  +  luchtdruk_k13_k14 + Diesel  | vaartuig + week_index, df)
panel_land1 = fepois(verkoop_ple_levend_1 ~ treat_we + BB_week_treat +   windnoord  +  windwest  +   windsnelheid +  temp    + golfhoogte  +  luchtdruk_k13_k14 + Diesel  | vaartuig + week_index, df)
print(panel_land_tot) 
print(panel_land4) 
print(panel_land3) 
print(panel_land2) 
print(panel_land1)


res = cbind(c(summary(panel_land_tot)$coefficients[2],summary(panel_land4)$coefficients[2],summary(panel_land3)$coefficients[2],summary(panel_land2)$coefficients[2],summary(panel_land1)$coefficients[2]),c(summary(panel_land_tot)$se[2],summary(panel_land4)$se[2],summary(panel_land3)$se[2],summary(panel_land2)$se[2],summary(panel_land1)$se[2]))
res_df = rbind(res_df,res) 

res_df$covar = c(rep("without covariates",5),rep("with covariates",5))
res_df$size =   c("All", "Medium-Small", "Medium", "Medium-Large", "Large","All","Medium-Small", "Medium", "Medium-Large", "Large")
rownames(res_df) <- NULL
colnames(res_df) <-  c("effect", "effect_se", "specification", "size")
res_df = rbind(res_df[1,],res_df[6,],res_df[2,],res_df[7,],res_df[3,],res_df[8,],res_df[4,],res_df[9,],res_df[5,],res_df[10,])
res_df$size <- as.character(res_df$size)
res_df$size <- factor(res_df$size, levels=unique(res_df$size))

## Figure 1 ##
pd = position_dodge(.2)    ### How much to jitter the points on the plot

print(ggplot(res_df,               
             aes(x     = size,
                 y     = effect,
                 color = specification)) +
        geom_point(shape = 15,
                   size  = 4,
                   position = pd) +
        geom_errorbar(aes(ymin  = effect - 1.96*effect_se,
                          ymax  = effect + 1.96*effect_se),
                      width = 0.2,
                      size  = 1,
                      position = pd) +
        theme_bw() +
        theme(text = element_text(size=20)) +
        theme(legend.title = element_blank()) +
        theme(legend.position = c(0.85, 0.08)) +
        theme(legend.background = element_rect(fill="white",
                                               size=0.5, linetype="solid", 
                                               colour ="black")) +
        scale_color_grey() +
        geom_hline(yintercept=0, linetype="dotted") +
        ylab("Approx. % change in weight (kg)") +
        xlab("Size category"))









######################################################
### FUEL EFFECTS                                  ####
######################################################


df = dfa

summary(df$Diesel)
table(df$Diesel)


# 
# # Plot number of vessels at sea for each week
# df_weekly = filter(df, (df$week_index==1))
# vessels_by_week = c(length(unique(df_weekly$vaartuig)),1)
# for (i in seq(2,156)) {
#   df_weekly = filter(df, (df$week_index==i))
#   vessels_by_week = rbind(vessels_by_week,c(length(unique(df_weekly$vaartuig)),i))
# }
# vessels_by_week
# 
# # Plot number of vessels at sea for each week
# plot(x=vessels_by_week[,2], y=vessels_by_week[,1])
# 
# plot_Dieseldur = as.data.frame(cbind(vessels_by_week[,2],vessels_by_week[,1],aggregate(df[, "Diesel"], list(df$week_index), mean)[,2],aggregate(df[, "length_trip"], list(df$week_index), mean)[,2])) 
# plot_Dieseldur = filter(plot_Dieseldur, !(plot_Dieseldur[,1] %in% c(52,104,156))) 
# colnames(plot_Dieseldur) <- c("week_index","nbr_vessels","Diesel", "avgDuration")
# 
# 
# # DieselVSvessels =  cbind(vessels_by_week[,1],aggregate(df[, "Diesel"], list(df$week_index), mean)[,2])
# # plot(x=DieselVSvessels[,1], y=DieselVSvessels[,2])
# plot(x=plot_Dieseldur[,1], y=plot_Dieseldur[,3])
# plot(x=plot_Dieseldur[,3], y=plot_Dieseldur[,2])
# 
# abline(lm(plot_Dieseldur[,2] ~ plot_Dieseldur[,3]))
# 
# plot_Dieseldur
# plot_Dieseldur = filter(plot_Dieseldur, !(plot_Dieseldur$avgDuration<4.9))
# plot_Dieseldur = filter(plot_Dieseldur, !(plot_Dieseldur$avgDuration>6.3))
# plot(x=plot_Dieseldur[,4], y=plot_Dieseldur[,2])
# abline(lm(plot_Dieseldur[,2] ~ plot_Dieseldur[,4]))
# summary(lm(plot_Dieseldur[,2] ~ plot_Dieseldur[,4]))
# 


#Dropping weeks in which coast guard was not patrolling
# NT_week = c( 1,10, 11, 17,21,22, 27,28, 29, 30, 31, 32, 33, 42,50, 52, 53,58,59, 61,62,70,73,74, 82,83, 84, 85, 86, 87, 94, 96, 97,104,105, 114,115, 116, 124, 125, 128,  131,132, 133, 134, 135, 136, 137, 140, 141, 146,147, 148 , 149, 153, 155,156 )  # Non-Treated weeks (no patrolling)
# nrow(df)
# df = filter(df, !(df$week_index %in% NT_week))  
# nrow(df)

# Dropping Christmas weeks which skews analysis of probability of fishing 
# -> fishing vessels and coast guard are almost all on vacation which means these are not comparable weeks to adjacent patrolling weeks
table(df$week_index)
nrow(df)
df = filter(df, !(df$week_index %in% c(52,104,156)))  # drop Christmas weeks and their comparisons when relevant
nrow(df)
table(df$week_index)


# Effects on shares of fish category landed
sX=c("windnoord","windwest","windsnelheid","temp","golfhoogte","luchtdruk_k13_k14")

# Most balanced specification is one with algorithm imputed values on NA and using
# covariates without higher order values sX=c("windnoord","windwest","windsnelheid","temp","golfhoogte","luchtdruk_k13_k14","Diesel")

############
## Impute value for missing values in "luchtdruk_k13_k14" ##
# replace missing air pressure values with values from nearby station
df$luchtdruk_k13_k14[(df$week_index == 128)] <- 1013.1857
df$luchtdruk_k13_k14[(df$week_index == 129)] <- 1015.9572
df$luchtdruk_k13_k14[(df$week_index == 130)] <- 1021.2286
df$luchtdruk_k13_k14[(df$week_index == 131)] <- 1020.0714

length(unique(df$week_index))
length(unique(df$Diesel))


# # If you want to take fuel price as a binary variable include the following 3 lines of
hist(df$Diesel,breaks=80,xlim=c(1.1,1.5),xlab="Diesel prices",main="", col=c("#0099FF"))  # Take cutoff price of 1.3 for binary outcome
#df$Diesel = as.numeric(df$Diesel >median(df$Diesel))
df$Diesel = -df$Diesel
#table(df$Diesel)




sX=c("windnoord","windwest","windsnelheid","temp","golfhoogte","luchtdruk_k13_k14")

sTreat <- "Diesel"




##############################################
### EFFECTS ON PLAICE SHARES  ####
##############################################

streatX = c(sTreat)

panel_share4 <- plm(as.formula(paste("perc_ple4 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share3 <- plm(as.formula(paste("perc_ple3 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share2 <- plm(as.formula(paste("perc_ple2 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share1 <- plm(as.formula(paste("perc_ple1 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
res4 = coef_test(panel_share4, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
res3 = coef_test(panel_share3, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
res2 = coef_test(panel_share2, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
res1 = coef_test(panel_share1, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]

res = rbind(res4,res3,res2,res1)
res_df = as.data.frame(res[,1:2])


streatX = c(sTreat,sX)
panel_share4 <- plm(as.formula(paste("perc_ple4 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share3 <- plm(as.formula(paste("perc_ple3 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share2 <- plm(as.formula(paste("perc_ple2 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share1 <- plm(as.formula(paste("perc_ple1 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
res4 = coef_test(panel_share4, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
res3 = coef_test(panel_share3, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
res2 = coef_test(panel_share2, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]
res1 = coef_test(panel_share1, vcov = "CR1", cluster = "individual", test = "naive-t")[1,]

res = rbind(res4,res3,res2,res1)

res_df = rbind(res_df,res[,1:2])
res_df$covar = c(rep("without covariates",4),rep("with covariates",4))
res_df$size =   c("Medium-Small", "Medium", "Medium-Large", "Large","Medium-Small", "Medium", "Medium-Large", "Large")
rownames(res_df) <- NULL
colnames(res_df) <-  c("effect", "effect_se", "specification", "size")
res_df = rbind(res_df[1,],res_df[5,],res_df[2,],res_df[6,],res_df[3,],res_df[7,],res_df[4,],res_df[8,])
res_df$size <- as.character(res_df$size)
res_df$size <- factor(res_df$size, levels=unique(res_df$size))

## Figure 1 ##
pd = position_dodge(.2)    ### How much to jitter the points on the plot

print(ggplot(res_df,                ### The data frame to use.
             aes(x     = size,
                 y     = effect,
                 color = specification)) +
        geom_point(shape = 15,
                   size  = 4,
                   position = pd) +
        geom_errorbar(aes(ymin  = effect - 1.96*effect_se,
                          ymax  = effect + 1.96*effect_se),
                      width = 0.2,
                      size  = 1,
                      position = pd) +
        theme_bw() +
        theme(text = element_text(size=20)) +
        theme(legend.title = element_blank()) +
        theme(legend.position = c(0.85, 0.08)) +
        theme(legend.background = element_rect(fill="white",
                                               size=0.5, linetype="solid", 
                                               colour ="black")) +
        scale_color_grey() +
        geom_hline(yintercept=0, linetype="dotted") +
        ylab("Change in share") +
        xlab("Size category"))



##############################################
### EFFECTS ON PLAICE WEIGHT - poisson model ###
##############################################



panel_land_tot = fepois(kg_totaal_ple ~ Diesel   | vaartuig, df)
panel_land4 = fepois(verkoop_ple_levend_4 ~ Diesel   | vaartuig, df)
panel_land3 = fepois(verkoop_ple_levend_3 ~ Diesel   | vaartuig, df)
panel_land2 = fepois(verkoop_ple_levend_2 ~ Diesel   | vaartuig, df)
panel_land1 = fepois(verkoop_ple_levend_1 ~ Diesel   | vaartuig, df)
print(panel_land_tot) 
print(panel_land4) 
print(panel_land3) 
print(panel_land2)
print(panel_land1) 



res = cbind(c(summary(panel_land_tot)$coefficients,summary(panel_land4)$coefficients,summary(panel_land3)$coefficients,summary(panel_land2)$coefficients,summary(panel_land1)$coefficients),c(summary(panel_land_tot)$se[1],summary(panel_land4)$se[1],summary(panel_land3)$se[1],summary(panel_land2)$se[1],summary(panel_land1)$se[1]))
res_df = as.data.frame(res)


panel_land_tot = fepois(kg_totaal_ple ~ Diesel +    windnoord  +  windwest  +  windsnelheid +  temp    + golfhoogte  +  luchtdruk_k13_k14 + Diesel  | vaartuig, df)
panel_land4 = fepois(verkoop_ple_levend_4 ~ Diesel +   windnoord  +  windwest  +   windsnelheid +  temp   + golfhoogte  +  luchtdruk_k13_k14 + Diesel  | vaartuig, df)
panel_land3 = fepois(verkoop_ple_levend_3 ~ Diesel +   windnoord  +  windwest  +   windsnelheid +  temp   + golfhoogte +  luchtdruk_k13_k14 + Diesel  | vaartuig, df)
panel_land2 = fepois(verkoop_ple_levend_2 ~ Diesel +   windnoord  +  windwest  +   windsnelheid +  temp    + golfhoogte  +  luchtdruk_k13_k14 + Diesel  | vaartuig, df)
panel_land1 = fepois(verkoop_ple_levend_1 ~ Diesel +   windnoord  +  windwest  +   windsnelheid +  temp    + golfhoogte  +  luchtdruk_k13_k14 + Diesel  | vaartuig, df)
print(panel_land_tot) 
print(panel_land4) 
print(panel_land3) 
print(panel_land2) 
print(panel_land1)


res = cbind(c(summary(panel_land_tot)$coefficients[1],summary(panel_land4)$coefficients[1],summary(panel_land3)$coefficients[1],summary(panel_land2)$coefficients[1],summary(panel_land1)$coefficients[1]),c(summary(panel_land_tot)$se[1],summary(panel_land4)$se[1],summary(panel_land3)$se[1],summary(panel_land2)$se[1],summary(panel_land1)$se[1]))
res_df = rbind(res_df,res) 

res_df$covar = c(rep("without covariates",5),rep("with covariates",5))
res_df$size =   c("All", "Medium-Small", "Medium", "Medium-Large", "Large","All","Medium-Small", "Medium", "Medium-Large", "Large")
rownames(res_df) <- NULL
colnames(res_df) <-  c("effect", "effect_se", "specification", "size")
res_df = rbind(res_df[1,],res_df[6,],res_df[2,],res_df[7,],res_df[3,],res_df[8,],res_df[4,],res_df[9,],res_df[5,],res_df[10,])
res_df$size <- as.character(res_df$size)
res_df$size <- factor(res_df$size, levels=unique(res_df$size))

## Figure 1 ##
pd = position_dodge(.2)    ### How much to jitter the points on the plot

print(ggplot(res_df,               
             aes(x     = size,
                 y     = effect,
                 color = specification)) +
        geom_point(shape = 15,
                   size  = 4,
                   position = pd) +
        geom_errorbar(aes(ymin  = effect - 1.96*effect_se,
                          ymax  = effect + 1.96*effect_se),
                      width = 0.2,
                      size  = 1,
                      position = pd) +
        theme_bw() +
        theme(text = element_text(size=20)) +
        theme(legend.title = element_blank()) +
        theme(legend.position = c(0.85, 0.08)) +
        theme(legend.background = element_rect(fill="white",
                                               size=0.5, linetype="solid", 
                                               colour ="black")) +
        scale_color_grey() +
        geom_hline(yintercept=0, linetype="dotted") +
        ylab("Approx. % change in weight (kg)") +
        xlab("Size category"))






















#####################################################################################################################
#####################################################################################################################

# APPENDIX #

#####################################################################################################################
#####################################################################################################################






df = dfa
## Defining treatment and restricting analysis sample ##
########################################################


# Below are all full weeks during which BB was not patrolling
# 2017: 1 10 11 17 21 22 27 28 29 30 31 32 33 42 50 52 
# 2018: 53 58 59 61 62 70 73 74 82 83 84 85 86 87 94 96 97 104
# 2019: 105 114 115 116 124 125 128 131 132 133 134 135 136 137 140 141 146 147 148 149 153 155 156

NT_week = c( 1,10, 11, 17,21,22, 27,28, 29, 30, 31, 32, 33, 42,50, 52, 53,58,59, 61,62,70,73,74, 82,83, 84, 85, 86, 87, 94, 96, 97,104,105, 114,115, 116, 124, 125, 128,  131,132, 133, 134, 135, 136, 137, 140, 141, 146,147, 148 , 149, 153, 155,156 )  # Non-Treated weeks (no patrolling)
All = seq(1,156)
T_week = All[!(All  %in% NT_week)] # Treated weeks (patrolling)
mAnalysis_weeks = rbind(cbind(NT_week,0),cbind(T_week,1))
mA_w = mAnalysis_weeks[order(mAnalysis_weeks[,1]),2]

analysis_weeks = 1
for (i in seq(2,155)) {
  analysis_weeks = cbind(analysis_weeks,i*as.numeric(mA_w[i] != mA_w[(i-1)]) + i*as.numeric(mA_w[i] != mA_w[(i+1)])* (1-as.numeric(mA_w[i] != mA_w[(i-1)])*as.numeric(mA_w[i] != mA_w[(i+1)])))
}
analysis_weeks
analysis_weeks = analysis_weeks[analysis_weeks!=0]  # Weeks to be included in sample
analysis_weeks
All[!(All  %in% analysis_weeks)]    # Weeks to be excluded from sample

df_weekly = filter(df, (df$week_index==1))
vessels_by_week = c(length(unique(df_weekly$vaartuig)),1)
for (i in seq(2,156)) {
  df_weekly = filter(df, (df$week_index==i))
  vessels_by_week = rbind(vessels_by_week,c(length(unique(df_weekly$vaartuig)),i))
}

# Plot number of vessels at sea for each week
plot(x=vessels_by_week[,2], y=vessels_by_week[,1])


nrow(df)
df = filter(df, (df$week_index %in% analysis_weeks))
nrow(df)
table(df$week_index)

# Plot number of vessels at sea for each week
vessels_by_week =vessels_by_week[(vessels_by_week[,2] %in% analysis_weeks),]
plot(x=vessels_by_week[,2], y=vessels_by_week[,1])

# Given the resulting dataset, these will be the weeks with no treatment (BB not deployed)
# NT_week = c( 1,10, 11, 17,21,22, 27, 33, 42,50, 52, 53,58,59, 61,62,70,73,74, 82, 87, 94, 96, 97,104,105, 114, 116, 124, 125, 128,  131, 137, 140, 141, 146, 149, 153, 155 )



# Dropping Christmas weeks which skews analysis of probability of fishing 
# -> fishing vessels and coast guard are almost all on vacation which means these are not comparable weeks to adjacent patrolling weeks
nrow(df)
df = filter(df, !(df$week_index %in% c(52,103,104)))  # drop Christmas weeks and their comparisons when relevant
nrow(df)
table(df$week_index)

table(df$BB_patrol_frac)
frac = 0.5
df$treat = as.numeric(df$BB_patrol_frac >= frac) # This version can only be used when leaving weeks of bad weather as part of treatment (variable was defined under that assumption)
table(df$treat)                # It defines as treated only the vessels which experienced any overlap with when the BB was patrolling
nrow(df)
df = filter(df, ((df$BB_patrol_frac > 0)*(df$BB_patrol_frac <frac ) !=1))
nrow(df)
table(df$treat) 
sum(as.numeric(df$length_trip <8))/nrow(df)   # fraction of trips lasting less than 7 days
sum(as.numeric(df$day_dep == "Monday") * as.numeric(df$day_return == "Thursday") + as.numeric(df$day_dep == "Sunday") * as.numeric(df$day_return == "Thursday") +
      as.numeric(df$day_dep == "Monday") * as.numeric(df$day_return == "Friday") + as.numeric(df$day_dep == "Sunday") * as.numeric(df$day_return == "Friday"))/nrow(df)  
# Fraction of trips within usual Sunday night / Monday morning to Thursday night/Friday 

nrow(df)


length(unique(df$vaartuig)) 
table(df$vaartuig)






# Effects on shares of fish category landed
sX=c("windnoord","windwest","windsnelheid","temp","golfhoogte","luchtdruk_k13_k14","Diesel")

# Most balanced specification is one with algorithm imputed values on NA and using
# covariates without higher order values sX=c("windnoord","windwest","windsnelheid","temp","golfhoogte","luchtdruk_k13_k14","Diesel")

############
## Impute value for missing values in "luchtdruk_k13_k14" ##
# replace missing air pressure values with values from nearby station
df$luchtdruk_k13_k14[(df$week_index == 128)] <- 1013.1857
df$luchtdruk_k13_k14[(df$week_index == 129)] <- 1015.9572
df$luchtdruk_k13_k14[(df$week_index == 130)] <- 1021.2286
df$luchtdruk_k13_k14[(df$week_index == 131)] <- 1020.0714




sTreat <- "treat"
streatX = c(sTreat,sX)


### EFFECTS ON SOLE SHARES  ####


streatX = c(sTreat,sX)
panel_share5 <- plm(as.formula(paste("perc_sol5 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share4 <- plm(as.formula(paste("perc_sol4 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share3 <- plm(as.formula(paste("perc_sol3 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share2 <- plm(as.formula(paste("perc_sol2 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share1 <- plm(as.formula(paste("perc_sol1 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
coef_test(panel_share5, vcov = "CR1", cluster = "individual", test = "naive-t")
coef_test(panel_share4, vcov = "CR1", cluster = "individual", test = "naive-t")
coef_test(panel_share3, vcov = "CR1", cluster = "individual", test = "naive-t")
coef_test(panel_share2, vcov = "CR1", cluster = "individual", test = "naive-t")
coef_test(panel_share1, vcov = "CR1", cluster = "individual", test = "naive-t")




### EFFECTS ON SOLE WEIGHT (kg)  ####


streatX = c(sTreat,sX)
panel_land5 <- plm(as.formula(paste("verkoop_sol_levend_5 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_land4 <- plm(as.formula(paste("verkoop_sol_levend_4 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_land3 <- plm(as.formula(paste("verkoop_sol_levend_3 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_land2 <- plm(as.formula(paste("verkoop_sol_levend_2 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_land1 <- plm(as.formula(paste("verkoop_sol_levend_1 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_land_tot <- plm(as.formula(paste("kg_totaal ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
coef_test(panel_land5, vcov = "CR1", cluster = "individual", test = "naive-t")
coef_test(panel_land4, vcov = "CR1", cluster = "individual", test = "naive-t")
coef_test(panel_land3, vcov = "CR1", cluster = "individual", test = "naive-t")
coef_test(panel_land2, vcov = "CR1", cluster = "individual", test = "naive-t")
coef_test(panel_land1, vcov = "CR1", cluster = "individual", test = "naive-t")
coef_test(panel_land_tot, vcov = "CR1", cluster = "individual", test = "naive-t")



### EFFECTS ON SOLE WEIGHT - poisson model ####



panel_land5 = fepois(verkoop_sol_levend_5 ~ treat +   windnoord  +  windwest  +   windsnelheid +  temp   + golfhoogte  +  luchtdruk_k13_k14 + Diesel | vaartuig, df)
panel_land4 = fepois(verkoop_sol_levend_4 ~ treat +   windnoord  +  windwest  +   windsnelheid +  temp   + golfhoogte  +  luchtdruk_k13_k14 + Diesel  | vaartuig, df)
panel_land3 = fepois(verkoop_sol_levend_3 ~ treat +   windnoord  +  windwest  +   windsnelheid +  temp   + golfhoogte +  luchtdruk_k13_k14 + Diesel  | vaartuig, df)
panel_land2 = fepois(verkoop_sol_levend_2 ~ treat +   windnoord  +  windwest  +   windsnelheid +  temp    + golfhoogte  +  luchtdruk_k13_k14 + Diesel  | vaartuig, df)
panel_land1 = fepois(verkoop_sol_levend_1 ~ treat +   windnoord  +  windwest  +   windsnelheid +  temp    + golfhoogte  +  luchtdruk_k13_k14 + Diesel  | vaartuig, df)
panel_land_tot = fepois(kg_totaal ~ treat +    windnoord  +  windwest  +  windsnelheid +  temp    + golfhoogte  +  luchtdruk_k13_k14 + Diesel  | vaartuig, df)
summary(panel_land5) 
summary(panel_land4) 
summary(panel_land3) 
summary(panel_land2)
summary(panel_land1) 
summary(panel_land_tot)




#### RERUN RESULTS RESTRICTING SAMPLE TO MONDAYish-THURSDAYish TRIPS  #####-
# If we restict sample to only vessels at sea Sunday-Monday to Thursday-Friday
df$start_day = weekdays(as.Date(df$vertrek,format="%Y-%m-%d"))
table(df$start_day)
df$start_sel = as.numeric(df$start_day == "Sunday")*as.numeric(df$length_trip <= 6) + as.numeric(df$start_day == "Monday")*as.numeric(df$length_trip <= 5) + as.numeric(df$start_day == "Tuesday")*as.numeric(df$length_trip <= 4) + as.numeric(df$start_day == "Wednesday")*as.numeric(df$length_trip <= 3) + as.numeric(df$start_day == "Thursday")*as.numeric(df$length_trip <= 1)
nrow(df)
df = filter(df, (df$start_sel == 1)) # Sunday-Monday trip start days observations
nrow(df)









##################################################
## Hetergenous Effects Vessel Length ##
##################################################

df = dfb


### DIFFERENCES BY VESSEL CHARACTERISTICS ####

table(df$vermogen)
hist(df$vermogen,breaks=10,xlim=c(0,1500),xlab="Power",main="", col=c("#0099FF"))
table(df$lengte_over_alles)
hist(df$lengte_over_alles,breaks=10,xlim=c(0,50),xlab="length (m)",main="", col=c("#0099FF"))
table(df$tonnage)
hist(df$tonnage,breaks=10,xlim=c(0,580),xlab="Weight",main="", col=c("#0099FF"))

df$power_D1000= as.numeric(df$vermogen <1000)
table(df$power_D1000)
df$length_D39= as.numeric(df$lengte_over_alles <39)
df$length_D39= as.numeric(df$lengte_over_alles <24)  # This is the cutoff for pulse trawling
table(df$length_D39)
df$weight_D290= as.numeric(df$tonnage <290)
table(df$weight_D290)

df$treat_powerD1000 = df$treat*df$power_D1000
df$treat_length_D39 = df$treat*df$length_D39
df$treat_weight_D290 = df$treat*df$weight_D290

### EFFECTS ON SOLE SHARES  ####

#sTreat <- c("treat","treat_powerD1000")
#sTreat <- c("treat","treat_weight_D290")
sTreat <- c("treat","treat_length_D39")   # We basiclaly have a clear length/power/weight cutoff so all results look similar


streatX = c(sTreat)
panel_share5 <- plm(as.formula(paste("perc_sol5 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share4 <- plm(as.formula(paste("perc_sol4 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share3 <- plm(as.formula(paste("perc_sol3 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share2 <- plm(as.formula(paste("perc_sol2 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share1 <- plm(as.formula(paste("perc_sol1 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_land_tot <- plm(as.formula(paste("kg_totaal ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
coef_test(panel_share5, vcov = "CR1", cluster = "individual", test = "naive-t")[1:2,]
coef_test(panel_share4, vcov = "CR1", cluster = "individual", test = "naive-t")[1:2,]
coef_test(panel_share3, vcov = "CR1", cluster = "individual", test = "naive-t")[1:2,]
coef_test(panel_share2, vcov = "CR1", cluster = "individual", test = "naive-t")[1:2,]
coef_test(panel_share1, vcov = "CR1", cluster = "individual", test = "naive-t")[1:2,]
coef_test(panel_land_tot, vcov = "CR1", cluster = "individual", test = "naive-t")[1:2,]


streatX = c(sTreat,sX)
panel_share5 <- plm(as.formula(paste("perc_sol5 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share4 <- plm(as.formula(paste("perc_sol4 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share3 <- plm(as.formula(paste("perc_sol3 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share2 <- plm(as.formula(paste("perc_sol2 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share1 <- plm(as.formula(paste("perc_sol1 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_land_tot <- plm(as.formula(paste("kg_totaal ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
coef_test(panel_share5, vcov = "CR1", cluster = "individual", test = "naive-t")[1:2,]
coef_test(panel_share4, vcov = "CR1", cluster = "individual", test = "naive-t")[1:2,]
coef_test(panel_share3, vcov = "CR1", cluster = "individual", test = "naive-t")[1:2,]
coef_test(panel_share2, vcov = "CR1", cluster = "individual", test = "naive-t")[1:2,]
coef_test(panel_share1, vcov = "CR1", cluster = "individual", test = "naive-t")[1:2,]
coef_test(panel_land_tot, vcov = "CR1", cluster = "individual", test = "naive-t")[1:2,]

### EFFECTS ON TRIP LENGTH  ####
streatX = c(sTreat)
panel_length1 <- plm(as.formula(paste("length_trip ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
streatX = c(sTreat,sX)
panel_length2 <- plm(as.formula(paste("length_trip ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
coef_test(panel_length1, vcov = "CR1", cluster = "individual", test = "naive-t")[1:2,]
coef_test(panel_length2, vcov = "CR1", cluster = "individual", test = "naive-t")[1:2,]





#### Effects on length of fishing trip  ####


df = dfb


df$power_D1000= as.numeric(df$vermogen <1000)
table(df$power_D1000)
df$length_D39= as.numeric(df$lengte_over_alles <39)
df$length_D39= as.numeric(df$lengte_over_alles <24)  # This is the cutoff for pulse trawling
table(df$length_D39)
df$weight_D290= as.numeric(df$tonnage <290)
table(df$weight_D290)

df$treat_powerD1000 = df$treat*df$power_D1000
df$treat_length_D39 = df$treat*df$length_D39
df$treat_weight_D290 = df$treat*df$weight_D290

sTreat <- c("treat","treat_length_D39")   # We basiclaly have a clear length/power/weight cutoff so all results look similar

sX=c("windnoord","windwest","windsnelheid","temp","golfhoogte","luchtdruk_k13_k14","Diesel")
streatX = c(sTreat)
panel_length1 <- plm(as.formula(paste("length_trip ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
streatX = c(sTreat,sX)
panel_length2 <- plm(as.formula(paste("length_trip ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
coef_test(panel_length1, vcov = "CR1", cluster = "individual", test = "naive-t")[1:2,]
coef_test(panel_length2, vcov = "CR1", cluster = "individual", test = "naive-t")[1:2,]
#summary(panel_length1)
#summary(panel_length2)


# If we restict sample to only vessels at sea Sunday-Monday to Thursday-Friday
df$start_day = weekdays(as.Date(df$vertrek,format="%Y-%m-%d"))
df$start_sel = as.numeric(df$start_day == "Sunday")*as.numeric(df$length_trip <= 6) + as.numeric(df$start_day == "Monday")*as.numeric(df$length_trip <= 5) + as.numeric(df$start_day == "Tuesday")*as.numeric(df$length_trip <= 4) + as.numeric(df$start_day == "Wednesday")*as.numeric(df$length_trip <= 3) + as.numeric(df$start_day == "Thursday")*as.numeric(df$length_trip == 1)
df = filter(df, (df$start_sel == 1)) # Sunday-Monday trip start days observations

streatX = c(sTreat)
panel_length1 <- plm(as.formula(paste("length_trip ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
streatX = c(sTreat,sX)
panel_length2 <- plm(as.formula(paste("length_trip ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
coef_test(panel_length1, vcov = "CR1", cluster = "individual", test = "naive-t")[1:2,]
coef_test(panel_length2, vcov = "CR1", cluster = "individual", test = "naive-t")[1:2,]
#summary(panel_length2)




#### Effects on probability of vessel out at sea   ####


df = dfb

df$power_D1000= as.numeric(df$vermogen <1000)
table(df$power_D1000)
df$length_D39= as.numeric(df$lengte_over_alles <39)
df$length_D39= as.numeric(df$lengte_over_alles <24)  # This is the cutoff for pulse trawling
table(df$length_D39)
df$weight_D290= as.numeric(df$tonnage <290)
table(df$weight_D290)

df$treat_powerD1000 = df$treat*df$power_D1000
df$treat_length_D39 = df$treat*df$length_D39
df$treat_weight_D290 = df$treat*df$weight_D290

sTreat <- c("treat","treat_length_D39")   # We basiclaly have a clear length/power/weight cutoff so all results look similar

sX=c("windnoord","windwest","windsnelheid","temp","golfhoogte","luchtdruk_k13_k14","Diesel")
streatX = c(sTreat)
panel_fished_sol1 <- plm(as.formula(paste("fished_sol1 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
streatX = c(sTreat,sX)
panel_fished_sol2 <- plm(as.formula(paste("fished_sol1 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
coef_test(panel_fished_sol1, vcov = "CR1", cluster = "individual", test = "naive-t")[1:2,]
coef_test(panel_fished_sol2, vcov = "CR1", cluster = "individual", test = "naive-t")[1:2,]
summary(panel_fished_sol2)



## In the following code we add 0 entries for weeks in which vessels did not go out at sea ##
dfp <- read.csv( "D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Stephen files\\Data_final_1719_newProb.csv")  # this file already made the selection of weeks for sample
#dfp <- read.csv( "D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Stephen files\\Data_final_1719_newProb_corr.csv")  # this file already made the selection of weeks for sample
dfp = dfp[,-1]


# Below are all full weeks during which BB was not patrolling
# 2017: 1 10 11 17 21 22 27 28 29 30 31 32 33 42 50 52 
# 2018: 53 58 59 61 62 70 73 74 82 83 84 85 86 87 94 96 97 104
# 2019: 105 114 115 116 124 125 128 131 132 133 134 135 136 137 140 141 146 147 148 149 153 155 156

NT_week = c( 1,10, 11, 17,21,22, 27,28, 29, 30, 31, 32, 33, 42,50, 52, 53,58,59, 61,62,70,73,74, 82,83, 84, 85, 86, 87, 94, 96, 97,104,105, 114,115, 116, 124, 125, 128,  131,132, 133, 134, 135, 136, 137, 140, 141, 146,147, 148 , 149, 153, 155,156 )  # Non-Treated weeks (no patrolling)
All = seq(1,156)
T_week = All[!(All  %in% NT_week)] # Treated weeks (patrolling)
mAnalysis_weeks = rbind(cbind(NT_week,0),cbind(T_week,1))
mA_w = mAnalysis_weeks[order(mAnalysis_weeks[,1]),2]

analysis_weeks = 1
for (i in seq(2,155)) {
  analysis_weeks = cbind(analysis_weeks,i*as.numeric(mA_w[i] != mA_w[(i-1)]) + i*as.numeric(mA_w[i] != mA_w[(i+1)])* (1-as.numeric(mA_w[i] != mA_w[(i-1)])*as.numeric(mA_w[i] != mA_w[(i+1)])))
}
analysis_weeks
analysis_weeks = analysis_weeks[analysis_weeks!=0]  # Weeks to be included in sample
analysis_weeks
All[!(All  %in% analysis_weeks)]    # Weeks to be excluded from sample

df_weekly = filter(dfp, (dfp$week_index==1))
vessels_by_week = c(length(unique(df_weekly$vaartuig)),1)
for (i in seq(2,156)) {
  df_weekly = filter(dfp, (dfp$week_index==i))
  vessels_by_week = rbind(vessels_by_week,c(length(unique(df_weekly$vaartuig)),i))
}

# Plot number of vessels at sea for each week
plot(x=vessels_by_week[,2], y=vessels_by_week[,1])


nrow(dfp)
dfp = filter(dfp, (dfp$week_index %in% analysis_weeks))
nrow(dfp)
table(dfp$week_index)

# Plot number of vessels at sea for each week
vessels_by_week =vessels_by_week[(vessels_by_week[,2] %in% analysis_weeks),]
plot(x=vessels_by_week[,2], y=vessels_by_week[,1])

# Given the resulting dataset, these will be the weeks with no treatment (BB not deployed)
NT_week = c( 1,10, 11, 17,21,22, 27, 33, 42,50, 52, 53,58,59, 61,62,70,73,74, 82, 87, 94, 96, 97,104,105, 114, 116, 124, 125, 128,  131, 137, 140, 141, 146, 149, 153, 155 )
df$treat = 1-as.numeric(df$week_index %in% NT_week)


# Dropping Christmas weeks which skews analysis of probability of fishing 
# -> fishing vessels and coast guard are almost all on vacation which means these are not comparable weeks to adjacent patrolling weeks
nrow(dfp)
dfp = filter(dfp, !(dfp$week_index %in% c(52,103,104)))  # drop Christmas weeks and their comparisons when relevant
nrow(dfp)
table(dfp$week_index)


dfp$fished_sol1 = as.numeric(dfp$kg_totaal>50) 
table(dfp$fished_sol1)  
sX=c("windnoord","windwest","windsnelheid","temp","golfhoogte","luchtdruk_k13_k14","Diesel")
#sX=c("windnoord","windnoordsq","windnoordcb","windwest","windwestsq","windwestcb","windsnelheid","windsnelheidsq","windsnelheidcb","temp","tempsq","tempcb","golfhoogte","golfhoogtesq","golfhoogtecb", "luchtdruk_k13_k14","luchtdruk_k13_k14sq","luchtdruk_k13_k14cb","Diesel","Dieselsq","Dieselcb") # To be added when using 3rd degree polynomials

sum(dfp$treat*dfp$fished_sol1)/sum(dfp$treat) - sum((1-dfp$treat)*dfp$fished_sol1)/sum(1-dfp$treat) # Difference in means of probability of fishing

sum(dfp$treat*dfp$fished_sol1)*length(unique(dfp$vaartuig)) /sum(dfp$treat)
sum((1-dfp$treat)*dfp$fished_sol1)*length(unique(dfp$vaartuig))/sum(1-dfp$treat)
length(unique(dfp$vaartuig)) 
table(dfp$treat)


dfp$length_D39= as.numeric(dfp$lengte_over_alles <39)
dfp$length_D39= as.numeric(dfp$lengte_over_alles <24)  # This is the cutoff for pulse trawling

dfp$treat_length_D39 = dfp$treat*dfp$length_D39


sTreat <- c("treat","treat_length_D39")   # We basiclaly have a clear length/power/weight cutoff so all results look similar


streatX = c(sTreat)
panel_fished_sol1 <- plm(as.formula(paste("fished_sol1 ~ ", paste(streatX, collapse= "+"))), data = dfp,index = c("vaartuig"), model = "within")
streatX = c(sTreat,sX)
panel_fished_sol2 <- plm(as.formula(paste("fished_sol1 ~ ", paste(streatX, collapse= "+"))), data = dfp,index = c("vaartuig"), model = "within")
coef_test(panel_fished_sol1, vcov = "CR1", cluster = "individual", test = "naive-t")[1:2,]
coef_test(panel_fished_sol2, vcov = "CR1", cluster = "individual", test = "naive-t")[1:2,]
#summary(panel_fished_sol2)







##################################################
## Hetergenous Effects Fuel prices  ##
##################################################

df = dfb

median(df$Diesel)
# # If you want to take fuel price as a binary variable include the following 3 lines of
hist(df$Diesel,breaks=80,xlim=c(1.1,1.5),xlab="Diesel prices",main="", col=c("#0099FF"))  
df$DieselD = as.numeric(df$Diesel >median(df$Diesel))
table(df$DieselD)
#df$DieselDunder = as.numeric(df$Diesel <=median(df$Diesel))

df$treat_Diesel = df$treat*df$Diesel
df$treat_DieselD = df$treat*df$DieselD

### EFFECTS ON SOLE SHARES  ####

#sTreat <- c("Diesel","treat","treat_Diesel")
sTreat <- c("DieselD","treat","treat_DieselD")


streatX = c(sTreat)
panel_share5 <- plm(as.formula(paste("perc_sol5 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share4 <- plm(as.formula(paste("perc_sol4 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share3 <- plm(as.formula(paste("perc_sol3 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share2 <- plm(as.formula(paste("perc_sol2 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share1 <- plm(as.formula(paste("perc_sol1 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_land_tot <- plm(as.formula(paste("kg_totaal ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
coef_test(panel_share5, vcov = "CR1", cluster = "individual", test = "naive-t")[1:3,]
coef_test(panel_share4, vcov = "CR1", cluster = "individual", test = "naive-t")[1:3,]
coef_test(panel_share3, vcov = "CR1", cluster = "individual", test = "naive-t")[1:3,]
coef_test(panel_share2, vcov = "CR1", cluster = "individual", test = "naive-t")[1:3,]
coef_test(panel_share1, vcov = "CR1", cluster = "individual", test = "naive-t")[1:3,]
coef_test(panel_land_tot, vcov = "CR1", cluster = "individual", test = "naive-t")[1:3,]


streatX = c(sTreat,sX)
panel_share5 <- plm(as.formula(paste("perc_sol5 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share4 <- plm(as.formula(paste("perc_sol4 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share3 <- plm(as.formula(paste("perc_sol3 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share2 <- plm(as.formula(paste("perc_sol2 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share1 <- plm(as.formula(paste("perc_sol1 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_land_tot <- plm(as.formula(paste("kg_totaal ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
coef_test(panel_share5, vcov = "CR1", cluster = "individual", test = "naive-t")[1:3,]
coef_test(panel_share4, vcov = "CR1", cluster = "individual", test = "naive-t")[1:3,]
coef_test(panel_share3, vcov = "CR1", cluster = "individual", test = "naive-t")[1:3,]
coef_test(panel_share2, vcov = "CR1", cluster = "individual", test = "naive-t")[1:3,]
coef_test(panel_share1, vcov = "CR1", cluster = "individual", test = "naive-t")[1:3,]
coef_test(panel_land_tot, vcov = "CR1", cluster = "individual", test = "naive-t")[1:3,]

### EFFECTS ON TRIP LENGTH  ####
streatX = c(sTreat)
panel_length1 <- plm(as.formula(paste("length_trip ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
streatX = c(sTreat,sX)
panel_length2 <- plm(as.formula(paste("length_trip ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
coef_test(panel_length1, vcov = "CR1", cluster = "individual", test = "naive-t")[1:3,]
coef_test(panel_length2, vcov = "CR1", cluster = "individual", test = "naive-t")[1:3,]








#### Effects on length of fishing trip  ####


df = dfb


df$DieselD = as.numeric(df$Diesel >median(df$Diesel))

df$treat_DieselD = df$treat*df$DieselD

sTreat <- c("DieselD","treat","treat_DieselD")

sX=c("windnoord","windwest","windsnelheid","temp","golfhoogte","luchtdruk_k13_k14","Diesel")
streatX = c(sTreat)
panel_length1 <- plm(as.formula(paste("length_trip ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
streatX = c(sTreat,sX)
panel_length2 <- plm(as.formula(paste("length_trip ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
coef_test(panel_length1, vcov = "CR1", cluster = "individual", test = "naive-t")[1:3,]
coef_test(panel_length2, vcov = "CR1", cluster = "individual", test = "naive-t")[1:3,]
#summary(panel_length1)
#summary(panel_length2)


# If we restict sample to only vessels at sea Sunday-Monday to Thursday-Friday
df$start_day = weekdays(as.Date(df$vertrek,format="%Y-%m-%d"))
df$start_sel = as.numeric(df$start_day == "Sunday")*as.numeric(df$length_trip <= 6) + as.numeric(df$start_day == "Monday")*as.numeric(df$length_trip <= 5) + as.numeric(df$start_day == "Tuesday")*as.numeric(df$length_trip <= 4) + as.numeric(df$start_day == "Wednesday")*as.numeric(df$length_trip <= 3) + as.numeric(df$start_day == "Thursday")*as.numeric(df$length_trip == 1)
df = filter(df, (df$start_sel == 1)) # Sunday-Monday trip start days observations

streatX = c(sTreat)
panel_length1 <- plm(as.formula(paste("length_trip ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
streatX = c(sTreat,sX)
panel_length2 <- plm(as.formula(paste("length_trip ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
coef_test(panel_length1, vcov = "CR1", cluster = "individual", test = "naive-t")[1:3,]
coef_test(panel_length2, vcov = "CR1", cluster = "individual", test = "naive-t")[1:3,]
#summary(panel_length2)




#### Effects on probability of vessel out at sea   ####


df = dfb


df$DieselD = as.numeric(df$Diesel >median(df$Diesel))

df$treat_DieselD = df$treat*df$DieselD

sTreat <- c("DieselD","treat","treat_DieselD")

sX=c("windnoord","windwest","windsnelheid","temp","golfhoogte","luchtdruk_k13_k14","Diesel")
streatX = c(sTreat)
panel_fished_sol1 <- plm(as.formula(paste("fished_sol1 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
streatX = c(sTreat,sX)
panel_fished_sol2 <- plm(as.formula(paste("fished_sol1 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
coef_test(panel_fished_sol1, vcov = "CR1", cluster = "individual", test = "naive-t")[1:3,]
coef_test(panel_fished_sol2, vcov = "CR1", cluster = "individual", test = "naive-t")[1:3,]
#summary(panel_fished_sol2)



## In the following code we add 0 entries for weeks in which vessels did not go out at sea ##
dfp <- read.csv( "D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Stephen files\\Data_final_1719_newProb.csv")  # this file already made the selection of weeks for sample
#dfp <- read.csv( "D:\\Fishing Data\\NVWA_visfraudeproject_datavoorbewerkingsstappen\\Stephen files\\Data_final_1719_newProb_corr.csv")  # this file already made the selection of weeks for sample
dfp = dfp[,-1]


# Below are all full weeks during which BB was not patrolling
# 2017: 1 10 11 17 21 22 27 28 29 30 31 32 33 42 50 52 
# 2018: 53 58 59 61 62 70 73 74 82 83 84 85 86 87 94 96 97 104
# 2019: 105 114 115 116 124 125 128 131 132 133 134 135 136 137 140 141 146 147 148 149 153 155 156

NT_week = c( 1,10, 11, 17,21,22, 27,28, 29, 30, 31, 32, 33, 42,50, 52, 53,58,59, 61,62,70,73,74, 82,83, 84, 85, 86, 87, 94, 96, 97,104,105, 114,115, 116, 124, 125, 128,  131,132, 133, 134, 135, 136, 137, 140, 141, 146,147, 148 , 149, 153, 155,156 )  # Non-Treated weeks (no patrolling)
All = seq(1,156)
T_week = All[!(All  %in% NT_week)] # Treated weeks (patrolling)
mAnalysis_weeks = rbind(cbind(NT_week,0),cbind(T_week,1))
mA_w = mAnalysis_weeks[order(mAnalysis_weeks[,1]),2]

analysis_weeks = 1
for (i in seq(2,155)) {
  analysis_weeks = cbind(analysis_weeks,i*as.numeric(mA_w[i] != mA_w[(i-1)]) + i*as.numeric(mA_w[i] != mA_w[(i+1)])* (1-as.numeric(mA_w[i] != mA_w[(i-1)])*as.numeric(mA_w[i] != mA_w[(i+1)])))
}
analysis_weeks
analysis_weeks = analysis_weeks[analysis_weeks!=0]  # Weeks to be included in sample
analysis_weeks
All[!(All  %in% analysis_weeks)]    # Weeks to be excluded from sample

df_weekly = filter(dfp, (dfp$week_index==1))
vessels_by_week = c(length(unique(df_weekly$vaartuig)),1)
for (i in seq(2,156)) {
  df_weekly = filter(dfp, (dfp$week_index==i))
  vessels_by_week = rbind(vessels_by_week,c(length(unique(df_weekly$vaartuig)),i))
}

# Plot number of vessels at sea for each week
plot(x=vessels_by_week[,2], y=vessels_by_week[,1])


nrow(dfp)
dfp = filter(dfp, (dfp$week_index %in% analysis_weeks))
nrow(dfp)
table(dfp$week_index)

# Plot number of vessels at sea for each week
vessels_by_week =vessels_by_week[(vessels_by_week[,2] %in% analysis_weeks),]
plot(x=vessels_by_week[,2], y=vessels_by_week[,1])

# Given the resulting dataset, these will be the weeks with no treatment (BB not deployed)
NT_week = c( 1,10, 11, 17,21,22, 27, 33, 42,50, 52, 53,58,59, 61,62,70,73,74, 82, 87, 94, 96, 97,104,105, 114, 116, 124, 125, 128,  131, 137, 140, 141, 146, 149, 153, 155 )
df$treat = 1-as.numeric(df$week_index %in% NT_week)


# Dropping Christmas weeks which skews analysis of probability of fishing 
# -> fishing vessels and coast guard are almost all on vacation which means these are not comparable weeks to adjacent patrolling weeks
nrow(dfp)
dfp = filter(dfp, !(dfp$week_index %in% c(52,103,104)))  # drop Christmas weeks and their comparisons when relevant
nrow(dfp)
table(dfp$week_index)


dfp$fished_sol1 = as.numeric(dfp$kg_totaal>50) 
table(dfp$fished_sol1)  
sX=c("windnoord","windwest","windsnelheid","temp","golfhoogte","luchtdruk_k13_k14","Diesel")
#sX=c("windnoord","windnoordsq","windnoordcb","windwest","windwestsq","windwestcb","windsnelheid","windsnelheidsq","windsnelheidcb","temp","tempsq","tempcb","golfhoogte","golfhoogtesq","golfhoogtecb", "luchtdruk_k13_k14","luchtdruk_k13_k14sq","luchtdruk_k13_k14cb","Diesel","Dieselsq","Dieselcb") # To be added when using 3rd degree polynomials

sum(dfp$treat*dfp$fished_sol1)/sum(dfp$treat) - sum((1-dfp$treat)*dfp$fished_sol1)/sum(1-dfp$treat) # Difference in means of probability of fishing

sum(dfp$treat*dfp$fished_sol1)*length(unique(dfp$vaartuig)) /sum(dfp$treat)
sum((1-dfp$treat)*dfp$fished_sol1)*length(unique(dfp$vaartuig))/sum(1-dfp$treat)
length(unique(dfp$vaartuig)) 
table(dfp$treat)



dfp$DieselD = as.numeric(dfp$Diesel >median(dfp$Diesel))

dfp$treat_DieselD = dfp$treat*dfp$DieselD

sTreat <- c("DieselD","treat","treat_DieselD")

streatX = c(sTreat)
panel_fished_sol1 <- plm(as.formula(paste("fished_sol1 ~ ", paste(streatX, collapse= "+"))), data = dfp,index = c("vaartuig"), model = "within")
streatX = c(sTreat,sX)
panel_fished_sol2 <- plm(as.formula(paste("fished_sol1 ~ ", paste(streatX, collapse= "+"))), data = dfp,index = c("vaartuig"), model = "within")
coef_test(panel_fished_sol1, vcov = "CR1", cluster = "individual", test = "naive-t")[1:3,]
coef_test(panel_fished_sol2, vcov = "CR1", cluster = "individual", test = "naive-t")[1:3,]
#summary(panel_fished_sol2)
















#####################################################################################################################
#####################################################################################################################

# ONLINE APPENDIX #

#####################################################################################################################
#####################################################################################################################



df = dfa
## Defining treatment and restricting analysis sample ##
########################################################



# Below are all full weeks during which BB was not patrolling
# 2017: 1 10 11 17 21 22 27 28 29 30 31 32 33 42 50 52 
# 2018: 53 58 59 61 62 70 73 74 82 83 84 85 86 87 94 96 97 104
# 2019: 105 114 115 116 124 125 128 131 132 133 134 135 136 137 140 141 146 147 148 149 153 155 156

NT_week = c( 1,10, 11, 17,21,22, 27,28, 29, 30, 31, 32, 33, 42,50, 52, 53,58,59, 61,62,70,73,74, 82,83, 84, 85, 86, 87, 94, 96, 97,104,105, 114,115, 116, 124, 125, 128,  131,132, 133, 134, 135, 136, 137, 140, 141, 146,147, 148 , 149, 153, 155,156 )  # Non-Treated weeks (no patrolling)
All = seq(1,156)
T_week = All[!(All  %in% NT_week)] # Treated weeks (patrolling)
mAnalysis_weeks = rbind(cbind(NT_week,0),cbind(T_week,1))
mA_w = mAnalysis_weeks[order(mAnalysis_weeks[,1]),2]

analysis_weeks = 1
for (i in seq(2,155)) {
  analysis_weeks = cbind(analysis_weeks,i*as.numeric(mA_w[i] != mA_w[(i-1)]) + i*as.numeric(mA_w[i] != mA_w[(i+1)])* (1-as.numeric(mA_w[i] != mA_w[(i-1)])*as.numeric(mA_w[i] != mA_w[(i+1)])))
}
analysis_weeks
analysis_weeks = analysis_weeks[analysis_weeks!=0]  # Weeks to be included in sample
analysis_weeks
All[!(All  %in% analysis_weeks)]    # Weeks to be excluded from sample

df_weekly = filter(df, (df$week_index==1))
vessels_by_week = c(length(unique(df_weekly$vaartuig)),1)
for (i in seq(2,156)) {
  df_weekly = filter(df, (df$week_index==i))
  vessels_by_week = rbind(vessels_by_week,c(length(unique(df_weekly$vaartuig)),i))
}

# Plot number of vessels at sea for each week
plot(x=vessels_by_week[,2], y=vessels_by_week[,1])


nrow(df)
df = filter(df, (df$week_index %in% analysis_weeks))
nrow(df)
table(df$week_index)



# Given the resulting dataset, these will be the weeks with no treatment (BB not deployed)
NT_week = c( 1,10, 11, 17,21,22, 27, 33, 42,50, 52, 53,58,59, 61,62,70,73,74, 82, 87, 94, 96, 97,104,105, 114, 116, 124, 125, 128,  131, 137, 140, 141, 146, 149, 153, 155 )
df$treat = 1-as.numeric(df$week_index %in% NT_week)


# Dropping Christmas weeks which skews analysis of probability of fishing 
# -> fishing vessels and coast guard are almost all on vacation which means these are not comparable weeks to adjacent patrolling weeks
nrow(df)
df = filter(df, !(df$week_index %in% c(52,103,104)))  # drop Christmas weeks and their comparisons when relevant
nrow(df)
table(df$week_index)

table(df$BB_patrol_frac)
frac = 0.5
df$treat = as.numeric(df$BB_patrol_frac >= frac) # This version can only be used when leaving weeks of bad weather as part of treatment (variable was defined under that assumption)
table(df$treat)                # It defines as treated only the vessels which experienced any overlap with when the BB was patrolling
nrow(df)
df = filter(df, ((df$BB_patrol_frac > 0)*(df$BB_patrol_frac <frac ) !=1))
nrow(df)
table(df$treat) 
sum(as.numeric(df$length_trip <8))/nrow(df)   # fraction of trips lasting less than 7 days
sum(as.numeric(df$day_dep == "Monday") * as.numeric(df$day_return == "Thursday") + as.numeric(df$day_dep == "Sunday") * as.numeric(df$day_return == "Thursday") +
      as.numeric(df$day_dep == "Monday") * as.numeric(df$day_return == "Friday") + as.numeric(df$day_dep == "Sunday") * as.numeric(df$day_return == "Friday"))/nrow(df)  
# Fraction of trips within usual Sunday night / Monday morning to Thursday night/Friday 

nrow(df)


length(unique(df$vaartuig)) 
table(df$vaartuig)







## TABLE 1 ##

# Effects on shares of fish category landed
sX=c("windnoord","windnoordsq","windnoordcb","windwest","windwestsq","windwestcb","windsnelheid","windsnelheidsq","windsnelheidcb","temp","tempsq","tempcb","golfhoogte","golfhoogtesq","golfhoogtecb", "luchtdruk_k13_k14","luchtdruk_k13_k14sq","luchtdruk_k13_k14cb","Diesel","Dieselsq","Dieselcb")

# Most balanced specification is one with algorithm imputed values on NA and using
# covariates without higher order values sX=c("windnoord","windwest","windsnelheid","temp","golfhoogte","luchtdruk_k13_k14","Diesel")

############
## Impute value for missing values in "luchtdruk_k13_k14" ##
## Impute value for missing values in "luchtdruk_k13_k14" ##
# replace missing air pressure values with values from nearby station
df$luchtdruk_k13_k14[(df$week_index == 128)] <- 1013.1857
df$luchtdruk_k13_k14[(df$week_index == 129)] <- 1015.9572
df$luchtdruk_k13_k14[(df$week_index == 130)] <- 1021.2286
df$luchtdruk_k13_k14[(df$week_index == 131)] <- 1020.0714
df$luchtdruk_k13_k14sq = df$luchtdruk_k13_k14^2  # To be added when using 3rd degree polynomials
df$luchtdruk_k13_k14cb = df$luchtdruk_k13_k14^3  # To be added when using 3rd degree polynomials
sX=c("windnoord","windnoordsq","windnoordcb","windwest","windwestsq","windwestcb","windsnelheid","windsnelheidsq","windsnelheidcb","temp","tempsq","tempcb","golfhoogte","golfhoogtesq","golfhoogtecb", "luchtdruk_k13_k14","luchtdruk_k13_k14sq","luchtdruk_k13_k14cb","Diesel","Dieselsq","Dieselcb") # To be added when using 3rd degree polynomials

# Option 2: Impute average value
#df$luchtdruk_k13_k14[is.na(df$luchtdruk_k13_k14)] <-1014.384   # replace missing values on 4 sequencial weeks by the average of the first preceding 1007.7 and following 1021.067  "luchtdruk_k13_k14" entries

# Option 3: Ignore these entries

###############



sTreat <- "treat"
streatX = c(sTreat,sX)


### EFFECTS ON SOLE SHARES  ####


streatX = c(sTreat,sX)
panel_share5 <- plm(as.formula(paste("perc_sol5 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share4 <- plm(as.formula(paste("perc_sol4 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share3 <- plm(as.formula(paste("perc_sol3 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share2 <- plm(as.formula(paste("perc_sol2 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_share1 <- plm(as.formula(paste("perc_sol1 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
coef_test(panel_share5, vcov = "CR1", cluster = "individual", test = "naive-t")
coef_test(panel_share4, vcov = "CR1", cluster = "individual", test = "naive-t")
coef_test(panel_share3, vcov = "CR1", cluster = "individual", test = "naive-t")
coef_test(panel_share2, vcov = "CR1", cluster = "individual", test = "naive-t")
coef_test(panel_share1, vcov = "CR1", cluster = "individual", test = "naive-t")




### EFFECTS ON SOLE WEIGHT (kg)  ####

streatX = c(sTreat,sX)
panel_land5 <- plm(as.formula(paste("verkoop_sol_levend_5 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_land4 <- plm(as.formula(paste("verkoop_sol_levend_4 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_land3 <- plm(as.formula(paste("verkoop_sol_levend_3 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_land2 <- plm(as.formula(paste("verkoop_sol_levend_2 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_land1 <- plm(as.formula(paste("verkoop_sol_levend_1 ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
panel_land_tot <- plm(as.formula(paste("kg_totaal ~ ", paste(streatX, collapse= "+"))), data = df,index = c("vaartuig"), model = "within")
coef_test(panel_land5, vcov = "CR1", cluster = "individual", test = "naive-t")
coef_test(panel_land4, vcov = "CR1", cluster = "individual", test = "naive-t")
coef_test(panel_land3, vcov = "CR1", cluster = "individual", test = "naive-t")
coef_test(panel_land2, vcov = "CR1", cluster = "individual", test = "naive-t")
coef_test(panel_land1, vcov = "CR1", cluster = "individual", test = "naive-t")
coef_test(panel_land_tot, vcov = "CR1", cluster = "individual", test = "naive-t")



### EFFECTS ON SOLE WEIGHT - poisson model ####


## When using 3rd degree polynomials ##
panel_land5 = fepois(verkoop_sol_levend_5 ~ treat +  windnoord + windnoordsq + windnoordcb  +  windwest + windwestsq + windwestcb +  windsnelheid + windsnelheidsq + windsnelheidcb +  temp  + tempsq + tempcb  + golfhoogte + golfhoogtesq + golfhoogtecb +    luchtdruk_k13_k14 + luchtdruk_k13_k14sq + luchtdruk_k13_k14cb + Diesel + Dieselsq + Dieselcb  | vaartuig, df)
panel_land4 = fepois(verkoop_sol_levend_4 ~ treat + windnoord + windnoordsq + windnoordcb +  windwest + windwestsq + windwestcb +  windsnelheid + windsnelheidsq + windsnelheidcb +  temp  + tempsq + tempcb  + golfhoogte + golfhoogtesq + golfhoogtecb +    luchtdruk_k13_k14 + luchtdruk_k13_k14sq + luchtdruk_k13_k14cb + Diesel + Dieselsq + Dieselcb | vaartuig, df)
panel_land3 = fepois(verkoop_sol_levend_3 ~ treat + windnoord + windnoordsq + windnoordcb  +  windwest + windwestsq + windwestcb +  windsnelheid + windsnelheidsq + windsnelheidcb +  temp  + tempsq + tempcb  + golfhoogte + golfhoogtesq + golfhoogtecb +  luchtdruk_k13_k14 + luchtdruk_k13_k14sq + luchtdruk_k13_k14cb + Diesel + Dieselsq + Dieselcb | vaartuig, df)
panel_land2 = fepois(verkoop_sol_levend_2 ~ treat + windnoord + windnoordsq + windnoordcb  +  windwest + windwestsq + windwestcb +  windsnelheid + windsnelheidsq + windsnelheidcb +  temp  + tempsq + tempcb  + golfhoogte + golfhoogtesq + golfhoogtecb +  luchtdruk_k13_k14 + luchtdruk_k13_k14sq + luchtdruk_k13_k14cb + Diesel + Dieselsq + Dieselcb | vaartuig, df)
panel_land1 = fepois(verkoop_sol_levend_1 ~ treat + windnoord + windnoordsq + windnoordcb  +  windwest + windwestsq + windwestcb +  windsnelheid + windsnelheidsq + windsnelheidcb +  temp  + tempsq + tempcb  + golfhoogte + golfhoogtesq + golfhoogtecb +   luchtdruk_k13_k14 + luchtdruk_k13_k14sq + luchtdruk_k13_k14cb + Diesel + Dieselsq + Dieselcb | vaartuig, df)
panel_land_tot = fepois(kg_totaal ~ treat + windnoord + windnoordsq + windnoordcb  +  windwest + windwestsq + windwestcb +  windsnelheid + windsnelheidsq + windsnelheidcb +  temp  + tempsq + tempcb  + golfhoogte + golfhoogtesq + golfhoogtecb +   luchtdruk_k13_k14 + luchtdruk_k13_k14sq + luchtdruk_k13_k14cb + Diesel + Dieselsq + Dieselcb | vaartuig, df)
print(panel_land5)
print(panel_land4) 
print(panel_land3) 
print(panel_land2) 
print(panel_land1)
print(panel_land_tot) 







