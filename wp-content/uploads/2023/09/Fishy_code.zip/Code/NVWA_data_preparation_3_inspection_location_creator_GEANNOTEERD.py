# -*- coding: utf-8 -*-
"""
Created on Tue Oct  1 15:27:40 2019

@author: jeanv
"""

#This file loads the data on the ships (all VMS points), Barend Biesheuvel, Seefalke and Vestkysten and the distances between fishing vessels and these ships.
#Then, this file identifies for each VMS data point from which EEZ it is transmitted


import numpy as np
import pandas as pd
#sys.path.append('c:\\users\\jeanv\\appdata\\roaming\\python\\python37\\site-packages')
import mpu
import time
tstart = time.time()

# Defining the location where to write the created files to
folder = ".\\"

# Defining the locations of the files for the seefalke and meerkatze
meerkatze2017 = folder + 'Data Inspectieschepen\\' + "Meerkatze-2017.tsv"
meerkatze2018 = folder + 'Data Inspectieschepen\\' + "Meerkatze-2018.tsv"
seefalke2017  = folder + 'Data Inspectieschepen\\' + "Seefalke-2017.tsv"
seefalke2018  = folder + 'Data Inspectieschepen\\' + "Seefalke-2018.tsv"

# Defining the file with absence of the BB
verlof_bb  = folder + 'Data Inspectieschepen\\' + 'verlof_bb.csv'

# Defining a function taht translates strings to months
def month_to_num(string):
    m = {'jan':1,'feb':2,'mar':3,'apr':4,'may':5,'jun':6,'jul':7,'aug':8,'sep':9,'oct':10,'nov':11,'dec':12}
    s = string.strip()[:3].lower()
    try:
        out = m[s]
        return out
    except:
        raise ValueError('Not a month')

def f(x,i,j):
    if x[i] < 0:
        return - x[j]
    else:
        return x[j]
    
    


#%% Loading Data of German Ships
df_meerk1 = pd.read_csv(meerkatze2017, encoding='iso-8859-1', sep="\t")
df_meerk2 = pd.read_csv(meerkatze2018, encoding='iso-8859-1', sep="\t")
df_seef1 = pd.read_csv(seefalke2017, encoding='iso-8859-1', sep="\t")
df_seef2 = pd.read_csv(seefalke2018, encoding='iso-8859-1', sep="\t")
del meerkatze2017,meerkatze2018,seefalke2017,seefalke2018

#Translating the location of the 2018 file of the meerkatze, and the files of the seefalke because they where not all 4 consistent.
df_meerk2['Lat.'] = df_meerk2["Lat."].replace(r',',r'.',regex=True)
df_meerk2['Lon.'] = df_meerk2["Lon."].replace(r',',r'.',regex=True)
df_seef1['Lat.'] = df_seef1["Lat."].replace(r',',r'.',regex=True)
df_seef1['Lon.'] = df_seef1["Lon."].replace(r',',r'.',regex=True)
df_seef2['Lat.'] = df_seef2["Lat."].replace(r',',r'.',regex=True)
df_seef2['Lon.'] = df_seef2["Lon."].replace(r',',r'.',regex=True)

#concatenating the meerkatze data to one long file instead of one for 2017 and one for 2018.
df_meerkatze = pd.concat([df_meerk1,df_meerk2])
del df_meerk1, df_meerk2

#dropping superfluous columns
drop_columns = ["Ident","local time",'Square','EEZ','Int.zone',"Nation","Internal Ident","Radio","Name","Avg.Course","Avg.Speed","Vessel type","Status","Delta time","Created UTC time","Boxes","Lat..1","Lon..1","Provider","IMO number","MMSI","Row","Unnamed: 28"]
df_meerkatze.drop(columns=drop_columns,inplace=True)

#Changing the time to a timestamp so python can work with it
df_meerkatze['UTC time']   = pd.to_datetime(df_meerkatze['UTC time'])

#Copying the column of UTC time so that we can review the difference in times between merged rows after using merge_asof later
df_meerkatze['UTC time MK'] = pd.to_datetime(df_meerkatze['UTC time'])

 #sort because it's necessary for the pd.merge_asof I will use later
df_meerkatze.sort_values(by=['UTC time'],inplace=True)

#change latitude and longitude to numeric values so I can calculate distances with them later
df_meerkatze['Lon.'] = pd.to_numeric(df_meerkatze['Lon.'],errors='coerce')
df_meerkatze['Lat.'] = pd.to_numeric(df_meerkatze['Lat.'],errors='coerce')

#changing columns in such a way that it will later be recognizable that they represent the Meerkatze
df_meerkatze.rename(index=str, columns={"Course": "Course MK", "Speed": "Speed MK","Lat.":"Lat. MK","Lon.":"Lon. MK","Harbour": "Harbour MK"},inplace=True)

#repeating the same procedure we did for the Meerkatze nog for the Seefalke.
df_seefalke  = pd.concat([df_seef1,df_seef2])
del df_seef1, df_seef2
df_seefalke.drop(columns=drop_columns,inplace=True)
df_seefalke['UTC time']   = pd.to_datetime(df_seefalke['UTC time'])
df_seefalke['UTC time SF'] = pd.to_datetime(df_seefalke['UTC time'])
df_seefalke.sort_values(by=['UTC time'],inplace=True) #sort because it's necessary for the pd.merge_asof I will use later
df_seefalke['Lon.'] = pd.to_numeric(df_seefalke['Lon.'],errors='coerce')
df_seefalke['Lat.'] = pd.to_numeric(df_seefalke['Lat.'],errors='coerce')
df_seefalke.rename(index=str, columns={"Course": "Course SF", "Speed": "Speed SF","Lat.":"Lat. SF","Lon.":"Lon. SF","Harbour": "Harbour SF"},inplace=True)
del drop_columns


#writing to csv
df_seefalke.to_csv(folder+'Output\\'+'locatie_seefalke.csv',index=False)
df_meerkatze.to_csv(folder+'Output\\'+'locatie_meerkatze.csv',index=False)


#%% Loading Vestkysten Locations. Effectively we do exactly the same for Vestkysten as for Seefalke and Meerkatze

vestkysten    = folder+'Data Inspectieschepen\\' + "Vestkysten_2017_2018.tsv"
df_vestkysten  = pd.read_csv(vestkysten, encoding='iso-8859-1', sep="\t")
drop_columns = ["Nation","Ident",'Internal Ident','Radio','Name',"Vessel type","Status","Delta time","Name","Avg.Course","Avg.Speed","Created UTC time","Boxes","Lat..1","Lon..1","Provider","IMO number","MMSI","Row","Unnamed: 28", "Square", "EEZ", "Int.zone"]
df_vestkysten.drop(columns=drop_columns,inplace=True)    
df_vestkysten['UTC time']   = pd.to_datetime(df_vestkysten['UTC time'])
df_vestkysten['UTC time VK'] = pd.to_datetime(df_vestkysten['UTC time'])
df_vestkysten.sort_values(by=['UTC time'],inplace=True) #sort because it's necessary for the pd.merge_asof I will use later
df_vestkysten['Lat.'] = df_vestkysten["Lat."].replace(r',',r'.',regex=True)
df_vestkysten['Lon.'] = df_vestkysten["Lon."].replace(r',',r'.',regex=True)
df_vestkysten['Lon.'] = pd.to_numeric(df_vestkysten['Lon.'],errors='coerce')
df_vestkysten['Lat.'] = pd.to_numeric(df_vestkysten['Lat.'],errors='coerce')
df_vestkysten.rename(index=str, columns={"Course": "Course VK", "Speed": "Speed VK","Lat.":"Lat. VK","Lon.":"Lon. VK","Harbour": "Harbour VK"},inplace=True)

#writing to csv
df_vestkysten.to_csv(folder+'Output\\'+'locatie_vestkysten.csv',index=False)


#%% Loading BB Locations.

#Loading the Barend Biesheuvel locatio nfiles
df_bb = pd.DataFrame()
df_bb1 = pd.read_excel(folder+'Data Inspectieschepen\\'+'Vaartuig_BB_2017.xlsx')
df_bb2 = pd.read_excel(folder+'Data Inspectieschepen\\'+'Vaartuig_BB_2018.xlsx')

# Precleaning and Preparing. Turning the coordinates into a format that we can work with.
df_bb1.replace(r',',r'.',regex=True,inplace = True)
df_bb1.iloc[:,2:6] = df_bb1.iloc[:,2:6].astype(float)

#Converting coordinates in BB data of 2017 so everything is connectable (notation was inconsistent beteen 2017 and 2018). Need to convert latitude and longitude systems.
df_bb1['Lat_degrees'] = df_bb1['Lat..1'].str.findall('(\d{2})').str[0].astype(float)
df_bb1['Lat_min_conv'] = df_bb1['Lat..1'].str.findall('(\d{2}.\d{3})').str[0].astype(float)/60
df_bb1['Lat.'] = df_bb1['Lat_degrees'] + df_bb1['Lat_min_conv']
df_bb1.drop(['Lat_min_conv','Lat_degrees'],axis=1,inplace=True)

df_bb1['Lon_degrees'] = df_bb1['Lon..1'].str.findall('(\d{1})').str[0].astype(float) #but can be negative too
df_bb1['Lon_min_conv'] = df_bb1['Lon..1'].str.findall('(\d{2}.\d{3})').str[0].astype(float)/60
df_bb1['Lon_decimal_degrees'] = df_bb1['Lon_degrees'] + df_bb1['Lon_min_conv']
df_bb1.drop(['Lon_min_conv','Lon_degrees'],axis=1,inplace=True)
df_bb1['Lon.'] = df_bb1.apply(lambda x: f(x,5,8),axis = 1)
df_bb1.drop(['Lon_decimal_degrees'],axis=1,inplace=True)

# Precleaning and Preparing
df_bb2.replace(r',',r'.',regex=True,inplace = True)
df_bb2.iloc[:,2:6] = df_bb2.iloc[:,2:6].astype(float)

#Concatenating two files
df_bb = pd.concat([df_bb1,df_bb2])
del df_bb2, df_bb1

#Change time to timestamp so that python can work with it
df_bb['local time'] = pd.to_datetime(df_bb['local time'])
df_bb['UTC time']   = pd.to_datetime(df_bb['UTC time'])

#drop superfluous columns
df_bb.drop(['Lat..1','Lon..1'],axis=1,inplace=True)

#sort for merge_asof later
df_bb.sort_values(by=['UTC time'],inplace=True)

#copy column so that it is recognizable which time was used for the BB later.  
df_bb['UTC time BB'] = df_bb['UTC time']

#Rename columns to later identify which correspond to the BB
df_bb.rename(index=str, columns={"Course": "Course BB", "Speed": "Speed BB","Lat.":"Lat. BB","Lon.":"Lon. BB"},inplace=True)

#writing to csv
df_bb.to_csv(folder+'Output\\'+'locatiesbb.csv',index=False)


#%% Loading Fishermen Locations
df_ships = pd.read_csv(folder+'Output\\'+'locations_grid.csv')
### df_ships = pd.read_csv(folder+'gekoppelde_VMS_bestanden_wind.csv') ### no weather # Only if weather information used at this stage (which is not)

#Converting the time to a timestamp
df_ships['UTC time'] = pd.to_datetime(df_ships['UTC time'])

#sort, needed for merge_asof later
df_ships.sort_values(by=['UTC time'],inplace=True)

#rename columns in order to be sure which columns belong to the fishing vessel later
df_ships.rename(index=str, columns={"local time": "local time FV" , "Course": "Course FV", "Speed": "Speed FV","Lat.":"Lat. FV","Lon.":"Lon. FV","Harbour": "Harbour SF"},inplace=True)

#Drop observations where the location is missing
df_ships = df_ships.dropna(subset = ['Lat. FV','Lon. FV'])

#Defining a maximum time difference between the vms report of the fishing vessel and the inspection ship. If at a given time the inspection ship has not reported it's location 
#for more tha 6 hour we assume it is in the harbour
maxtimediff = pd.Timedelta('6 hours')

#Seeing where the Meerkatze is at each point
ships_mk = pd.merge_asof(df_ships,df_meerkatze,on = 'UTC time',direction = 'nearest')

#Calculating the difference in time between ship time and closest report of the Meerkatze
ships_mk['timediff_meerkatze_ship'] = ships_mk.apply(lambda x: x['UTC time'] - x['UTC time MK'] ,axis=1)

#Setting the location to the most frequented harbour of the Meerkatze when the timediff is larger than 6 hours
ships_mk['Lat. MK'] = ships_mk.apply(lambda x: x['Lat. MK'] if (abs(x['timediff_meerkatze_ship']) < maxtimediff) else 53.861,axis=1) 
ships_mk['Lon. MK'] = ships_mk.apply(lambda x: x['Lon. MK'] if (abs(x['timediff_meerkatze_ship']) < maxtimediff) else 8.711 ,axis=1)

#Calculating the distance between the reported location of the fishing vessel and that of the Meerkatze 
ships_mk['distance_meerkatze'] = ships_mk.apply(lambda x: mpu.haversine_distance((x['Lat. FV'],x['Lon. FV']),(x['Lat. MK'],x['Lon. MK'])),axis=1)

print("Calculated distance from Meerkatze, total time spend is: ",time.time() - tstart)

#repeating the procedure for the seefalke.
ships_mk_sf = pd.merge_asof(ships_mk,df_seefalke,on = 'UTC time',direction = 'nearest')
del ships_mk
ships_mk_sf['timediff_seefalke_ship'] = ships_mk_sf.apply(lambda x: x['UTC time'] - x['UTC time SF'] ,axis=1)
ships_mk_sf['Lat. SF'] = ships_mk_sf.apply(lambda x: x['Lat. SF'] if (abs(x['timediff_seefalke_ship']) < maxtimediff) else 53.862,axis=1) 
ships_mk_sf['Lon. SF'] = ships_mk_sf.apply(lambda x: x['Lon. SF'] if (abs(x['timediff_seefalke_ship']) < maxtimediff) else 8.711 ,axis=1) 
ships_mk_sf['distance_seefalke']      = ships_mk_sf.apply(lambda x: mpu.haversine_distance((x['Lat. FV'],x['Lon. FV']),(x['Lat. SF'],x['Lon. SF'])),axis=1)
print("Calculated distance from Seefalke, total time spend is: ",time.time() - tstart)

#Repeating the procedure for the Barend Biesheuvel
ships_mk_sf_bb = pd.merge_asof(ships_mk_sf,df_bb,on = 'UTC time',direction = 'nearest')
ships_mk_sf_bb['timediff_bb_ship'] = ships_mk_sf_bb.apply(lambda x: x['UTC time'] - x['UTC time BB'] ,axis=1)
ships_mk_sf_bb['Lat. BB'] = ships_mk_sf_bb.apply(lambda x: x['Lat. BB'] if (abs(x['timediff_bb_ship']) < maxtimediff) else 52.1007 ,axis=1) 
ships_mk_sf_bb['Lon. BB'] = ships_mk_sf_bb.apply(lambda x: x['Lon. BB'] if (abs(x['timediff_bb_ship']) < maxtimediff) else 4.268 ,axis=1) 
ships_mk_sf_bb['distance_bb'] = ships_mk_sf_bb.apply(lambda x: mpu.haversine_distance((x['Lat. FV'],x['Lon. FV']),(x['Lat. BB'],x['Lon. BB'])),axis=1)


#MAKING DISTANCE LARGER THAN 60 WHEN BB IS IN THE HARBOUR SO THAT TREATMENT IS ZERO WHEN VESSEL IS IN HARBOUR
ships_mk_sf_bb['distance_bb'] = ships_mk_sf_bb.apply(lambda x: x['distance_bb'] if ((x['Lat. BB'] > 52.11 or x['Lat. BB'] < 52.09) or (x['Lon. BB'] >4.278 or x['Lon. BB'] < 4.258)) else 250,axis=1)



print("Calculated distance from Barend Biesheuvel, total time spend is: ",time.time() - tstart)

#repeating the procedure for the Vestkysten
ships_mk_sf_bb_vk = pd.merge_asof(ships_mk_sf_bb,df_vestkysten,on = 'UTC time',direction = 'nearest')
ships_mk_sf_bb_vk['timediff_vk_ship'] = ships_mk_sf_bb_vk.apply(lambda x: x['UTC time'] - x['UTC time VK'] ,axis=1)
ships_mk_sf_bb_vk['Lat. VK'] = ships_mk_sf_bb_vk.apply(lambda x: x['Lat. VK'] if (abs(x['timediff_vk_ship']) < maxtimediff) else 56.713 ,axis=1) 
ships_mk_sf_bb_vk['Lon. VK'] = ships_mk_sf_bb_vk.apply(lambda x: x['Lon. VK'] if (abs(x['timediff_vk_ship']) < maxtimediff) else 8.209 ,axis=1) 
ships_mk_sf_bb_vk['distance_vk'] = ships_mk_sf_bb_vk.apply(lambda x: mpu.haversine_distance((x['Lat. FV'],x['Lon. FV']),(x['Lat. VK'],x['Lon. VK'])),axis=1)

print("Calculated distance from Vestkysten, total time spend is: ",time.time() - tstart)

df_locations = ships_mk_sf_bb_vk
df_locations['local time FV']   = pd.to_datetime(df_locations['local time FV'])



#%% Now for each VMS data point we will exame in which country's EEZ the data point lies
df_locations.sort_values(by=['Lat. FV'],inplace=True) 

#Loading the files with the borders. These are created with border_creator.py
#Then the borders are sorted on longitude for all borders except the english border (because for the english border we see if a location is east or west of it instead of north or south)
df_border_eng = pd.read_csv(folder+'Data Border\\'+'coordinates_english_border.csv') 
df_border_nl_be = pd.read_csv(folder+'Data Border\\'+'coordinates_dutch_belgian_border.csv')
df_border_nl_be.sort_values(by=['lon'],inplace=True) 
df_border_nl_ge = pd.read_csv(folder+'Data Border\\'+'coordinates_dutch_german_border.csv')
df_border_nl_ge.sort_values(by=['lon'],inplace=True)
df_border_da_ge = pd.read_csv(folder+'Data Border\\'+'coordinates_danish_german_border.csv')
df_border_da_ge.sort_values(by=['lon'],inplace=True)
df_border_da_nw = pd.read_csv(folder+'Data Border\\'+'coordinates_danish_norwegian_border.csv')
df_border_da_nw.sort_values(by=['lon'],inplace=True)


#Merging the locations of fishing vessels with the english border based on the closest latitude. Then, for that latitude we will look if the ship is east or west of the border.
df_locations_eng = pd.merge_asof(df_locations,df_border_eng,left_on = 'Lat. FV',right_on = 'lat',direction = 'nearest')
df_locations_eng.rename(index=str, columns={"lat":"lat_border_eng","lon":"lon_border_eng"},inplace=True)
df_locations_eng.sort_values(by=['Lon. FV'],inplace=True)

#Then for the order borders we merge the locations of the fishing vessels with those of the borders based on closest longitude. Then we will see if the ships are north or south of these borders.
df_locations_eng_nl_be = pd.merge_asof(df_locations_eng,df_border_nl_be,left_on = 'Lon. FV',right_on = 'lon',direction = 'nearest')
df_locations_eng_nl_be.rename(index=str, columns={"lat":"lat_border_nl_be","lon":"lon_border_nl_be"},inplace=True)

df_locations_eng_nl_be_ge = pd.merge_asof(df_locations_eng_nl_be,df_border_nl_ge,left_on = 'Lon. FV',right_on = 'lon',direction = 'nearest')
df_locations_eng_nl_be_ge.rename(index=str, columns={"lat":"lat_border_nl_ge","lon":"lon_border_nl_ge"},inplace=True)

df_locations_eng_nl_be_ge_da = pd.merge_asof(df_locations_eng_nl_be_ge,df_border_da_ge,left_on = 'Lon. FV',right_on = 'lon',direction = 'nearest')
df_locations_eng_nl_be_ge_da.rename(index=str, columns={"lat":"lat_border_ge_da","lon":"lon_border_ge_da"},inplace=True)

df_locations_eng_nl_be_ge_da_nw = pd.merge_asof(df_locations_eng_nl_be_ge_da,df_border_da_nw,left_on = 'Lon. FV',right_on = 'lon',direction = 'nearest')
df_locations_eng_nl_be_ge_da_nw.rename(index=str, columns={"lat":"lat_border_da_nw","lon":"lon_border_da_nw"},inplace=True)

#Outside an area fishing vessels will not be in our sample anymore as they are fishing too far away, therefore we do not need to look at the EEZ for those vms points
min_lat = 51
max_lat = 70
min_lon = -3
max_lon = 10


df_locations_border = df_locations_eng_nl_be_ge_da_nw.copy()

#Creating variables for different countries
df_locations_border['faraway']     = 0
df_locations_border['england']     = 0
df_locations_border['belgium']     = 0
df_locations_border['netherlands'] = 0
df_locations_border['germany']     = 0
df_locations_border['denmark']     = 0
df_locations_border['norway']      = 0
df_locations_border['country']     = np.nan 


#VMS is in faraway it its outside the defined square
df_locations_border['faraway'] = np.where(((df_locations_border['Lat. FV']< min_lat)|(df_locations_border['Lat. FV'] > max_lat )|(df_locations_border['Lon. FV']< min_lon)|(df_locations_border['Lon. FV'] > max_lon )), 1,0)

#VMS is in england if its not in faraway and west of the english border
df_locations_border['england'] = np.where(((df_locations_border['faraway']!=1)&(df_locations_border['Lon. FV'] < df_locations_border['lon_border_eng'])), 1,0)

#vms is in belgium if it's not in faraway or england and is south of the dutch belgian border
df_locations_border['belgium'] = np.where(((df_locations_border['faraway']!=1)&(df_locations_border['england']!=1)&(df_locations_border['Lat. FV'] < df_locations_border['lat_border_nl_be'])), 1,0)
#similar to belgium
df_locations_border['netherlands'] = np.where(((df_locations_border['faraway']!=1)&(df_locations_border['england']!=1)&(df_locations_border['belgium']!=1)&(df_locations_border['Lat. FV'] < df_locations_border['lat_border_nl_ge'])), 1,0)
#similar to belgium
df_locations_border['germany'] = np.where(((df_locations_border['faraway']!=1)&(df_locations_border['england']!=1)&(df_locations_border['belgium']!=1)&(df_locations_border['netherlands']!=1)&(df_locations_border['Lat. FV'] < df_locations_border['lat_border_ge_da'])), 1,0)
#similar to belgium
df_locations_border['denmark'] = np.where(((df_locations_border['faraway']!=1)&(df_locations_border['england']!=1)&(df_locations_border['belgium']!=1)&(df_locations_border['netherlands']!=1)&(df_locations_border['germany']!=1)&(df_locations_border['Lat. FV'] < df_locations_border['lat_border_da_nw'])), 1,0)
#similar to belgium
df_locations_border['norway'] = np.where(((df_locations_border['faraway']!=1)&(df_locations_border['england']!=1)&(df_locations_border['belgium']!=1)&(df_locations_border['netherlands']!=1)&(df_locations_border['germany']!=1)&(df_locations_border['denmark']!=1)), 1,0)

#The varaible country is the name of the country it is in
df_locations_border['country'] = np.where(df_locations_border['faraway']==1, 'faraway',df_locations_border['country'])
df_locations_border['country'] = np.where(df_locations_border['england']==1, 'england',df_locations_border['country'])
df_locations_border['country'] = np.where(df_locations_border['belgium']==1, 'belgium',df_locations_border['country'])
df_locations_border['country'] = np.where(df_locations_border['netherlands']==1, 'netherlands',df_locations_border['country'])
df_locations_border['country'] = np.where(df_locations_border['germany']==1, 'germany',df_locations_border['country'])
df_locations_border['country'] = np.where(df_locations_border['denmark']==1, 'denmark',df_locations_border['country'])
df_locations_border['country'] = np.where(df_locations_border['norway']==1, 'norway',df_locations_border['country'])

#dropping superfluous columns
df_locations_border.drop(columns=['lat_border_eng','lon_border_eng','lat_border_nl_be','lon_border_nl_be','lat_border_nl_ge','lon_border_nl_ge','lat_border_ge_da','lon_border_ge_da', 'lat_border_da_nw','lon_border_da_nw'],inplace=True)

#writing to csv
df_locations_border.to_csv(folder+'Output\\'+'vms_combined_bb_seefalke_meerkatze_vestkysten.csv',index=False)
