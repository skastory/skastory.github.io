Stephen Kastoryano and Bas van der Klaauw, "Dynamic Evaluation of Job Search Assistance", 
Journal of Applied Econometrics, forthcoming

The data used in the article are from the Participation Fund in the 
Netherlands (Participatiefonds https://www.vfpf.nl/). This fund is 
responsible for collecting premiums, and paying unemployment insurance benefits.


The data are in one file, 'jobtraining.csv', with 3064 rows and 12 columns

## Variables in the dataset ##
Variables in the dataset have no column names, but have the following correspondance:

Outcome and treatment variables:
data[][4] -> time until reemployment 	  
data[][5] -> indicator ==1 if individual exited employment
data[][6] -> time until training 
data[][7] -> indicator ==1 if individual entered training	

Covariates:
data[][0] -> gender
data[][2] -> age at time of layoff
data[][1] -> people considered low skilled in 2005
data[][3] -> dailywages in previous employment position (measured in euro)
data[][9] -> dummy for people older than 50 at layoff	  
data[][8] -> total duration UI benefits
data[][10] -> month of layoff
data[][11] -> year of layoff


## Program Execution ##
Estimation was executed using Ox programming language.
Additional descriptions on how to run code are provided in the code files:

PMatchingLogit.ox: Table 2 (top panel), Table 3 (top panel)
ATETScontin.ox: Table 2 (bottom panel), Table 3 (bottom panel), Table D1 (Baseline), Table C1, Table D2
ATETScontinAangepast.ox: Table 3 (bottom panel: 'limited set of covariates')
PMatchingMethods.ox: Table 4
ATETScontinLock.ox: Table D1: right panel
BalanceTable.ox: Table 1 (uses as input 'BalancingData.csv')

